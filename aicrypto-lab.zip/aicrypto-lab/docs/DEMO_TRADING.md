# Kalshi demo trading (Milestones B + D foundation)

**Demo only.** Orders go to `https://demo-api.kalshi.co` with Kalshi's simulated funds. The
host is hard-coded in `aicrypto/kalshi/demo_exec/exchange.py`; there is no setting, environment
variable or button that can point it anywhere else, and non-demo credentials are refused.

## First manual demo trade
1. Open AI Crypto Lab → **Demo Trading** → enter a **Risk budget** (e.g. 700) → Save.
   Limits: 1% max loss per position, 5% total open risk, 3% daily loss stop — of this budget.
2. Open a market (Markets → pick one marked MANUAL DEMO or AUTO-ELIGIBLE).
3. In the order ticket choose **Buy YES / Buy NO**, a limit price and contracts →
   **Review Demo Order** → check the dialog → **Confirm Demo Trade**.
4. Watch it on **Demo Trading**: open orders (with **Cancel**), positions, fills, history,
   and the activity log. **Emergency stop** cancels every open demo order and turns
   automation off; it stays on until you reset it.

Before sending, the backend re-checks: market eligibility and status, a valid fresh order book,
price range/tick, whole contracts (≤ 500), fat-finger (≤ 10¢ above the best offer), demo
balance, the risk limits and the emergency stop. Each order gets a unique client order id. If
the network fails while sending, the order is marked *checking* and the app looks it up on the
exchange before doing anything else; it is never re-sent automatically.

## Automatic demo trading
The engine supports arm / start / pause / stop / emergency stop, max positions, max orders per
minute, one working order per market, strategy version tracking and a full activity log.
A strategy can run only when **all** are true:
1. its validation report passes for its exact code (`experiments/kalshi_validation/<name>@<version>.json`,
   produced by the replay/backtest pipeline — Milestone C),
2. you approve it in Ubuntu: `aicrypto demo approve <name> <version> --i-approve`,
3. you type `ARM DEMO` in the app this session (restarting always disarms).

`aicrypto demo strategies` lists strategies and why each can or can't run. The bundled
`example_spread_quoter` is an example only and is not validated, so it cannot be armed.

## Portfolio, cash out and transactions (2026-11-09)
- Prices show the Kalshi way: cents per contract and % chance.
- **Portfolio → Positions** (also on the Dashboard): every active position with average price,
  current price, value and profit/loss, and a **Cash out** button. Cash out sells the whole
  position immediately (immediate-or-cancel, reduce-only) at the best bids, never lower than
  10¢ under the best bid; anything unsold stays open. It works while the emergency stop is on.
- **Portfolio → Transactions**: closed positions (cashed out or settled) with entry, exit,
  fees and profit/loss, rebuilt from the exchange's fills.
- The risk budget and emergency-stop reset are in **Settings**.

## Bot practice mode and compounding size (2026-11-09, owner decision)

- **Practice mode (default on):** when the bot is ON it places real demo orders for rules the
  lab is still testing, as well as proven ones. A rule with 10 or more settled results and no
  profit is skipped. One order per market: the best-supported rule that fired.
- **Size:** each trade stakes a share of the demo account value (default 2%, adjustable
  0.5–10% on the Bot & Strategies page), so size grows and shrinks with the balance. Never
  more than is offered at the price, than cash can pay for, or than an optional spending
  limit allows. Up to 8 markets at once.
- Practice trades are training. They are not evidence that a rule is profitable; only the
  lab's promotion gates say that. Nothing here adds any production capability.

## How the bot learns, and real-exchange prices (2026-11-10)

- The lab paper-trades every rule twice: at **demo** prices (`lab.sqlite`) and at the **real exchange's
  public prices** (`lab_real.sqlite`, read-only, no account, no orders). The Strategies table shows both.
- In practice mode the bot gives each market to the rule with the strongest record (its confidence t: the
  real-price record once a rule has 20+ results there, otherwise its demo record). It skips a rule whose
  demo record (10+ results) or real-price record (20+ results) is not profitable. Rules keep paper-trading,
  so a skipped rule returns if its record recovers. Thresholds are fixed; nothing is tuned on results.
- **Bot & Strategies → "Is the bot getting better?"**: win rate over the last 25 trades, total profit after
  fees, and a day-by-day table. A win counts only if the trade made money after fees.
