# Phase A final report: multi-timeframe discovery and recorder protection (2026-11-12)

Status: **Phase A complete.** All seven acceptance criteria set by the owner on 2026-11-12 pass (section 6).

Unchanged throughout:
- Production trading stays disabled.
- The demo bot was not changed, and it stayed off.
- No strategy was activated.
- The Freqtrade crypto risk setting is untouched at 2%.

## 1. What is available, by asset and duration

Source: `user_data/kalshi/timeframes/registry.json`, from the full discovery of 2026-11-12, about 01:05–03:06 ET.

**Open-market counts are a snapshot.** That run ended right before Kalshi's Thursday maintenance pause, when
hourly ladders are thinner. Earlier the same day BTC hourly had 636 open markets.

The 15-minute series always have one window open at a time.

| Asset | Duration | Series | Open markets | Mode | Data grade | Research status |
|---|---|---|---|---|---|---|
| BTC | 15m | KXBTC15M | 1 | tradeable | A | research-ready (execution-realistic) |
| BTC | 1h | KXBTC, KXBTCD | 260 | tradeable | B | research-ready (exploratory) |
| BTC | longer | KXBTCY | 28 | tradeable | D | discoverable, recorded since Phase B |
| ETH | 15m | KXETH15M | 1 | tradeable | A | research-ready (execution-realistic) |
| ETH | 1h | KXETH, KXETHD | 180 | tradeable | B | research-ready (exploratory) |
| ETH | longer | KXETHY | 18 | tradeable | D | discoverable, recorded since Phase B |
| SOL | 15m | KXSOL15M | 1 | tradeable | A | research-ready (execution-realistic) |
| SOL | 1h | KXSOLD, KXSOLE | 250 | tradeable | B | research-ready (exploratory) |
| SOL | longer | KXSOL26500, KXSOLD26 | 10 | tradeable | D | discoverable, recorded since Phase B |
| XRP | 15m | KXXRP15M | 1 | tradeable | A | research-ready (execution-realistic) |
| XRP | 1h | KXXRP, KXXRPD | 180 | tradeable | B | research-ready (exploratory) |
| XRP | longer | KXXRPY | 24 | tradeable | D | discoverable, recorded since Phase B |
| DOGE | 15m | KXDOGE15M | 1 | tradeable | A | research-ready (execution-realistic) |
| DOGE | 1h | KXDOGE, KXDOGED | (118 each) | not eligible | (B*) | recorded; see section 2 |
| DOGE | longer | KXDOGEY | 21 | tradeable | D | discoverable, recorded since Phase B |
| GOLD | 15m | KXGOLD15M | 1 | record-only | C | market-price-only research |
| GOLD | 1h | KXGOLDH | 126 | record-only | C | market-price-only research |
| GOLD | daily | KXGOLDD | 40 | record-only | C | market-price-only research |
| GOLD | weekly | KXGOLDW | 40 | record-only | D | recorded since Phase B |
| GOLD | monthly | KXGOLDMON | 40 | record-only | D | recorded since Phase B |
| GOLD | longer | KXGOLDDIRY | 24 | record-only | D | recorded since Phase B |
| SILVER | 15m | KXSILVER15M | 1 | record-only | C | market-price-only research |
| SILVER | 1h | KXSILVERH | 118 | record-only | C | market-price-only research |
| SILVER | daily | KXSILVERD | 40 | record-only | C | market-price-only research |
| SILVER | weekly | KXSILVERW | 40 | record-only | D | recorded since Phase B |
| SILVER | monthly | KXSILVERMON | 40 | record-only | D | recorded since Phase B |
| COPPER | 15m | KXCOPPER15M | 1 | record-only | C | market-price-only research |
| COPPER | daily | KXCOPPERD | 40 | record-only | C | market-price-only research |
| COPPER | weekly | KXCOPPERW | 40 | record-only | D | recorded since Phase B |
| COPPER | monthly | KXCOPPERMON | 40 | record-only | D | recorded since Phase B |
| WTI (oil) | 15m | KXWTI15M | 1 | record-only | C | market-price-only research |
| WTI (oil) | 1h | KXWTIH | 120 | record-only | C | market-price-only research |
| WTI (oil) | daily | KXWTI | 60 | record-only | C | market-price-only research |
| WTI (oil) | weekly | KXWTIW | 27 | record-only | D | recorded since Phase B |
| WTI (oil) | longer | KXWTIDIRY | 11 | record-only | D | recorded since Phase B |

**Grades**
- **A:** 1-second quotes, order-book depth and the settlement index recorded. Execution-realistic research.
- **B:** 1-minute quotes plus the settlement index. Probability models; fills are exploratory only.
- **C:** 1-minute quotes, but no validated settlement reference. Market-price-only research.
- **D:** not recorded at the time of discovery.

The registry regrades at its next run. The weekly, monthly and yearly series have been recorded since the
Phase B recorder change, so they will move from D to B or C as data accumulates.

**Tradeable vs record-only**
- **Crypto is tradeable** in the research sense: it has a validated settlement reference, the CF Benchmarks index.
- **Commodities are record-only.** Their settlement reference is the Pyth feed, which stays off by owner decision.
  Research on them can use Kalshi's own prices only.

**Daily crypto contracts** (the 5 pm ET close) are part of the hourly ladders (KXBTCD and others), so they appear
under 1h. A separate daily row exists only where Kalshi lists a separate daily series.

## 2. Missing, unsupported and excluded series

**Discovery coverage**
- 1,649 series listed across Crypto, Commodities and Financials (1,646 unique tickers).
- **Every one was checked, with complete market pagination. Lookup failures: 0.**
- The 48 series missed on 2026-11-11 were all retrieved. None remain unavailable.

**Listed but not eligible for automated research.** 75 series on the priority assets. They are listed rather than
hidden, with the reason Kalshi's terms fail the app's existing eligibility rules:

| Kind | Examples | Why not eligible |
|---|---|---|
| Event-style weekly and monthly crypto and metal ladders | KXBTCEVENT, KXETHEVENT, KXSOLEVENT, KXGOLDEVENT, KXSILVEREVENT, KXCOPPEREVENT | Rules template not recognised, so the settlement mapping can't be verified |
| Max/min and "hit by a date" contracts | KXBTCMAXY, KXBTCMINMON, KXBTCHITBY, KXWTIMAX | Path-dependent; the settlement isn't a single price at a single time |
| Comparison contracts | KXBTCVSGOLD, KXGOLDVSSILVER, KXINXVSBTC | Two underlyings; strike type not allowed |
| DOGE hourly | KXDOGE, KXDOGED | Strike type not allowed by the eligibility rules. Recorded anyway since 2026-11-11, so the data exists if the rule is ever widened (owner decision) |
| Name collisions | KXFSLR (First Solar, not Solana), KXCEOGS (Goldman Sachs, not gold) | Not the asset |

**Excluded from everything:** sports, politics, weather, entertainment and earnings markets. The category and tag
denial rules apply, and a test checks that they're never kept, even when the name matches a priority asset.

## 3. Rate limiting: what was built and what was measured

**Design**
- **One shared request budget.** One file-locked budget for all processes on this machine that read Kalshi's public
  market data: 6 requests/s, burst of 4.
- **Priorities.**
  - The recorder can use all of it.
  - The app's real-price lab leaves 1 request of headroom.
  - Background work (discovery, backfill) can only use what's left above 2.5 requests.
- **Background allowance.** Background work gets its own adaptive allowance, at most one request every ~3 s. Any
  rate-limit answer halves that allowance and pauses background work for about 30 s; it recovers slowly.
- **Shared back-off.** Every rate-limit answer starts a shared exponential cool-down with jitter. Each request
  retries with exponential back-off, jitter and Retry-After.

**Incidents, in order**

| When | Setup | Rate-limit answers | Recorder impact |
|---|---|---|---|
| 2026-11-11 | No shared budget; discovery alongside the recorder | ~240 recorder errors | Lost polls (the reason this work started) |
| 2026-11-11 | Shared budget, 8/s | 22 in 8 min | Reduced to 6/s: 3 in 5 min |
| 2026-11-11 | Full discovery, shared budget only | 612 in 37 min | 3 recorder errors |
| 2026-11-12 | + adaptive background, 1 request/s max | 73 in 70 min (69 hit the recorder's own requests) | 15-minute recorder 0 errors; hourly/daily **1 lost quote poll** (one series, one minute; it had only 1 retry then) |
| 2026-11-12 | **Final:** background capped at ~0.3 requests/s | Recorder alone: **0.10/min** (2 in 20 min). During a full 121-min discovery: **0.26/min** (31) | **0 recorder errors, 0 hourly/daily errors, 0 index gaps, 0 reconnects** |

**What the remaining rate limits mean**
- About 0.16 extra rate-limit answers per minute during a full discovery run. Each delayed one request by roughly
  0.5–2 s, and every one succeeded on retry.
- A full discovery is a rare job. Incremental runs skip unchanged series and finish in minutes.
- At the recorder's 15-minute polling rate of about 3 requests/s, 0.26 retries a minute affects about 0.15% of
  requests, and only by delaying them.

## 4. Recorder interruptions and data quality, 2026-11-11 to 2026-11-12

From `python -m aicrypto.timeframes quality --days 2`.

| Item | Measured |
|---|---|
| Recorder uptime | 100% of 19.3 h covered. No outage longer than 60 s |
| Recorder restarts | 9, all deliberate (code changes and measurements), each under 60 s. One more on 2026-11-12 03:26 ET for Phase B |
| App outage | ~10 min, 2026-11-11 22:18–22:27 ET. The startup safety check refused to start the app because a Freqtrade environment had been created inside the repo. Fixed by moving it to ~/aicrypto-ft-venv. The recorder kept its own index connection |
| Hourly/daily stream | Closed markets more than 1 h old with no settlement line: **0**. Settlements are re-read with a 6-hour look-back, so a failed settlement poll is recovered automatically |
| Settlement index (CF Benchmarks via the demo WebSocket) | 30 short gaps over 2 days. Each 2–10 s, across 10 indices, about 73 s in total. 32 reconnects, nearly all clean server closes (code 1000). Same rate with and without discovery running; this connection doesn't use the public request budget |
| Disk | ~165 MB/day, 1,019 GB free, no alerts. Nothing is deleted automatically |

**Kalshi maintenance:** at 03:30 ET on 2026-11-12, Kalshi reported `trading_active: false`, its weekly Thursday
maintenance. During it the 15-minute recorder correctly shows 0 live markets. This is not a recorder fault.

## 5. Tests and safety, after the final change

| Environment | Passed | Failed | Skipped |
|---|---|---|---|
| App (.venv) | 445 | 0 | 3: Freqtrade-only tests; Freqtrade isn't installed in this environment |
| Freqtrade (~/aicrypto-ft-venv, with pytest-asyncio) | 448 | 0 | 0 |

`aicrypto safety-check`: OK (paper-only: yes).

**Commits on branch kalshi-realism-research**

| Commit | What |
|---|---|
| 06c9fc0 | Registry and plan |
| 722917d | Shared budget and complete discovery |
| 3c4b209 | Adaptive background throttle |
| 2bade31 | Phase A complete, measured |

## 6. Acceptance criteria (owner, 2026-11-12)

| # | Criterion | Result |
|---|---|---|
| 1 | No unrecovered recorder request failures | **Pass**: 0 errors in either recorder during the final measured discovery |
| 2 | No missing market or settlement data attributable to background discovery | **Pass**: 0 failed polls, 0 closed markets without a settlement |
| 3 | No significant increase in feed gaps vs. a recorder-only baseline | **Pass**: 0 index gaps during discovery; gaps happen at the same low rate without it |
| 4 | Rate-limited requests back off and recover without overwhelming Kalshi | **Pass**: shared exponential cool-down with jitter; 0.26 rate-limit answers/min during a full run, all recovered |
| 5 | Background discovery never takes priority over the recorder | **Pass**: enforced by the shared budget's reserve and background cap; tested |
| 6 | All 1,649 series discoverable with complete pagination | **Pass**: 1,649 checked, 0 lookup failures, full cursor pagination; tested |
| 7 | All automated tests and safety checks pass | **Pass**: see section 5 |
