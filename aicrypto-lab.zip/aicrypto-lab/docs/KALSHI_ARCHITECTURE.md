# Kalshi Financial-Markets Research & Paper-Trading Engine — Phase 1: Audit and Architecture

**Status: Phase 3 complete (auth, guarded REST transport, schema verification, WebSocket client with reconnect/resubscribe/seq-resync, order books, discovery, read-only stream session). Verified offline against mocks only; the demo-environment connection tests are scripted for WSL and not yet run.**
**Scope: paper trading only. No real-money order execution will be implemented.**

This document records (A) the audit of the existing `aicrypto-lab` repository, (B) what was verified against the current official Kalshi documentation, (C) the integration architecture, (D) safety findings and required remediations, (E) the phased plan with acceptance criteria, and (F) decisions that need your input before Phase 3.

---

## A. Audit of the existing repository

### A.1 Module-by-module reuse assessment

| Existing module | Verdict | Notes |
|---|---|---|
| `aicrypto/safety.py` | **Extend, don't fork** | Add Kalshi-specific checks (no order endpoints in code, key-file permissions, env-only credentials, paper flag). Keep the single-source-of-truth property. |
| `aicrypto/settings.py` | **Extend** | Add a `KalshiSettings` model loaded from a separate `config/kalshi.yaml`. Crypto `research.yaml` stays untouched. |
| `aicrypto/experiments/tracker.py` | **Reuse with generalisation** | `runs` table is Freqtrade/candle-shaped (`timeframe`, `pairs`). Add an `engine` column (`crypto`/`kalshi`) and a `kalshi_runs` artefact schema; keep `lifecycle` and `sessions` tables, extend `LIFECYCLE` with the six Kalshi states (§C.8). `run_id` hashing is reusable as-is. |
| `aicrypto/promotion/gates.py` | **Reuse pattern, new gate set** | `GateResult`/`GateOutcome` reused. Kalshi needs different gates (fill-model agreement, reference-mapping validated, holdout untouched, multiple-testing control). |
| `aicrypto/research/leakage.py` | **Reuse concept, reimplement for events** | Lookahead probe (truncate + scramble-future) transfers directly to event streams. Recursive probe is candle-specific. |
| `aicrypto/research/walkforward.py` | **Reimplement** | Candle-indexed folds. Kalshi folds must be time/contract-window indexed with holdout separation. |
| `aicrypto/research/backtest.py` | **Not reused** | Next-bar-open candle fills are the wrong model for an order book. A Kalshi backtester replays recorded L2 books. |
| `aicrypto/agent/researcher.py` | **Reuse the loop shape** | Budgeted session, seeded candidate generation, idempotent evaluation. Candidate type becomes a `KalshiStrategySpec`. |
| `aicrypto/dashboard/app.py` + `index.html` | **Extend** | Add `/api/kalshi/*` routes and a tabbed UI (Crypto / Scanner / Portfolio / Lab / Latency / Safety). Same host binding (127.0.0.1). |
| `aicrypto/reporting/` | **Extend** | Daily report gains Kalshi sections; paper reader for the Kalshi ledger. |
| `aicrypto/freqtrade_bridge/` | **Not involved** | Freqtrade stays the crypto spot execution simulator only. |
| `aicrypto/cli.py` | **Extend** | `aicrypto kalshi <subcommand>` namespace. |
| `docker-compose.yml` | **Extend** | New `kalshi-ingest` service (research never runs in that container). |

### A.2 Unresolved issues from the previous audit — honest status

None of these were fixed in the first build. Status and planned remediation:

| Issue | Finding in current code | Severity | Remediation (phase) |
|---|---|---|---|
| **2% vs 1% trade risk** | Crypto engine uses 2% of *current* equity per trade (as originally specified). The Kalshi spec requires 1% of *initial* paper capital per position and 5% aggregate, sized against full plausible loss. | Design | Kalshi uses its own `RiskLimits` (1% / 5% / 3% daily stop, of $700 initial). Crypto stays 2% but the setting is documented as a *planned* risk, not a cap on realised loss (gaps can exceed it). (Phase 7) |
| **Incomplete promotion gates** | `freqtrade_agreement` gate exists but is **not wired into the automated loop**; it only runs via manual `verify-ft`. `parameter_stability` is skipped when OOS return ≤ 0 (acceptable: it fails other gates) but the skip is not recorded as a gate result. No multiple-testing control, no holdout set. | High | Crypto: wire `verify-ft` into `promote` (promotion requires it). Kalshi: gates include holdout, multiple-testing (deflated Sharpe or Bonferroni on candidate count), fill-model agreement. (Phase 2 remediation + Phase 8) |
| **Daily-script fail-closed** | `scripts/daily.sh`: `data-check \|\| echo ...` swallows the failure and research + promote still run. Not fail-closed. | High | Make every step fail-closed (`set -e` without `\|\|`), and have `promote` refuse when the last data-check failed. (Phase 1 remediation, done in this commit) |
| **Backtester fill assumptions** | Fills at next-bar open ± fixed slippage, unlimited liquidity, no partial fills, no volume cap. Stop fills at exactly the stop price unless the bar opens through it. | Medium (crypto) / Disqualifying for Kalshi | Crypto: documented limitation; optionally add a volume-participation cap later. Kalshi: book-replay fills with optimistic/baseline/conservative models (Phase 7). |
| **Trailing-stop intrabar assumption** | Within a bar the engine checks the stop against the bar's low *before* raising the trailing stop with the bar's high. That is conservative (never credits a same-bar high) but the ordering of high/low inside a bar is unknown; a bar that hits the trail level after making a new high is treated as not stopped. Documented, not modelled. | Low-Medium | Document in `ARCHITECTURE.md`; Freqtrade's own backtester uses a different intrabar assumption, which is partly why returns differ while trade counts match. (Phase 1 doc) |
| **Docker safety verification** | Tests check compose *text* for `--dry-run`; the container was never run here (no daemon). Image tag `freqtradeorg/freqtrade:stable` is unpinned and moves. | Medium | Pin the image tag; add `scripts/verify_compose.sh` that runs `docker compose config` and asserts the rendered command. Executed on WSL in Phase 11. |
| **Dependency reproducibility** | `pyproject.toml` has `>=` floors only; no lockfile. The tested set was pandas 3.0.5 / numpy 2.5.3 / pyarrow 26.0.1 / pydantic 2.13.5 / fastapi 0.162.2 / freqtrade 2026.10. | Medium | Add `requirements.lock` (pinned, generated from the tested environment) and use it in `Dockerfile.research` and `docs/WSL_SETUP.md`. (Phase 1 remediation, done in this commit) |

Additional findings from re-reading the code:

- `aicrypto/safety.py::test_no_live_state_in_codebase` is a token scan; it would not catch a renamed live state. Acceptable as a tripwire, not a proof.
- `research.log` and the tracker DB are not rotated. Bounded by candidate budgets; add rotation when the Kalshi recorder lands.
- The dashboard has no auth; it binds to 127.0.0.1 and is read-only, which is the intended control.

---

## B. Verified against official Kalshi documentation (docs.kalshi.com, read 2026-11-08)

Everything below was read from docs.kalshi.com pages (or Kalshi's fee-schedule PDF / help centre) on 2026-11-08. Anything not listed here is unverified and must be checked against `GET /account/endpoint_costs`, `indexlist`, and live series metadata in Phase 3.

### B.1 Hosts and authentication
- REST (public, unauthenticated, market data only): `https://external-api.kalshi.com/trade-api/v2` — confirmed endpoints: `GET /series/{ticker}`, `GET /markets`, `GET /events/{ticker}`, `GET /markets/{ticker}/orderbook`. The "elections" host serves all markets too.
- REST (authenticated): `https://api.elections.kalshi.com/trade-api/v2`. Demo: `https://demo-api.kalshi.co/trade-api/v2`.
- WebSocket: `wss://api.elections.kalshi.com/trade-api/ws/v2` (demo `wss://demo-api.kalshi.co/trade-api/ws/v2`). **Every WebSocket connection requires API-key authentication, even for public channels.**
- Signing: headers `KALSHI-ACCESS-KEY`, `KALSHI-ACCESS-TIMESTAMP` (Unix **milliseconds**), `KALSHI-ACCESS-SIGNATURE`. String to sign = `timestamp + METHOD + path` with **no query string**; WS path is `/trade-api/ws/v2`. Key types: **Ed25519 (default, recommended)** or RSA-2048 with RSA-PSS/SHA-256, MGF1-SHA-256, salt = 32 bytes. Signature base64.
- **No read-only key scope is documented.** An API key can place orders. This drives the credential-handling design in §D.
- Rate limits (Predictions, Basic tier): **200 read tokens/s, 100 write tokens/s; default 10 tokens per request → ~20 read req/s**, 3 s burst on Basic read. WebSocket: 200 concurrent connections per user. `GET /account/limits` and `GET /account/endpoint_costs` are authoritative.

### B.2 Market schema (GET /market)
- Prices are **fixed-point dollar strings** (`yes_bid_dollars`, `"0.5600"`); counts are `*_fp` strings with 2 decimals. Tick size comes from `price_ranges[].step`. → integer arithmetic in units of **$0.0001** and contracts in **hundredths**.
- `status` ∈ {initialized, inactive, active, closed, determined, disputed, amended, finalized}. `market_type` ∈ {binary, scalar}.
- Strike: `strike_type` ∈ {greater, greater_or_equal, less, less_or_equal, between, functional, custom, structured}, `floor_strike`, `cap_strike`, `functional_strike`, `custom_strike`; `expiration_value`, `result`, `settlement_value_dollars`, `settlement_ts`, `settlement_timer_seconds`.
- Timing: `open_time`, `close_time`, `expected_expiration_time`, `latest_expiration_time`, `can_close_early`.
- Rules: `rules_primary`, `rules_secondary` (plain language; the **series** carries `settlement_sources[]`, `fee_type`, `fee_multiplier`, `category`, `tags`, `contract_terms_url`).

### B.3 WebSocket channels relevant to this project
- `orderbook_delta`: `orderbook_snapshot` then deltas. Levels `[price_dollars, count_fp]`; **bids only per side** (YES asks are implied by NO bids: ask_yes = 1 − bid_no). `delta_fp` is a signed **change**. `seq` per subscription (gap detection); `clock` is the exchange clock (same across connections, monotonic per market outside maintenance, may skip). `update_subscription` actions: `add_markets`, `delete_markets`, `get_snapshot`.
- `ticker`: `price_dollars`, `yes_bid/ask_dollars`, sizes, `volume_fp`, `open_interest_fp`, `ts_ms`; **all-markets subscription supported** (omit tickers).
- `trade`: public trades.
- `market_lifecycle_v2`: `created / activated / deactivated / close_date_updated / determined / settled / price_level_structure_updated / metadata_updated`; `event_lifecycle` on event creation. No ticker filter → firehose of new listings (this is the no-polling discovery path).
- `cfbenchmarks_value` (1 Hz) and `cfbenchmarks_value_5hz`: CF Benchmarks real-time indices (**BRTI, ETHUSD_RTI, SOLUSD_RTI, XRPUSD_RTI, DOGEUSD_RTI** on 5 Hz; more on 1 Hz). 1 Hz messages carry `avg_60s_data` (the trailing 60-s average) and, in the final minute before each quarter-hour, `last_60s_windowed_average_15min`. Fields: `index_id`, `value_usd`, `source_ts_ms`, `received_at`. No price listed in the docs.
- `pyth_value`: metals (XAU/XAG/XPT/XPD spot and blended indices), oil (WTI, Brent, blended), natural gas, copper, US30, Treasury yields, FX. **$1,000/month, 7-day free trial.** `source_ts_ms` and `received_at`.
- Keep-alive: control frames per `connection-keep-alive` page (ping/pong), to be implemented exactly as documented in Phase 3.

### B.4 Settlement mechanics (help centre + rules)
- All crypto price markets settle on **CF Benchmarks RTIs**, averaged over **60 one-second readings** before the time in the rules.
- **15-minute up/down series** (`KXBTC15M`, `KXETH15M`, `KXSOL15M`, `KXXRP15M`, …, plus `KXGOLD15M`, `KXSILVER15M`, oil, indices): one market per window; YES iff the 60-s average before close ≥ the 60-s average before open. No strike ladder.
- **Hourly / daily strike ladders** (e.g. `KXBTCD-…` "BTC price at 5pm EST", many strikes per event) and **range markets** (`KXBTC-…`, `between`).
- Weekly/monthly/annual contracts exist; `strike_date`/`strike_period` on events.
- Fees: taker = ceil-to-cent(M × 0.07 × C × P × (1−P)); maker = ceil(M × 0.0175 × C × P × (1−P)) only on series with `fee_type` ∈ {quadratic_with_maker_fees, quadratic_with_combo_maker_fees}; M = `fee_multiplier`. No settlement fee. Rounding rules in `fee_rounding.md` (verify at implementation).
- Historical: `GET /historical/markets`, `/historical/trades`, candlesticks (1 m / 1 h / 1 d). **No historical L2 order-book data is offered** → we must record our own books from day one; candle/trade history supports only coarse research.

### B.5 Implications
1. **The settlement reference for crypto is itself a Kalshi feed.** For BTC/ETH/SOL/XRP the correct "reference price" is BRTI etc. from `cfbenchmarks_value(_5hz)`, not an exchange spot quote. The lead/lag hypothesis therefore has two legs we can measure separately: (a) exchange spot → BRTI (does the aggregate index lag the venues it aggregates?), (b) BRTI → Kalshi contract prices.
2. **Metals/energy/indices reference needs Pyth at $1,000/month.** Without it, §6.2 of the spec ("reject strategies when the reference mapping cannot be validated") means those markets are **discovered and recorded but not strategy-evaluated**. Decision required (§F).
3. Discovery can be entirely push-based: public REST once at start-up, then `market_lifecycle_v2` + all-markets `ticker` for liquidity ranking. REST polling is only a periodic reconciliation (every 15 min) well inside the 20 req/s budget.
4. Book subscriptions are cheap in connection terms (200 allowed) but not in CPU: one WS connection with a bounded set of `orderbook_delta` markets, ranked and rotated.

---

## C. Target architecture

```
                 ┌──────────────── Kalshi WS (1 conn, authed) ────────────────┐
                 │ orderbook_delta (≤N books) · ticker (all) · trade ·        │
                 │ market_lifecycle_v2 · cfbenchmarks_value_5hz · [pyth_value] │
                 └───────────────┬────────────────────────────────────────────┘
  exchange spot WS (Coinbase/Kraken public) ─┐  │
                                             ▼  ▼
   ┌──────────── INGEST PROCESS (asyncio, 1 core, no research) ───────────────┐
   │ websocket.py  decode → events.py (typed, int prices) → orderbook.py       │
   │ reference_feeds.py (BRTI/spot/pyth adapters, freshness, jump detection)   │
   │ market_registry.py (eligibility, durations, strikes, ranking, rotation)   │
   │ latency.py (stage stamps, p50/p95/p99, queue depth)                       │
   │ signal_runner.py (deterministic, prevalidated strategy objects only)      │
   │ paper/engine.py (orders, fill models, ledger, risk, safety stops)         │
   │ recorder.py (append-only, bounded queue, batched writes, off hot path)    │
   └──────────────┬──────────────────────────────┬────────────────────────────┘
                  │ JSONL.zst segments            │ SQLite (ledger, registry snapshot, metrics)
                  ▼                              ▼
   ┌────── RESEARCH PROCESS (scheduled, nice 10, bounded) ──────┐   ┌── DASHBOARD (read-only) ──┐
   │ replay.py (deterministic, accelerated/real-time)           │   │ /api/kalshi/* + tabs      │
   │ backtest.py (book replay, 3 fill models)                   │   └───────────────────────────┘
   │ strategies/ (A..H families as specs)  validation/ (WFO,   │
   │ lookahead, sensitivity, multiple-testing, holdout)         │
   │ gates.py → tracker (engine=kalshi) → experimental paper    │
   └────────────────────────────────────────────────────────────┘
```

### C.1 Process model
- **Ingest** and **research** are separate OS processes. The ingest process never imports research code, never calls an LLM, never blocks on disk: the recorder consumes a bounded `asyncio.Queue` and writes in batches from a thread; when the queue is full the recorder drops *recorder* events (counted, surfaced on the latency tab) — the book and ledger never drop.
- Research is scheduled (cron/`daily.sh`) with `nice`, single worker, candidate/time/memory budgets as today.
- Dashboard reads SQLite + the latest metrics snapshot file; no live socket into the ingest loop.

### C.2 Modules (new)
```
aicrypto/kalshi/
  auth.py             Ed25519/RSA-PSS signer; key loaded from path in env; never logged
  client.py           REST: series/events/markets/orderbook/candles/historical; rate limiter; backoff
  websocket.py        auth handshake, subscribe/update_subscription, ping/pong, reconnect, resubscribe, seq checks
  events.py           typed events; prices as int(10^-4 $), counts as int(10^-2 contracts); stage timestamps
  orderbook.py        per-market YES/NO bid books; implied asks; snapshot/delta; clock/seq; invalidation
  eligibility.py      allowlist + rule inspection → Accepted/Rejected with reasons (persisted)
  market_registry.py  discovery (REST bootstrap + lifecycle WS), durations/strikes, ranking, subscription scheduler
  reference_feeds.py  BRTI (Kalshi WS), exchange spot (Coinbase/Kraken public WS), optional Pyth; integrity
  settlement_map.py   per-series: provider, instrument, method (60s avg / window compare), timestamps; validated or rejected
  latency.py          stage stamps, histograms, p50/p95/p99/max, queue depth, reconnects, stale incidents
  recorder.py         append-only JSONL.zst segments with schema_version; segment fingerprints
  replay.py           deterministic event replay; accelerated / real-time
  fees.py             quadratic/flat fee calc with fee_multiplier and cent rounding; unit-tested against the schedule table
  paper/
    orders.py         marketable/limit, cancel/replace, partial fills
    fills.py          optimistic / baseline / conservative models (queue position, adverse selection, latency)
    ledger.py         cash, reserved, positions, cost basis, realised/unrealised, settlement, exposure
    risk.py           1% / 5% / 3%-daily, full-loss sizing, correlated exposure, safety stops
    engine.py         event-driven paper engine; every fill carries a reason trace
  research/
    specs.py          KalshiStrategySpec (id, version, hypothesis, assets, durations, data, formulas, sizing, risk, failure conditions)
    strategies/       A lead_lag, B prob_mispricing, C book_imbalance, D spread_capture, E strike_consistency,
                      F cross_timeframe, G momentum_reversion, H expiry_dynamics  (each: deterministic signal fn + param space)
    backtest.py       replay-driven, uses paper engine with chosen fill model
    validation.py     time/window folds, holdout registry, lookahead probe, sensitivity, multiple-testing control
    gates.py          Kalshi gate set
    researcher.py     bounded loop reusing Tracker; may launch experimental paper portfolios (isolated ledgers)
```

### C.3 Eligibility (allowlist, never keywords alone)
A market is **Accepted** only if all hold:
1. Series `category`/`categories`/`tags` ∈ allowlist (`Crypto`, `Financials`/`Commodities`/`Economics`-price subcategories — exact strings verified live in Phase 2) **and** not in the denylist (politics, elections, sports, entertainment, companies, earnings, M&A).
2. `settlement_sources[]` matches a known provider in `settlement_map.py` (CF Benchmarks RTIs; Pyth-fed series only if the Pyth feed is enabled).
3. `strike_type` ∈ {greater, greater_or_equal, less, less_or_equal, between} or the 15-minute up/down structure; `functional`/`custom`/`structured` rejected until individually reviewed.
4. `market_type == binary`, `status ∈ {active}` for trading, `{closed, determined, finalized}` kept for history.
5. `rules_primary` parses to a known template (asset, observation method, timestamp) — parse failures reject.
6. `close_time`, `expected_expiration_time` present; `can_close_early` recorded.
Every decision is written to `kalshi_eligibility` (ticker, decision, reasons, rules hash, time). Enforced at discovery, subscription, strategy evaluation, replay and paper execution via one function.

### C.4 Durations
Derived, not hard-coded: `duration = close_time − open_time` and event `strike_period`, bucketed (≤5m, 15m, 30m, 1h, multi-hour, daily, weekly, monthly, quarterly, longer). Overlapping windows and multi-strike ladders are first-class in the registry (`event_ticker` groups strikes; `series_ticker` + close time groups windows).

### C.5 Subscription scheduler (bounded)
Score = f(top-of-book depth, spread, 24 h volume, time-to-close, feed health, measured per-market processing cost). Budget: `max_books` (default 24), `max_ticker_markets` = all (ticker channel is cheap), rotation every 60 s with hysteresis. Markets within 2 min of close for 15-m series get priority (that is where the lead/lag hypothesis lives).

### C.6 Latency instrumentation
Each event carries: `exchange_ts` (where provided: `ts_ms`, `source_ts_ms`, `sending_ts_ms`), `t_recv` (socket read, `time.monotonic_ns`), `t_decoded`, `t_book`, `t_signal`, `t_decision`. Reported: per-stage p50/p95/p99/max, end-to-end local (`t_decision − t_recv`), queue depth, reconnects, stale incidents, dropped recorder events. "Exchange→local" is reported **separately and labelled as clock-dependent** (wall-clock, unsynchronised); never used to infer one-way network latency.

### C.7 Fill models
- **Optimistic**: marketable fills at displayed top-of-book up to displayed size; passive fills when price touches.
- **Baseline**: marketable fills walk the book with a latency offset (replay the book at `t + measured p95`); passive fills only after the level trades through by ≥ our size (queue-ahead = displayed size at placement).
- **Conservative**: baseline + adverse selection (skip fills where the reference moved against us within the latency window) + 1 extra tick of slippage + no passive fill unless the level is fully consumed.
Promotion uses conservative only.

### C.8 Lifecycle states (Kalshi)
`RESEARCH → VALIDATION → CANDIDATE → EXPERIMENTAL_PAPER → APPROVED_PAPER → RETIRED`. Autonomous research may create `EXPERIMENTAL_PAPER` portfolios (isolated ledgers, tiny notional). `APPROVED_PAPER` (the primary $700 ledger) requires a manual `aicrypto kalshi approve <strategy_id> --version` by you; the AI has no path to it. No live state exists.

### C.9 Resource budget (i5-9400F, 16 GB, WSL cap 8 GB)
Ingest ≤ 1 core, ≤ 600 MB RSS (books for 24 markets are KB-sized; the recorder queue is bounded at 50k events). Recorder: ~5–20 MB/hour compressed at 24 books; rotate daily, retain 30 days raw + summaries. Research: 1 worker, `nice 10`, 4 GB soft limit, scheduled off-peak. Dashboard < 200 MB. Freqtrade container unchanged (2 GB).

---

## D. Safety findings and controls

### D.1 Findings
1. **Kalshi API keys are full-privilege.** No read-only scope is documented. A leaked key could place real orders on your funded account. This is the single largest risk the integration introduces.
2. The spec asks for "dedicated market-data credentials with minimum permissions" — **not available on Kalshi as documented**. Mitigation must be structural (below) rather than permission-based.
3. The demo environment (`demo-api.kalshi.co`) uses the same key mechanism but separate keys and has no listing parity. It is the right place for the first live-socket tests (Phase 3/11), with production keys introduced only for read-only data channels after the no-order-path tests pass.

### D.2 Controls to implement (tested)
- **No order path in the codebase.** The REST client exposes only GET market-data and account-limit endpoints. A test greps the package for `/portfolio/orders`, `POST`/`DELETE` on portfolio paths, `create_order`, `batch_create`, `cancel`, `amend`, and FIX — any hit fails CI. `client.py` has a hard allowlist of request paths and raises on anything else.
- **No production trading client dependency.** `pyproject.toml` must not include `kalshi-python`, `pykalshi-client`, or similar; a test asserts this.
- **Credentials**: `KALSHI_API_KEY_ID` and `KALSHI_PRIVATE_KEY_PATH` from env only; key file must be `0600` and outside the repo; the signer object has `__repr__` redacted and never logs headers; `.gitignore` covers `*.pem`, `.env*`, `secrets/`. A test asserts no PEM content is present in the repo tree.
- **Paper flag** in `config/kalshi.yaml`: `paper_only: true` is required (schema-validated) and `aicrypto safety-check` fails if absent or false.
- **Research isolation**: the research process has no network client to Kalshi WS; it reads recordings only. The ingest process imports no strategy code that is not in the `APPROVED`/`EXPERIMENTAL` registry with a matching version hash.
- **Safety stops** (§12.1 of the spec) implemented as a single `TradingGate` the paper engine consults on every decision; state shown on the Safety tab.
- **`CLAUDE.md`** extended: never edit `aicrypto/kalshi/auth.py`, `aicrypto/kalshi/paper/risk.py`, `aicrypto/safety.py`; never add order endpoints; never commit keys.

### D.3 Remediations applied in this Phase 1 commit
- `scripts/daily.sh` made fail-closed (no step runs after a failed safety or data check).
- `requirements.lock` added with the exact tested versions; `Dockerfile.research` installs from it.
- `docker-compose.yml` Freqtrade image pinned to `freqtradeorg/freqtrade:2026.10` (verify the tag exists on your side; `stable` is kept in a comment as fallback).
- `ARCHITECTURE.md` gains the fill/trailing-stop limitation notes.

---

## E. Phased plan with acceptance criteria

| Phase | Deliverable | Tests / acceptance |
|---|---|---|
| 1 ✔ | This document; remediations in D.3 | Existing 55 tests pass; `daily.sh` aborts on failed checks (shell test) |
| 2 ✔ | `eligibility.py`, `settlement_map.py`, `config/kalshi.yaml`, duration bucketing, registry data model, `paths.py` runtime allowlist | Fixtures: BTC 15m, ETH hourly ladder, gold 15m (reference unavailable → rejected unless Pyth on), election, sports, earnings, `functional` strike, missing settlement source. All decisions recorded with reasons. |
| 3 ✔ (offline) | `auth.py`, `transport.py` (single guarded HTTP path), `schemas.py` (fail-closed), `client.py`, `websocket.py`, `orderbook.py`, `discovery.py`, `stream.py` | Mock WS server fixtures: handshake signature verified against a known-answer vector for Ed25519 and RSA-PSS; reconnect with backoff; resubscribe; seq gap → resync via `get_snapshot`; path allowlist blocks any order endpoint. Demo-env smoke test (manual, your keys). |
| 4 | `reference_feeds.py` (BRTI via Kalshi WS, Coinbase + Kraken public spot WS, optional Pyth), integrity (stale, jump, duplicate, conflict) | Recorded fixture replays; stale/jump/outage → `TradingGate` closes; mapping validation rejects unmapped series. |
| 5 | `orderbook.py`, `latency.py`, hot-path benchmark | Property tests: snapshot+deltas == REST book; implied asks; zero-level removal; clock/seq semantics; invalidation. Benchmark: ≥ 20k deltas/s single core on synthetic burst, p99 decode→book < 200 µs (target, to be measured). |
| 6 | `recorder.py`, `replay.py`, segment fingerprints | Same recording + same strategy ⇒ identical ledger hash twice; accelerated and real-time modes; schema version checks. |
| 7 | `paper/` engine, fee calc, risk limits, safety stops | Fee table known-answer tests from the schedule; cash reconciliation invariant (cash + reserved + positions MTM == equity); 1%/5%/3% enforcement; expiry/settlement; partial fills; three fill models ordered optimistic ≥ baseline ≥ conservative on every fixture. |
| 8 | Strategies A–H as specs, probability model (B), validation (folds, holdout, lookahead, sensitivity, multiple-testing) | Leaky strategy caught; holdout untouched by optimiser (asserted by access log); candle-only data cannot validate book strategies (gate asserts data class). |
| 9 | `researcher.py` for Kalshi, tracker `engine` column, experimental paper portfolios, manual approval CLI | Budget tests; AI cannot reach `APPROVED_PAPER`; rejection reasons persisted. |
| 10 | Dashboard tabs + `/api/kalshi/*`; daily report sections | HTTP tests; no credential strings in any response (test); localhost binding. |
| 11 | Offline e2e, adversarial tests (gaps, duplicates, halts, clock skew), benchmark report, supervised demo-env then production read-only trial | Readiness report separating verified from assumed. |

Each phase ends with: what changed, tests run (with counts), failures and fixes, limitations, git commit.

---

## F. Decisions taken (2026-11-08) and Phase 2 notes

Decisions: Pyth OFF (no purchases, no paid trials) · demo environment first, no production credentials yet ·
Coinbase + Kraken public WebSockets for exchange spot · 24 live books (subject to measurement) · crypto risk stays 2% ·
Kalshi paper risk 1% / 5% / 3% · no real-money execution under any circumstances.

**Settlement-reference findings (Phase 2 research).** Kalshi commodity markets (gold/silver/copper 15-minute,
daily, monthly, year-end) settle on *Pyth* — rules read "close price of the 1-minute candlestick … Outcome verified
from Pyth - Gold"; Kalshi's liquid oil market settles on ICE. Pyth's own Hermes service carries the same Core feeds
and (since Aug 2026) requires an API key with a free tier; it is recorded as a **candidate**, not enabled: licence
terms must be reviewed and you would register the key. Until a feed is validated, every Pyth/ICE-settled market is
`RECORD_ONLY` with reason `reference_feed_unavailable`, and `MarketRegistry.reevaluate_all()` flips them to
`TRADEABLE` automatically (history preserved) once `reference_feeds.pyth.enabled` is true and validated.

**Eligibility tiers.** `TRADEABLE` / `RECORD_ONLY` / `REJECTED`, each with stable reason codes and notes, persisted
with rules-hash and config-hash so decisions can be re-derived and audited. Discovery is unbounded; only the live
L2 subscription set is budgeted (24, with hysteresis, closing-soon windows prioritised, unhealthy feeds de-ranked).

**Runtime allowlist** (`aicrypto/kalshi/paths.py`): GET-only market-data paths, hard-deny on portfolio/orders/
order_groups/rfq/api_keys/margin/perps/FIX, traversal-normalised, WS channels/commands allowlisted; refusals
counted for the Safety tab. Adversarial tests cover traversal, case, query/fragment smuggling and WS payloads.

## F-old. Decisions that were needed before Phase 3 (answered above)

1. **Pyth feed ($1,000/mo).** Default plan: *discover + record* metals/energy/indices markets, **do not strategy-evaluate them** (reference unvalidated → rejected per §6.2). Crypto (BTC/ETH/SOL/XRP) is fully supported via the free-as-documented CF Benchmarks channel. Say if you want the 7-day Pyth trial scheduled for a specific week.
2. **API key.** Create an **Ed25519** key in your Kalshi profile; store the PEM outside the repo (`~/.kalshi/data-key.pem`, `chmod 600`). Because the key is full-privilege, also create a **demo-environment** key first; Phase 3 live tests run against demo until the no-order-path tests pass.
3. **Exchange spot feeds** for the lead/lag leg (a): Coinbase and Kraken public WebSockets (US-accessible, no keys). Binance is excluded by default (geo-restrictions). Confirm.
4. **Subscription budget**: `max_books = 24` default. Raise only after the Phase 5 benchmark.
5. **Crypto engine risk**: leave at 2% (your original spec) or align to 1%? Kalshi is 1% of initial capital regardless.

Until these are answered I proceed with the defaults stated (Pyth off, demo first, Coinbase+Kraken, 24 books, crypto stays 2%).


## G. Phase 3 notes (2026-11-09)

**Bypass-proofing.** `transport.py` is the only module in `aicrypto.kalshi` that imports an HTTP
library and `websocket.py` the only one importing a WebSocket library (`test_transport_is_the_only_http_import`).
`GuardedTransport.request()` is the single entry point; it runs the allowlist *before* building a URL or
signing, refuses non-GET, refuses unknown hosts, and every outbound WebSocket command passes
`RequestAllowlist.check_ws_command`. The REST client exposes no write methods; the mock server in
`tests/test_kalshi_ws.py` records every command it receives and the tests assert only market-data commands arrive.

**Schema verification.** `schemas.py` checks every REST payload (market, series, price ranges, fee types) and every
WS frame (envelope, snapshot levels, delta fields, side enum, lifecycle event types) against the shapes read from
docs.kalshi.com on 2026-11-08. Mismatching payloads are not ingested; they are recorded in the registry table
`schema_mismatches` (REST) and counted in `WsStats.schema_mismatches` (WS). Unknown extra fields are counted
(`SCHEMA_STATS.unknown_fields`) so API additions are visible without breaking ingestion.

**Recovery semantics.** Reconnect → exponential backoff with jitter (cap 60 s) → `invalidate_all()` books →
resubscribe every tracked subscription with its current market list. `seq` gap on a book subscription →
invalidate that book → `update_subscription get_snapshot` → rebuild from the fresh snapshot; clock regression
→ invalidate + resync. Stale socket (no frame for `stale_after_s`, default 30 s; Kalshi pings every 10 s) →
forced reconnect. `error` code 9 (auth required) → subscription dropped and logged, not retried forever.

**Bounded queue.** Books and lifecycle are applied synchronously in the reader and never dropped; only fan-out to
slow consumers is bounded (`dropped_fanout` counter).

**Benchmarks (2-vCPU build VM, synthetic burst, single core).** `scripts/bench_kalshi_book.py`:
book `apply_delta` 425,769/s, p50 2.0 µs, p99 4.8 µs; full frame path (decode + schema + book + fan-out)
76,784 frames/s, p50 10.3 µs, p99 42.6 µs, max 685 µs. Re-run on the i5-9400F for real numbers.

**Unverified against the live API (requires the demo run on WSL):**
1. Whether `GET /markets?status=unopened` is accepted on the demo host (docs list `open`; the registry handles an empty page).
2. Whether `subscribed` responses echo our command `id` (the client falls back to channel matching if not).
3. Exact category strings used on live series (`Crypto`, `Commodities`, …) — the allow/deny lists may need spelling updates.
4. Whether `ticker` frames carry `seq` (schema treats it as optional for `ticker`, required elsewhere).
5. Rate-limit behaviour for *unauthenticated* public REST (we default to 4 req/s; authenticated Basic tier is 20/s).
6. Demo-environment listing parity (expected to be thin; discovery will report few eligible markets).
7. Real `seq` numbering across `get_snapshot` re-requests on the same subscription.

## H. Revised roadmap (owner decision 2026-11-09)

Priorities reordered for a usable desktop application; the research architecture is kept.

| Milestone | Scope | Builds on |
|---|---|---|
| **A — Desktop UI foundation** | `aicrypto ui` terminal backend + SPA (`aicrypto/terminal/`), strict financial allowlist with three access levels (visible / manual demo / automated), Windows launcher (`windows/`) | registry, eligibility, read-only stream, public REST |
| **B — Manual Kalshi demo trading** | separate demo-only execution module (own host allowlist without any production host, idempotent client order IDs, reconcile-before-retry, risk checks on an explicitly selected demo budget, confirmation per order), balance/positions/orders/fills, cancel, kill switch | A + auth.py signer |
| **C — Recorder, replay, local paper sim** | Phase 4–5 as originally planned (deterministic replay, fill model, settlement accounting, risk gates) | stream recorder |
| **D — AI research + armed demo automation** | strategy generation, validation gates, explicitly armed per session, start/pause/stop/emergency stop, max positions, version tracking | B + C |

Three systems are kept apart everywhere (storage, UI, P/L): **market data** (read-only),
**local paper simulation** ($700 engine), **Kalshi demo exchange** (real API orders on the demo
host with mock funds). The read-only `GuardedTransport` and its allowlist are unchanged; demo
orders never go through it.

Access levels (`aicrypto/terminal/access.py`): *visible* = approved financial-price contract on
an allowed asset (non-financial categories, denied tags, undecided markets and markets whose
series is absent from the API are never shown); *manual demo* = visible + verified terms +
active + strike set + not closing (book validity and confirmation re-checked at order time);
*automated* = TRADEABLE tier only (validated settlement reference and an enabled feed).
