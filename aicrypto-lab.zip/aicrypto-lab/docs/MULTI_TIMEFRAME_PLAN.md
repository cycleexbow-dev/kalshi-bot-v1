# Multi-timeframe research: recorder audit and integration plan (2026-11-11)

Owner goals: find strategies across every Kalshi financial-market duration. The target is an 83%+ win rate
**and** positive net expectancy after realistic costs. Production trading stays prohibited until the owner
explicitly says otherwise, and none of this work adds any production order path. No new strategy is switched on.

## 1. Audit of the hourly/daily recorder (started 2026-11-11 21:17)

| Item | Finding |
|---|---|
| Coverage | 22 series, 17 with open markets: crypto hourly ladders (above/below and range) for BTC, ETH, SOL, XRP and DOGE; gold, silver and oil hourly; gold, silver, copper and oil daily. Old daily crypto series (BTCD, BTC, ETHD, ETH) have nothing open |
| Fidelity | Top of book and sizes every 60 s (only when changed), no depth, no trades; settlements every 5 min |
| Volume | ~3,400 markets, ~0.5 requests/s, ~100 MB/day; no errors so far |
| Weak points | (1) **60 s quotes cannot show realistic fills** for anything latency-sensitive. (2) **The series list is hard-coded**, so new series are missed; it should follow the registry. (3) **No weekly or monthly series**, and none of the other eligible assets. (4) A restart re-records up to 6 h of settlements as duplicates; readers must deduplicate by ticker. (5) **Commodity settlement references are not recorded**, because the Pyth feed is off by owner decision, so commodity research is limited to Kalshi's own prices |
| Shortcut available | The real exchange publishes 1-minute candles (bid/ask OHLC) for past markets. Months of hourly and daily history can be **backfilled in hours**, as was done for the 15-minute markets, instead of waiting weeks for live recordings |

## 2. Integration plan (reuses the current engine; each phase is gated)

**Phase A — multi-timeframe registry (built now).**
- `python -m aicrypto.timeframes discover` reads every Crypto, Commodities and Financials series on the real exchange.
- It samples each series' open markets and applies the app's **existing eligibility and duration rules**: financial
  only, settlement source verified, sports, politics and other non-financial markets rejected.
- It maps each asset × duration to:
  - its series and contract structures
  - its settlement reference
  - liquidity (open markets, two-sided markets, spread, 24 h volume)
  - recorder coverage
  - a **data-quality grade**:
    - A: 1 s quotes, depth and the settlement index
    - B: 1-minute quotes and the settlement index
    - C: 1-minute quotes, no validated settlement reference
    - D: not recorded
- The result goes to `user_data/kalshi/timeframes/registry.json`, plus a dated copy each run.

**Phase B — data quality and execution readiness.**
- **Recorder follows the registry,** so coverage is dynamic and includes weekly and monthly series.
- **Higher fidelity only where research shows promise:** 5–10 s quotes and depth for the specific hourly events
  near their close, within the 4–6 requests/s public budget.
- **Historical backfill** of hourly and daily markets from 1-minute candles, with Coinbase and Kraken prices for the
  underlying.
- **Storage:** retention setting, disk-space alert, missing-data detection, a per asset × duration data-quality
  report, and recorder crash recovery (a watchdog restarts it).

**Phase C — hourly research (BTC, ETH, SOL first).**
- Extend the research-agent harness with a timeframe dimension. Each asset × duration gets its own dataset, ledger
  entries, results and validation status.
- **Baseline models:**
  - strike distance in volatility units
  - time left
  - 5 m / 15 m / 1 h momentum
  - volatility regime
  - market-implied probability versus estimated probability
  - consistency across neighbouring strikes on the same hourly ladder
- **Same fixed gates as now:** chronological out-of-sample, conservative fills, clustered statistics, Bonferroni
  across every variant ever tested, calibration better than the market, favourite-trap check, drawdown limit.

**Phase D — daily and commodity research.**
- **Daily crypto ladders:** intraday trend, realized volatility, probability of finishing above or below each strike,
  time-of-day effects, and each series' settlement rules and observation schedule.
- **Commodities:** Kalshi-price-only research until a validated settlement reference exists. That stays the owner's
  decision; Pyth is a paid feed and remains off.

**Phase E — cross-timeframe research.**
- Test whether longer-horizon trend and volatility, such as BTC's hourly trend, improve **15-minute** entries.
- Each idea is an ordinary hypothesis with its own ledger entry. The 30-day evidence so far is negative: the 1 h
  and 4 h direction filters flipped sign out of sample.

**Phase F — experimental demo trading.**
- A candidate that passes the offline gates **and** a pre-registered forward shadow test at real quotes is presented
  to the owner. It runs as a separately approved, isolated demo experiment.
- The active 15-minute bot is never changed without approval.

**User interface (alongside Phases B–D).**
- An asset selector, then that asset's available durations as tabs. Example: BTC → 15m | 1h | Daily | Weekly, only
  the ones the registry finds.
- A market list with strike filters, time to settlement, Yes/No in %, the book where recorded, and status.
- Research results per asset × duration.
- A strategy comparison table: experimental / validated / approved for demo, with demo results kept separate from
  real-price shadow results.

**Hardware (i5-9400F, 16 GB).**
- Research runs as separate, lower-priority processes (`nice`) with the existing CPU and memory budgets.
- The recorder and the demo app keep their own processes.
- Backfills are paced so the recorder's public request budget is never exceeded.
