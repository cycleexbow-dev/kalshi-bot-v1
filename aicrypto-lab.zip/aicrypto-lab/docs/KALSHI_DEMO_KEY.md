# Creating and storing a Kalshi **demo** API key (outside the repository)

Kalshi API keys have **no read-only scope**: a key can place orders on the account it
belongs to. This procedure therefore uses the **demo environment only**
(`demo-api.kalshi.co`, play money, separate account and separate keys) and keeps the
private key outside the repo with restrictive permissions. Do not create or use a
production key for this project until a later phase explicitly asks for one.

The engine itself never calls an order endpoint and refuses to at runtime
(`aicrypto/kalshi/paths.py`), but defence in depth means the key is handled as if it could.

## 1. Create the demo account and key

1. Open the demo site: `https://demo.kalshi.co` and sign up / log in (demo accounts are
   separate from production; no real funds).
2. Go to profile settings → **API Keys** → **Create New API Key**.
3. Leave the default key type **Ed25519** (preferred; smaller, faster, and the engine
   supports it natively). RSA-2048 also works if that is all the UI offers.
4. Kalshi shows the **Key ID** (a UUID) and downloads the **private key** once. Save the
   file immediately; Kalshi does not store it.

## 2. Store it outside the repo (WSL)

```bash
mkdir -p ~/.kalshi && chmod 700 ~/.kalshi
mv ~/Downloads/kalshi-demo-key.txt ~/.kalshi/demo-key.pem      # adjust the source path
chmod 600 ~/.kalshi/demo-key.pem
ls -l ~/.kalshi/            # must show -rw------- on the key and drwx------ on the dir
```

If you downloaded on Windows, move it with `mv /mnt/c/Users/<you>/Downloads/<file> ~/.kalshi/demo-key.pem`
and then `chmod 600` as above (files on `/mnt/c` cannot hold Unix permissions; the key
must live inside the WSL filesystem).

## 3. Expose it to the engine via environment variables only

Add to `~/.bashrc` (not to any file inside `aicrypto-lab/`):

```bash
export KALSHI_ENV=demo
export KALSHI_API_KEY_ID="<the Key ID UUID>"
export KALSHI_PRIVATE_KEY_PATH="$HOME/.kalshi/demo-key.pem"
```

Then `source ~/.bashrc`. The engine:

- refuses to start if `KALSHI_PRIVATE_KEY_PATH` is world/group readable or inside the repo;
- refuses `KALSHI_ENV=production` unless `config/kalshi.yaml` `environment:` also says
  `production` (it currently says `demo`), so a stray environment variable cannot switch hosts;
- never logs the key, the Key ID, signatures or auth headers (`KalshiSigner.__repr__` is redacted
  and the HTTP logger strips `KALSHI-ACCESS-*` headers);
- `aicrypto safety-check` fails if any `*.pem`/`*.key` or PEM text appears anywhere in the repo tree.

## 4. Verify (no trading involved)

```bash
cd ~/aicrypto-lab && source .venv/bin/activate
aicrypto safety-check
aicrypto kalshi auth-check          # loads the key, signs a test string, verifies with the public half, prints key type only
aicrypto kalshi limits              # GET /account/limits on demo (first authenticated REST call)
aicrypto kalshi discover            # public REST discovery on demo -> registry (no auth needed)
aicrypto kalshi stream --seconds 60 # authenticated WebSocket: ticker + lifecycle + ≤24 books, read-only
```

`aicrypto kalshi stream` records what it sees to `user_data/kalshi/recordings/` and prints
feed-health and sequence statistics. It cannot place orders: the WebSocket command
allowlist permits only `subscribe`, `unsubscribe`, `update_subscription`, `list_subscriptions`
on market-data channels.

## 5. Rotation and revocation

Revoke the key from the same API Keys page if you ever suspect exposure; create a new one
and update `KALSHI_API_KEY_ID` / the PEM file. Nothing in the repo needs to change.
