# Market recorder and production-price shadow engine (2026-11-11)

`bash scripts/start_recorder.sh` / `bash scripts/stop_recorder.sh`. Runs as its own process, separate
from the desktop app and the demo bot. Health: `run/recorder_status.json`, log: `logs/recorder.log`.

## What it records

Files: `user_data/kalshi/recordings/real/<UTC date>/<source>-<UTC hour>.jsonl.gz`. Every line carries the
local receive time `t` and a monotonic clock `m`.

| Source | How | Kinds |
|---|---|---|
| `kalshi_real` | Real exchange, public GET-only `KalshiRestClient("production", signer=None)`: no account, no key, no orders | `series_meta` (fees, settlement sources), `market_meta` (ticker, strike, open/close/expiration, status, rules), `quote`, `book` (top 10 levels/side when changed), `book_full` (all levels every 30 s), `book_empty`, `trade`, `settled` (result + settlement value), `error` |
| `cfindex` | CF Benchmarks indices from Kalshi's **demo** WebSocket (demo key, market-data channel). Same index the real markets settle on | `value` (with publisher time and latency), `avg60` (Kalshi's running 60-s average), `invalid`, `seq_gap`, `reconnect` |
| `coinbase` | Public WebSocket `ticker` | `ticker` (price, best bid/ask and sizes, trade id, exchange time, latency), `gap` (trade-id jump), `stale`, `reconnect`, `error` |
| `kraken` | Public WebSocket v2 `trade` + `ticker` | `trade`, `ticker`, `gap`, `stale`, `reconnect`, `error` |
| `kalshi_real_long` | Real exchange, hourly and daily price markets, same unsigned GET-only client, low frequency (`aicrypto/recorder/longer.py`) | `market_meta` (strike type, floor/cap strike, close time), `quote` (top of book, sizes, last, volume, when changed), `settled` (result, settlement value), `error` |
| `recorder` | — | `start`, `health` (every 10 s), `stop`, `error` |

**15-minute markets (`kalshi_real`):**
- quotes and order books for BTC/ETH/SOL/XRP/DOGE about every second; other markets' books every 5 s
- trades round-robin
- settlements every 15 s
- open windows every 60 s

**Hourly and daily markets (`kalshi_real_long`, owner request 2026-11-11):**
- **Crypto hourly ladders**, above/below and range: KXBTCD/KXBTC, KXETHD/KXETH, KXSOLD/KXSOLE/KXSOL, KXXRPD/KXXRP,
  KXDOGED/KXDOGE.
- **Commodities:** gold/silver/oil hourly (KXGOLDH, KXSILVERH, KXWTIH) and gold/silver/copper/oil daily.
- **Older daily crypto series** (BTCD, BTC, ETHD, ETH), recorded whenever they have open markets.
- **Cadence:** one request per series every 60 s, prices only when they change, no order-book depth; settlements
  every 5 minutes. About 3,400 markets, roughly 0.5 requests a second.
- **Excluded:** path-dependent or composite series (for example "BTC max daily", "gold vs silver").
- **Not used by the research experiment,** which stays on 15-minute markets.

Failed requests are recorded as `error` events; nothing is estimated or filled in. Production WebSocket access
needs an account key, which is not allowed, so production data is polled (about 1 s resolution).

**Disk:** about 420 MB a day in total (about 100 MB of it hourly/daily). Delete old day folders when needed.

## Shadow engine (hypothetical fills only)

Every lab rule (`aicrypto/kalshi/lab/candidates.py`, version `lab1`) is evaluated each second on real prices
and the recorded CF index. Proposals go to `user_data/kalshi/shadow_real.sqlite` with strategy and version,
asset, duration, signal time, side, displayed ask/bid, top-5 depth, time left, model probability and spread.

Fill model, fixed in advance:
- marketable orders only (passive fills are never assumed),
- 1 s and 3 s latency: filled against the first recorded book at or after that delay,
- only 50% of each displayed level counts as available,
- at most 2¢ above the signal ask, otherwise partial or no fill,
- Kalshi taker fee,
- sizes of 1 contract and $10,
- held to the official result.

Reports: `python -m aicrypto.research15.shadow_report` (live shadow), `python -m aicrypto.research15.validate`
(30-day history), `aicrypto/research15/finalminute.py` (experimental final-minute model, never used by the bot).
