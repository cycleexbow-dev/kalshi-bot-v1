# Real-money trading: setup and controls

Decided by the owner on 2026-11-19. The rules are in CLAUDE.md, rule 21.

## What it does

The **REAL MONEY** bot trades your real Kalshi account. It uses the same rules as the demo bot's practice mode,
with prices and checks taken from the real exchange.

**None of the rules is proven yet.** Demo and backtest results are not evidence of profit, and losses are possible.

## Limits

These are fixed in the code. The bot can't change them.

| Limit | Value |
|---|---|
| Smallest trade | $1 |
| Largest trade | 10% of the account value |
| Spent per day | no limit (owner's choice; the 30% limit was removed 2026-11-19) |
| Daily loss stop | none (owner's choice) |
| Automatic cash-out | sells a position when its chance of winning falls to 10% or less (adjustable on Bot & Strategies, 0 = off), only if that is under half of what was paid and brings back at least $0.10 |
| Bet size per trade | your setting, 0.5–10% (starts at 2%) |

## One-time setup (you do this; Claude never touches the key)

1. On kalshi.com, open Account → API keys, create a key, and download its private key file.
2. Open the Ubuntu (WSL) terminal and run:

   ```bash
   mkdir -p ~/.config/aicrypto && chmod 700 ~/.config/aicrypto
   ```

3. Copy the downloaded key file there and name it `kalshi_real.pem`. From Windows, the folder is
   `\\wsl.localhost\Ubuntu\root\.config\aicrypto\`. Then make it private:

   ```bash
   chmod 600 ~/.config/aicrypto/kalshi_real.pem
   ```

4. Create the settings file. Replace `YOUR-KEY-ID` with the key ID shown on kalshi.com:

   ```bash
   printf 'KALSHI_REAL_API_KEY_ID=YOUR-KEY-ID\nKALSHI_REAL_PRIVATE_KEY_PATH=/root/.config/aicrypto/kalshi_real.pem\n' > ~/.config/aicrypto/kalshi_real.env && chmod 600 ~/.config/aicrypto/kalshi_real.env
   ```

5. Restart the app. The REAL MONEY card at the top of Bot & Strategies should show **real account connected** and
   your cash.

The app refuses the key if either file can be read by other users, or if the key is inside the project folder.

## Turning it on and off

- **On:** Bot & Strategies → REAL MONEY → **Turn on**, type `REAL MONEY`, confirm.
- **Off:** the same button. Open orders stay open.
- **STOP REAL TRADING:** turns the bot off and cancels every open real order. The emergency stop on the demo
  page does the same.
- The real bot is always off when the app starts.

## Where to see what it did

- **Real-account activity** in the REAL MONEY card: orders, refusals, limits.
- Your own Kalshi account on kalshi.com, which is the record that counts.
