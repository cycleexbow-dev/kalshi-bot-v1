# Research agent (Phase 1, 2026-11-11)

Offline experiment system for the AI researcher. It never trades and cannot promote anything into the demo bot.
The plan is in `docs/RESEARCH_SYSTEM_PLAN.md`.

## How a hypothesis is tested

1. **Write the probability code.** It goes in `research/sandbox/<name>.py` and defines `probability(ctx)`, the chance
   the window settles YES. `ctx` holds only what was known at the decision time:
   - `ask_yes`, `bid_yes`, `mid` and `spread`: the real exchange's last complete minute
   - `spot`: Coinbase, translated onto the settlement index level
   - `strike` and `t_left_s`
   - `ret_1m` … `ret_240m`, `vol_5m` / `vol_15m` / `vol_60m`, `closes_60m` and `hour_utc`

   Outcomes are never passed in.
2. **Write the spec.** It goes in `research/hypotheses/<name>.json`: id, title, rationale, sandbox path, assets,
   decision leads in seconds before close, and the margin grid. Each margin is one variant.
3. **Run it:** `python -m aicrypto.research_agent run research/hypotheses/<name>.json`. To see every attempt:
   `python -m aicrypto.research_agent ledger`.

## Protections

- **Sandbox, static checks:**
  - only `math`, `statistics`, `bisect`, `itertools`, `functools`, `collections` and `numpy` may be imported
  - no file, network, process, eval or introspection built-ins
  - no dunder attributes and no global state
- **Sandbox, how it runs:**
  - in its own Python process, in isolated mode with an empty environment
  - under CPU and memory limits
  - called twice in different orders to catch hidden state
  - outputs must lie between 0 and 1
- **Budgets and gates** are in `config/research_agent.yaml`. They are owner-controlled and pinned by a test.
- **Every attempt is logged.** Started, finished, failed and refused attempts all go into an append-only ledger
  (`experiments/research_agent/ledger.sqlite`; database triggers block edits and deletes). Each row records the
  hashes of the spec, the code, the config and the protected harness files.
- **Fixed harness** (`aicrypto/research_agent/harness.py`):
  - one trade per window
  - conservative fills (+2 points on the displayed ask, plus fees)
  - chronological 60/40 split, with the margin chosen on the training part only
  - statistics clustered by day, a Wilson interval for the win rate and a day-block bootstrap for the return
  - Bonferroni over every variant in the ledger
  - calibration against the market's own price
  - a favourite-trap check
- **Passing the gates only means "candidate for forward shadow testing".** It is never a trading decision.

## First results (2026-11-11, BTC + SOL, 30 days of real-exchange data)

| Hypothesis | Verdict | Test return (conservative) | Calibration (Brier, model vs market) |
|---|---|---|---|
| market_baseline (control) | rejected, no trades | — | 0.1512 vs 0.1512 |
| vol_settlement | rejected | −4.4% (1,400 trades) | 0.1567 vs 0.1512 |
| market_vol_blend | rejected | +0.2% (201 trades, not significant) | 0.1509 vs 0.1512 |

## Phase 2: final-minute data (2026-11-11)

- **Specs can choose their data.** `"data": "recorded"` tests on the recorder's data (`aicrypto/research_agent/harness_recorded.py`):
  - decisions at 50, 40, 30, 20, 10 and 5 seconds before close
  - the official 1-second index prints already inside the settlement minute, the latest value and 300 one-second returns
  - Kalshi's own 60-second average
  - the real order book
- **Fills:** the book as it stood 1 s after the decision, half of the displayed size, at most 2 points above the
  decision ask, plus fees.
- **No estimates:** decisions with index gaps or a stale book (no record for over 31 s) are excluded and counted.
  When one side of the book is empty near the close, only the other side can be bought.
- **Gap logging:** the recorder now records every index gap over 1.5 s (`gap` events). The gaps come from the app
  and recorder sharing one demo key, because Kalshi drops one connection when the other connects. A second demo key
  for the recorder would remove them.
- **Five assets** (owner decision 2026-11-11): BTC, SOL, ETH, XRP and DOGE, 15-minute markets only. Every result is
  reported per asset (trades, win rate with a Wilson interval, net return, fees, drawdown, calibration against the
  market) and combined.
- **Correlation:** the combined figure shows the number of independent settlement times, the correlation of results
  between assets in the same window, and a t value clustered by settlement time. The gate keeps the stricter
  clustering by day. Promotion still requires a positive combined return after conservative costs and every
  existing evidence rule.
- **Index feed redundancy:** the recorder also reads the desktop app's copy of the CF index (`GET /api/terminal/cf_stream`,
  local and read-only) whenever the app is running. Prints are deduplicated by publisher timestamp, so a print
  only one connection received fills the other's gap with real data. The ~2 s gaps were clean closes by Kalshi's
  demo server, not a shared-key conflict. Close codes are now logged (`last_close` in reconnect events).
- **First run** (110 BTC/SOL windows, 13.7 h of recordings): the settlement-average model is better calibrated than
  the market overall (Brier 0.0105 vs 0.0124). That comes mostly from windows already decided. Only 6–10 training
  trades fired and filled, and they lost. Far too little data: the gates need 300 test trades over 7+ days.
