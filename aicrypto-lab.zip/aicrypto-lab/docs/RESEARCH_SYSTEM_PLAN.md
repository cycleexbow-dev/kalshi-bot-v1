# Autonomous strategy research system: audit and plan (2026-11-11, PROPOSAL — not built)

Owner goal: Kalshi financial-market strategies with a sustained win rate above 83% **and** positive net profit
after fees, spread, slippage and execution costs. Production trading stays prohibited; nothing in this plan
creates a production order path.

## 1. Audit of what exists

### Data

| Source | Coverage | Quality |
|---|---|---|
| Real-exchange history (`research15.data`) | 30 days × BTC/ETH/SOL/XRP/DOGE: 14,240 windows with target, result, settlement value and 1-minute bid/ask | No order-book depth; no second-level index history |
| Recorder (`aicrypto/recorder`, since 2026-11-11 07:05) | Real quotes and 10-level books every ~1 s, trades, settlements (893 so far); CF index 5 Hz/1 Hz plus Kalshi's 60-s average; Coinbase and Kraken | ~330 MB/day. **The CF index link reconnected 27 times**: short gaps in exactly the data the final-minute model needs |
| Demo ledger | Every actual demo fill, order and position | Good; reconciles to the account balance |

### Research code

| Piece | What it does | Verdict |
|---|---|---|
| `research15` (audit, realism, replay, validate, selection, finalminute) | Offline, tested, no order code. Chronological out-of-sample tests, Bonferroni across 130 variants, conservative fills | Solid base to reuse |
| Recorder shadow engine | Every rule at real prices, 1 s / 3 s latency, half of displayed depth, 2-point limit, fees | Solid. This is the forward-test harness |
| App's real-price lab (`lab/realprice.py`) | Same rules at the **displayed** real price, instant fill | **Optimistic**: fair value +12% here vs −6.5% in the shadow engine. Should not feed verdicts |
| Final-minute model | Settlement-average model with fat tails; reconstructs official settlement values to ~0.1 bp | Promising tool. Not validated: needs weeks of clean index recordings |

### Demo-selection system (the bot)

1. **The lab promotes rules into demo trading by itself.** A rule that passes the lab's gates becomes "proven" and
   trades demo money even with practice mode off. There is no owner approval step. Two BTC fair-value versions were
   **shortlisted today**, and they can reach "proven" after about 250 more trades.
2. **Those gates use demo prices**, which proved misleading: the demo price was below the real price in 80% of trades.
3. **The multiple-testing correction undercounts.** The Bonferroni divisor counts only rules that reached shortlisting,
   not all 447 versions tried, so the bar is too low.
4. **Correlation is ignored.** Rule versions that take the same trade are counted as separate evidence, and the t
   statistics are per trade rather than per window or per day.
5. **Ranking rules by past results added nothing** in replay (+0.26 points, noise) and switched rules 63–68% of the time.
6. **Practice mode spends demo money on unproven rules** at 10% of the account per trade (an owner decision, kept).

### The 83% question (30 days of real-exchange data)

The real market is well calibrated at high prices. Favourites priced 80–99% win about as often as their price says,
so buying them returns −0% to −5% after fees at every price band and time left. **An 83% win rate is easy to get
and loses money.** A profitable 83%+ strategy needs a model that finds favourites priced below their true chance by
more than the fee plus execution costs, which is at least about 1–3 points. The final seconds, where part of the
settlement average is already fixed, are the most plausible place. The early evidence there is not encouraging:
only 17 of 137 lock-in signals would have filled at a 1 s delay, and those lost.

**Minimum evidence:**
- **Win rate:** pinning an 85% win rate to ±3 points takes about 550 independent windows.
- **Profit:** showing a +2% return when one trade's return varies by about 30% takes roughly 1,500–2,000 independent windows.
- **How long that takes:** with BTC and SOL and a selective rule, expect **weeks to months of forward shadow
  trading**. There is no shortcut that is honest.

## 2. Plan (reuses the current engine; each phase needs the owner's go-ahead)

### Phase 0: guardrails and data fixes (changes demo selection, so it needs explicit permission)
- **Owner approval for demo money.** Lab "proven" becomes "awaiting owner approval". Demo money goes to a new rule
  only after approval, through the existing human-only `aicrypto demo approve`.
- **Stricter gates** (CLAUDE.md allows stricter without discussion):
  - Bonferroni counts every version ever tested.
  - Statistics are clustered by day.
  - Duplicate trades across versions count once.
  - Promotion evidence must come from the recorder's conservative real-price shadow, not demo prices.
- **Honest numbers.** The app's optimistic real-price lab no longer feeds verdicts. It is relabelled "displayed price,
  instant fill".
- **Clean index data.** Fix the recorder's CF-index reconnects and record every gap explicitly, so the final-minute
  model can trust the data.

### Phase 1: experiment registry and budgeted runner (`aicrypto/research_agent/`)
- **Hypotheses.** A hypothesis is a small spec (assets, timing, features, model, decision rule) plus optional
  feature code in a sandbox folder.
- **Every attempt is logged** in an append-only experiment ledger, including failures and errors.
- **Budgets live in config the AI cannot edit:** experiments per day, CPU minutes, variants per hypothesis.
- **Protected files.** A test enforces that research code cannot touch the gates, the budgets, the fill model or any
  order code. Sandbox code is checked for no network, no order imports, and causal features (leakage probe).
- **One fixed evaluation harness:**
  - time-aligned data from the recorder and history
  - chronological walk-forward
  - conservative fills from recorded books (latency, partial depth)
  - fees
  - statistics clustered by window and day
  - multiple-testing control across all attempts in the ledger (alpha spending)
  - drawdown and confidence intervals

### Phase 2: probability models and calibration (BTC and SOL first)
- **Final-minute settlement model** on recorded index prints, then short-horizon models: volatility regimes,
  order-book signals, cross-asset lead (for example BTC → SOL) and Coinbase/Kraken versus the index.
- **For every model:**
  - reliability curves
  - Brier score and log-loss
  - calibration error by price band
  - always compared with **the market's own executable price** out of sample
- **A model is only used if it beats the market's calibration out of sample.** A "90%" bucket must be right about
  90% of the time.

### Phase 3: candidate strategies from calibrated models
- **Trade rule:** trade only when model probability − executable price − fee − slippage allowance ≥ margin.
- **The win rate is reported, never optimised.**
- **Favourite-trap check:** reject any candidate whose profit relies on bands where the market itself is calibrated
  and the model shows no calibration edge.

### Phase 4: forward shadow at production quotes (recorder)
- **Survivors are pre-registered:** fixed rule, fixed duration and sample size from a power calculation.
- They run forward on live real-exchange quotes with the conservative fill model.
- No changes are allowed during the test. Results are recorded separately from demo fills.

### Phase 5: demo trading, owner-approved only
- A strategy that passes Phase 4 is offered to the owner for demo approval.
- Experimental strategies never share the approved execution path.

### Phase 6: real-money readiness dashboard
- **What it shows:**
  - observed win rate with a confidence interval
  - net expectancy with a confidence interval
  - profit factor and maximum drawdown
  - execution costs (demo vs displayed real vs conservative)
  - production-price shadow results
  - sample size against requirement
- **The readiness verdict is hard-coded "NOT READY"** unless all of the following hold:
  - forward shadow results positive after conservative costs, at the required confidence and sample size
  - acceptable drawdown
  - stable across halves
- **Even then it reads "Eligible for a safety review — NOT AUTHORIZED".** No research result can enable
  production orders; that needs a separate explicit owner authorization and a safety review outside this system.

### What "AI research agent" means here
- **The AI researcher is Claude, working in research sessions.** It reads the ledger, proposes hypotheses, writes
  sandboxed feature and model code, and runs the fixed harness within budget.
- **The real-time path stays deterministic** (CLAUDE.md rule 12): no AI in the trading loop.
- **The AI cannot edit its own gates, budgets, fill model or safety controls**, and cannot promote anything into
  demo execution.
