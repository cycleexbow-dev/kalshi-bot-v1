# Windows + WSL Ubuntu setup (16 GB desktop)

## 1. Cap WSL memory so Windows stays usable

Create `C:\Users\<you>\.wslconfig`:

```ini
[wsl2]
memory=8GB
processors=4
swap=4GB
localhostForwarding=true
```

Then in PowerShell: `wsl --shutdown` and reopen Ubuntu.

## 2. Docker

Either Docker Desktop (Settings → Resources → WSL integration → enable your Ubuntu
distro) **or** native docker-ce inside WSL:

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER && newgrp docker
```

Check: `docker compose version` and `docker run --rm hello-world`.

## 3. Project

```bash
cd ~
unzip aicrypto-lab.zip && cd aicrypto-lab        # or git clone
chmod +x scripts/*.sh
scripts/wsl_audit.sh                             # environment audit
sudo apt install -y python3-venv
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest -q                              # should be all green
aicrypto audit
```

Freqtrade itself runs in Docker; you do not need to pip-install it on the host.
If you want `aicrypto verify-ft` to run without Docker, `pip install -e ".[freqtrade]"`
works too (TA-Lib wheels are available for Python 3.11–3.13).

## 4. Data

```bash
docker compose pull freqtrade
scripts/download_data.sh 1095 15m 1h 4h          # ~3 years, 3 pairs, feather
aicrypto data-check
```

If Binance is geo-blocked for you, set `markets.exchange: kraken` in
`config/research.yaml` (pairs become `BTC/USD` etc. — update `markets.pairs` too)
and re-run.

## 5. Research → promote → paper trade

```bash
aicrypto research --timeframe 1h --max-candidates 40 --max-minutes 30
aicrypto promote --dry-run-config
aicrypto verify-ft <ClassName> --timerange 20250101-     # Freqtrade's own backtest/lookahead/recursive
scripts/start_dryrun.sh                                   # starts freqtrade (dry-run) + dashboard
```

Dashboard: http://127.0.0.1:8080 — Freqtrade API: http://127.0.0.1:8081 (user `paper`,
password in `user_data/config_dryrun.json`). FreqUI can be pointed at 8081 if you want it.

## 6. Daily automation

```bash
crontab -e
15 6 * * * /home/<you>/aicrypto-lab/scripts/daily.sh >> /home/<you>/aicrypto-lab/reports/cron.log 2>&1
```

WSL cron needs the distro running; on Windows 11 enable `systemd=true` in
`/etc/wsl.conf` or use Windows Task Scheduler to run
`wsl -d Ubuntu -- /home/<you>/aicrypto-lab/scripts/daily.sh` at 06:15.

## 7. Using Claude Code here

Open the repo in WSL and run `claude`. `CLAUDE.md` holds the rules (no live
trading, no edits to safety files, bounded budgets, no profitability claims).
A good first prompt: "Read CLAUDE.md and docs/RESEARCH_LOG.md, then propose two
new StrategySpec JSON files under specs/ with a stated hypothesis each, evaluate
them with `aicrypto research --spec`, and record the outcome in the log."

## 8. Kalshi demo connection test (Phase 3, read-only)

Follow `docs/KALSHI_DEMO_KEY.md` to create a **demo** key and export `KALSHI_ENV=demo`,
`KALSHI_API_KEY_ID`, `KALSHI_PRIVATE_KEY_PATH`. Then:

```bash
aicrypto safety-check
aicrypto kalshi auth-check                # key type + self-verify only
aicrypto kalshi discover                  # public REST -> registry; prints tiers, durations, rejections, mismatches
aicrypto kalshi limits                    # first authenticated call (GET /account/limits)
aicrypto kalshi stream --seconds 120      # authenticated WS: ticker, lifecycle, CF index values, ≤24 books
python scripts/bench_kalshi_book.py       # local processing benchmark on your CPU
```
Send back `experiments/kalshi_discovery_last.json` and `experiments/kalshi_stream_last.json`; they contain
no credentials. Nothing in these commands can place an order.
