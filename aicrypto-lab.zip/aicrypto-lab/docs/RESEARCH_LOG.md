# Research log

Dated lab notebook. Hypothesis → what was run → what the gates said → what was learned.
Negative results are results. Never record a "profitable" verdict; record gate outcomes.

## 2026-11-08 — pipeline validation on synthetic data (build environment)

- Data: synthetic regime-switching random walks (8000 × 1h bars, 3 pairs). Says nothing about real markets.
- Ran `aicrypto research --max-candidates 12 --seed 1` with production gates: **0/12 passed**. Expected —
  random-walk data has no exploitable structure and the gates should reject.
- Ran a throwaway loosened-gate config (not committed) to exercise promote → export → Freqtrade:
  Freqtrade backtesting on the exported `ACEmaCross…` reproduced our trade count exactly on the
  comparison spec (134/134), `lookahead-analysis` reported no bias, `recursive-analysis` drift ≤0.02% at
  the strategy's own startup count.
- Learned: pointwise relative drift is the wrong recursive metric for scores that cross zero; switched to
  drift / std(score) with a 1% threshold and zero signal flips required.

## Next (on real data, WSL)

1. `scripts/download_data.sh 1095 15m 1h 4h`, `aicrypto data-check`.
2. Baseline session per timeframe with production gates; expect most/all candidates rejected.
3. Only after ≥1 spec passes gates on real data: `promote`, `verify-ft`, start dry-run, let it run ≥4 weeks
   before reading anything into paper results.

## 2026-11-08 — Kalshi Phase 2 (offline)

- Settlement sources verified from live listings/help centre: crypto → CF Benchmarks RTIs (60-s averages; 15M = window
  compare); commodities → Pyth 1-minute candle close; liquid oil → ICE. Encoded in `settlement_map.py` with agreement
  required between series metadata, rules text and ticker asset.
- Fixture universe (30 markets, 14 series): 11 tradeable crypto markets, 3 record-only (gold 15m, gold daily, WTI),
  the rest rejected with reasons (politics, sports, earnings, functional strike, scalar, missing source, tag denylist,
  provider conflict, provisional, missing timestamps).
- Crypto promote now compares 7 quantities with Freqtrade (synthetic run: entries 100% matched, exits 64–86%,
  stake ratio 0.95–0.98, P/L diff 4–5% of capital, fees ±5%, DD diff ≤5 pts). Tolerances documented in research.yaml.

## 2026-11-09 — Kalshi Phase 3 (offline)

- Built auth (Ed25519/RSA-PSS, known-answer tests), guarded transport (allowlist before URL/sign; only HTTP import),
  fail-closed schema verification, REST client with pagination/backoff, WebSocket client (reconnect, resubscribe,
  seq-gap resync via get_snapshot, stale watchdog, error-9 handling, bounded fan-out), integer order books,
  discovery into the registry, read-only stream session with raw-frame recording.
- 13 scripted mock-server scenarios + 10 transport/auth + 7 client/discovery tests. 192 total, all passing.
- Network from the build VM is blocked; demo-environment run is scripted for WSL (docs/WSL_SETUP.md §8).
- Housekeeping: an interrupted earlier attempt at this phase left orphan files (schema.py, events.py, a duplicate
  demo-key doc, two incompatible tests); removed so the tree holds one coherent implementation.

## 2026-11-09 — First live demo discovery: findings and fixes

- 117,581 demo markets read in ~2 min; **0 schema mismatches, 0 unknown fields** in market/series payloads.
- Bugs found against real data (fixed, pinned in tests/test_kalshi_live_regressions.py with captured payloads):
  1. Ticker-suffix asset parsing misread `KXETH` (as 'ET'+'H') and `KXSOLE` (as 'SOLE') → ~14k CF-settled ETH/SOL range
     markets wrongly rejected. Asset now comes from the settlement source link/rules (CF index id), ticker prefix only as fallback.
  2. Pyth instruments were guessed; real ones are `Metal.Index.1OZGOLD/USD`, `Metal.Index.SILVER/USD`,
     `Commodities.Index.PYTHOIL/USD`, `InterestRate.US2Y` … now read from each series' settlement-source URL.
  3. Duration used listing length; hourly ladders are listed ~1 day early. Kalshi's `series.frequency` ("hourly", …) is now authoritative.
  4. Queued 15-minute windows (strike not yet stamped) were rejected; now RECORD_ONLY `strike_pending`, re-decided on activation.
  5. Treasury yields, FX, S&P 500 / Nasdaq-100 were "asset_unparseable"; now discoverable RECORD_ONLY. Index markets name only
     "For example, Google Finance" as source → provider `unspecified`, stays record-only even if Pyth is enabled.
  6. Market listing hit a 100-page cap (100k open markets); cap raised to 1000 pages and a truncation flag is recorded.
- Correctly rejected (confirmed): sports, elections, entertainment, Exotics (multivariate combos), company KPIs filed under
  "Financials" (app ranks, subscriber counts), macro releases, DOGE ladders with strike only in text (`custom`).
- Second live pass (213k markets after raising the page cap): ETH/SOL/HYPE/BNB/XRP hourly ladders tradeable with correct CF
  indices; crypto 15-min queued windows record-only `strike_pending`; rates/S&P/Nasdaq/commodities record-only.
  Further fixes: commodity 15-min windows are listed ACTIVE a day early with a null strike (now `strike_pending`);
  Pyth window-compare wording ("is at least the close price of the 1-minute …") recognised; exchange test series
  (`KXMAXSHARDINGTEST`, filed under Crypto) rejected as `test_series`. Re-evaluation now runs in one transaction.
- Third live pass (per-series examples): added observed wordings — Pyth FX 15-min window compare, Treasury-yield 15-min
  window compare ("close yield of the 1-minute"), Pyth DJI value-at-time, end-of-day S&P/Nasdaq index value, official
  Treasury par-yield "any business day" touch markets (provider us_treasury), Hermes feed-id links. All record-only.
  CF markets quoted in a non-USD currency are refused. Deliberately still rejected: path-dependent "ever above/below"
  crypto/commodity/index markets (methodology not precise), DOGE ladders whose strike exists only in text (`custom`),
  CPI/GDP/Fed/IPO/M&A/company KPIs, GPU/DRAM compute-price indices (Ornn).

## 2026-11-09 — Phase 3 demo connection verification (user's WSL desktop, Kalshi demo)

- Auth: Ed25519 demo key loaded from outside the repo; signature self-verify OK. `kalshi limits`
  (first signed REST call) returned tier `basic`, read 200/s refill (600 burst). No production host used.
- Discovery: 233,130 markets / ~15.5k series. Current tiers: tradeable 59,380 · record_only 13,322 ·
  rejected 140,583. 252 series lookups 404 on demo (absent there). All 32 tradeable series manually
  checked against rules text: CF Benchmarks USD RTIs with matching 60-s methods.
- Stream (120 s, authenticated, read-only): 1 connect, 0 reconnects, 0 seq gaps, 0 resyncs,
  0 schema mismatches over ~31k frames; CF 5 Hz ≈ 4.8 msg/s per index, 1 Hz ≈ 1/s; 24/24 books
  valid, live subscriptions = budget 24; fan-out drops 0.
- Fixed from the first stream run: stale books retained after rotation (48 held), unread fan-out
  queue, eligibility history rewritten on every reload.
- Known, deferred: the first ranking has no liquidity data, so the first rotation (60 s) swaps all
  24 books at once and briefly holds none while new snapshots arrive. Candidate Phase 4 item:
  warm up on ticker data before the first book subscription. Startup re-evaluation takes ~70 s
  for 233k markets.
- Not exercised live: reconnect/resubscribe, seq-gap resync, stale-socket watchdog (covered by
  mock-server tests only). No order endpoints exist; none were called.

## 2026-11-10 — First bot practice run on Kalshi demo (descriptive only, not evidence of profit)

- Run: 2026-11-09 21:25 to 2026-11-10 17:43 local, practice mode, stake 10% (owner setting). 160 closed bot
  positions, 83 won. From exchange fills: $143.14 before fees, $26.60 fees, +$116.54 after fees; account went
  ~$100 to $216.53. fair BTC +$146 (52 trades, 28 won); one lock SOL long shot at about 8c paid +$45.58. favorite,
  imbalance, kmomentum and momentum were all net negative. One day, many rules, demo prices: treat as noise.
- Bugs found and fixed: (1) Transactions dropped 78 of 160 settled positions: KalshiRestClient.get_market
  returns the bare market, callers read data["market"] (also in the lab result lookup and shard lookup).
  (2) Settled P/L ignored Kalshi realized_pnl from YES/NO pairs netted on the same market. (3) The bot bought
  both sides of a market twice (two rules, seconds apart) because a just-filled order was not counted until
  the position list refreshed. Kalshi realized_pnl_dollars is before fees (matches fill math to the cent).
- 40 refusals "Not connected to the Kalshi demo account" (last 15:57): connection drops cost some trades.

## 2026-11-10 — Do the demo results hold at real-exchange prices? (descriptive, past data)

- Hypothesis: the BTC fair-value edge on demo comes from demo prices lagging the CF index, not from a real edge.
- Spot check: the same BTC window was priced at 8.9c Up on the real exchange and 19c on demo; demo volume about 1/2000th.
- Re-priced 1,764 settled lab trades (after re-settling 914 that had been voided by the result-lookup bug) at the
  real exchange's public 1-minute quotes (same tickers, same targets, same results). One trade per rule family/asset/
  market/side (versions overlap). Cents per contract after fees; neutral = close of the minute containing the entry:
  fair BTC (n=117): demo +10.2 (t 2.8) -> real +0.0 (t 0.0). All fair (n=247): +10.0 -> +1.1 (t 0.4).
  fair XRP (n=33): +20.8 -> +10.6 (t 2.0), not significant after testing about 30 rule groups. Momentum on
  SOL/XRP/DOGE was negative on both. A worst-case (minute-high ask) pricing makes every family negative.
- Learned: the demo edge is mostly demo mispricing. 1-minute quotes are too coarse to settle it, so the lab now
  scores every rule live on real-exchange quotes (polled every 2 s) and the bot skips rules that lose there.

## 2026-11-10 — Live demo feed kept dropping ("keepalive ping timeout")

- Cause 1: the whole backend shares one event loop. Re-checking ~233k markets (every 15 s and after Refresh)
  blocked it for 2-3.6 s each time. Now the per-series check is cached and the pass yields every 500 markets.
- Cause 2: a lifecycle message about an unknown market awaited a REST lookup inside the socket reader, so the
  reader stopped and Kalshi pings went unanswered. The lookup now runs in the background (one per market).
- Added aicrypto/terminal/loopwatch.py (logs where the loop was stuck if it stalls > 1.5 s) and GET /api/terminal/loop.
- Result: 5 quiet minutes with 0 stalls and 0 reconnects (before: ~57 drops in the log). 2 reconnects happened
  while the full test suite was loading the PC at the same time. test_kalshi_ws stream test now pins its clock
  to the fixture date (it had started failing only because 2026-11-09 had passed).

## 2026-11-10 — Day 1 audit, production realism and 30-day research (see reports/kalshi15_day1_audit_2026-11-10.md)

- Day 1 actual demo: 160 positions, 51.9% wins, +$143.14 before fees, +$116.54 after; top 5 trades = 166% of profit.
- Same trades at real quotes: +$20 (same minute) to -$155 (worst ask). Demo price was ~4.8c below the real ask.
- 30 days x 5 assets of real windows: no extra price feature beat the real exchange's own Kalshi price; fair value
  +1.8c neutral, -12.8c conservative on test days. Longer-timeframe filters flipped sign between train and test.
- Selection replay: ranking rules by past demo results added +0.26c (t 0.31) and switched rules 63-68% of the time.
- New offline package aicrypto/research15 (data, features, experiment, audit, realism, selection), not used by the bot.
  It lives outside aicrypto/kalshi so the "only transport.py imports HTTP" rule still holds (it calls Coinbase/Kraken).
- Feed follow-up: under load the app still froze up to 59 s on registry.sqlite writes (rollback journal, 1.8 GB file)
  and per-tick scans of 233k decisions. Registry now uses WAL + synchronous=NORMAL; the lab caches its market list
  for 30 s. Full test suite run alongside the app: 0 stalls (max 1.0 s), 0 reconnects.

## 2026-11-11 — Recorder, live shadow, 30-day validation (reports/kalshi15_realism_2026-11-11.md)

- Recorder (aicrypto/recorder) running: real-exchange quotes/books/trades/settlements, CF index + Kalshi 60-s average,
  Coinbase/Kraken. Recorded index reproduces official settlement values to ~0.08 bp (5 windows).
- 30-day historical shadow, exact rule code, 130 variants, Bonferroni z 3.36: 0 survivors at optimistic or
  conservative (+2c) fills; every family and every asset/timing/liquidity cell negative at conservative fills.
- App stability: overnight the app still froze 404 times (max 40 s) from full garbage collections over the
  ~2.7 GB registry heap. gc.freeze() after load and hourly; 15 min after: 1 stall (1.7 s), 0 reconnects.

## 2026-11-11 — Day 2 audit (reports/kalshi15_day2_audit_2026-11-11.md)

- Demo: 88 trades, 59% won, +$338.18 after fees (+18c/contract vs +4.5c Day 1); top 5 = 84% of profit.
- Same trades at recorded real books: +$112 at the real ask, +$65 conservative. Demo price below real ask in 80%.
- Rules did not improve (fixed); the bot used fewer losing rules. Live shadow at realistic execution: all families <= ~0.
- Bot & Strategies page simplified: status line, 3 numbers, one profit chart, 6 strategy rows with a verdict; details folded.
