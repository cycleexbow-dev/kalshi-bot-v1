# Environment Audit

Two environments matter for this project. The **build environment** is where the
code was written and tested. The **target environment** is your Windows desktop
with WSL Ubuntu, where Docker, Freqtrade dry-run and the dashboard will run.

## Build environment (where this repo was developed and tested)

| Item | Result |
|---|---|
| OS | Linux x86_64 (cloud VM), 2 vCPU, 7.8 GB RAM, no swap |
| Python | 3.13.18 |
| pandas / numpy | 3.0.5 / 2.5.3 |
| pyarrow | 26.0.1 (installed) |
| fastapi / uvicorn / pydantic | 0.162.2 / installed / 2.13.5 |
| pytest | 9.1.1 |
| Freqtrade | **2026.10** installed from PyPI; `freqtrade --version` works |
| TA-Lib | 0.8.3 (wheel install, no manual C build needed) |
| ccxt | 4.5.92 |
| Docker | Client 29.9.2 present, **daemon not running** (no socket) |
| Exchange network | **Blocked** (`api.binance.com` unreachable); all tests use synthetic/cached data |

Consequences:

- Everything in the research layer (data loading, backtesting, walk-forward,
  leakage checks, tracker, gates, report, dashboard) was tested end-to-end here.
- Exported Freqtrade strategy files were verified by running Freqtrade's **own**
  `backtesting`, `lookahead-analysis` and `recursive-analysis` commands against
  synthetic candles written in Freqtrade's feather format.
- Live market data download and the Docker dry-run bot were **not** exercised
  here. The commands are scripted in `scripts/` and `Makefile`; run them in WSL.

## Target environment (your desktop) — checklist

Run `scripts/wsl_audit.sh` inside WSL. It verifies and prints each item:

1. WSL2 kernel (`uname -r` contains `microsoft`), Ubuntu 22.04/24.04.
2. Docker Desktop with WSL integration enabled for the Ubuntu distro, **or**
   docker-ce installed natively in WSL. `docker compose version` must work.
3. `.wslconfig` in `%UserProfile%` limiting WSL memory so Windows stays
   responsive on a 16 GB machine (recommended: `memory=8GB`, `swap=4GB`,
   `processors=4`). See `docs/WSL_SETUP.md`.
4. Python 3.11–3.13 inside WSL with `venv` (research layer runs on the host
   Python; Freqtrade runs inside Docker).
5. Free disk: ~5 GB (Freqtrade image ~1.5 GB, 3 pairs × 3 timeframes × 3 years of
   candles ≈ 150 MB in feather, experiment DB grows slowly).
6. Outbound HTTPS to the exchange public API (Binance, or Kraken as fallback;
   no API keys needed for public candles or dry-run).

## Resource bounds adopted (16 GB desktop)

- Research runs are single-process by default (`AICRYPTO_WORKERS=1`, max 2).
- Candidate budget per research session: 40 candidates (configurable), hard
  wall-clock cap 30 min.
- Candle data loaded per pair/timeframe is capped at 3 years; frames are
  float32 where precision allows; one pair/timeframe is resident at a time
  during walk-forward.
- Freqtrade container limited to 2 GB RAM / 1.5 CPU in `docker-compose.yml`.
- A soft RSS limit (`resource.RLIMIT_AS`) is set on research processes so a
  runaway search fails fast instead of swapping the machine.
