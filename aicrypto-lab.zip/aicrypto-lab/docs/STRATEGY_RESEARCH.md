# 15-minute Kalshi markets: research notes (2026-11-09)

Scope: Kalshi 15-minute up/down windows only — crypto (BTC, ETH, SOL, XRP, DOGE, HYPE, BNB,
NEAR, ZEC) and commodities (gold, silver, copper, WTI).

## How the markets work
- **Crypto (`KX…15M`)**: a new window every 15 minutes, 24/7. YES if the simple average of the
  60 one-second CF Benchmarks index prints before the close is **at least** the target; the
  target is the previous window's final average. Taker fee 0.07 × C × P × (1−P); no maker fee
  on the plain-quadratic series. Settlement usually within seconds.
- **Commodities (`KXGOLD15M`, `KXSILVER15M`, `KXCOPPER15M`, WTI 15m)**: YES if the Pyth 1-minute
  candle close at the end of the window is at or above the stamped target. Gold launched in
  August 2026 and quickly out-traded 15-minute ether. The app has no licensed Pyth feed
  (owner decision), so commodity rules use Kalshi prices/order book only.

## What published tests found (paraphrased; numbers are the authors')
| Idea | Finding |
|---|---|
| Buy the leading side and hold (BTC 15m, ~6,300 windows) | Leader wins a little more often than its mid price implies, but at the ask after fees it is about break-even to slightly negative at every entry time. |
| "Sure thing" 90–99¢ favourites late | Win rate ≈ price; no reliable edge after fees. |
| Final-minute favourites, selected using how much of the 60-s average is already fixed | The one positive result: about +1.9¢/contract after fees on ~540 final-minute fills in a 14-day tape; blind final-minute buying was not significant; the authors' live paper record was still negative on a tiny sample. |
| Resting (maker) bids on favourites | Large losses (~−5.8¢/contract) from adverse selection: orders fill when the favourite is about to stop being one. |
| Fading extremes (mean reversion) | Lost money in historical simulation even with regime filters. |
| 3-minute index momentum, take the side it moved toward ≤ 65¢ | Run publicly by one site as a pre-registered strategy; no independent confirmation. |
| Kalshi-wide (300k contracts, academic) | Clear favourite–longshot bias: cheap contracts lose heavily, expensive ones earn small positive returns; takers do worse than makers. |

**Bottom line:** edges in these markets, if any, are around a cent per contract — the same size
as the fee. Most popular rules lose after fees. That is why the lab only counts taker fills at
the real ask with fees rounded up, requires confirmation on fresh trades, and corrects for
trying many ideas.

## Rules the lab tests (fixed parameters, never tuned on results)
| Rule | Markets | Uses settlement index |
|---|---|---|
| Final-seconds lock-in (fair value from the fixed share of the 60-s average) | crypto | yes |
| Mid-window fair value (volatility model vs ask + fee) | crypto | yes |
| 3-minute index momentum, price cap | crypto | yes |
| Favourite band late in the window (favourite–longshot) | crypto + commodities | no |
| Top-of-book imbalance | crypto + commodities | no |
| Kalshi price momentum | crypto + commodities | no |

Maker/resting strategies are excluded: their fills cannot be simulated honestly from live
quotes (the research shows adverse selection dominates).

## Important limitation
The lab currently reads **demo-exchange** prices. Demo order books and traders differ from the
real exchange, so a rule proven on demo prices may not hold with real money. Before any real
account is considered, the same rules should be proven on the real exchange's public market
data (read-only, no keys) — that needs the owner's go-ahead.

## Sources
- Bot for Kalshi, "Kalshi 15-Minute Bitcoin: How KXBTC15M Works & Strategy Data" — botforkalshi.com/blog/kalshi-15-minute-bitcoin-markets
- PredictionMarketsPicks, "Kalshi BTC 15-Min Strategy: The 12:30 Rule vs Our Tape" — predictionmarketspicks.com/articles/kalshi-bitcoin-15-minute-last-60-seconds
- PredictionMarketsPicks, "Kalshi 15-Minute Bitcoin Strategy: What Our Tools Read" — predictionmarketspicks.com/articles/kalshi-15-minute-bitcoin-strategy
- Turbine, "Kalshi BTC 15-minute markets mean-revert…" — turbinefi.com/research
- Bürgi, Deng & Whelan, "Makers and Takers: The Economics of the Kalshi Prediction Market" (CEPR DP 20631 / CESifo WP 12122)
- Cointelegraph / Crypto.news coverage of 15-minute gold volume (Oct 2026); Robinhood/Kalshi silver & gold 15-min contract terms (Pyth 1-minute candle settlement)
