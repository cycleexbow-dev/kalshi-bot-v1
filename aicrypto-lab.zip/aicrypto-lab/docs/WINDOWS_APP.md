# AI Crypto Lab — Windows desktop app

Double-click **AI Crypto Lab** on the desktop → a startup window checks WSL, starts (or
reuses) the backend inside Ubuntu, waits for a real health check, then shows the trading
terminal in a native window (Microsoft Edge WebView2). No terminal, no browser, no typing.

```
 Windows                                   WSL Ubuntu (~/aicrypto-lab)
 ┌──────────────────────────┐   wsl.exe    ┌──────────────────────────────────────┐
 │ AI Crypto Lab.exe        │ ───────────▶ │ scripts/start_ui.sh                  │
 │  pywebview + WebView2    │              │  └─ aicrypto ui  (FastAPI, 127.0.0.1) │
 │  only calls /api/health  │ ◀─ 127.0.0.1:8765 (WSL localhost forwarding) ────────│
 └──────────────────────────┘              │  registry · read-only live stream    │
                                           └──────────────────────────────────────┘
```

## Build (one time, and after launcher updates)

Prerequisites on Windows: WSL with Ubuntu (already set up), **Python 3.12 for Windows**
(python.org installer with the *py launcher* ticked, or let the build install it with
winget), and the WebView2 runtime (preinstalled on Windows 10/11).

In Ubuntu:

```bash
cd ~/aicrypto-lab && bash windows/build_from_wsl.sh
# no Windows Python yet?  bash windows/build_from_wsl.sh --install-python
```

What it does (`windows/build.ps1`, native Windows PowerShell + Python — the `.exe` is not
built inside Linux):

1. Copies `windows/launcher/*` to `%LOCALAPPDATA%\AICryptoLab\src` (PyInstaller cannot build
   from a `\\wsl$` path).
2. Creates a Windows venv in `%LOCALAPPDATA%\AICryptoLab\build\venv` and installs the pinned
   `windows/requirements-launcher.txt` (pywebview 6.2.1, pythonnet 3.2.1, PyInstaller 6.22.3).
3. Runs a quick check of the launcher logic, then PyInstaller (`--windowed`, one-folder build,
   app icon).
4. **Tests the output**: runs `AI Crypto Lab.exe --selftest` (no window): bundled files present,
   pywebview loads, `wsl.exe` found, distro list readable; and checks the file is a real
   Windows PE executable (`MZ` header).
5. Installs to `%LOCALAPPDATA%\Programs\AICryptoLab\` and creates **Desktop\AI Crypto Lab.lnk**.

Disk and memory use have not been measured on Windows yet; record them after the first build
(Task Manager: "AI Crypto Lab" + "Microsoft Edge WebView2"; in Ubuntu: `ps -o rss= -p $(cat ~/aicrypto-lab/run/ui.pid)`).

## Start

Double-click **AI Crypto Lab**. The first start after a reboot takes longer while WSL wakes
up and the backend loads the financial markets (a progress bar shows inside the app; the
full 233k-market re-check took ~70 s on your PC, and the terminal loads only the financial
subset, so expect less). Live market data connects automatically when the demo
key is configured (`scripts/kalshi_demo_setup.sh`). **Opening the app never places orders or
starts automation.**

## Stop

Close the window. If this launcher started the backend, it stops it (`scripts/stop_ui.sh`,
graceful SIGTERM). If the backend was already running before you opened the app, it is left
running. **Safety & System → Shut down backend and exit** stops it in every case.

From Ubuntu you can also run `bash scripts/start_ui.sh` / `bash scripts/stop_ui.sh` and open
http://127.0.0.1:8765 in a browser.

## Logs and settings

| What | Where |
|---|---|
| Launcher log | `%LOCALAPPDATA%\AICryptoLab\logs\launcher.log` (rotating) |
| Build self-test report | `%LOCALAPPDATA%\AICryptoLab\logs\selftest.json` |
| Backend log | `~/aicrypto-lab/logs/ui.log` (rotates at 5 MB) — also `\\wsl.localhost\Ubuntu\root\aicrypto-lab\logs\ui.log` |
| Launcher settings | `%LOCALAPPDATA%\AICryptoLab\launcher.json` — `distro`, `project_dir`, `port`, `start_timeout_s`, `stop_backend_on_exit` |

Both log locations open from buttons in the app (startup errors and Safety & System).

## Problems the launcher detects

| Situation | What you see |
|---|---|
| WSL missing/disabled | "WSL is not installed or not enabled" + `wsl --install` |
| No Ubuntu distro | "No Ubuntu distribution found in WSL" |
| Project not in `~/aicrypto-lab` | "AI Crypto Lab is not installed in WSL" |
| `.venv` missing | "Python environment missing" + setup command |
| Port 8765 used by another program | "Port is used by another program" (change `port` in launcher.json) |
| Backend already running | Reuses it — no duplicate process |
| Backend crashes while starting | "The backend stopped while starting" + last 40 log lines |
| No answer in 120 s | "The backend did not answer in time" + log tail |
| Second double-click | "AI Crypto Lab is already open." (single-instance lock) |

## Why not Electron

pywebview uses the WebView2 runtime that Windows already ships, so the launcher is a small
Python program (no bundled Chromium, ~10× smaller, lower RAM). The UI is the same web app the
backend serves, so it also works in any browser at http://127.0.0.1:8765.
