"""Phase D (EXPERIMENTAL, never wired to the bot): settlement-aware final-minute model.

Crypto 15-minute windows settle YES when the simple average A of the 60 one-second CF Benchmarks
prints before the close is >= the target K. Inside the final minute part of that average is already
fixed. With k prints known (sum Sk) and n = 60 - k still to come, the remaining prints are modelled
as a driftless random walk from the latest value S with per-second volatility sigma:

    E[A]   = (Sk + n*S) / 60
    sd[A]  = S * sigma * sqrt(n(n+1)(2n+1)/6) / 60
    P(YES) = F((E[A] - K) / sd[A])

F is a Student-t with `nu` degrees of freedom scaled to unit variance (fat tails; nu=inf gives the
normal model the live lab uses). sigma is the EWMA of 1-second log returns over the previous minutes.

`evaluate` replays recorded data: at fixed seconds-before-close it compares the model probability
with the executable real-exchange ask (book recorded LATENCY_S later, DEPTH_SHARE of displayed size,
2c price limit, taker fee) and scores against the official result. It also checks the model's
expected average against the actual settlement value, which tests the averaging logic directly.
Nothing here can trade; promotion would require the owner's approval after out-of-sample validation.
"""
from __future__ import annotations

import math
import statistics
from typing import Any, Dict, List, Optional, Sequence

from ..recorder.shadow import DEPTH_SHARE, SLIPPAGE_LIMIT, simulate_fill
from .recordings import Recorded, one_per_second

LATENCY_S = 1.0
LEADS_S = (50, 40, 30, 20, 10, 5)
INDEX = {"BTC": "BRTI", "SOL": "SOLUSD_RTI", "ETH": "ETHUSD_RTI", "XRP": "XRPUSD_RTI", "DOGE": "DOGEUSD_RTI"}


def _t_cdf(x: float, nu: float) -> float:
    """CDF of a unit-variance Student-t (numerical; nu > 2). nu=inf -> normal."""
    if math.isinf(nu):
        return 0.5 * (1 + math.erf(x / math.sqrt(2)))
    s = math.sqrt(nu / (nu - 2))            # scale so the variance is 1
    z = x * s
    if z == 0:
        return 0.5
    # regularized incomplete beta via continued fraction (Numerical Recipes betacf)
    a, b = nu / 2, 0.5
    xx = nu / (nu + z * z)

    def betacf(a, b, x):
        qab, qap, qam = a + b, a + 1, a - 1
        c, d = 1.0, 1 - qab * x / qap
        d = 1 / (d if abs(d) > 1e-30 else 1e-30)
        h = d
        for m in range(1, 200):
            m2 = 2 * m
            aa = m * (b - m) * x / ((qam + m2) * (a + m2))
            d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-30 else 1e-30)
            c = 1 + aa / c if abs(c) > 1e-30 else 1e-30
            h *= d * c
            aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
            d = 1 + aa * d; d = 1 / (d if abs(d) > 1e-30 else 1e-30)
            c = 1 + aa / c if abs(c) > 1e-30 else 1e-30
            de = d * c
            h *= de
            if abs(de - 1) < 1e-12:
                break
        return h
    lbeta = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    ib = math.exp(a * math.log(xx) + b * math.log(1 - xx) - lbeta) * betacf(a, b, xx) / a
    return 1 - 0.5 * ib if z > 0 else 0.5 * ib


def ewma_sigma(per_s: Dict[int, float], end: int, lookback: int = 600, halflife: float = 120.0) -> Optional[float]:
    secs = [s for s in range(end - lookback, end) if s in per_s and (s - 1) in per_s]
    if len(secs) < 60:
        return None
    lam = math.log(2) / halflife
    num = den = 0.0
    for s in secs:
        r = math.log(per_s[s] / per_s[s - 1])
        w = math.exp(-lam * (end - s))
        num += w * r * r
        den += w
    return math.sqrt(num / den) if den > 0 else None


def prob_yes(known: Sequence[float], spot: float, target: float, sigma: float, nu: float = 5.0) -> Dict[str, float]:
    k = len(known)
    n = max(0, 60 - k)
    mean = (sum(known) + n * spot) / 60
    if n == 0:
        return {"p": 1.0 if mean >= target else 0.0, "mean": mean, "sd": 0.0}
    sd = spot * sigma * math.sqrt(n * (n + 1) * (2 * n + 1) / 6) / 60
    if sd <= 0:
        return {"p": 1.0 if mean >= target else 0.0, "mean": mean, "sd": 0.0}
    return {"p": _t_cdf((mean - target) / sd, nu), "mean": mean, "sd": sd}


def fee1(p: float) -> float:
    return math.ceil(0.07 * p * (1 - p) * 100 - 1e-9) / 100 if 0 < p < 1 else 0.0


def evaluate(rec: Recorded, assets: Sequence[str] = ("BTC", "SOL"), edge: float = 0.03, nu: float = 5.0) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    avg_err: List[float] = []
    for t, s in rec.settled.items():
        m = rec.meta.get(t) or {}
        asset = m.get("asset")
        if asset not in assets or m.get("strike") is None or not m.get("close_ts"):
            continue
        C, K = float(m["close_ts"]), float(m["strike"])
        idx = INDEX[asset]
        per_s = one_per_second(rec.cf.get(idx, []), C - 900, C)
        if s.get("settle_value"):
            win = [per_s[x] for x in range(int(C) - 60, int(C)) if x in per_s]
            if len(win) >= 55:
                avg_err.append((sum(win) / len(win) - float(s["settle_value"])) / float(s["settle_value"]) * 1e4)
        bs = rec.books.get(t)
        for lead in LEADS_S:
            now = int(C - lead)
            known = [per_s[x] for x in range(int(C) - 60, now) if x in per_s]
            expected_known = max(0, now - (int(C) - 60))
            last = max((x for x in per_s if x < now), default=None)
            sigma = ewma_sigma(per_s, now)
            row: Dict[str, Any] = {"ticker": t, "asset": asset, "lead": lead, "result": s["result"], "status": "ok"}
            if last is None or now - last > 3 or sigma is None or len(known) < expected_known - 2:
                row["status"] = "missing_index_data"            # recorded gap: no estimate is substituted
                rows.append(row)
                continue
            pr = prob_yes(known, per_s[last], K, sigma, nu)
            row.update(p=pr["p"], mean=pr["mean"], sd=pr["sd"])
            if bs is None or bs.before(now) is None:
                row["status"] = "missing_book"
                rows.append(row)
                continue
            i = bs.before(now)
            ya = bs.asks(i, "yes")
            na = bs.asks(i, "no")
            row["ask_yes"] = ya[0][0] if ya else None
            row["ask_no"] = na[0][0] if na else None
            row["mid"] = ((ya[0][0] + (1 - na[0][0])) / 2) if (ya and na) else None
            best = None
            for side, prob, asks in (("yes", pr["p"], ya), ("no", 1 - pr["p"], na)):
                if asks:
                    e = prob - asks[0][0] - fee1(asks[0][0])
                    if e >= edge and (best is None or e > best[1]):
                        best = (side, e, asks[0][0])
            if best:
                side, e, ask = best
                j = bs.at_or_after(now + LATENCY_S)
                fill = simulate_fill(bs.asks(j, side), 1, ask + SLIPPAGE_LIMIT, DEPTH_SHARE) if j is not None else {"filled": 0}
                row.update(side=side, edge=e, signal_ask=ask, fill=fill)
                if fill.get("filled"):
                    won = 1.0 if s["result"] == side else 0.0
                    row["net"] = fill["filled"] * won - fill["cost"] - fill["fee"]
            rows.append(row)
    ok = [r for r in rows if r["status"] == "ok" and r.get("mid") is not None]
    y = [1.0 if r["result"] == "yes" else 0.0 for r in ok]
    brier = lambda ps: statistics.fmean((p - t) ** 2 for p, t in zip(ps, y)) if y else None  # noqa: E731
    traded = [r for r in rows if "net" in r]
    return {"windows": len({r["ticker"] for r in rows}), "decisions": len(rows), "usable": len(ok),
            "missing": {k: sum(1 for r in rows if r["status"] == k) for k in ("missing_index_data", "missing_book")},
            "brier_model": brier([r["p"] for r in ok]), "brier_kalshi_mid": brier([r["mid"] for r in ok]),
            "signals": sum(1 for r in rows if "side" in r), "filled": len(traded),
            "net_c_per_contract": 100 * statistics.fmean(r["net"] for r in traded) if traded else None,
            "settle_avg_error_bp": {"n": len(avg_err), "median_abs": statistics.median(abs(e) for e in avg_err) if avg_err else None},
            "rows": rows}
