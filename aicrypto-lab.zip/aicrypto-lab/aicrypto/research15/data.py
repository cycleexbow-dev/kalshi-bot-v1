"""Download and cache historical data for 15-minute window research (public, read-only).

* Kalshi REAL exchange: settled 15-minute markets (target, result, settlement average) and their
  1-minute candles (yes bid/ask OHLC) via the existing guarded GET-only KalshiRestClient, unsigned.
* Coinbase: 1-minute BTC/ETH/SOL/XRP/DOGE-USD candles (public endpoint, full history).
* Kraken: 1-minute candles (public endpoint; only the last ~12 hours are offered).

Limitations, reported rather than assumed away: the official CF Benchmarks settlement index is not
available historically (only each window's final 60-second average, `expiration_value`), and neither
is historical order-book depth (candles carry best bid/ask only).
"""
from __future__ import annotations

import asyncio
import gzip
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx

SERIES = {"BTC": "KXBTC15M", "ETH": "KXETH15M", "SOL": "KXSOL15M", "XRP": "KXXRP15M", "DOGE": "KXDOGE15M"}
COINBASE = {"BTC": "BTC-USD", "ETH": "ETH-USD", "SOL": "SOL-USD", "XRP": "XRP-USD", "DOGE": "DOGE-USD"}
KRAKEN = {"BTC": "XBTUSD", "ETH": "ETHUSD", "SOL": "SOLUSD", "XRP": "XRPUSD", "DOGE": "XDGUSD"}
COINBASE_URL = "https://api.exchange.coinbase.com/products/{p}/candles"
KRAKEN_URL = "https://api.kraken.com/0/public/OHLC"


def cache_dir(root: Path) -> Path:
    d = Path(root) / "user_data" / "kalshi" / "research15"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _save(path: Path, obj: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(tmp, "wt") as f:
        json.dump(obj, f)
    tmp.replace(path)


def load(path: Path) -> Any:
    with gzip.open(path, "rt") as f:
        return json.load(f)


def _ts(iso: str) -> float:
    return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()


async def kalshi_windows(asset: str, days: int, client=None) -> List[Dict[str, Any]]:
    """Settled real-exchange windows of one asset over the last `days` days, oldest first."""
    from ..kalshi.client import KalshiRestClient
    own = client is None
    client = client or KalshiRestClient("production", signer=None, public=True, requests_per_second=4.0, priority="background")
    try:
        since = int(time.time() - days * 86400)
        rows = await client.list_markets(status="settled", series_ticker=SERIES[asset], min_close_ts=since, max_pages=50)
    finally:
        if own:
            await client.aclose()
    out = []
    for m in rows:
        if m.get("result") not in ("yes", "no") or m.get("floor_strike") is None:
            continue
        out.append({"ticker": m["ticker"], "asset": asset, "open_ts": _ts(m["open_time"]), "close_ts": _ts(m["close_time"]),
                    "strike": float(m["floor_strike"]), "result": m["result"],
                    "settle": float(m["expiration_value"]) if m.get("expiration_value") not in (None, "") else None})
    out.sort(key=lambda r: r["close_ts"])
    return out


async def kalshi_candles(windows: List[Dict[str, Any]], client=None, batch: int = 20) -> Dict[str, List[Dict[str, Any]]]:
    """1-minute candles (yes bid/ask/price) for each window, keyed by ticker."""
    from ..kalshi.client import KalshiRestClient
    own = client is None
    client = client or KalshiRestClient("production", signer=None, public=True, requests_per_second=4.0, priority="background")
    out: Dict[str, List[Dict[str, Any]]] = {}
    try:
        for i in range(0, len(windows), batch):
            chunk = windows[i:i + batch]
            start = int(min(w["open_ts"] for w in chunk)) - 60
            end = int(max(w["close_ts"] for w in chunk)) + 60
            try:
                data = await client.get_candlesticks_multi([w["ticker"] for w in chunk], start, end, 1)
            except Exception:
                await asyncio.sleep(2)
                data = await client.get_candlesticks_multi([w["ticker"] for w in chunk], start, end, 1)
            for m in data.get("markets", []):
                out[m.get("market_ticker") or m.get("ticker")] = [_candle(c) for c in m.get("candlesticks", [])]
    finally:
        if own:
            await client.aclose()
    return out


def _f(x: Any) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _candle(c: Dict[str, Any]) -> Dict[str, Any]:
    ya, yb, pr = c.get("yes_ask") or {}, c.get("yes_bid") or {}, c.get("price") or {}
    return {"end": c["end_period_ts"], "ask_o": _f(ya.get("open_dollars")), "ask_h": _f(ya.get("high_dollars")),
            "ask_c": _f(ya.get("close_dollars")), "bid_c": _f(yb.get("close_dollars")), "bid_l": _f(yb.get("low_dollars")),
            "bid_o": _f(yb.get("open_dollars")), "vol": _f(c.get("volume_fp")), "last": _f(pr.get("close_dollars"))}


async def coinbase_minutes(asset: str, start_ts: int, end_ts: int) -> List[List[float]]:
    """[[start_ts, low, high, open, close, volume], ...] ascending. A candle covers [start, start+60)."""
    rows: Dict[int, List[float]] = {}
    async with httpx.AsyncClient(timeout=20, headers={"User-Agent": "aicrypto-lab-research"}) as http:
        t = start_ts - start_ts % 60
        while t < end_ts:
            e = min(end_ts, t + 300 * 60)
            params = {"granularity": 60, "start": datetime.fromtimestamp(t, timezone.utc).isoformat(),
                      "end": datetime.fromtimestamp(e, timezone.utc).isoformat()}
            for attempt in range(4):
                r = await http.get(COINBASE_URL.format(p=COINBASE[asset]), params=params)
                if r.status_code == 200:
                    break
                await asyncio.sleep(1 + attempt * 2)
            r.raise_for_status()
            for row in r.json():
                rows[int(row[0])] = [float(x) for x in row]
            t = e
            await asyncio.sleep(0.15)
    return [rows[k] for k in sorted(rows)]


async def kraken_minutes(asset: str) -> List[List[float]]:
    """Last ~12 h of Kraken 1-minute candles: [[start_ts, open, high, low, close, vwap, volume], ...]."""
    async with httpx.AsyncClient(timeout=20) as http:
        r = await http.get(KRAKEN_URL, params={"pair": KRAKEN[asset], "interval": 1})
        r.raise_for_status()
        res = r.json()["result"]
        key = next(k for k in res if k != "last")
        return [[float(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5]), float(x[6])] for x in res[key]]


async def build(root: Path, assets: List[str], days: int, progress=print) -> Dict[str, Any]:
    d = cache_dir(root)
    report: Dict[str, Any] = {"built_at": time.time(), "days": days, "assets": {}}
    for a in assets:
        progress(f"{a}: settled windows")
        wins = await kalshi_windows(a, days)
        progress(f"{a}: {len(wins)} windows; Kalshi 1-minute candles")
        kc = await kalshi_candles(wins)
        start = int(wins[0]["open_ts"]) - 5 * 3600 if wins else int(time.time()) - days * 86400
        progress(f"{a}: Coinbase 1-minute candles")
        cb = await coinbase_minutes(a, start, int(time.time()))
        try:
            kr = await kraken_minutes(a)
        except Exception as e:  # optional: only 12 h exist anyway
            kr, _ = [], progress(f"{a}: Kraken unavailable ({type(e).__name__})")
        _save(d / f"{a}_windows.json.gz", wins)
        _save(d / f"{a}_kalshi_candles.json.gz", kc)
        _save(d / f"{a}_coinbase.json.gz", cb)
        _save(d / f"{a}_kraken.json.gz", kr)
        report["assets"][a] = {"windows": len(wins), "with_candles": sum(1 for w in wins if kc.get(w["ticker"])),
                               "coinbase_minutes": len(cb), "kraken_minutes": len(kr)}
        progress(f"{a}: {report['assets'][a]}")
    _save(d / "manifest.json.gz", report)
    return report


if __name__ == "__main__":
    import sys
    root = Path(__file__).resolve().parents[2]
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 21
    assets = sys.argv[2].split(",") if len(sys.argv) > 2 else list(SERIES)
    print(json.dumps(asyncio.run(build(root, assets, days)), indent=1))
