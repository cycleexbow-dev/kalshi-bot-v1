"""Does choosing rules by their past results help, or is it chasing noise? (selection audit)

Replays the lab's paper trades in time order. For each market, the rules that fired first are the
candidates the bot would have chosen between. A policy may use only results of windows that had
already CLOSED before the decision (no lookahead). We compare the forward per-contract result of the
policy's pick with picking uniformly among the eligible candidates, and measure how often the
"best" rule for an asset changes (switching).
"""
from __future__ import annotations

import math
import sqlite3
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

Record = Tuple[int, float, float]   # n, mean, t


def _rec(xs: List[float]) -> Record:
    n = len(xs)
    if n == 0:
        return 0, 0.0, 0.0
    m = statistics.fmean(xs)
    if n < 2:
        return n, m, 0.0
    sd = statistics.stdev(xs)
    return n, m, (m / (sd / math.sqrt(n)) if sd > 0 else 0.0)


def policy_old(cands: List[Dict[str, Any]], rec: Dict[str, Record], min_n: int = 10) -> Optional[Dict[str, Any]]:
    """Day-1 bot: skip rules with >= min_n results and mean <= 0; prefer the highest mean (n >= min_n)."""
    ok = [c for c in cands if not (rec.get(c["cid"], (0, 0, 0))[0] >= min_n and rec[c["cid"]][1] <= 0)]
    if not ok:
        return None
    return sorted(ok, key=lambda c: (-(rec.get(c["cid"], (0, 0, 0))[1] if rec.get(c["cid"], (0, 0, 0))[0] >= min_n else 0.0), c["cid"]))[0]


def policy_t(cands: List[Dict[str, Any]], rec: Dict[str, Record], min_n: int = 10) -> Optional[Dict[str, Any]]:
    """Current bot (demo record only): same skip, prefer the highest t."""
    ok = [c for c in cands if not (rec.get(c["cid"], (0, 0, 0))[0] >= min_n and rec[c["cid"]][1] <= 0)]
    if not ok:
        return None
    return sorted(ok, key=lambda c: (-(rec.get(c["cid"], (0, 0, 0))[2] if rec.get(c["cid"], (0, 0, 0))[0] >= min_n else 0.0), c["cid"]))[0]


def replay(trades: List[Dict[str, Any]], policy: Callable, min_n: int = 10, settle_lag_s: float = 60.0,
           fire_gap_s: float = 1.5) -> Dict[str, Any]:
    """trades: cid, family, asset, ticker, t_entry, close_ts, pnl (per contract, after fee)."""
    by_ticker: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for t in trades:
        by_ticker[t["ticker"]].append(t)
    markets = sorted(by_ticker.items(), key=lambda kv: min(x["t_entry"] for x in kv[1]))
    hist = sorted(trades, key=lambda t: t["close_ts"])
    picks, uniform, skipped_fwd, kept_fwd, chosen_by_asset = [], [], [], [], defaultdict(list)
    for ticker, ts in markets:
        t0 = min(x["t_entry"] for x in ts)
        cands = [x for x in ts if x["t_entry"] - t0 <= fire_gap_s]
        known: Dict[str, List[float]] = defaultdict(list)
        for h in hist:                                   # only windows closed (and settled) before the decision
            if h["close_ts"] + settle_lag_s > t0:
                break
            known[h["cid"]].append(h["pnl"])
        rec = {c["cid"]: _rec(known.get(c["cid"], [])) for c in cands}
        ok = [c for c in cands if not (rec[c["cid"]][0] >= min_n and rec[c["cid"]][1] <= 0)]
        for c in cands:
            (kept_fwd if c in ok else skipped_fwd).append(c["pnl"])
        if not ok:
            continue
        p = policy(cands, rec, min_n)
        picks.append(p["pnl"])
        uniform.append(statistics.fmean(c["pnl"] for c in ok))
        chosen_by_asset[p["asset"]].append(p["cid"])
    switches = sum(sum(1 for a, b in zip(v, v[1:]) if a != b) for v in chosen_by_asset.values())
    decisions = sum(len(v) for v in chosen_by_asset.values())
    return {"markets": len(picks), "pick_mean": statistics.fmean(picks) if picks else None,
            "uniform_mean": statistics.fmean(uniform) if uniform else None,
            "pick_minus_uniform": (statistics.fmean(picks) - statistics.fmean(uniform)) if picks else None,
            "pick_t": _rec(picks)[2], "diff_t": _rec([a - b for a, b in zip(picks, uniform)])[2],
            "kept_forward_mean": statistics.fmean(kept_fwd) if kept_fwd else None, "kept_n": len(kept_fwd),
            "skipped_forward_mean": statistics.fmean(skipped_fwd) if skipped_fwd else None, "skipped_n": len(skipped_fwd),
            "switch_rate": switches / max(1, decisions - len(chosen_by_asset)),
            "distinct_rules_used": len({c for v in chosen_by_asset.values() for c in v})}


def load_lab(path: Path) -> List[Dict[str, Any]]:
    c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    q = ("SELECT t.cid, c.family, c.asset, t.ticker, t.t_entry, t.close_ts, CAST(t.pnl AS REAL) FROM trades t JOIN candidates c USING(cid) "
         "WHERE t.result IN ('yes','no') ORDER BY t.t_entry")
    return [dict(zip(("cid", "family", "asset", "ticker", "t_entry", "close_ts", "pnl"), r)) for r in c.execute(q)]
