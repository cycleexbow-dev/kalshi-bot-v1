"""Would the demo trades have looked the same on the REAL exchange? (shadow re-pricing, never executions)

For each actual demo position we look up the real exchange's 1-minute candles for the same market
(same ticker, target and result) and price the same side and size three ways:

* prev_close  - ask at the close of the last finished minute before entry (up to 60 s stale: optimistic)
* same_close  - ask at the close of the minute that contains the entry (neutral)
* worst       - highest ask during the minute that contains the entry (conservative: latency / slippage)

Fees are recomputed at the real price (Kalshi taker fee, rounded up). Historical order-book depth is
not published, so size is assumed fillable at the top-of-book price; that is a stated limitation.
These are SHADOW numbers: they are never presented as executions.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional


def taker_fee(contracts: float, price: float) -> float:
    if not (0 < price < 1) or contracts <= 0:
        return 0.0
    return math.ceil(0.07 * contracts * price * (1 - price) * 100 - 1e-9) / 100


def ask_for(side: str, c: Dict[str, Any], how: str) -> Optional[float]:
    if side == "yes":
        v = c.get("ask_h") if how == "worst" else c.get("ask_c")
    else:
        b = c.get("bid_l") if how == "worst" else c.get("bid_c")
        v = (1 - b) if b is not None else None
    return v if (v is not None and 0.01 <= v <= 0.99) else None


def reprice(trade: Dict[str, Any], candles: List[Dict[str, Any]], result: Optional[str]) -> Dict[str, Any]:
    """trade: side, entry_ts, contracts, demo_price. Returns real-price shadow P/L per method."""
    out: Dict[str, Any] = {"ticker": trade["ticker"], "available": False}
    if not candles or result not in ("yes", "no"):
        return out
    te = trade["entry_ts"]
    prev = [c for c in candles if c["end"] <= te]
    cur = [c for c in candles if c["end"] > te][:1]
    side, n = trade["side"], float(trade["contracts"])
    win = 1.0 if side == result else 0.0
    for name, c, how in (("prev_close", prev[-1] if prev else None, "close"), ("same_close", cur[0] if cur else None, "close"),
                         ("worst", cur[0] if cur else None, "worst")):
        a = ask_for(side, c, how) if c else None
        if a is None:
            out[name] = None
            continue
        out[name] = {"ask": a, "net": n * (win - a) - taker_fee(n, a)}
    out["available"] = any(out.get(k) for k in ("prev_close", "same_close", "worst"))
    out["demo_price"] = float(trade["demo_price"])
    if out.get("same_close"):
        out["real_minus_demo"] = out["same_close"]["ask"] - out["demo_price"]
    return out
