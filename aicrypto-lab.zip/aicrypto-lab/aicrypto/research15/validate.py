"""Phase C: validate the rule families on real-exchange prices, chronologically out of sample.

    python -m aicrypto.research15.validate

Protocol: the first TRAIN_FRAC of time selects variants (positive train mean under CONSERVATIVE
fills); the remaining time tests them. A variant counts as surviving only if its TEST mean under
conservative fills is positive AND its daily-clustered t clears a Bonferroni threshold for the number
of variants tried. Reaching any trade count alone never qualifies a rule.
"""
from __future__ import annotations

import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

from . import data as Dd
from .replay import REPLAYABLE, day, replay, stats

TRAIN_FRAC = 0.6
ALPHA = 0.05


def _z(m: int) -> float:
    return statistics.NormalDist().inv_cdf(1 - ALPHA / max(1, m))


def run(root: Path, assets: List[str]) -> Dict[str, Any]:
    d = Dd.cache_dir(root)
    trades: List[Dict[str, Any]] = []
    for a in assets:
        p = d / f"{a}_windows.json.gz"
        if p.exists():
            trades += replay(Dd.load(p), Dd.load(d / f"{a}_coinbase.json.gz"), Dd.load(d / f"{a}_kalshi_candles.json.gz"))
    trades.sort(key=lambda t: t["close_ts"])
    ts = sorted({t["close_ts"] for t in trades})
    cut = ts[int(len(ts) * TRAIN_FRAC)]
    train = [t for t in trades if t["close_ts"] < cut]
    test = [t for t in trades if t["close_ts"] >= cut]
    variants = sorted({t["cid"] for t in trades})
    z = _z(len(variants))
    rep: Dict[str, Any] = {"trades": len(trades), "variants": len(variants), "bonferroni_z": z, "cut": cut,
                           "test_days": len({day(t["close_ts"]) for t in test})}

    def S(rows, key="pnl_cons"):
        rows = [r for r in rows if r[key] is not None]
        return stats([r[key] for r in rows], [day(r["close_ts"]) for r in rows])

    # 1) every family, all variants pooled (TEST period), neutral vs conservative
    rep["family_test"] = {f: {"neutral": S([t for t in test if t["family"] == f], "pnl_neutral"),
                              "conservative": S([t for t in test if t["family"] == f])} for f in REPLAYABLE}
    # 2) breakdowns on TEST, conservative
    rep["by_asset"] = {f"{f}/{a}": S([t for t in test if t["family"] == f and t["asset"] == a]) for f in REPLAYABLE for a in assets}
    edges = [(0, 60), (60, 120), (120, 300), (300, 600), (600, 900)]
    rep["by_timing"] = {f"{f}/{lo // 60}-{hi // 60}min": S([t for t in test if t["family"] == f and lo <= t["t_left"] < hi])
                        for f in REPLAYABLE for lo, hi in edges}
    vols = sorted(t["volume_min"] or 0 for t in test)
    q1, q2 = (vols[len(vols) // 3], vols[2 * len(vols) // 3]) if vols else (0, 0)
    reg = lambda v: "low" if (v or 0) <= q1 else ("mid" if (v or 0) <= q2 else "high")  # noqa: E731
    rep["liquidity_cuts"] = [q1, q2]
    rep["by_liquidity"] = {f"{f}/{r}": S([t for t in test if t["family"] == f and reg(t["volume_min"]) == r])
                           for f in REPLAYABLE for r in ("low", "mid", "high")}
    # 3) variant selection on TRAIN, verdict on TEST
    by_v_train, by_v_test = defaultdict(list), defaultdict(list)
    for t in train:
        by_v_train[t["cid"]].append(t)
    for t in test:
        by_v_test[t["cid"]].append(t)
    for key, label in (("pnl_neutral", "optimistic"), ("pnl_cons", "conservative")):
        selected, survivors = [], []
        for v in variants:
            tr = S(by_v_train[v], key)
            if tr.get("n", 0) >= 30 and tr["mean_c"] > 0:
                te = S(by_v_test[v], key)
                row = {"variant": v, "train": tr, "test": te}
                selected.append(row)
                if te.get("n", 0) >= 30 and te["mean_c"] > 0 and te.get("t_daily", 0) >= z:
                    survivors.append(row)
        rep[f"selected_on_train_{label}"] = selected
        rep[f"survivors_{label}"] = survivors
        rep[f"test_variants_positive_{label}"] = sum(1 for v in variants if S(by_v_test[v], key).get("n") and S(by_v_test[v], key)["mean_c"] > 0)
        rep[f"test_signals_positive_{label}"] = sum(1 for t in test if t[key] is not None and t[key] > 0)
    rep["test_signals"] = len(test)
    rep["family_test_stress"] = {f: S([t for t in test if t["family"] == f], "pnl_stress") for f in REPLAYABLE}
    return rep


def _f(s: Dict[str, Any]) -> str:
    if not s.get("n"):
        return "n=0"
    return (f"n={s['n']:5d} {s['mean_c']:+6.2f}c/contract (±{(s['se_c'] or 0):.2f}) win {s['win_rate'] * 100:4.1f}% "
            f"PF {s['pf']:.2f} DD {s['mdd']:.1f} t(daily) {s.get('t_daily', 0):+.2f}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    assets = sys.argv[1].split(",") if len(sys.argv) > 1 else list(Dd.SERIES)
    r = run(root, assets)
    print(f"replayed signals {r['trades']} | variants {r['variants']} | Bonferroni z {r['bonferroni_z']:.2f} | test days {r['test_days']}")
    print("\nTEST period, all variants pooled:")
    for f, v in r["family_test"].items():
        print(f"  {f:10} neutral      {_f(v['neutral'])}\n  {'':10} conservative {_f(v['conservative'])}")
    for title in ("by_asset", "by_timing", "by_liquidity"):
        print(f"\nTEST, conservative, {title}:")
        for k, v in r[title].items():
            if v.get("n"):
                print(f"  {k:22} {_f(v)}")
    print("\nTEST, stress fills (worst ask of the next 60 s; biased, shown for completeness):")
    for f, v in r["family_test_stress"].items():
        print(f"  {f:10} {_f(v)}")
    for label in ("optimistic", "conservative"):
        sel = r[f"selected_on_train_{label}"]
        print(f"\n[{label} fills] variants selected on TRAIN (n>=30, mean>0): {len(sel)}")
        for row in sel:
            print(f"  {row['variant']:55} train {_f(row['train'])}\n  {'':55} test  {_f(row['test'])}")
        print(f"[{label} fills] SURVIVORS (test mean > 0 and t >= {r['bonferroni_z']:.2f}): {len(r[f'survivors_{label}'])}; "
              f"variants with positive test mean: {r[f'test_variants_positive_{label}']} of {r['variants']}; "
              f"profitable test signals: {r[f'test_signals_positive_{label}']} of {r['test_signals']}")
    (root / "reports").mkdir(exist_ok=True)
    (root / "reports" / "research15_validate.json").write_text(json.dumps(r, default=str, indent=1))
