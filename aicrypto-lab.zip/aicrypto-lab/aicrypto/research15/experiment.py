"""Out-of-sample experiments on real-exchange 15-minute windows (shadow results, never executions).

Protocol (fixed before looking at test data):
* Rows are ordered by window close time. The first TRAIN_FRAC of time is training; the rest is test.
  Anything fitted or chosen (model weights, scaling, edge threshold, filters) uses training rows only.
* Prices: the real exchange's displayed ask/bid at the last complete minute before the decision
  ("neutral"), and the worst ask in the following minute ("conservative": latency and slippage).
  Kalshi taker fee per contract, rounded up. Depth is not available historically: 1 contract per trade.
* Significance: windows on the same day are correlated, so the t value is computed over DAILY means.
"""
from __future__ import annotations

import math
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

TRAIN_FRAC = 0.6
EDGE_GRID = (0.02, 0.04, 0.06, 0.10)
MIN_TRAIN_TRADES = 50
FEATURES = ("logit_mid", "z", "mom1", "mom5", "trend15", "dir1h", "dir4h", "vol_accel", "spread", "basis")


def fee1(p: float) -> float:
    return math.ceil(0.07 * p * (1 - p) * 100 - 1e-9) / 100 if 0 < p < 1 else 0.0


def logit(p: float) -> float:
    p = min(max(p, 1e-4), 1 - 1e-4)
    return math.log(p / (1 - p))


def split(rows: List[Dict[str, Any]], frac: float = TRAIN_FRAC) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], float]:
    ts = sorted(r["close_ts"] for r in rows)
    cut = ts[int(len(ts) * frac)] if ts else 0.0
    return [r for r in rows if r["close_ts"] < cut], [r for r in rows if r["close_ts"] >= cut], cut


def _x(rows: List[Dict[str, Any]], feats: Sequence[str]) -> np.ndarray:
    return np.array([[logit(r["mid"]) if f == "logit_mid" else float(r[f]) for f in feats] for r in rows], dtype=float)


class Logistic:
    """L2-regularised logistic regression (IRLS), standardised on the training rows only."""

    def __init__(self, feats: Sequence[str], l2: float = 1.0):
        self.feats, self.l2 = tuple(feats), l2

    def fit(self, rows: List[Dict[str, Any]]) -> "Logistic":
        X = _x(rows, self.feats)
        self.mu, self.sd = X.mean(0), X.std(0) + 1e-12
        X = np.c_[np.ones(len(X)), (X - self.mu) / self.sd]
        y = np.array([r["y"] for r in rows], dtype=float)
        w = np.zeros(X.shape[1])
        reg = self.l2 * np.eye(X.shape[1])
        reg[0, 0] = 0.0
        for _ in range(50):
            p = 1 / (1 + np.exp(-X @ w))
            W = p * (1 - p) + 1e-9
            H = X.T @ (X * W[:, None]) + reg
            g = X.T @ (y - p) - reg @ w
            step = np.linalg.solve(H, g)
            w += step
            if np.max(np.abs(step)) < 1e-8:
                break
        self.w = w
        return self

    def predict(self, rows: List[Dict[str, Any]]) -> np.ndarray:
        X = (_x(rows, self.feats) - self.mu) / self.sd
        return 1 / (1 + np.exp(-(np.c_[np.ones(len(X)), X] @ self.w)))


def scores(p: Sequence[float], y: Sequence[int]) -> Dict[str, float]:
    p = np.clip(np.asarray(p, float), 1e-4, 1 - 1e-4)
    y = np.asarray(y, float)
    return {"n": int(len(y)), "brier": float(np.mean((p - y) ** 2)),
            "logloss": float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))}


def trade(r: Dict[str, Any], p: float, edge: float, fill: str = "neutral") -> Optional[Dict[str, Any]]:
    """Taker entry if the model price beats the ask + fee by `edge`. Returns per-contract P/L."""
    best = None
    for side, prob, ask in (("yes", p, r["ask"]), ("no", 1 - p, 1 - r["bid"])):
        e = prob - ask - fee1(ask)
        if e >= edge and (best is None or e > best[1]):
            best = (side, e, ask)
    if best is None:
        return None
    side, _, ask = best
    if fill == "worst":
        w = r.get("worst_yes") if side == "yes" else r.get("worst_no")
        if w is None:
            return None
        ask = max(ask, w)
    win = 1.0 if (r["y"] == 1) == (side == "yes") else 0.0
    return {"side": side, "price": ask, "pnl": win - ask - fee1(ask), "close_ts": r["close_ts"], "asset": r["asset"],
            "dir1h": r["dir1h"], "dir4h": r["dir4h"], "vol_accel": r["vol_accel"], "lead": r["lead"]}


def summarize(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not trades:
        return {"n": 0}
    xs = [t["pnl"] for t in trades]
    days: Dict[str, List[float]] = defaultdict(list)
    for t in trades:
        days[datetime.fromtimestamp(t["close_ts"], timezone.utc).strftime("%Y-%m-%d")].append(t["pnl"])
    dm = [statistics.fmean(v) for v in days.values()]
    t_day = (statistics.fmean(dm) / (statistics.stdev(dm) / math.sqrt(len(dm)))) if len(dm) > 2 and statistics.stdev(dm) > 0 else 0.0
    return {"n": len(xs), "mean_c": 100 * statistics.fmean(xs), "win_rate": sum(x > 0 for x in xs) / len(xs),
            "days": len(dm), "t_daily": t_day, "pos_days": sum(1 for d in dm if d > 0)}


def run_strategy(train: List[Dict[str, Any]], test: List[Dict[str, Any]], prob: Callable[[List[Dict[str, Any]]], np.ndarray],
                 filt: Optional[Callable[[Dict[str, Any]], bool]] = None) -> Dict[str, Any]:
    """Choose the edge threshold on TRAIN (best mean with >= MIN_TRAIN_TRADES), then report TEST."""
    ptr, pte = prob(train), prob(test)
    best = None
    for e in EDGE_GRID:
        tr = [x for x in (trade(r, float(p), e) for r, p in zip(train, ptr)) if x and (filt is None or filt(x))]
        if len(tr) >= MIN_TRAIN_TRADES:
            m = statistics.fmean(t["pnl"] for t in tr)
            if best is None or m > best[1]:
                best = (e, m, len(tr))
    if best is None:
        return {"edge": None, "train": {"n": 0}, "test": {"n": 0}, "test_worst": {"n": 0}}
    e = best[0]
    tr = [x for x in (trade(r, float(p), e) for r, p in zip(train, ptr)) if x and (filt is None or filt(x))]
    te = [x for x in (trade(r, float(p), e) for r, p in zip(test, pte)) if x and (filt is None or filt(x))]
    tw = [x for x in (trade(r, float(p), e, "worst") for r, p in zip(test, pte)) if x and (filt is None or filt(x))]
    return {"edge": e, "train": summarize(tr), "test": summarize(te), "test_worst": summarize(tw), "test_trades": te}


def agree(t: Dict[str, Any], key: str) -> bool:
    d = t[key]
    return (d > 0 and t["side"] == "yes") or (d < 0 and t["side"] == "no")
