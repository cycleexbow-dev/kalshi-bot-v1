"""Day-level audit of ACTUAL demo-exchange results, rebuilt from the exchange's own fills.

Every number here comes from fills recorded in demo_ledger.sqlite plus each market's official result.
Positions are grouped per market (one bot position per market). Kalshi V2 reports a NO buy as
action=sell / side=no at no_price; a YES sell (cash-out) is the same thing, so YES and NO contracts
held together are netted into $1 pairs, exactly as Kalshi settles them.
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import statistics
from collections import defaultdict
from datetime import datetime
from decimal import Decimal as D
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional
from zoneinfo import ZoneInfo

ET = ZoneInfo("America/New_York")
_MON = {m: i for i, m in enumerate(["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], 1)}


def close_ts_from_ticker(ticker: str) -> Optional[float]:
    """KXBTC15M-26NOV092130-30 -> 2026-11-09 21:30 New York time (Kalshi names windows in ET)."""
    m = re.search(r"-(\d{2})([A-Z]{3})(\d{2})(\d{2})(\d{2})-", ticker)
    if not m or m.group(2) not in _MON:
        return None
    yy, mon, dd, hh, mi = int(m.group(1)), _MON[m.group(2)], int(m.group(3)), int(m.group(4)), int(m.group(5))
    return datetime(2000 + yy, mon, dd, hh, mi, tzinfo=ET).timestamp()


def asset_of(ticker: str) -> str:
    m = re.match(r"KX([A-Z]+?)15M", ticker)
    return m.group(1) if m else ticker.split("-")[0]


def positions_from_fills(fills: Iterable[Dict[str, Any]], origin_by_order: Dict[str, str]) -> Dict[str, Dict[str, Any]]:
    pos: Dict[str, Dict[str, Any]] = {}
    for f in sorted(fills, key=lambda f: f["ts"]):
        t = f["market_ticker"]
        p = pos.setdefault(t, {"ticker": t, "yes": D(0), "no": D(0), "cost": D(0), "fees": D(0), "origin": None,
                               "entry_ts": f["ts"], "first_side": None, "first_price": None, "fills": 0})
        n = D(f["count_fp"])
        if (f["action"], f["side"]) == ("buy", "yes"):
            side, px = "yes", D(f["yes_price_dollars"])
        elif (f["action"], f["side"]) == ("sell", "no"):
            side, px = "no", D(f["no_price_dollars"])
        else:
            raise ValueError(f"unexpected fill shape {f['action']}/{f['side']}")
        p[side] += n
        p["cost"] += n * px
        p["fees"] += D(str(f.get("fee_cost") or "0"))
        p["fills"] += 1
        p["origin"] = p["origin"] or origin_by_order.get(f["order_id"])
        if p["first_side"] is None:
            p["first_side"], p["first_price"] = side, px
    return pos


def settle_positions(pos: Dict[str, Dict[str, Any]], results: Dict[str, str]) -> List[Dict[str, Any]]:
    out = []
    for t, p in pos.items():
        y, n = p["yes"], p["no"]
        pairs = min(y, n)
        r = results.get(t)
        open_left = (y - pairs) + (n - pairs)
        if open_left and r not in ("yes", "no"):
            out.append({**p, "state": "open"})
            continue
        payout = pairs + ((y - pairs) if r == "yes" else 0) + ((n - pairs) if r == "no" else 0)
        gross = payout - p["cost"]
        origin = p["origin"] or "manual"
        parts = origin.split(":")
        bot = origin.startswith("bot:")
        close_ts = close_ts_from_ticker(t)
        contracts = max(y, n)
        out.append({**p, "state": "settled", "result": r, "gross": gross, "net": gross - p["fees"], "bot": bot,
                    "family": parts[1] if bot and len(parts) > 2 else ("manual" if not bot else "?"),
                    "rule": ":".join(parts[1:]).split("@")[0] if bot else "manual",
                    "asset": asset_of(t), "close_ts": close_ts, "contracts": contracts,
                    "secs_left": (close_ts - p["entry_ts"]) if close_ts else None,
                    "both_sides": bool(y and n)})
    return out


def metrics(trades: List[Dict[str, Any]]) -> Dict[str, Any]:
    tr = sorted(trades, key=lambda r: r.get("close_ts") or r["entry_ts"])
    n = len(tr)
    if not n:
        return {"trades": 0}
    nets = [float(r["net"]) for r in tr]
    wins = [x for x in nets if x > 0]
    losses = [x for x in nets if x <= 0]
    eq, peak, mdd = 0.0, 0.0, 0.0
    for x in nets:
        eq += x
        peak = max(peak, eq)
        mdd = max(mdd, peak - eq)
    contracts = sum(float(r["contracts"]) for r in tr)
    sd = statistics.stdev(nets) if n > 1 else 0.0
    srt = sorted(nets, reverse=True)
    tot = sum(nets)
    return {"trades": n, "wins": len(wins), "losses": len(losses), "win_rate": len(wins) / n,
            "gross": sum(float(r["gross"]) for r in tr), "fees": sum(float(r["fees"]) for r in tr), "net": tot,
            "staked": sum(float(r["cost"]) for r in tr),
            "avg_entry_price": sum(float(r["cost"]) for r in tr) / contracts if contracts else None,
            "avg_win": statistics.fmean(wins) if wins else 0.0, "avg_loss": statistics.fmean(losses) if losses else 0.0,
            "profit_factor": (sum(wins) / -sum(losses)) if losses and sum(losses) < 0 else math.inf,
            "max_drawdown": mdd, "t": (statistics.fmean(nets) / (sd / math.sqrt(n))) if sd else 0.0,
            "top1_share": srt[0] / tot if tot > 0 else None,
            "top5_share": sum(srt[:5]) / tot if tot > 0 else None,
            "net_without_top5": tot - sum(srt[:5])}


def breakdown(trades: List[Dict[str, Any]], key: Callable[[Dict[str, Any]], Any]) -> Dict[Any, Dict[str, Any]]:
    g: Dict[Any, List[Dict[str, Any]]] = defaultdict(list)
    for r in trades:
        g[key(r)].append(r)
    return {k: metrics(v) for k, v in sorted(g.items(), key=lambda kv: str(kv[0]))}


def price_bucket(r: Dict[str, Any]) -> str:
    p = float(r["first_price"])
    for lo, hi in ((0, .2), (.2, .4), (.4, .6), (.6, .8), (.8, 1.01)):
        if lo <= p < hi:
            return f"{int(lo * 100):02d}-{min(99, int(hi * 100) - 1)}c"
    return "?"


def time_bucket(r: Dict[str, Any]) -> str:
    s = r.get("secs_left")
    if s is None:
        return "?"
    for hi, name in ((60, "a) <1 min"), (180, "b) 1-3 min"), (300, "c) 3-5 min"), (600, "d) 5-10 min"), (10**9, "e) >10 min")):
        if s < hi:
            return name
    return "?"


def load_demo(ledger_path: Path, lab_path: Optional[Path] = None, extra_results: Optional[Dict[str, str]] = None):
    L = sqlite3.connect(f"file:{ledger_path}?mode=ro", uri=True)
    fills = [json.loads(r[0]) for r in L.execute("SELECT raw FROM fills")]
    origin = dict(L.execute("SELECT order_id, origin FROM orders"))
    results: Dict[str, str] = {}
    for t, r in L.execute("SELECT ticker, result FROM pos_track WHERE result IN ('yes','no')"):
        results[t] = r
    if lab_path and Path(lab_path).exists():
        B = sqlite3.connect(f"file:{lab_path}?mode=ro", uri=True)
        for t, r in B.execute("SELECT ticker, result FROM trades WHERE result IN ('yes','no')"):
            results.setdefault(t, r)
    results.update(extra_results or {})
    return fills, origin, results
