"""Run the 15-minute research experiments on cached data and print a plain report.

    python -m aicrypto.research15.run [ASSETS]        e.g. BTC,ETH,SOL,XRP,DOGE

Reads only the cache written by research15.data. Prints shadow (simulated) results on the
real exchange's past quotes; nothing here trades.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

from . import data as Dd
from . import experiment as X
from .features import build_rows


def load_rows(root: Path, assets: List[str]) -> List[Dict[str, Any]]:
    d = Dd.cache_dir(root)
    rows: List[Dict[str, Any]] = []
    for a in assets:
        p = d / f"{a}_windows.json.gz"
        if not p.exists():
            continue
        rows += build_rows(Dd.load(p), Dd.load(d / f"{a}_coinbase.json.gz"), Dd.load(d / f"{a}_kalshi_candles.json.gz"))
    rows.sort(key=lambda r: (r["close_ts"], r["asset"], -r["lead"]))
    return rows


def fmt(s: Dict[str, Any]) -> str:
    if not s.get("n"):
        return "no trades"
    return f"n={s['n']:4d} {s['mean_c']:+6.2f}c/contract win {s['win_rate'] * 100:4.1f}% t(daily)={s['t_daily']:+.2f} ({s['pos_days']}/{s['days']} days up)"


def main(assets: List[str]) -> Dict[str, Any]:
    root = Path(__file__).resolve().parents[2]
    rows = load_rows(root, assets)
    train, test, cut = X.split(rows)
    out: Dict[str, Any] = {"rows": len(rows), "train": len(train), "test": len(test), "cut": cut}
    print(f"rows {len(rows)} (train {len(train)}, test {len(test)}); assets {assets}")

    # 1) calibration: who predicts the result best on TEST?
    simple = X.Logistic(("logit_mid",)).fit(train)
    full = X.Logistic(X.FEATURES).fit(train)
    yte = [r["y"] for r in test]
    cal = {"kalshi_mid": X.scores([r["mid"] for r in test], yte),
           "vol_model": X.scores([r["p_model"] for r in test], yte),
           "kalshi_recalibrated": X.scores(simple.predict(test), yte),
           "kalshi_plus_features": X.scores(full.predict(test), yte)}
    out["calibration"] = cal
    print("\n1) Predicting the result on test windows (lower is better)")
    for k, v in cal.items():
        print(f"   {k:22} logloss {v['logloss']:.4f}  brier {v['brier']:.4f}")

    # 2) which single feature adds information beyond Kalshi's own price?
    print("\n2) Added value of each feature on top of Kalshi's price (test logloss change; negative = helps)")
    base = cal["kalshi_recalibrated"]["logloss"]
    add = {}
    for f in X.FEATURES[1:]:
        m = X.Logistic(("logit_mid", f)).fit(train)
        add[f] = X.scores(m.predict(test), yte)["logloss"] - base
        print(f"   {f:10} {add[f]:+.5f}")
    out["feature_value"] = add

    # 3) shadow trading on test (edge chosen on train)
    print("\n3) Shadow trading at the real exchange's quotes, 1 contract, taker fee (edge chosen on train only)")
    strategies = {
        "fair value (vol model)": lambda rs: np.array([r["p_model"] for r in rs]),
        "Kalshi + all features": full.predict,
    }
    res = {}
    for name, fn in strategies.items():
        r = X.run_strategy(train, test, fn)
        res[name] = {k: v for k, v in r.items() if k != "test_trades"}
        print(f"   {name}: edge {r['edge']}")
        print(f"      train   {fmt(r['train'])}")
        print(f"      test    {fmt(r['test'])}")
        print(f"      test, worst fill {fmt(r['test_worst'])}")
        if name.startswith("fair") and r.get("test_trades"):
            print("      by asset (test):")
            for a in assets:
                print(f"         {a:5} {fmt(X.summarize([t for t in r['test_trades'] if t['asset'] == a]))}")
            print("      by time left (test):")
            for lead in (600, 300, 120):
                print(f"         {lead // 60:2d} min {fmt(X.summarize([t for t in r['test_trades'] if t['lead'] == lead]))}")
    out["strategies"] = res

    # 4) longer timeframes as FILTERS on fair value (chosen on train, checked on test)
    print("\n4) Longer-timeframe filters on fair value (test)")
    fv = strategies["fair value (vol model)"]
    filters = {"agrees with 1h direction": lambda t: X.agree(t, "dir1h"), "against 1h direction": lambda t: not X.agree(t, "dir1h"),
               "agrees with 4h direction": lambda t: X.agree(t, "dir4h"), "against 4h direction": lambda t: not X.agree(t, "dir4h"),
               "volatility rising (5m/60m > 1.2)": lambda t: t["vol_accel"] > 1.2, "volatility calm (<= 1.2)": lambda t: t["vol_accel"] <= 1.2}
    fres = {}
    for name, f in filters.items():
        r = X.run_strategy(train, test, fv, filt=f)
        fres[name] = {"train": r["train"], "test": r["test"]}
        print(f"   {name:34} train {fmt(r['train'])}\n   {'':34} test  {fmt(r['test'])}")
    out["filters"] = fres
    return out


if __name__ == "__main__":
    assets = sys.argv[1].split(",") if len(sys.argv) > 1 else list(Dd.SERIES)
    res = main(assets)
    root = Path(__file__).resolve().parents[2]
    (root / "reports").mkdir(exist_ok=True)
    (root / "reports" / "research15_latest.json").write_text(json.dumps(res, indent=1, default=str))
