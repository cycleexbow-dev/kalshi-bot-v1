"""Read the recorder's files back into time-ordered structures for replay (read-only).

Only what was actually recorded is returned. Gaps stay gaps: nothing is interpolated.
"""
from __future__ import annotations

import bisect
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..recorder.store import read_source


@dataclass
class BookSeries:
    times: List[float] = field(default_factory=list)
    yes_bids: List[List[Tuple[float, float]]] = field(default_factory=list)
    no_bids: List[List[Tuple[float, float]]] = field(default_factory=list)

    def add(self, t: float, yb, nb) -> None:
        self.times.append(t)
        self.yes_bids.append([tuple(x) for x in yb])
        self.no_bids.append([tuple(x) for x in nb])

    def at_or_after(self, t: float) -> Optional[int]:
        i = bisect.bisect_left(self.times, t)
        return i if i < len(self.times) else None

    def before(self, t: float) -> Optional[int]:
        i = bisect.bisect_right(self.times, t) - 1
        return i if i >= 0 else None

    def asks(self, i: int, side: str) -> List[Tuple[float, float]]:
        src = self.no_bids[i] if side == "yes" else self.yes_bids[i]
        return sorted(((round(1 - p, 4), s) for p, s in src), key=lambda x: x[0])


@dataclass
class Recorded:
    meta: Dict[str, Dict[str, Any]] = field(default_factory=dict)          # ticker -> latest market_meta
    books: Dict[str, BookSeries] = field(default_factory=lambda: defaultdict(BookSeries))
    settled: Dict[str, Dict[str, Any]] = field(default_factory=dict)       # ticker -> settled record
    cf: Dict[str, List[Tuple[float, float, Optional[float]]]] = field(default_factory=lambda: defaultdict(list))  # index -> (recv, value, src)
    avg60: Dict[str, List[Dict[str, Any]]] = field(default_factory=lambda: defaultdict(list))
    errors: int = 0


def load(root: Path, day: Optional[str] = None) -> Recorded:
    r = Recorded()
    for rec in read_source(root, "kalshi_real", day):
        k = rec.get("k")
        if k == "market_meta":
            r.meta[rec["ticker"]] = rec
        elif k in ("book", "book_full"):
            r.books[rec["ticker"]].add(rec["t"], rec.get("yes_bids") or [], rec.get("no_bids") or [])
        elif k == "settled":
            r.settled[rec["ticker"]] = rec
        elif k == "error":
            r.errors += 1
    for rec in read_source(root, "cfindex", day):
        if rec.get("k") == "value":
            r.cf[rec["index"]].append((rec["t"], float(rec["value"]), rec.get("src_ts")))
        elif rec.get("k") == "avg60":
            r.avg60[rec["index"]].append(rec)
    for v in r.cf.values():
        v.sort(key=lambda x: (x[2] or x[0]))
    return r


def one_per_second(prints: List[Tuple[float, float, Optional[float]]], start: float, end: float) -> Dict[int, float]:
    """Last value published in each whole second [start, end): the settlement uses 1-second prints."""
    out: Dict[int, float] = {}
    for recv, v, src in prints:
        ts = src or recv
        if start <= ts < end:
            out[int(ts)] = v
    return out
