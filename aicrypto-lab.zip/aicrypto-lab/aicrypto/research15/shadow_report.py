"""Summarize the recorder's production-price SHADOW proposals (hypothetical fills, never executions).

    python -m aicrypto.research15.shadow_report

Per strategy family, asset, entry timing and liquidity: proposals, how many would have filled under the
conservative fill model, net expectancy per contract after fees, profit factor, drawdown and uncertainty.
Also reports whether demo and real contracts with the same ticker are genuinely comparable
(same strike, close time and settlement source) before any demo-vs-real comparison is made.
"""
from __future__ import annotations

import json
import math
import sqlite3
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from .replay import stats

SCENARIOS = ("L1_one", "L3_one", "L1_stake", "L3_stake")


def load(db: Path) -> List[Dict[str, Any]]:
    if not db.exists():
        return []
    c = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return [dict(r) for r in c.execute("SELECT * FROM proposals ORDER BY signal_ts")]


def per_contract(row: Dict[str, Any], scen: str) -> Optional[float]:
    """Net P/L per filled contract for one scenario, or None if it did not fill / is unsettled."""
    if not row.get("result"):
        return None
    net = json.loads(row.get("net") or "{}")
    if scen not in net:
        return None
    L, size = scen.split("_")
    f = (json.loads(row.get("fills") or "{}").get(L) or {}).get(size) or {}
    return net[scen] / f["filled"] if f.get("filled") else None


def summarize(rows: List[Dict[str, Any]], scen: str = "L1_one") -> Dict[str, Any]:
    settled = [r for r in rows if r.get("result")]
    xs = [per_contract(r, scen) for r in settled]
    filled = [x for x in xs if x is not None]
    s = stats(filled, [str(int(r["signal_ts"] // 86400)) for r, x in zip(settled, xs) if x is not None])
    s.update(proposals=len(rows), settled=len(settled), fill_rate=(len(filled) / len(settled)) if settled else None)
    return s


def comparability(rows: List[Dict[str, Any]], registry_db: Path, recorded_meta: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """Demo vs real contract with the same ticker: same strike, same close time, same settlement series?"""
    out = {"checked": 0, "comparable": 0, "strike_differs": 0, "close_differs": 0, "missing_on_demo": 0}
    if not registry_db.exists():
        return out
    c = sqlite3.connect(f"file:{registry_db}?mode=ro", uri=True)
    for t in sorted({r["ticker"] for r in rows}):
        real = recorded_meta.get(t)
        if not real:
            continue
        out["checked"] += 1
        d = c.execute("SELECT floor_strike, close_time, series_ticker FROM markets WHERE ticker=?", (t,)).fetchone()
        if d is None:
            out["missing_on_demo"] += 1
            continue
        from datetime import datetime
        ds = float(d[0]) if d[0] is not None else None
        dc = datetime.fromisoformat(d[1]).timestamp() if d[1] else None
        if ds is None or real.get("strike") is None or abs(ds - real["strike"]) > 1e-6 * max(1, abs(ds)):
            out["strike_differs"] += 1
        elif dc is None or abs(dc - (real.get("close_ts") or 0)) > 1:
            out["close_differs"] += 1
        else:
            out["comparable"] += 1
    return out


def _f(s: Dict[str, Any]) -> str:
    if not s.get("n"):
        return f"proposals {s.get('proposals', 0)}, settled {s.get('settled', 0)}, filled 0"
    fr = s.get("fill_rate")
    return (f"proposals {s['proposals']:4d} settled {s['settled']:4d} filled {s['n']:4d} ({(fr or 0) * 100:3.0f}%) "
            f"{s['mean_c']:+6.2f}c/contract (±{(s['se_c'] or 0):.2f}) win {s['win_rate'] * 100:4.1f}% PF {s['pf']:.2f} DD {s['mdd']:.2f}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    rows = load(root / "user_data" / "kalshi" / "shadow_real.sqlite")
    if not rows:
        print("no shadow proposals recorded yet")
        sys.exit(0)
    hours = (rows[-1]["signal_ts"] - rows[0]["signal_ts"]) / 3600
    print(f"SHADOW (hypothetical) proposals: {len(rows)} over {hours:.1f} h; settled {sum(1 for r in rows if r['result'])}")
    for scen in SCENARIOS:
        print(f"\n== fill scenario {scen} (L = seconds of latency; one = 1 contract, stake = $10)")
        g = defaultdict(list)
        for r in rows:
            g[r["family"]].append(r)
        for f, rs in sorted(g.items()):
            print(f"  {f:10} {_f(summarize(rs, scen))}")
    print("\n== L1_one by asset / entry timing / spread (liquidity)")
    for title, key in (("asset", lambda r: r["asset"]),
                       ("time left", lambda r: "<1m" if r["t_left"] < 60 else "1-2m" if r["t_left"] < 120 else "2-5m" if r["t_left"] < 300 else "5-10m" if r["t_left"] < 600 else ">10m"),
                       ("spread", lambda r: "tight (<=1c)" if (r["spread"] or 1) <= 0.011 else "wide (>1c)")):
        g = defaultdict(list)
        for r in rows:
            g[f"{r['family']}/{key(r)}"].append(r)
        print(f"  -- {title}")
        for k, rs in sorted(g.items()):
            print(f"  {k:22} {_f(summarize(rs))}")
    from .recordings import load as load_rec
    rec = load_rec(root)
    print("\ndemo vs real comparability:", comparability(rows, root / "user_data" / "kalshi" / "registry.sqlite", rec.meta))
