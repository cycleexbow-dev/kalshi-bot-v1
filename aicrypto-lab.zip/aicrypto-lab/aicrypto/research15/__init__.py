"""Offline research for 15-minute Kalshi up/down markets (owner request 2026-11-10).

Separate from the live engine: nothing here is imported by the terminal, the labs or the bot, and
nothing here can place an order. It reads public, read-only market data (Kalshi's real exchange via the
guarded GET-only client; Coinbase and Kraken public candles), caches it under
user_data/kalshi/research15/, and runs reproducible, time-ordered experiments. Results are
descriptive statistics of past data, never a promise of profit.
"""
