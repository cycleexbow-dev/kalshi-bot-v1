"""Replay the lab's EXACT rule code on 30 days of real-exchange 1-minute data (REAL-QUOTE SHADOW).

Families replayed: fair, momentum, favorite, kmomentum (the same Candidate.signal functions the bot uses).
Not replayable from 1-minute history, judged only on the live recorder: lock (needs the 1-second index
inside the averaging minute) and imbalance (needs order-book sizes, which are not published historically).

At every completed minute of a window, the rule sees: the real exchange's yes bid/ask of that minute,
the time left, the Kalshi mid two minutes earlier (kmomentum), and, for crypto, a probability and a
3-minute move computed from Coinbase 1-minute prices translated onto the settlement index level
(fair / momentum; an APPROXIMATION of the live rule, which uses the index itself). Each variant enters
at most once per window, as the live lab does.

Fills, 1 contract (depth is not known historically, a stated limitation):
  neutral       the ask displayed at the decision minute (optimistic: no latency, always filled)
  conservative  that ask + 2c on every trade (the live shadow engine's slippage limit)
  stress        the worst ask during the following 60 s. Biased against every rule (near the close it
                already reflects the outcome), so it is shown only as a stress test, never as the verdict.
"""
from __future__ import annotations

import math
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional, Sequence

from ..kalshi.lab.candidates import WindowView, build
from .features import Minutes, norm_cdf

REPLAYABLE = ("fair", "momentum", "favorite", "kmomentum")
SLIPPAGE = 0.02        # conservative: every entry pays 2c above the displayed ask (the live shadow's limit)


def fee1(p: float) -> float:
    return math.ceil(0.07 * p * (1 - p) * 100 - 1e-9) / 100 if 0 < p < 1 else 0.0


def _views(w: Dict[str, Any], cb: Minutes, kc: List[Dict[str, Any]]):
    """Yield (decision_t, WindowView, candle_index) for each completed minute of the window."""
    K, C, O = w["strike"], w["close_ts"], w["open_ts"]
    open_px = cb.close_at(O)
    basis = math.log(open_px / K) if open_px and K > 0 else 0.0
    by_end = {c["end"]: i for i, c in enumerate(kc)}
    for i, c in enumerate(kc):
        e = c["end"]
        if not (O < e < C):
            continue
        a, b = c.get("ask_c"), c.get("bid_c")
        if a is None or b is None or not (0.01 <= a <= 0.99) or not (0.01 <= b <= 0.99) or b > a:
            continue
        mid = (a + b) / 2
        prev = kc[by_end[e - 120]] if (e - 120) in by_end else None
        pm = None
        if prev and prev.get("ask_c") and prev.get("bid_c") and 0.01 <= prev["ask_c"] <= 0.99 and 0.01 <= prev["bid_c"] <= 0.99:
            pm = (prev["ask_c"] + prev["bid_c"]) / 2
        vw = WindowView(w["ticker"], w["asset"], "crypto", float(e), C, O, Decimal(str(b)), Decimal(str(a)), 1e9, 1e9,
                        mid_change_120s=(mid - pm) if pm is not None else None)
        spot = cb.close_at(e)
        r15 = cb.returns(e, 15)
        if spot and len(r15) >= 10 and K > 0:
            m = sum(r15) / len(r15)
            sd = math.sqrt(sum((x - m) ** 2 for x in r15) / (len(r15) - 1))
            t_left = C - e
            if sd > 0 and t_left > 60:
                tau = (t_left - 60) / 60 + 1 / 3
                vw.p_up = norm_cdf(math.log(spot / math.exp(basis) / K) / (sd * math.sqrt(tau)))
            s3 = cb.close_at(e - 180)
            if s3:
                vw.move_3m_pct = (spot / s3 - 1) * 100
        yield e, vw, i


def replay(windows: List[Dict[str, Any]], cb_rows, candles: Dict[str, List[Dict[str, Any]]], families: Sequence[str] = REPLAYABLE) -> List[Dict[str, Any]]:
    cb = Minutes(cb_rows)
    out: List[Dict[str, Any]] = []
    assets = sorted({w["asset"] for w in windows})
    cands = [c for c in build({"crypto": assets}) if c.family in families]
    by_asset = defaultdict(list)
    for c in cands:
        by_asset[c.asset].append(c)
    for w in windows:
        kc = candles.get(w["ticker"]) or []
        done = set()
        for e, vw, i in _views(w, cb, kc):
            for c in by_asset[w["asset"]]:
                if c.cid in done:
                    continue
                side = c.signal(vw)
                if not side:
                    continue
                done.add(c.cid)
                ask = float(vw.ask(side))
                nxt = kc[i + 1] if i + 1 < len(kc) else None
                worst = None
                if nxt:
                    worst = nxt.get("ask_h") if side == "yes" else ((1 - nxt["bid_l"]) if nxt.get("bid_l") is not None else None)
                    if worst is not None and not (0.01 <= worst <= 0.99):
                        worst = None
                stress = max(ask, worst) if worst is not None else None
                cons = min(0.99, ask + SLIPPAGE)
                win = 1.0 if (w["result"] == "yes") == (side == "yes") else 0.0
                vol = kc[i].get("vol")
                out.append({"cid": c.cid, "family": c.family, "asset": w["asset"], "ticker": w["ticker"], "close_ts": w["close_ts"],
                            "t_left": w["close_ts"] - e, "side": side, "ask": ask, "volume_min": vol,
                            "pnl_neutral": win - ask - fee1(ask),
                            "pnl_cons": win - cons - fee1(cons),
                            "pnl_stress": (win - stress - fee1(stress)) if stress is not None else None})
    return out


def stats(xs: List[float], days: Optional[List[str]] = None) -> Dict[str, Any]:
    n = len(xs)
    if n == 0:
        return {"n": 0}
    m = statistics.fmean(xs)
    wins = [x for x in xs if x > 0]
    losses = [x for x in xs if x <= 0]
    eq = peak = mdd = 0.0
    for x in xs:
        eq += x
        peak = max(peak, eq)
        mdd = max(mdd, peak - eq)
    sd = statistics.stdev(xs) if n > 1 else 0.0
    out = {"n": n, "mean_c": 100 * m, "win_rate": len(wins) / n, "pf": (sum(wins) / -sum(losses)) if losses and sum(losses) < 0 else math.inf,
           "mdd": mdd, "se_c": 100 * sd / math.sqrt(n) if n > 1 else None}
    if days:
        g = defaultdict(list)
        for d, x in zip(days, xs):
            g[d].append(x)
        dm = [statistics.fmean(v) for v in g.values()]
        out["days"] = len(dm)
        out["t_daily"] = (statistics.fmean(dm) / (statistics.stdev(dm) / math.sqrt(len(dm)))) if len(dm) > 2 and statistics.stdev(dm) > 0 else 0.0
    return out


def day(ts: float) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%d")
