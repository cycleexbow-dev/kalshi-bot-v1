"""Time-aligned features for one 15-minute window at one decision time (no lookahead).

Rules that prevent leakage:
* A Coinbase candle starting at s covers [s, s+60); it is usable only if s + 60 <= decision time.
* A Kalshi candle with end_period_ts e is usable only if e <= decision time.
* The target (strike) is known when the window opens; the result is only ever the label.
* The previous window's settlement average equals this window's target, so the Coinbase-vs-index
  basis is measured at the window's OPEN (known), never at its close.
"""
from __future__ import annotations

import bisect
import math
from typing import Any, Dict, List, Optional, Sequence

AVG_S = 60.0


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


class Minutes:
    """Coinbase 1-minute candles ([start, low, high, open, close, volume]) with leakage-safe lookups."""

    def __init__(self, rows: Sequence[Sequence[float]]):
        rows = sorted(rows, key=lambda r: r[0])
        self.start = [int(r[0]) for r in rows]
        self.close = [float(r[4]) for r in rows]

    def idx_before(self, t: float) -> int:
        """Index of the last candle that is complete at time t (start + 60 <= t); -1 if none."""
        return bisect.bisect_right(self.start, t - 60) - 1

    def close_at(self, t: float) -> Optional[float]:
        i = self.idx_before(t)
        return self.close[i] if i >= 0 else None

    def returns(self, t: float, minutes: int) -> List[float]:
        i = self.idx_before(t)
        j = max(0, i - minutes)
        out = []
        for k in range(j + 1, i + 1):
            if self.start[k] - self.start[k - 1] == 60 and self.close[k - 1] > 0:
                out.append(math.log(self.close[k] / self.close[k - 1]))
        return out


def _sd(xs: List[float]) -> Optional[float]:
    if len(xs) < 5:
        return None
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))


def _ret(mins: Minutes, t: float, back_min: int) -> Optional[float]:
    a, b = mins.close_at(t), mins.close_at(t - back_min * 60)
    return math.log(a / b) if (a and b) else None


def kalshi_quote(candles: List[Dict[str, Any]], t: float) -> Optional[Dict[str, float]]:
    """Last complete Kalshi minute at time t: bid/ask close. None if no usable two-sided quote."""
    use = [c for c in candles if c["end"] <= t]
    if not use:
        return None
    c = use[-1]
    a, b = c.get("ask_c"), c.get("bid_c")
    if a is None or b is None or not (0.01 <= a <= 0.99) or not (0.01 <= b <= 0.99) or b > a:
        return None
    return {"ask": a, "bid": b, "mid": (a + b) / 2, "spread": a - b, "end": c["end"]}


def next_minute_worst(candles: List[Dict[str, Any]], t: float, side: str) -> Optional[float]:
    """Conservative fill: worst ask during the minute after the decision (latency + slippage)."""
    nxt = [c for c in candles if c["end"] > t][:1]
    if not nxt:
        return None
    c = nxt[0]
    if side == "yes":
        v = c.get("ask_h")
    else:
        v = (1 - c["bid_l"]) if c.get("bid_l") is not None else None
    return v if (v is not None and 0.01 <= v <= 0.99) else None


def window_features(w: Dict[str, Any], decision_t: float, cb: Minutes, kc: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    K, C = w["strike"], w["close_ts"]
    spot = cb.close_at(decision_t)
    q = kalshi_quote(kc, decision_t)
    if spot is None or q is None or K <= 0:
        return None
    open_px = cb.close_at(w["open_ts"])            # Coinbase at the open vs the official average that set K
    basis = math.log(open_px / K) if open_px else 0.0
    spot_adj = spot / math.exp(basis)               # Coinbase translated onto the settlement index's level
    r15, r60 = cb.returns(decision_t, 15), cb.returns(decision_t, 60)
    r5 = cb.returns(decision_t, 5)
    s15, s60, s5 = _sd(r15), _sd(r60), _sd(r5)
    if not s15 or not s60:
        return None
    t_left = C - decision_t
    tau_min = max(1e-6, (t_left - AVG_S) / 60.0 + (AVG_S / 60.0) / 3.0) if t_left > AVG_S else max(1e-6, t_left / 180.0)
    dist = math.log(spot_adj / K)
    z = dist / (s15 * math.sqrt(tau_min))
    return {
        "ticker": w["ticker"], "asset": w["asset"], "close_ts": C, "decision_t": decision_t, "t_left": t_left,
        "y": 1 if w["result"] == "yes" else 0,
        "ask": q["ask"], "bid": q["bid"], "mid": q["mid"], "spread": q["spread"],
        "p_model": norm_cdf(z), "z": z, "dist": dist, "basis": basis,
        "mom1": _ret(cb, decision_t, 1) or 0.0, "mom5": _ret(cb, decision_t, 5) or 0.0,
        "trend15": _ret(cb, decision_t, 15) or 0.0, "dir1h": _ret(cb, decision_t, 60) or 0.0,
        "dir4h": _ret(cb, decision_t, 240) or 0.0,
        "vol15": s15, "vol60": s60, "vol_accel": (s5 / s60) if s5 else 1.0,
    }


def build_rows(windows: List[Dict[str, Any]], cb_rows, candles: Dict[str, List[Dict[str, Any]]],
               leads_s: Sequence[int] = (600, 300, 120)) -> List[Dict[str, Any]]:
    cb = Minutes(cb_rows)
    out = []
    for w in windows:
        kc = candles.get(w["ticker"]) or []
        for lead in leads_s:
            f = window_features(w, w["close_ts"] - lead, cb, kc)
            if f is not None:
                f["lead"] = lead
                f["worst_yes"] = next_minute_worst(kc, f["decision_t"], "yes")
                f["worst_no"] = next_minute_worst(kc, f["decision_t"], "no")
                out.append(f)
    return out
