"""Reproducible experiment tracking.

run_id = sha256(spec json | sorted dataset fingerprints | cost model | capital |
walk-forward config | code version | seed)[:16]

Same inputs => same run_id, and (because everything is seeded) the same metrics.
Each run stores a row in SQLite plus a JSON artefact directory with metrics, fold
details, gate results and the equity curve (as CSV) for the dashboard.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import subprocess
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd

from ..data.ohlcv import DatasetInfo
from ..strategies import StrategySpec

LIFECYCLE = ("CANDIDATE", "VALIDATED", "PAPER", "RETIRED")  # no real-money state exists


def code_version(root: Path) -> str:
    """git short sha if available, else hash of the package sources."""
    try:
        out = subprocess.run(["git", "-C", str(root), "rev-parse", "--short", "HEAD"],
                             capture_output=True, text=True, timeout=5)
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    h = hashlib.sha256()
    for p in sorted((root / "aicrypto").rglob("*.py")):
        h.update(p.read_bytes())
    return "src-" + h.hexdigest()[:10]


def make_run_id(spec: StrategySpec, datasets: Iterable[DatasetInfo], cfg_blob: Dict[str, Any], code: str) -> str:
    h = hashlib.sha256()
    h.update(spec.to_json().encode())
    for d in sorted(datasets, key=lambda x: (x.pair, x.timeframe)):
        h.update(d.fingerprint.encode())
    h.update(json.dumps(cfg_blob, sort_keys=True, default=str).encode())
    h.update(code.encode())
    return h.hexdigest()[:16]


@dataclass
class RunRecord:
    run_id: str
    created_at: float
    spec_hash: str
    family: str
    timeframe: str
    pairs: str
    code_version: str
    seed: int
    status: str                 # lifecycle state of the spec after this run
    gates_passed: bool
    is_sharpe: float
    oos_sharpe: float
    oos_return: float
    oos_max_dd: float
    oos_trades: int
    n_folds: int
    positive_fold_fraction: float
    lookahead_ok: bool
    recursive_ok: bool
    spec_json: str
    notes: str = ""


_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    created_at REAL, spec_hash TEXT, family TEXT, timeframe TEXT, pairs TEXT,
    code_version TEXT, seed INTEGER, status TEXT, gates_passed INTEGER,
    is_sharpe REAL, oos_sharpe REAL, oos_return REAL, oos_max_dd REAL, oos_trades INTEGER,
    n_folds INTEGER, positive_fold_fraction REAL, lookahead_ok INTEGER, recursive_ok INTEGER,
    spec_json TEXT, notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_spec ON runs(spec_hash);
CREATE TABLE IF NOT EXISTS lifecycle (
    spec_hash TEXT PRIMARY KEY, status TEXT, updated_at REAL, run_id TEXT, reason TEXT, spec_json TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY, started_at REAL, finished_at REAL, candidates INTEGER,
    passed INTEGER, budget_json TEXT, notes TEXT
);
"""


class Tracker:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / "tracker.sqlite"
        self.runs_dir = self.root / "runs"
        self.runs_dir.mkdir(exist_ok=True)
        with self._conn() as c:
            c.executescript(_SCHEMA)

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    # ---- runs ---------------------------------------------------------------
    def has_run(self, run_id: str) -> bool:
        with self._conn() as c:
            return c.execute("SELECT 1 FROM runs WHERE run_id=?", (run_id,)).fetchone() is not None

    def record(self, rec: RunRecord, artefacts: Dict[str, Any], equity: Optional[pd.Series] = None) -> Path:
        d = self.runs_dir / rec.run_id
        d.mkdir(parents=True, exist_ok=True)
        (d / "run.json").write_text(json.dumps({**asdict(rec), **artefacts}, indent=2, default=str))
        if equity is not None:
            equity.rename("equity").to_csv(d / "oos_equity.csv", header=True)
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO runs VALUES (" + ",".join("?" * 21) + ")",
                (rec.run_id, rec.created_at, rec.spec_hash, rec.family, rec.timeframe, rec.pairs,
                 rec.code_version, rec.seed, rec.status, int(rec.gates_passed), rec.is_sharpe,
                 rec.oos_sharpe, rec.oos_return, rec.oos_max_dd, rec.oos_trades, rec.n_folds,
                 rec.positive_fold_fraction, int(rec.lookahead_ok), int(rec.recursive_ok),
                 rec.spec_json, rec.notes),
            )
        return d

    def load_run(self, run_id: str) -> Dict[str, Any]:
        return json.loads((self.runs_dir / run_id / "run.json").read_text())

    def list_runs(self, limit: int = 200, only_passed: bool = False) -> List[Dict[str, Any]]:
        q = "SELECT * FROM runs" + (" WHERE gates_passed=1" if only_passed else "") + " ORDER BY created_at DESC LIMIT ?"
        with self._conn() as c:
            return [dict(r) for r in c.execute(q, (limit,))]

    # ---- lifecycle ----------------------------------------------------------
    def set_status(self, spec: StrategySpec, status: str, run_id: str, reason: str = "") -> None:
        if status not in LIFECYCLE:
            raise ValueError(f"invalid lifecycle state {status}; allowed: {LIFECYCLE}")
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO lifecycle VALUES (?,?,?,?,?,?)",
                (spec.spec_hash, status, time.time(), run_id, reason, spec.to_json()),
            )

    def status_of(self, spec_hash: str) -> Optional[str]:
        with self._conn() as c:
            r = c.execute("SELECT status FROM lifecycle WHERE spec_hash=?", (spec_hash,)).fetchone()
            return r["status"] if r else None

    def by_status(self, status: str) -> List[Dict[str, Any]]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM lifecycle WHERE status=? ORDER BY updated_at DESC", (status,))]

    # ---- sessions -----------------------------------------------------------
    def start_session(self, session_id: str, budget: Dict[str, Any]) -> None:
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO sessions VALUES (?,?,?,?,?,?,?)",
                      (session_id, time.time(), None, 0, 0, json.dumps(budget), ""))

    def finish_session(self, session_id: str, candidates: int, passed: int, notes: str = "") -> None:
        with self._conn() as c:
            c.execute("UPDATE sessions SET finished_at=?, candidates=?, passed=?, notes=? WHERE session_id=?",
                      (time.time(), candidates, passed, notes, session_id))

    def sessions(self, limit: int = 20) -> List[Dict[str, Any]]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM sessions ORDER BY started_at DESC LIMIT ?", (limit,))]

    def summary(self) -> Dict[str, Any]:
        with self._conn() as c:
            total = c.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
            passed = c.execute("SELECT COUNT(*) FROM runs WHERE gates_passed=1").fetchone()[0]
            states = {s: c.execute("SELECT COUNT(*) FROM lifecycle WHERE status=?", (s,)).fetchone()[0] for s in LIFECYCLE}
        return {"runs": total, "runs_passed": passed, "lifecycle": states}
