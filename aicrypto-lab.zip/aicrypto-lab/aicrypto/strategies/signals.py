"""Turn a StrategySpec + OHLCV frame into entry/exit signal columns.

Output frame has boolean columns `enter_long` and `exit_long`, computed from data
available at the close of each bar. The backtester fills them at the NEXT bar's
open, which is the structural no-lookahead guarantee.
"""
from __future__ import annotations

import pandas as pd

from . import indicators as ind
from .spec import StrategySpec


def compute_signals(df: pd.DataFrame, spec: StrategySpec, startup: int | None = None) -> pd.DataFrame:
    """`startup` overrides the warm-up mask length (used by the recursive probe to
    emulate a shorter Freqtrade startup_candle_count)."""
    close, high, low = df["close"], df["high"], df["low"]
    p = spec.params
    out = pd.DataFrame(index=df.index)

    if spec.family == "ema_cross":
        fast = ind.ema(close, int(p["fast"]))
        slow = ind.ema(close, int(p["slow"]))
        cross_up = (fast > slow) & (fast.shift(1) <= slow.shift(1))
        cross_dn = (fast < slow) & (fast.shift(1) >= slow.shift(1))
        if int(p["trend_filter"]) > 0:
            trend_ok = close > ind.sma(close, int(p["trend_filter"]))
        else:
            trend_ok = pd.Series(True, index=df.index)
        out["enter_long"] = cross_up & trend_ok
        out["exit_long"] = cross_dn
        out["_score"] = (fast - slow) / close

    elif spec.family == "rsi_reversion":
        r = ind.rsi(close, int(p["rsi_len"]))
        out["enter_long"] = (r < p["buy_below"]) & (r.shift(1) >= p["buy_below"])
        out["exit_long"] = r > p["sell_above"]
        out["_score"] = r / 100.0

    elif spec.family == "donchian_breakout":
        _, upper = ind.donchian(high, low, int(p["channel"]))
        lower_x, _ = ind.donchian(high, low, int(p["exit_channel"]))
        out["enter_long"] = close > upper
        out["exit_long"] = close < lower_x
        out["_score"] = close / upper - 1.0

    elif spec.family == "bollinger_reversion":
        lower, mid, _ = ind.bollinger(close, int(p["bb_len"]), float(p["bb_k"]))
        out["enter_long"] = (close < lower) & (close.shift(1) >= lower.shift(1))
        out["exit_long"] = close > mid
        out["_score"] = (close - mid) / (mid - lower).replace(0.0, float("nan"))

    else:  # pragma: no cover
        raise ValueError(spec.family)

    out["enter_long"] = out["enter_long"].fillna(False).astype(bool)
    out["exit_long"] = out["exit_long"].fillna(False).astype(bool)
    # No signals during warm-up: indicators are NaN or unsettled there.
    warm = spec.startup_bars() if startup is None else int(startup)
    out.loc[out.index[:warm], ["enter_long", "exit_long"]] = False
    if "_score" in out:
        out["_score"] = out["_score"].astype(float)
        out.loc[out.index[:warm], "_score"] = float("nan")
    return out
