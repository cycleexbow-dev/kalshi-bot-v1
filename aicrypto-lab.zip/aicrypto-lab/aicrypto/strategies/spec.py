"""Declarative strategy specification.

A StrategySpec is data: family name, integer/float parameters, and exit rules.
Being data makes it hashable (for experiment ids), mutable by the research loop,
and renderable to a Freqtrade IStrategy class.
"""
from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Union

Number = Union[int, float]


@dataclass(frozen=True)
class ParamSpace:
    """Inclusive integer or float grid with a step; used for sampling and neighbours."""

    lo: Number
    hi: Number
    step: Number
    is_int: bool = True

    def sample(self, rng: random.Random) -> Number:
        n_steps = int(round((self.hi - self.lo) / self.step))
        v = self.lo + rng.randint(0, n_steps) * self.step
        return int(v) if self.is_int else round(float(v), 6)

    def clamp(self, v: Number) -> Number:
        v = min(max(v, self.lo), self.hi)
        return int(v) if self.is_int else round(float(v), 6)


# family -> (param -> space). Exit params are shared across families.
FAMILIES: Dict[str, Dict[str, ParamSpace]] = {
    "ema_cross": {
        "fast": ParamSpace(5, 40, 1),
        "slow": ParamSpace(20, 200, 5),
        "trend_filter": ParamSpace(0, 200, 50),  # 0 disables; else close > SMA(trend_filter)
    },
    "rsi_reversion": {
        "rsi_len": ParamSpace(7, 30, 1),
        "buy_below": ParamSpace(15, 40, 1),
        "sell_above": ParamSpace(55, 85, 1),
    },
    "donchian_breakout": {
        "channel": ParamSpace(10, 100, 5),
        "exit_channel": ParamSpace(5, 50, 5),
    },
    "bollinger_reversion": {
        "bb_len": ParamSpace(10, 50, 2),
        "bb_k": ParamSpace(1.5, 3.0, 0.1, is_int=False),
    },
}

EXIT_SPACE: Dict[str, ParamSpace] = {
    "stop_pct": ParamSpace(0.01, 0.10, 0.005, is_int=False),      # hard stop below entry
    "trail_pct": ParamSpace(0.0, 0.10, 0.01, is_int=False),       # 0 disables trailing
    "max_bars": ParamSpace(0, 400, 20),                            # 0 disables time exit
}


@dataclass(frozen=True)
class StrategySpec:
    family: str
    params: Dict[str, Number]
    exits: Dict[str, Number]
    timeframe: str = "1h"
    version: int = 1
    tags: Tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        if self.family not in FAMILIES:
            raise ValueError(f"unknown family {self.family}")
        missing = set(FAMILIES[self.family]) - set(self.params)
        if missing:
            raise ValueError(f"missing params {missing}")
        missing_e = set(EXIT_SPACE) - set(self.exits)
        if missing_e:
            raise ValueError(f"missing exits {missing_e}")
        if self.family == "ema_cross" and self.params["fast"] >= self.params["slow"]:
            raise ValueError("fast must be < slow")
        if self.family == "rsi_reversion" and self.params["buy_below"] >= self.params["sell_above"]:
            raise ValueError("buy_below must be < sell_above")
        if self.exits["stop_pct"] <= 0:
            raise ValueError("stop_pct must be > 0 (risk sizing depends on it)")

    # ---- identity -------------------------------------------------------
    def to_dict(self) -> dict:
        d = asdict(self)
        d["tags"] = list(self.tags)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)

    @classmethod
    def from_dict(cls, d: dict) -> "StrategySpec":
        d = dict(d)
        d["tags"] = tuple(d.get("tags", ()))
        return cls(**d)

    @property
    def spec_hash(self) -> str:
        return hashlib.sha256(self.to_json().encode()).hexdigest()[:12]

    @property
    def name(self) -> str:
        return f"AC_{self.family}_{self.spec_hash}"

    @property
    def class_name(self) -> str:
        parts = self.family.split("_")
        return "AC" + "".join(p.capitalize() for p in parts) + self.spec_hash

    def startup_bars(self) -> int:
        """Longest lookback; used for warm-up and Freqtrade startup_candle_count."""
        p = self.params
        if self.family == "ema_cross":
            return int(max(p["slow"], p["trend_filter"])) * 3  # EMA needs ~3x span to settle
        if self.family == "rsi_reversion":
            return int(p["rsi_len"]) * 10
        if self.family == "donchian_breakout":
            return int(max(p["channel"], p["exit_channel"])) + 2
        if self.family == "bollinger_reversion":
            return int(p["bb_len"]) + 2
        raise AssertionError


def random_spec(rng: random.Random, family: str | None = None, timeframe: str = "1h") -> StrategySpec:
    fam = family or rng.choice(sorted(FAMILIES))
    for _ in range(100):
        params = {k: s.sample(rng) for k, s in FAMILIES[fam].items()}
        exits = {k: s.sample(rng) for k, s in EXIT_SPACE.items()}
        try:
            return StrategySpec(fam, params, exits, timeframe=timeframe)
        except ValueError:
            continue
    raise RuntimeError("could not sample a valid spec")


def mutate_spec(spec: StrategySpec, rng: random.Random, n_changes: int = 1) -> StrategySpec:
    """Perturb a few parameters by ±1..3 steps; keep the family."""
    space = {**FAMILIES[spec.family], **EXIT_SPACE}
    for _ in range(100):
        params = dict(spec.params)
        exits = dict(spec.exits)
        keys = rng.sample(sorted(space), k=min(n_changes, len(space)))
        for k in keys:
            s = space[k]
            delta = rng.choice([-3, -2, -1, 1, 2, 3]) * s.step
            target = params if k in params else exits
            target[k] = s.clamp(target[k] + delta)
        try:
            return StrategySpec(spec.family, params, exits, spec.timeframe, spec.version, spec.tags + ("mutant",))
        except ValueError:
            continue
    return spec


def neighbours(spec: StrategySpec) -> List[StrategySpec]:
    """All ±1-step single-parameter neighbours (for the stability gate)."""
    out: List[StrategySpec] = []
    space = {**FAMILIES[spec.family], **EXIT_SPACE}
    for k, s in space.items():
        for sign in (-1, 1):
            params = dict(spec.params)
            exits = dict(spec.exits)
            target = params if k in params else exits
            nv = s.clamp(target[k] + sign * s.step)
            if nv == target[k]:
                continue
            target[k] = nv
            try:
                out.append(StrategySpec(spec.family, params, exits, spec.timeframe, spec.version, spec.tags))
            except ValueError:
                pass
    return out
