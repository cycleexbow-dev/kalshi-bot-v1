"""Local record of every demo order event: submissions, acknowledgements, fills, cancels.

SQLite at user_data/kalshi/demo_ledger.sqlite. Separate from the local paper ledger and from
market data; amounts are integers (p4 = $0.0001, c2 = 0.01 contract) or Decimal strings.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

OPEN_STATES = ("SUBMITTING", "UNKNOWN", "RESTING", "PARTIAL", "CANCEL_PENDING")
FINAL_STATES = ("FILLED", "CANCELED", "REJECTED", "FAILED")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
  client_order_id TEXT PRIMARY KEY, order_id TEXT, ticker TEXT, side TEXT, action TEXT,
  price_p4 INTEGER, count_c2 INTEGER, filled_c2 INTEGER DEFAULT 0, remaining_c2 INTEGER,
  state TEXT, exchange_status TEXT, origin TEXT, max_loss TEXT, fees TEXT DEFAULT '0',
  error TEXT DEFAULT '', reconcile_attempts INTEGER DEFAULT 0, created_at REAL, updated_at REAL
);
CREATE INDEX IF NOT EXISTS idx_orders_state ON orders(state);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, t REAL, client_order_id TEXT, kind TEXT, origin TEXT, message TEXT, payload TEXT
);
CREATE TABLE IF NOT EXISTS fills (
  fill_id TEXT PRIMARY KEY, order_id TEXT, client_order_id TEXT, ticker TEXT, side TEXT, action TEXT,
  count_c2 INTEGER, price_p4 INTEGER, is_taker INTEGER, created_time TEXT, raw TEXT
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS pos_track (
  ticker TEXT PRIMARY KEY, side TEXT, contracts TEXT, cost TEXT, fees TEXT, realized TEXT, state TEXT,
  how TEXT, result TEXT, pnl TEXT, opened REAL, closed REAL
);
CREATE TABLE IF NOT EXISTS strategies (
  name TEXT, version TEXT, status TEXT, code_hash TEXT, validation TEXT, approved_by TEXT, approved_at REAL,
  updated_at REAL, PRIMARY KEY (name, version)
);
"""


class DemoLedger:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._c() as c:
            c.executescript(_SCHEMA)

    def _c(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    # ---- settings
    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        with self._c() as c:
            r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def put(self, key: str, value: Optional[str]) -> None:
        with self._c() as c:
            if value is None:
                c.execute("DELETE FROM settings WHERE key=?", (key,))
            else:
                c.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, str(value)))

    # ---- events
    def event(self, kind: str, message: str, *, client_order_id: str = "", origin: str = "", payload: Any = None) -> None:
        with self._c() as c:
            c.execute("INSERT INTO events (t, client_order_id, kind, origin, message, payload) VALUES (?,?,?,?,?,?)",
                      (time.time(), client_order_id, kind, origin, message, json.dumps(payload, default=str) if payload is not None else None))

    def events(self, limit: int = 200, kinds: Optional[List[str]] = None, origin_prefix: str = "") -> List[Dict[str, Any]]:
        q, args = "SELECT * FROM events", []
        conds = []
        if kinds:
            conds.append("kind IN (%s)" % ",".join("?" * len(kinds)))
            args += kinds
        if origin_prefix:
            conds.append("origin LIKE ?")
            args.append(origin_prefix + "%")
        if conds:
            q += " WHERE " + " AND ".join(conds)
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._c() as c:
            return [dict(r) for r in c.execute(q, args)]

    # ---- orders
    def insert_order(self, o: Dict[str, Any]) -> None:
        now = time.time()
        with self._c() as c:
            c.execute("INSERT INTO orders (client_order_id, order_id, ticker, side, action, price_p4, count_c2, filled_c2, remaining_c2,"
                      " state, exchange_status, origin, max_loss, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (o["client_order_id"], None, o["ticker"], o["side"], o.get("action", "buy"), o["price_p4"], o["count_c2"], 0, o["count_c2"],
                       "SUBMITTING", "", o["origin"], o["max_loss"], now, now))

    def update_order(self, client_order_id: str, **kw) -> None:
        if not kw:
            return
        kw["updated_at"] = time.time()
        cols = ", ".join(f"{k}=?" for k in kw)
        with self._c() as c:
            c.execute(f"UPDATE orders SET {cols} WHERE client_order_id=?", (*kw.values(), client_order_id))

    def order(self, client_order_id: str) -> Optional[Dict[str, Any]]:
        with self._c() as c:
            r = c.execute("SELECT * FROM orders WHERE client_order_id=?", (client_order_id,)).fetchone()
        return dict(r) if r else None

    def order_by_exchange_id(self, order_id: str) -> Optional[Dict[str, Any]]:
        with self._c() as c:
            r = c.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
        return dict(r) if r else None

    def orders(self, states: Optional[tuple] = None, limit: int = 300, origin_prefix: str = "") -> List[Dict[str, Any]]:
        q, args = "SELECT * FROM orders", []
        conds = []
        if states:
            conds.append("state IN (%s)" % ",".join("?" * len(states)))
            args += list(states)
        if origin_prefix:
            conds.append("origin LIKE ?")
            args.append(origin_prefix + "%")
        if conds:
            q += " WHERE " + " AND ".join(conds)
        q += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        with self._c() as c:
            return [dict(r) for r in c.execute(q, args)]

    # ---- fills
    def add_fill(self, f: Dict[str, Any]) -> bool:
        with self._c() as c:
            cur = c.execute("INSERT OR IGNORE INTO fills VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (f["fill_id"], f.get("order_id"), f.get("client_order_id"), f.get("ticker"), f.get("side"), f.get("action"),
                             f.get("count_c2"), f.get("price_p4"), int(bool(f.get("is_taker"))), f.get("created_time"),
                             json.dumps(f.get("raw", {}), default=str)))
            return cur.rowcount > 0

    def fills(self, limit: int = 200) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT fill_id, order_id, client_order_id, ticker, side, action, count_c2, price_p4,"
                                               " is_taker, created_time FROM fills ORDER BY created_time DESC LIMIT ?", (limit,))]

    def all_fills(self) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT * FROM fills ORDER BY created_time ASC")]

    # ---- position tracking (for the Transactions list)
    def track(self, ticker: str) -> Optional[Dict[str, Any]]:
        with self._c() as c:
            r = c.execute("SELECT * FROM pos_track WHERE ticker=?", (ticker,)).fetchone()
        return dict(r) if r else None

    def track_put(self, ticker: str, **kw) -> None:
        cur = self.track(ticker) or {"ticker": ticker, "side": None, "contracts": "0", "cost": "0", "fees": "0", "realized": "0",
                                     "state": "open", "how": None, "result": None, "pnl": None, "opened": time.time(), "closed": None}
        cur.update(kw)
        with self._c() as c:
            c.execute("INSERT OR REPLACE INTO pos_track VALUES (:ticker,:side,:contracts,:cost,:fees,:realized,:state,:how,:result,:pnl,:opened,:closed)", cur)

    def tracks(self, state: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._c() as c:
            if state:
                return [dict(r) for r in c.execute("SELECT * FROM pos_track WHERE state=?", (state,))]
            return [dict(r) for r in c.execute("SELECT * FROM pos_track")]

    # ---- strategies
    def strategy(self, name: str, version: str) -> Optional[Dict[str, Any]]:
        with self._c() as c:
            r = c.execute("SELECT * FROM strategies WHERE name=? AND version=?", (name, version)).fetchone()
        return dict(r) if r else None

    def upsert_strategy(self, name: str, version: str, **kw) -> None:
        cur = self.strategy(name, version) or {"name": name, "version": version, "status": "draft", "code_hash": "",
                                                 "validation": "", "approved_by": "", "approved_at": None}
        cur.update(kw)
        cur["updated_at"] = time.time()
        with self._c() as c:
            c.execute("INSERT OR REPLACE INTO strategies (name, version, status, code_hash, validation, approved_by, approved_at, updated_at)"
                      " VALUES (?,?,?,?,?,?,?,?)", (name, version, cur["status"], cur["code_hash"], cur["validation"],
                                                    cur["approved_by"], cur["approved_at"], cur["updated_at"]))

    def strategies(self) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT * FROM strategies ORDER BY name, version")]
