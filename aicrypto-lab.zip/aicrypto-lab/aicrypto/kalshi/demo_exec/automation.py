"""Demo-only automated execution, explicitly armed for each session.

A strategy can be armed only if ALL of these hold:
  * it is registered in code (STRATEGIES) and its code hash matches the approved hash,
  * it has a validation report with gates passed for exactly that code hash
    (experiments/kalshi_validation/<name>@<version>.json, produced by the replay/backtest
    pipeline of Milestone C),
  * a human approved it: `aicrypto demo approve <name> <version> --i-approve` (the AI cannot),
  * the demo account is connected, a risk budget is set and the emergency stop is off,
  * the user typed the arming phrase in the app for this session.
Arming lives in memory only: restarting the backend always comes back DISARMED.
Every automated order goes through DemoTrader.place(automated=True), so the same validation,
risk limits, kill switch and demo-only exchange apply; its origin records strategy@version.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import time
import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type

from .ledger import OPEN_STATES, DemoLedger
from .trader import DemoTrader, Intent, OrderRefused

ARM_PHRASE = "ARM DEMO"


# ------------------------------------------------------------------ strategies
@dataclass
class StrategyContext:
    now: float
    markets: List[Dict[str, Any]]          # auto-eligible open markets with quotes
    reference: Dict[str, float]            # asset -> latest settlement-reference price
    positions: List[Dict[str, Any]]
    open_orders: List[Dict[str, Any]]      # this strategy's open orders


class Strategy:
    name = "base"
    version = "0"
    description = ""
    interval_s = 10.0
    max_intents_per_tick = 2

    def decide(self, ctx: StrategyContext) -> List[Intent]:   # deterministic, no I/O
        return []


class ExampleSpreadQuoter(Strategy):
    """EXAMPLE ONLY, not validated: bids 1 contract one cent inside a wide spread on auto-eligible
    hourly BTC markets priced near 50c. Exists to exercise the engine; it makes no claim of edge."""
    name = "example_spread_quoter"
    version = "0.1"
    description = "Example: 1-lot bid inside wide spreads on hourly BTC markets near 50¢ (not validated)."
    interval_s = 15.0

    def decide(self, ctx: StrategyContext) -> List[Intent]:
        out: List[Intent] = []
        busy = {o["ticker"] for o in ctx.open_orders} | {p["ticker"] for p in ctx.positions}
        for m in ctx.markets:
            if m["asset"] != "BTC" or m["duration"] != "1h" or m["ticker"] in busy:
                continue
            b, a = m["yes_bid"], m["yes_ask"]
            if b is None or a is None or not (Decimal("0.40") <= b <= Decimal("0.60")) or a - b < Decimal("0.06"):
                continue
            if (m.get("seconds_to_close") or 0) < 1200:
                continue
            out.append(Intent(m["ticker"], "yes", b + Decimal("0.01"), 1, reason=f"spread {a - b:.2f}"))
        return out[: self.max_intents_per_tick]


STRATEGIES: Dict[str, Type[Strategy]] = {ExampleSpreadQuoter.name: ExampleSpreadQuoter}


def code_hash(cls: Type[Strategy]) -> str:
    return hashlib.sha256(inspect.getsource(cls).encode()).hexdigest()[:16]


def validation_report(root: Path, name: str, version: str) -> Optional[Dict[str, Any]]:
    p = Path(root) / "experiments" / "kalshi_validation" / f"{name}@{version}.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except ValueError:
        return None


def strategy_status(ledger: DemoLedger, root: Path, name: str, version: str) -> Dict[str, Any]:
    cls = STRATEGIES.get(name)
    if cls is None or cls.version != version:
        return {"name": name, "version": version, "status": "unknown", "why": "not registered in code"}
    h = code_hash(cls)
    rep = validation_report(root, name, version)
    validated = bool(rep and rep.get("gates_passed") is True and rep.get("code_hash") == h)
    rec = ledger.strategy(name, version) or {}
    approved = rec.get("status") == "approved_demo" and rec.get("code_hash") == h
    if approved and validated:
        status, why = "approved_demo", "validated and approved by you"
    elif validated:
        status, why = "validated", "passed validation; waiting for your approval"
    else:
        status = "draft"
        why = ("validation report is for different code" if rep and rep.get("code_hash") != h else
               "validation gates not passed" if rep else "not validated yet (needs replay/backtest results, Milestone C)")
    return {"name": name, "version": version, "description": cls.description, "status": status, "why": why,
            "code_hash": h, "metrics": (rep or {}).get("metrics", {}), "approved_at": rec.get("approved_at")}


def approve(ledger: DemoLedger, root: Path, name: str, version: str, who: str = "owner") -> Dict[str, Any]:
    """Human-only (CLI with --i-approve). Refuses anything not validated for the current code."""
    st = strategy_status(ledger, root, name, version)
    if st["status"] not in ("validated", "approved_demo"):
        raise ValueError(f"cannot approve {name}@{version}: {st['why']}")
    ledger.upsert_strategy(name, version, status="approved_demo", code_hash=st["code_hash"], approved_by=who, approved_at=time.time(),
                           validation=json.dumps(st["metrics"]))
    ledger.event("auto", f"strategy {name}@{version} approved for demo automation by {who}", origin=f"auto:{name}@{version}")
    return strategy_status(ledger, root, name, version)


def revoke(ledger: DemoLedger, name: str, version: str) -> None:
    ledger.upsert_strategy(name, version, status="revoked")
    ledger.event("auto", f"strategy {name}@{version} approval revoked", origin=f"auto:{name}@{version}")


# ------------------------------------------------------------------ engine
@dataclass
class Limits:
    max_positions: int = 3
    max_orders_per_min: int = 6


class AutomationEngine:
    def __init__(self, trader: DemoTrader, ledger: DemoLedger, root: Path,
                 context_fn: Callable[[], Dict[str, Any]], clock: Callable[[], float] = time.time):
        self.trader, self.ledger, self.root = trader, ledger, Path(root)
        self.context_fn = context_fn
        self.clock = clock
        self.state = "disarmed"           # disarmed | armed | running | paused
        self.session: Optional[str] = None
        self.strategy: Optional[Strategy] = None
        self.limits = Limits()
        self._task: Optional[asyncio.Task] = None
        self._sent: List[float] = []
        self.last_error = ""
        trader.on_kill.append(self._on_kill)

    # ---- helpers
    @property
    def origin(self) -> str:
        return f"auto:{self.strategy.name}@{self.strategy.version}:{self.session}" if self.strategy else ""

    def log(self, msg: str, payload: Any = None) -> None:
        self.ledger.event("auto", msg, origin=self.origin or "auto", payload=payload)

    def status(self) -> Dict[str, Any]:
        return {"state": self.state, "session": self.session, "arm_phrase": ARM_PHRASE,
                "strategy": {"name": self.strategy.name, "version": self.strategy.version} if self.strategy else None,
                "limits": self.limits.__dict__, "last_error": self.last_error,
                "strategies": [strategy_status(self.ledger, self.root, n, c.version) for n, c in STRATEGIES.items()]}

    # ---- controls
    def arm(self, name: str, version: str, phrase: str, max_positions: int = 3, max_orders_per_min: int = 6) -> Dict[str, Any]:
        errs = []
        if phrase != ARM_PHRASE:
            errs.append(f'Type "{ARM_PHRASE}" to arm automatic demo trading.')
        if self.state != "disarmed":
            errs.append("Automation is already armed. Stop it first.")
        st = strategy_status(self.ledger, self.root, name, version)
        if st["status"] != "approved_demo":
            errs.append(f"{name} {version} can't run: {st['why']}.")
        if self.trader.state != "connected":
            errs.append("Not connected to the Kalshi demo account.")
        if self.trader.kill_on():
            errs.append("Emergency stop is on. Reset it first.")
        if not (1 <= int(max_positions) <= 20):
            errs.append("Max positions must be 1–20.")
        if not (1 <= int(max_orders_per_min) <= 30):
            errs.append("Max orders per minute must be 1–30.")
        if errs:
            raise OrderRefused(errs)
        self.strategy = STRATEGIES[name]()
        self.session = uuid.uuid4().hex[:8]
        self.limits = Limits(int(max_positions), int(max_orders_per_min))
        self.state = "armed"
        self.log(f"ARMED {name}@{version} (code {st['code_hash']}) max_positions={max_positions} max_orders_per_min={max_orders_per_min}")
        return self.status()

    def start(self) -> Dict[str, Any]:
        if self.state not in ("armed", "paused"):
            raise OrderRefused(["Arm a strategy first."])
        self.state = "running"
        self.log("STARTED" if self._task is None else "RESUMED")
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop())
        return self.status()

    def pause(self) -> Dict[str, Any]:
        if self.state != "running":
            raise OrderRefused(["Automation is not running."])
        self.state = "paused"
        self.log("PAUSED (no new orders; open orders stay)")
        return self.status()

    async def stop(self, why: str = "user") -> Dict[str, Any]:
        was = self.origin
        await self._halt()
        canceled = 0
        if was:
            for o in self.ledger.orders(states=("RESTING", "PARTIAL"), origin_prefix=was):
                try:
                    await self.trader.cancel(o["client_order_id"], why="automation stopped")
                    canceled += 1
                except OrderRefused:
                    pass
        self.ledger.event("auto", f"STOPPED ({why}); canceled {canceled} open order(s); DISARMED", origin=was or "auto")
        return self.status()

    async def emergency(self) -> Dict[str, Any]:
        await self.trader.kill("emergency stop pressed")
        return self.status()

    async def _on_kill(self):
        if self.state != "disarmed":
            self.ledger.event("auto", "DISARMED by emergency stop", origin=self.origin or "auto")
        await self._halt()

    async def _halt(self):
        self.state = "disarmed"
        t, self._task = self._task, None
        if t is not None and t is not asyncio.current_task():
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self.strategy, self.session = None, None

    # ---- loop
    def _rate_ok(self) -> bool:
        now = self.clock()
        self._sent = [t for t in self._sent if now - t < 60]
        return len(self._sent) < self.limits.max_orders_per_min

    async def tick(self) -> int:
        """One decision cycle. Returns number of orders placed."""
        if self.state != "running" or self.strategy is None:
            return 0
        if self.trader.kill_on():
            await self._halt()
            return 0
        raw = self.context_fn()
        mine = self.ledger.orders(states=OPEN_STATES, origin_prefix=f"auto:{self.strategy.name}@{self.strategy.version}")
        ctx = StrategyContext(now=self.clock(), markets=raw.get("markets", []), reference=raw.get("reference", {}),
                              positions=self.trader.account.get("positions", []), open_orders=mine)
        try:
            intents = list(self.strategy.decide(ctx))[: self.strategy.max_intents_per_tick]
        except Exception as e:
            self.state, self.last_error = "paused", f"strategy error: {type(e).__name__}: {e}"
            self.log("PAUSED: " + self.last_error)
            return 0
        placed = 0
        held = {p["ticker"] for p in ctx.positions} | {o["ticker"] for o in mine}
        working = {o["ticker"] for o in mine}
        for it in intents:
            if it.ticker in working:
                continue                     # one working order per market per strategy
            if it.ticker not in held and len(held) >= self.limits.max_positions:
                self.log(f"skipped {it.ticker}: max positions ({self.limits.max_positions}) reached")
                continue
            if not self._rate_ok():
                self.log("skipped: order rate limit reached")
                break
            it.origin = self.origin
            try:
                r = await self.trader.place(it, automated=True)
                self._sent.append(self.clock())
                held.add(it.ticker)
                working.add(it.ticker)
                placed += 1
                self.log(f"order {r['state']}: buy {it.count} {it.side.upper()} @ ${it.price:.2f} {it.ticker} ({it.reason})",
                         {"client_order_id": r["client_order_id"]})
            except OrderRefused as e:
                self.log(f"refused {it.ticker}: {'; '.join(e.errors)}")
        return placed

    async def _loop(self):
        while self.state in ("running", "paused"):
            if self.state == "running":
                try:
                    await self.tick()
                except Exception as e:
                    self.state, self.last_error = "paused", f"{type(e).__name__}: {e}"
                    self.log("PAUSED after error: " + self.last_error)
            await asyncio.sleep(self.strategy.interval_s if self.strategy else 5)
