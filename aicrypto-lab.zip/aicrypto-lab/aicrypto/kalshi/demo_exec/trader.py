"""Demo order management: validation, risk, confirmation, submission, reconciliation, kill switch.

Every order (manual or automated) goes through DemoTrader.place(). Manual orders additionally
need a single-use confirmation token issued by prepare() for exactly the same parameters.
"""
from __future__ import annotations

import asyncio
import hmac
import logging
import secrets
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import ROUND_CEILING, Decimal, InvalidOperation
from typing import Any, Callable, Dict, List, Optional, Protocol

from ...terminal.fees import fee_estimate
from ..models import MarketStatus, dollars_to_p4, fp_to_c2
from ..settings import KalshiSettings
from .exchange import DemoExchange, DemoOnlyViolation, ExchangeError, UncertainOutcome
from .ledger import OPEN_STATES, DemoLedger

log = logging.getLogger("aicrypto.demo")

P4 = Decimal("0.0001")
CENT = Decimal("0.01")
MAX_CONTRACTS = 500
FAT_FINGER = Decimal("0.10")          # never pay more than 10c above the best offer
BOOK_MAX_AGE_S = 15.0
TOKEN_TTL_S = 60.0
UNKNOWN_FAIL_AFTER = 3                # reconcile attempts before declaring "not placed"
UNKNOWN_MIN_AGE_S = 15.0
CASHOUT_SLIPPAGE = Decimal("0.10")    # a cash-out sells no lower than 10c under the best bid


class MarketContext(Protocol):
    def market_access(self, ticker: str): ...
    def market(self, ticker: str): ...
    def series_for(self, ticker: str): ...
    async def fresh_book(self, ticker: str) -> Dict[str, Any]: ...


@dataclass
class Intent:
    ticker: str
    side: str            # yes | no
    price: Decimal       # dollars, price of the side being bought
    count: int
    origin: str = "manual"
    reason: str = ""


class OrderRefused(Exception):
    def __init__(self, errors: List[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


def _d(s: Any) -> Decimal:
    try:
        return Decimal(str(s))
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(0)


def risk_errors(*, max_loss: Decimal, budget: Optional[Decimal], per_position: float, aggregate: float, daily_stop: float,
                exposure: Decimal, resting: Decimal, realized_today: Decimal, available: Optional[Decimal], kill: bool,
                existing_position_loss: Decimal = Decimal(0)) -> List[str]:
    """Pure risk check. Amounts in dollars (Decimal). Limits are fractions of the selected demo budget."""
    e: List[str] = []
    if kill:
        e.append("Emergency stop is on. Reset it in Settings before placing orders.")
    if budget is None or budget <= 0:
        # owner decision 2026-11-09: no risk budget by default; the cap is the demo cash available
        if available is not None and max_loss > available:
            e.append(f"Not enough demo cash (${available:.2f} available).")
        return e
    if max_loss + existing_position_loss > budget * Decimal(str(per_position)):
        e.append(f"Max loss ${max_loss + existing_position_loss:.2f} on this market is over the {per_position:.0%} per-position limit "
                 f"(${budget * Decimal(str(per_position)):.2f}).")
    if exposure + resting + max_loss > budget * Decimal(str(aggregate)):
        e.append(f"Total open risk would be ${exposure + resting + max_loss:.2f}, over the {aggregate:.0%} limit "
                 f"(${budget * Decimal(str(aggregate)):.2f}).")
    if realized_today <= -budget * Decimal(str(daily_stop)):
        e.append(f"Daily loss stop reached (${-realized_today:.2f} lost today, limit {daily_stop:.0%}). New orders resume tomorrow.")
    if available is not None and max_loss > available:
        e.append(f"Not enough demo balance (${available:.2f} available).")
    return e


class DemoTrader:
    def __init__(self, ks: KalshiSettings, ledger: DemoLedger, ctx: MarketContext,
                 exchange_factory: Callable[[], Optional[DemoExchange]], clock: Callable[[], float] = time.time):
        self.ks, self.ledger, self.ctx = ks, ledger, ctx
        self.exchange_factory = exchange_factory
        self.clock = clock
        self.ex: Optional[DemoExchange] = None
        self.state = "off"          # off | no_credentials | connected | error
        self.last_error = ""
        self.account: Dict[str, Any] = {}
        self._tokens: Dict[str, Dict[str, Any]] = {}
        self._secret = secrets.token_bytes(32)
        self.shards: Dict[int, Decimal] = {}
        self.on_kill: List[Callable[[], Any]] = []

    # ------------------------------------------------------------------ connection / account
    def exchange(self) -> Optional[DemoExchange]:
        if self.ex is None:
            try:
                self.ex = self.exchange_factory()
            except DemoOnlyViolation as e:
                self.state, self.last_error = "error", str(e)
                return None
            if self.ex is None:
                self.state = "no_credentials"
        return self.ex

    async def refresh_account(self) -> Dict[str, Any]:
        ex = self.exchange()
        if ex is None:
            return self.account
        try:
            bal = await ex.balance()
            shards = {int(b["exchange_index"]): _d(b.get("balance")) for b in (bal.get("balance_breakdown") or [])
                      if isinstance(b, dict) and b.get("exchange_index") is not None}
            rows, seen_t = [], set()
            for idx in (sorted(shards) or [None]):          # reads are per exchange shard
                for p in (await ex.positions(exchange_index=idx)).get("market_positions") or []:
                    if p.get("ticker") not in seen_t:
                        seen_t.add(p.get("ticker"))
                        rows.append(p)
        except ExchangeError as e:
            self.state, self.last_error = "error", str(e)
            return self.account
        self.shards = shards
        try:
            self._track_positions(rows)
        except Exception as e:                    # bookkeeping must never break the account view
            log.error("position tracking failed: %s", e)
        positions = []
        realized_total = Decimal(0)
        for p in rows:
            qty = _d(p.get("position_fp", p.get("position", 0)))
            rp = _d(p.get("realized_pnl_dollars", "0"))
            realized_total += rp
            if qty != 0:
                positions.append({"ticker": p.get("ticker"), "side": "yes" if qty > 0 else "no", "contracts": str(abs(qty)),
                                  "exposure": str(_d(p.get("market_exposure_dollars"))), "realized_pnl": str(rp),
                                  "fees_paid": str(_d(p.get("fees_paid_dollars")))})
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.ledger.get("realized_day") != today:
            self.ledger.put("realized_day", today)
            self.ledger.put("realized_start", str(realized_total))
        realized_today = realized_total - _d(self.ledger.get("realized_start", "0"))
        if self.account.get("realized_today") is not None and getattr(self.ctx, "pnl_today", None):
            realized_today = _d(self.account["realized_today"])    # the service's figure from closed positions
        self.account = {"balance": str((_d(bal.get("balance", 0)) / 100).quantize(CENT)),
                        "portfolio_value": str((_d(bal.get("portfolio_value", 0)) / 100).quantize(CENT)),
                        "positions": positions, "realized_today": str(realized_today), "t": self.clock(),
                        "shards": {str(k): str(v) for k, v in shards.items()}}
        self.state, self.last_error = "connected", ""
        return self.account

    def _track_positions(self, rows: List[Dict[str, Any]]) -> None:
        """Remember each position while it is open so it can be listed once it closes.
        Kalshi's own realized P/L and fees are used for positions closed by selling."""
        now = self.clock()
        seen = set()
        for p in rows:
            t = p.get("ticker")
            if not t:
                continue
            seen.add(t)
            qty = _d(p.get("position_fp", p.get("position", 0)))
            realized, fees = _d(p.get("realized_pnl_dollars", "0")), _d(p.get("fees_paid_dollars", "0"))
            tr = self.ledger.track(t)
            if qty != 0:
                kw = dict(side="yes" if qty > 0 else "no", contracts=str(abs(qty)), cost=str(_d(p.get("market_exposure_dollars")).copy_abs()),
                          fees=str(fees), realized=str(realized), state="open", how=None, pnl=None, closed=None)
                if tr is None or tr["state"] != "open":
                    kw["opened"] = now
                self.ledger.track_put(t, **kw)
            elif (tr and tr["state"] == "open") or (tr is None and (realized != 0 or fees != 0 or _d(p.get("total_traded_dollars", "0")) != 0)):
                kw = dict(state="closed", how="cashout", pnl=str(realized), realized=str(realized), fees=str(fees), closed=now)
                if tr is None:                   # closed before tracking began: take side/size from our own orders
                    buys = [o for o in self.ledger.orders(limit=500) if o["ticker"] == t and o["action"] == "buy" and (o["filled_c2"] or 0) > 0]
                    if buys:
                        first = buys[-1]
                        n = sum((o["filled_c2"] or 0) for o in buys) / 100
                        kw.update(side=first["side"], contracts=f"{n:.2f}", opened=first["created_at"],
                                  cost=str(sum((Decimal(o["filled_c2"] or 0) / 100) * Decimal(o["price_p4"] or 0) / 10000 for o in buys)))
                self.ledger.track_put(t, **kw)
            elif tr and tr["state"] == "closed" and tr["how"] == "cashout":
                self.ledger.track_put(t, pnl=str(realized), realized=str(realized), fees=str(fees))      # keep Kalshi's latest numbers
        for tr in self.ledger.tracks("open"):
            if tr["ticker"] not in seen:         # no longer listed: the market settled
                self.ledger.track_put(tr["ticker"], state="gone", closed=now)

    # ------------------------------------------------------------------ settings
    def budget(self) -> Optional[Decimal]:
        v = self.ledger.get("risk_budget_v2")
        return _d(v) if v else None

    def set_budget(self, amount: Any) -> Optional[Decimal]:
        """Optional. Empty or 0 removes the limit (then only the account's cash caps an order)."""
        if amount in (None, "", "0", 0):
            self.ledger.put("risk_budget_v2", None)
            self.ledger.event("settings", "risk limit removed (using account cash)")
            return None
        a = _d(amount).quantize(CENT)
        if not (Decimal(1) <= a <= Decimal(1_000_000)):
            raise OrderRefused(["Limit must be between $1 and $1,000,000, or empty for no limit."])
        self.ledger.put("risk_budget_v2", str(a))
        self.ledger.event("settings", f"risk budget set to ${a}")
        return a

    def kill_on(self) -> bool:
        return self.ledger.get("kill_switch") == "on"

    # ------------------------------------------------------------------ validation
    def _exposure(self) -> Decimal:
        return sum((_d(p["exposure"]).copy_abs() for p in self.account.get("positions", [])), Decimal(0))

    def _resting_risk(self) -> Decimal:
        tot = Decimal(0)
        for o in self.ledger.orders(states=OPEN_STATES):
            tot += _d(o["max_loss"]) * (Decimal(o["remaining_c2"] or 0) / Decimal(o["count_c2"] or 1))
        return tot

    async def validate(self, it: Intent, *, automated: bool, feed_free: bool = False) -> Dict[str, Any]:
        errors: List[str] = []
        side = (it.side or "").lower()
        if side not in ("yes", "no"):
            errors.append("Side must be YES or NO.")
        a = self.ctx.market_access(it.ticker)
        m = self.ctx.market(it.ticker)
        if a is None or m is None or not a.visible:
            raise OrderRefused(["This market is not available for trading."])
        if automated:
            # Bots may act inside the final minute (the manual 60-second cutoff is for people);
            # they stop 3 seconds before the close.
            now_dt = self.ctx.now_fn() if hasattr(self.ctx, "now_fn") else datetime.now(timezone.utc)
            secs = (m.close_time - now_dt).total_seconds() if m.close_time else 0
            blk = [b for b in (a.auto_blockers if not feed_free else a.manual_blockers) if b != "closing"]
            if secs < 3:
                errors.append("Market closes in under 3 seconds.")
            if blk:
                txt = {b["code"]: b["text"] for b in a.to_dict()["auto_blockers" if not feed_free else "manual_blockers"]}
                errors.append(("Market is not eligible for automated trading: " if not feed_free else
                               "Market is not open for automated feed-free trading: ") + "; ".join(txt[c] for c in blk))
        if not automated and not a.manual:
            errors.append("Market is not open for manual demo orders: " + "; ".join(b["text"] for b in a.to_dict()["manual_blockers"]))
        if m.status is not MarketStatus.ACTIVE:
            errors.append("Market is not open.")
        price = it.price
        tick = Decimal(m.tick_p4 or 100) * P4
        if not (Decimal("0.01") <= price <= Decimal("0.99")):
            errors.append("Price must be between $0.01 and $0.99.")
        elif price % tick != 0:
            errors.append(f"Price must be a multiple of ${tick:.2f}.")
        if not isinstance(it.count, int) or it.count < 1:
            errors.append("Quantity must be a whole number of at least 1.")
        elif it.count > MAX_CONTRACTS:
            errors.append(f"Quantity is limited to {MAX_CONTRACTS} contracts per order.")
        book = await self.ctx.fresh_book(it.ticker)
        if not book.get("valid") or (book.get("age_s") or 0) > BOOK_MAX_AGE_S:
            errors.append("No valid, fresh order book for this market right now.")
        else:
            best_ask_p4 = book.get("best_yes_ask") if side == "yes" else (10000 - book["best_yes_bid"] if book.get("best_yes_bid") else None)
            if best_ask_p4 and price > Decimal(best_ask_p4) * P4 + FAT_FINGER:
                errors.append(f"Price is more than ${FAT_FINGER:.2f} above the best offer (${Decimal(best_ask_p4) * P4:.2f}); check the price.")
        s = self.ctx.series_for(it.ticker)
        cnt = Decimal(it.count if isinstance(it.count, int) else 0)
        cost = (price * cnt).quantize(CENT, rounding=ROUND_CEILING)
        fee = fee_estimate(cnt, price, fee_type=s.fee_type if s else "quadratic", multiplier=_d(s.fee_multiplier if s else 1))
        max_loss = cost + fee
        if not self.account or self.clock() - self.account.get("t", 0) > 10:
            await self.refresh_account()
        if self.state != "connected":
            errors.append("Not connected to the Kalshi demo account.")
        existing = Decimal(0)
        for p in self.account.get("positions", []):
            if p["ticker"] == it.ticker:
                existing += _d(p["exposure"]).copy_abs()
        errors += risk_errors(max_loss=max_loss, budget=self.budget(), per_position=self.ks.risk.max_loss_per_position,
                              aggregate=self.ks.risk.max_aggregate_planned_loss, daily_stop=self.ks.risk.daily_realized_loss_stop,
                              exposure=self._exposure(), resting=self._resting_risk(), realized_today=_d(self.account.get("realized_today", "0")),
                              available=_d(self.account["balance"]) if self.account.get("balance") is not None else None,
                              kill=self.kill_on(), existing_position_loss=existing)
        return {"errors": errors, "cost": cost, "fee": fee, "max_loss": max_loss, "max_profit": cnt - cost - fee,
                "title": (m.yes_sub_title or m.title), "book": book}

    # ------------------------------------------------------------------ manual: prepare + confirm
    def _key(self, it: Intent) -> str:
        return f"{it.ticker}|{it.side.lower()}|{it.price:.4f}|{it.count}"

    async def prepare(self, it: Intent) -> Dict[str, Any]:
        v = await self.validate(it, automated=False)
        out = {"ticker": it.ticker, "title": v["title"], "side": it.side.lower(), "price": f"{it.price:.2f}", "count": it.count,
               "cost": f"{v['cost']:.2f}", "fee": f"{v['fee']:.2f}", "max_loss": f"{v['max_loss']:.2f}",
               "max_profit": f"{v['max_profit']:.2f}", "errors": v["errors"], "token": None}
        if not v["errors"]:
            tok = secrets.token_urlsafe(24)
            self._tokens[tok] = {"key": self._key(it), "intent": it, "exp": self.clock() + TOKEN_TTL_S}
            out["token"], out["expires_in"] = tok, int(TOKEN_TTL_S)
        return out

    async def confirm(self, token: str, ticker: str, side: str, price: str, count: int) -> Dict[str, Any]:
        rec = self._tokens.pop(token or "", None)               # single use
        it = Intent(ticker, side, _d(price), count, origin="manual")
        if rec is None:
            raise OrderRefused(["This confirmation is invalid or was already used. Review the order again."])
        if rec["exp"] < self.clock():
            raise OrderRefused(["This confirmation expired. Review the order again."])
        if not hmac.compare_digest(rec["key"], self._key(it)):
            raise OrderRefused(["The order changed after review. Review it again."])
        return await self.place(rec["intent"], automated=False)

    # ------------------------------------------------------------------ placement (all orders)
    async def place(self, it: Intent, *, automated: bool, feed_free: bool = False) -> Dict[str, Any]:
        v = await self.validate(it, automated=automated, feed_free=feed_free)
        if v["errors"]:
            self.ledger.event("refused", "; ".join(v["errors"]), origin=it.origin, payload={"ticker": it.ticker, "side": it.side,
                                                                                        "price": str(it.price), "count": it.count})
            raise OrderRefused(v["errors"])
        ex = self.exchange()
        if ex is None:
            raise OrderRefused(["Not connected to the Kalshi demo account."])
        await self.ensure_shard_funds(it.ticker, v["max_loss"])
        cid = str(uuid.uuid4())
        side = it.side.lower()
        price_s = f"{it.price:.4f}"
        self.ledger.insert_order({"client_order_id": cid, "ticker": it.ticker, "side": side, "price_p4": dollars_to_p4(price_s),
                                  "count_c2": it.count * 100, "origin": it.origin, "max_loss": str(v["max_loss"])})
        body = {"ticker": it.ticker, "client_order_id": cid, "side": side, "action": "buy", "type": "limit", "count": it.count,
                ("yes_price_dollars" if side == "yes" else "no_price_dollars"): price_s, "time_in_force": "good_till_canceled"}
        self.ledger.event("submit", f"buy {it.count} {side.upper()} @ ${it.price:.2f} {it.ticker}", client_order_id=cid,
                          origin=it.origin, payload={**body, "reason": it.reason})
        try:
            resp = await ex.create_order(body)
        except UncertainOutcome as e:
            self.ledger.update_order(cid, state="UNKNOWN", error=str(e))
            self.ledger.event("uncertain", f"outcome unknown ({e}); will reconcile before anything else", client_order_id=cid, origin=it.origin)
            return {"client_order_id": cid, "state": "UNKNOWN"}
        except ExchangeError as e:
            self.ledger.update_order(cid, state="REJECTED", error=e.message[:300])
            self.ledger.event("rejected", e.message[:300], client_order_id=cid, origin=it.origin)
            raise OrderRefused([f"Kalshi rejected the order: {e.message[:200]}"])
        self._apply_exchange_order(cid, resp.get("order") or {}, ack=True)
        return {"client_order_id": cid, "state": self.ledger.order(cid)["state"], "order_id": self.ledger.order(cid)["order_id"]}

    def _apply_exchange_order(self, cid: str, o: Dict[str, Any], ack: bool = False) -> None:
        if not o:
            return
        status = (o.get("status") or "").lower()
        filled = fp_to_c2(o.get("fill_count_fp")) if o.get("fill_count_fp") is not None else int(o.get("fill_count", 0) or 0) * 100
        remaining = fp_to_c2(o.get("remaining_count_fp")) if o.get("remaining_count_fp") is not None else int(o.get("remaining_count", 0) or 0) * 100
        fees = _d(o.get("taker_fees_dollars", "0")) + _d(o.get("maker_fees_dollars", "0"))
        prev = self.ledger.order(cid) or {}
        if status == "executed":
            state = "FILLED"
        elif status == "canceled":
            state = "CANCELED"
        elif status == "resting":
            state = "PARTIAL" if filled else "RESTING"
        else:
            state = prev.get("state") or "UNKNOWN"
        if prev.get("state") == "CANCEL_PENDING" and status == "resting":
            state = "CANCEL_PENDING"
        self.ledger.update_order(cid, order_id=o.get("order_id") or prev.get("order_id"), exchange_status=status, state=state,
                                 filled_c2=filled or 0, remaining_c2=remaining if remaining is not None else prev.get("remaining_c2"),
                                 fees=str(fees))
        if ack:
            self.ledger.event("ack", f"accepted by exchange: {status}", client_order_id=cid, origin=prev.get("origin", ""),
                              payload={"order_id": o.get("order_id")})
        elif prev.get("state") != state or (prev.get("filled_c2") or 0) != (filled or 0):
            kind = "fill" if (filled or 0) > (prev.get("filled_c2") or 0) else "status"
            self.ledger.event(kind, f"{state} · filled {(filled or 0) / 100:g}/{(prev.get('count_c2') or 0) / 100:g}",
                              client_order_id=cid, origin=prev.get("origin", ""))

    # ------------------------------------------------------------------ cancel / kill
    async def cancel(self, client_order_id: str, why: str = "user") -> Dict[str, Any]:
        o = self.ledger.order(client_order_id)
        if o is None:
            raise OrderRefused(["Unknown order."])
        if o["state"] not in ("RESTING", "PARTIAL", "CANCEL_PENDING"):
            raise OrderRefused([f"Order is {o['state'].lower()}; nothing to cancel."])
        ex = self.exchange()
        if ex is None or not o["order_id"]:
            raise OrderRefused(["Not connected to the Kalshi demo account."])
        self.ledger.update_order(client_order_id, state="CANCEL_PENDING")
        self.ledger.event("cancel", f"cancel requested ({why})", client_order_id=client_order_id, origin=o["origin"])
        try:
            resp = await ex.cancel_order(o["order_id"], o["ticker"])
        except UncertainOutcome:
            return {"client_order_id": client_order_id, "state": "CANCEL_PENDING"}
        except ExchangeError as e:
            self.ledger.event("cancel_error", e.message[:200], client_order_id=client_order_id, origin=o["origin"])
            if e.status == 404:
                await self._refresh_one(client_order_id)
                return {"client_order_id": client_order_id, "state": self.ledger.order(client_order_id)["state"]}
            raise OrderRefused([f"Cancel failed: {e.message[:200]}"])
        self._apply_exchange_order(client_order_id, resp.get("order") or {"status": "canceled", "order_id": o["order_id"]})
        if self.ledger.order(client_order_id)["state"] == "CANCEL_PENDING":
            self.ledger.update_order(client_order_id, state="CANCELED")
        return {"client_order_id": client_order_id, "state": self.ledger.order(client_order_id)["state"]}

    # ------------------------------------------------------------------ exchange-shard funding
    def _shard_list(self) -> List[Optional[int]]:
        return sorted(self.shards) or [None]

    async def ensure_shard_funds(self, ticker: str, need: Decimal) -> None:
        """Kalshi keeps cash per exchange shard and does not auto-fund API orders. If this market's
        shard is short, move the account's demo cash there from its other shards and wait for it."""
        ex = self.exchange()
        shard = await self.ctx.market_shard(ticker) if hasattr(self.ctx, "market_shard") else None
        if ex is None or shard is None or not self.shards:
            return
        if self.shards.get(shard, Decimal(0)) >= need:
            return
        moved = Decimal(0)
        for src, bal in sorted(self.shards.items(), key=lambda kv: -kv[1]):
            if src == shard or bal <= 0:
                continue
            tid = str(uuid.uuid4())
            self.ledger.event("funding", f"moving ${bal:.2f} demo cash from exchange {src} to exchange {shard} (needed for {ticker})",
                              payload={"client_transfer_id": tid})
            try:
                await ex.shard_transfer(bal, src, shard, tid)
                moved += bal
            except UncertainOutcome:
                moved += bal                      # may have gone through; the balance poll below decides
            except ExchangeError as e:
                self.ledger.event("funding_error", e.message[:200])
                raise OrderRefused([f"Couldn't move demo cash to this market's exchange: {e.message[:160]}"])
        if moved <= 0:
            raise OrderRefused([f"Not enough demo cash for this market (needs ${need:.2f})."])
        for _ in range(20):                       # transfers are asynchronous on Kalshi's side
            await self.refresh_account()
            if self.shards.get(shard, Decimal(0)) >= need:
                self.ledger.event("funding", f"exchange {shard} funded: ${self.shards[shard]:.2f} available")
                return
            await asyncio.sleep(1.0)
        raise OrderRefused(["Demo cash is still moving to this market's exchange. Try again in a few seconds."])

    # ------------------------------------------------------------------ cash out one position
    async def cashout_quote(self, ticker: str, slippage: Optional[Decimal] = None) -> Dict[str, Any]:
        """What an immediate exit would look like right now (no order is sent)."""
        await self.refresh_account()
        pos = next((p for p in self.account.get("positions", []) if p["ticker"] == ticker), None)
        if pos is None:
            raise OrderRefused(["You have no open position in this market."])
        count = int(_d(pos["contracts"]))
        if count < 1:
            raise OrderRefused(["Position is smaller than one contract."])
        book = await self.ctx.fresh_book(ticker)
        if not book.get("valid"):
            raise OrderRefused(["Can't read this market's order book right now. Try again."])
        bid_p4 = book.get("best_yes_bid") if pos["side"] == "yes" else (10000 - book["best_yes_ask"] if book.get("best_yes_ask") else None)
        if not bid_p4 or bid_p4 < 100:
            raise OrderRefused(["Nobody is bidding for this position right now, so it can't be cashed out. It will settle when the market closes."])
        bid = Decimal(bid_p4) * P4
        floor = max(Decimal("0.01"), (bid - (CASHOUT_SLIPPAGE if slippage is None else slippage)).quantize(CENT))
        return {"ticker": ticker, "side": pos["side"], "count": count, "bid": bid, "floor": floor,
                "est_proceeds": (bid * count).quantize(CENT), "cost": _d(pos["exposure"]).copy_abs()}

    async def cashout(self, ticker: str, origin: str = "manual", slippage: Optional[Decimal] = None) -> Dict[str, Any]:
        """Sell the whole position now: immediate-or-cancel, reduce-only, at most 10c below the best
        bid. Allowed while the emergency stop is on (it only reduces risk)."""
        ex = self.exchange()
        if ex is None:
            raise OrderRefused(["Not connected to the Kalshi demo account."])
        q = await self.cashout_quote(ticker, slippage)
        for o in self.ledger.orders(states=("RESTING", "PARTIAL")):          # resting buys would reopen the position
            if o["ticker"] == ticker and o["action"] == "buy":
                try:
                    await self.cancel(o["client_order_id"], why="cash out")
                except OrderRefused:
                    pass
        cid = str(uuid.uuid4())
        side, price_s = q["side"], f"{q['floor']:.4f}"
        self.ledger.insert_order({"client_order_id": cid, "ticker": ticker, "side": side, "action": "sell", "price_p4": dollars_to_p4(price_s),
                                  "count_c2": q["count"] * 100, "origin": f"cashout:{origin}", "max_loss": "0"})
        body = {"ticker": ticker, "client_order_id": cid, "side": side, "action": "sell", "type": "limit", "count": q["count"],
                ("yes_price_dollars" if side == "yes" else "no_price_dollars"): price_s,
                "time_in_force": "immediate_or_cancel", "reduce_only": True}
        self.ledger.event("cashout", f"sell {q['count']} {side.upper()} {ticker} (best bid ${q['bid']:.2f}, floor ${q['floor']:.2f})",
                          client_order_id=cid, origin=f"cashout:{origin}", payload=body)
        try:
            resp = await ex.create_order(body)
        except UncertainOutcome as e:
            self.ledger.update_order(cid, state="UNKNOWN", error=str(e))
            self.ledger.event("uncertain", "cash-out outcome unknown; checking with the exchange", client_order_id=cid, origin=f"cashout:{origin}")
            return {"client_order_id": cid, "state": "UNKNOWN", "sold": 0, "count": q["count"]}
        except ExchangeError as e:
            self.ledger.update_order(cid, state="REJECTED", error=e.message[:300])
            self.ledger.event("rejected", e.message[:300], client_order_id=cid, origin=f"cashout:{origin}")
            raise OrderRefused([f"Kalshi rejected the cash-out: {e.message[:200]}"])
        self._apply_exchange_order(cid, resp.get("order") or {}, ack=True)
        o = self.ledger.order(cid)
        if o["state"] in ("RESTING", "PARTIAL"):          # an IOC order should never rest; make sure
            try:
                await self.cancel(cid, why="cash-out remainder")
            except OrderRefused:
                pass
            o = self.ledger.order(cid)
        await self.refresh_account()
        return {"client_order_id": cid, "state": o["state"], "sold": (o["filled_c2"] or 0) / 100, "count": q["count"]}

    async def kill(self, why: str = "emergency stop") -> Dict[str, Any]:
        self.ledger.put("kill_switch", "on")
        self.ledger.event("kill", f"EMERGENCY STOP: {why}")
        for cb in self.on_kill:
            try:
                r = cb()
                if hasattr(r, "__await__"):
                    await r
            except Exception as e:  # never let a callback block the stop
                log.error("kill callback failed: %s", e)
        canceled, failed = 0, 0
        for o in self.ledger.orders(states=("RESTING", "PARTIAL", "CANCEL_PENDING")):
            try:
                await self.cancel(o["client_order_id"], why="emergency stop")
                canceled += 1
            except Exception:
                failed += 1
        ex = self.exchange()
        if ex is not None:                       # also anything resting on the exchange we don't know locally
            try:
                rest_orders = []
                for idx in self._shard_list():
                    rest_orders += (await ex.orders(status="resting", exchange_index=idx)).get("orders") or []
                for o in {x.get("order_id"): x for x in rest_orders}.values():
                    if self.ledger.order_by_exchange_id(o.get("order_id")) is None:
                        try:
                            await ex.cancel_order(o["order_id"], o.get("ticker"))
                            canceled += 1
                        except Exception:
                            failed += 1
            except ExchangeError:
                failed += 1
        self.ledger.event("kill", f"emergency stop finished: {canceled} canceled, {failed} failed")
        return {"canceled": canceled, "failed": failed}

    def reset_kill(self) -> None:
        self.ledger.put("kill_switch", None)
        self.ledger.event("kill", "emergency stop reset by user")

    # ------------------------------------------------------------------ reconciliation
    async def _find_orders(self, ticker: str, min_ts: Optional[int] = None) -> List[Dict[str, Any]]:
        out: Dict[str, Dict[str, Any]] = {}
        for idx in self._shard_list():
            for x in (await self.ex.orders(ticker=ticker, min_ts=min_ts, exchange_index=idx)).get("orders") or []:
                out[x.get("order_id")] = x
        return list(out.values())

    async def _refresh_one(self, cid: str) -> None:
        o = self.ledger.order(cid)
        if not o or not o["order_id"] or self.ex is None:
            return
        try:
            found = next((x for x in await self._find_orders(o["ticker"], int(o["created_at"]) - 300) if x.get("order_id") == o["order_id"]), None)
            if found is None:
                found = (await self.ex.order(o["order_id"])).get("order")
            self._apply_exchange_order(cid, found or {})
        except ExchangeError:
            pass

    async def reconcile(self) -> Dict[str, int]:
        """Bring local records in line with the exchange. Never submits anything."""
        ex = self.exchange()
        stats = {"adopted": 0, "failed": 0, "updated": 0, "fills": 0}
        if ex is None:
            return stats
        # 1) uncertain submissions: find them by client_order_id before anything else
        for o in self.ledger.orders(states=("UNKNOWN", "SUBMITTING")):
            if self.clock() - o["created_at"] < 2:
                continue
            try:
                found = None
                for x in await self._find_orders(o["ticker"], int(o["created_at"]) - 300):
                    if x.get("client_order_id") == o["client_order_id"]:
                        found = x
                        break
            except ExchangeError:
                continue
            if found:
                self._apply_exchange_order(o["client_order_id"], found)
                self.ledger.event("reconciled", "order found on the exchange after uncertain submit", client_order_id=o["client_order_id"], origin=o["origin"])
                stats["adopted"] += 1
            else:
                n = (o["reconcile_attempts"] or 0) + 1
                self.ledger.update_order(o["client_order_id"], reconcile_attempts=n)
                if n >= UNKNOWN_FAIL_AFTER and self.clock() - o["created_at"] >= UNKNOWN_MIN_AGE_S:
                    self.ledger.update_order(o["client_order_id"], state="FAILED", error="not found on the exchange: order was not placed")
                    self.ledger.event("failed", "not placed (confirmed absent on the exchange); safe to place again",
                                      client_order_id=o["client_order_id"], origin=o["origin"])
                    stats["failed"] += 1
        # 2) open orders: refresh status, fills, partial fills
        for o in self.ledger.orders(states=("RESTING", "PARTIAL", "CANCEL_PENDING")):
            before = (o["state"], o["filled_c2"])
            await self._refresh_one(o["client_order_id"])
            after = self.ledger.order(o["client_order_id"])
            if (after["state"], after["filled_c2"]) != before:
                stats["updated"] += 1
        # 3) fills
        try:
            since = int(_d(self.ledger.get("fills_since", "0")))
            all_fills: Dict[str, Dict[str, Any]] = {}
            for idx in self._shard_list():
                for f in (await ex.fills(min_ts=since or None, exchange_index=idx)).get("fills") or []:
                    all_fills[f.get("fill_id") or f.get("trade_id") or f"{f.get('order_id')}:{f.get('created_time')}"] = f
            newest = since
            for f in all_fills.values():
                local = self.ledger.order_by_exchange_id(f.get("order_id") or "")
                price = f.get("yes_price_dollars") if (f.get("side") == "yes") else f.get("no_price_dollars")
                added = self.ledger.add_fill({"fill_id": f.get("fill_id") or f.get("trade_id") or f"{f.get('order_id')}:{f.get('created_time')}",
                                              "order_id": f.get("order_id"), "client_order_id": local["client_order_id"] if local else "",
                                              "ticker": f.get("ticker") or f.get("market_ticker"), "side": f.get("side"), "action": f.get("action"),
                                              "count_c2": fp_to_c2(f.get("count_fp")) if f.get("count_fp") is not None else int(_d(f.get("count", 0)) * 100),
                                              "price_p4": dollars_to_p4(price), "is_taker": f.get("is_taker"),
                                              "created_time": f.get("created_time"), "raw": f})
                stats["fills"] += int(added)
                try:
                    ts = int(datetime.fromisoformat(str(f.get("created_time")).replace("Z", "+00:00")).timestamp())
                    newest = max(newest, ts - 5)
                except (ValueError, TypeError):
                    pass
            if newest > since:
                self.ledger.put("fills_since", str(newest))
        except ExchangeError:
            pass
        return stats

    def issues(self) -> List[Dict[str, str]]:
        out = []
        unk = self.ledger.orders(states=("UNKNOWN",))
        if unk:
            out.append({"id": "ORDER-UNCERTAIN", "level": "warning", "title": "Checking an order with Kalshi",
                        "message": f"{len(unk)} order(s) had a network problem while sending. The app is checking whether they went through before doing anything else.",
                        "detail": ",".join(o["client_order_id"] for o in unk)})
        if self.kill_on():
            out.append({"id": "KILL-ON", "level": "warning", "title": "Emergency stop is on",
                        "message": "No demo orders can be placed until you reset it in Settings.", "detail": "kill_switch=on"})
        if self.state == "error":
            out.append({"id": "DEMO-ACCOUNT", "level": "error", "title": "Can't reach your Kalshi demo account",
                        "message": "Balance, positions and orders can't be loaded right now.", "detail": self.last_error})
        return out
