"""Kalshi DEMO-environment order execution (Milestone B/D). See exchange.py for the guarantees."""
