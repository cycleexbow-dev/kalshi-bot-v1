"""Kalshi DEMO exchange client — the only code in this repository that can place an order.

Structural guarantees (tested in tests/test_demo_exec.py):
  * The base URL is a module constant for Kalshi's demo host. There is no parameter, setting,
    environment variable or UI control that changes it. Production hosts are listed below only
    so that any attempt to reach them is detected and refused.
  * Credentials must be demo credentials (Credentials.env == "demo"); anything else is refused.
  * A separate allowlist covers exactly: balance, positions, orders (list/get; V2 create/cancel),
    moving the account's own cash between exchange shards,
    fills. No multi-order, amend, decrease, order-group, RFQ, API-key or transfer endpoints.
  * Order creation is never retried automatically. A timeout / network error / 5xx on create
    raises UncertainOutcome; the caller must reconcile with GET /portfolio/orders first.
The read-only market-data transport (aicrypto/kalshi/transport.py) is untouched.
"""
from __future__ import annotations

import asyncio
import json
from decimal import Decimal
import re
from typing import Any, Dict, Optional
from urllib.parse import urlsplit

import httpx

from ..auth import API_PREFIX, Credentials, KalshiSigner

DEMO_HOST = "demo-api.kalshi.co"
DEMO_BASE = "https://demo-api.kalshi.co/trade-api/v2"
PRODUCTION_HOSTS = ("api.elections.kalshi.com", "external-api.kalshi.com", "trading-api.kalshi.com", "api.kalshi.com", "kalshi.com")

_ID = r"[A-Za-z0-9_.:-]{1,80}"
DEMO_ALLOWED = [
    ("GET", re.compile(r"^/portfolio/balance$")),
    ("GET", re.compile(r"^/portfolio/positions$")),
    ("GET", re.compile(r"^/portfolio/orders$")),
    ("GET", re.compile(rf"^/portfolio/orders/{_ID}$")),
    ("GET", re.compile(r"^/portfolio/fills$")),
    # order placement/cancel: Kalshi's V2 event-order endpoints (the legacy /portfolio/orders
    # mutations were retired by Kalshi and answer "Please switch to the V2 endpoints")
    ("POST", re.compile(r"^/portfolio/events/orders$")),
    ("DELETE", re.compile(rf"^/portfolio/events/orders/{_ID}$")),
    # moving the account's own demo cash between Kalshi exchange shards (API orders are not
    # auto-funded; crypto/commodities trade on their own shard)
    ("POST", re.compile(r"^/portfolio/intra_exchange_instance_transfer$")),
]
_DENY = re.compile(r"batched|amend|decrease|order_groups|rfq|quotes|api_keys|subaccount|margin|perps|fcm|\.\.|//", re.I)


class DemoOnlyViolation(RuntimeError):
    """Raised for anything that is not a demo-host, allowlisted request."""


class ExchangeError(RuntimeError):
    def __init__(self, status: int, message: str, body: Any = None):
        super().__init__(f"HTTP {status}: {message}")
        self.status, self.message, self.body = status, message, body


class UncertainOutcome(RuntimeError):
    """The request may or may not have reached the exchange. Reconcile before doing anything else."""


def check_demo_request(method: str, path: str) -> str:
    m = method.upper()
    if "://" in path or path.startswith("//") or "?" in path or "#" in path:
        raise DemoOnlyViolation(f"path must be a plain API path: {path!r}")
    if _DENY.search(path):
        raise DemoOnlyViolation(f"endpoint not permitted for demo execution: {m} {path}")
    if not any(m == am and rx.match(path) for am, rx in DEMO_ALLOWED):
        raise DemoOnlyViolation(f"endpoint not on the demo-execution allowlist: {m} {path}")
    return path


def _assert_demo_url(url: str) -> None:
    host = (urlsplit(url).hostname or "").lower()
    if host != DEMO_HOST or any(host == p or host.endswith("." + p) for p in PRODUCTION_HOSTS):
        raise DemoOnlyViolation(f"refusing non-demo host {host!r}")


class DemoExchange:
    def __init__(self, signer: KalshiSigner, *, http_transport: Optional[httpx.AsyncBaseTransport] = None,
                 timeout_s: float = 8.0, _credentials_env: str = "demo"):
        if _credentials_env != "demo":
            raise DemoOnlyViolation("demo execution requires demo credentials")
        if signer is None:
            raise DemoOnlyViolation("a signer is required")
        _assert_demo_url(DEMO_BASE)
        self._signer = signer
        self._client = httpx.AsyncClient(base_url=DEMO_BASE, timeout=timeout_s, transport=http_transport,
                                         headers={"User-Agent": "aicrypto-lab-demo/0.2", "Accept": "application/json"},
                                         follow_redirects=False)
        self.calls: list = []          # (method, path) for audit/tests; never contains secrets

    @classmethod
    def from_credentials(cls, creds: Credentials, **kw) -> "DemoExchange":
        if creds.env != "demo":
            raise DemoOnlyViolation(f"refusing {creds.env!r} credentials: demo execution only")
        return cls(KalshiSigner.from_credentials(creds), _credentials_env=creds.env, **kw)

    async def aclose(self):
        await self._client.aclose()

    async def _request(self, method: str, path: str, *, params: Optional[Dict[str, Any]] = None,
                       body: Optional[Dict[str, Any]] = None, retry_get: int = 1) -> Dict[str, Any]:
        path = check_demo_request(method, path)
        url = DEMO_BASE + path
        _assert_demo_url(url)
        query = {k: v for k, v in (params or {}).items() if v is not None}
        attempt = 0
        while True:
            headers = self._signer.headers(method.upper(), API_PREFIX + path)
            if body is not None:
                headers["Content-Type"] = "application/json"
            self.calls.append((method.upper(), path))
            try:
                resp = await self._client.request(method.upper(), path, params=query or None,
                                                  content=json.dumps(body) if body is not None else None, headers=headers)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                if method.upper() == "GET" and attempt < retry_get:
                    attempt += 1
                    await asyncio.sleep(0.5)
                    continue
                if method.upper() == "GET":
                    raise ExchangeError(0, f"network error ({type(exc).__name__})")
                raise UncertainOutcome(f"{method} {path}: {type(exc).__name__}") from None
            if resp.is_redirect:
                raise DemoOnlyViolation("redirects are not followed")
            if resp.status_code >= 500:
                if method.upper() == "GET" and attempt < retry_get:
                    attempt += 1
                    await asyncio.sleep(0.5)
                    continue
                if method.upper() != "GET":
                    raise UncertainOutcome(f"{method} {path}: HTTP {resp.status_code}")
            if resp.status_code >= 400:
                try:
                    j = resp.json()
                except ValueError:
                    j = {}
                err = j.get("error") if isinstance(j, dict) else None
                msg = (err.get("message") if isinstance(err, dict) else None) or (err if isinstance(err, str) else None) or resp.text[:200]
                raise ExchangeError(resp.status_code, msg or "request failed", j)
            if resp.status_code == 204 or not resp.content:
                return {}
            try:
                return resp.json()
            except ValueError:
                if method.upper() == "GET":
                    raise ExchangeError(resp.status_code, "invalid JSON")
                raise UncertainOutcome(f"{method} {path}: unreadable response")

    # ---- the complete demo API surface ---------------------------------------------------
    async def balance(self) -> Dict[str, Any]:
        return await self._request("GET", "/portfolio/balance")

    async def positions(self, limit: int = 200, exchange_index: Optional[int] = None) -> Dict[str, Any]:
        return await self._request("GET", "/portfolio/positions", params={"limit": limit, "exchange_index": exchange_index})

    async def orders(self, *, ticker: Optional[str] = None, status: Optional[str] = None, limit: int = 200,
                     min_ts: Optional[int] = None, exchange_index: Optional[int] = None) -> Dict[str, Any]:
        return await self._request("GET", "/portfolio/orders", params={"ticker": ticker, "status": status, "limit": limit,
                                                                       "min_ts": min_ts, "exchange_index": exchange_index})

    async def order(self, order_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/portfolio/orders/{order_id}")

    async def fills(self, *, ticker: Optional[str] = None, order_id: Optional[str] = None, limit: int = 200,
                    min_ts: Optional[int] = None, exchange_index: Optional[int] = None) -> Dict[str, Any]:
        return await self._request("GET", "/portfolio/fills", params={"ticker": ticker, "order_id": order_id, "limit": limit,
                                                                      "min_ts": min_ts, "exchange_index": exchange_index})

    async def shard_transfer(self, amount: Decimal, source_shard: int, destination_shard: int, client_transfer_id: str) -> Dict[str, Any]:
        """Move demo cash between two exchange shards of the SAME account (primary account,
        event-contract balances only). Amount in dollars; Kalshi takes centicents."""
        if amount <= 0 or source_shard == destination_shard or not (0 <= source_shard <= 100 and 0 <= destination_shard <= 100):
            raise DemoOnlyViolation("bad shard transfer")
        body = {"source": "event_contract", "destination": "event_contract", "amount": int((amount * 10000).to_integral_value()),
                "client_transfer_id": client_transfer_id, "source_exchange_shard": int(source_shard),
                "destination_exchange_shard": int(destination_shard)}
        return await self._request("POST", "/portfolio/intra_exchange_instance_transfer", body=body)

    @staticmethod
    def to_v2(body: Dict[str, Any]) -> Dict[str, Any]:
        """Translate an internal order (side yes/no, action buy/sell, price of that side) into
        Kalshi's V2 single-YES-book shape: buy YES = bid at p; buy NO = ask at 1-p;
        sell YES = ask at p; sell NO = bid at 1-p. Prices and counts are fixed-point strings."""
        side, action = body["side"], body.get("action", "buy")
        if side not in ("yes", "no") or action not in ("buy", "sell"):
            raise DemoOnlyViolation("bad side/action")
        p = Decimal(str(body["yes_price_dollars"] if side == "yes" else body["no_price_dollars"]))
        yes_px = p if side == "yes" else Decimal(1) - p
        v2_side = "bid" if (side == "yes") == (action == "buy") else "ask"
        out = {"ticker": body["ticker"], "side": v2_side, "count": f"{Decimal(str(body['count'])):.2f}", "price": f"{yes_px:.4f}",
               "time_in_force": body.get("time_in_force", "good_till_canceled"), "self_trade_prevention_type": "taker_at_cross",
               "client_order_id": body["client_order_id"]}
        if body.get("reduce_only"):
            if out["time_in_force"] != "immediate_or_cancel":
                raise DemoOnlyViolation("reduce_only requires immediate_or_cancel")
            out["reduce_only"] = True
        return out

    async def create_order(self, body: Dict[str, Any]) -> Dict[str, Any]:
        """Single POST, never retried here. Returns {"order": {...}} in the shape the trader reads."""
        v2 = self.to_v2(body)
        r = await self._request("POST", "/portfolio/events/orders", body=v2)
        if "order" in r and isinstance(r["order"], dict):
            return r
        fill = Decimal(str(r.get("fill_count", "0") or "0"))
        rem = Decimal(str(r.get("remaining_count", "0") or "0"))
        want = Decimal(v2["count"])
        if v2["time_in_force"] == "good_till_canceled":
            status = "executed" if (rem == 0 and fill > 0) else "resting"
        else:                                   # IOC / FOK never rest
            status, rem = ("executed" if fill >= want else "canceled"), Decimal(0)
        fees = Decimal(str(r.get("average_fee_paid", "0") or "0")) * fill
        return {"order": {"order_id": r.get("order_id"), "client_order_id": r.get("client_order_id") or body["client_order_id"],
                          "status": status, "fill_count_fp": f"{fill:.2f}", "remaining_count_fp": f"{rem:.2f}",
                          "taker_fees_dollars": f"{fees:.4f}", "average_fill_price": r.get("average_fill_price")}}

    async def cancel_order(self, order_id: str, ticker: Optional[str] = None) -> Dict[str, Any]:
        return await self._request("DELETE", f"/portfolio/events/orders/{order_id}", params={"market_ticker": ticker}, retry_get=0)
