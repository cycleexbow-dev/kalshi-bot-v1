"""Market discovery: REST bootstrap + periodic reconciliation into the MarketRegistry.

The universe is never trimmed: every open/unopened market Kalshi lists is fetched (paginated),
schema-checked and upserted with its eligibility decision. Series metadata is fetched once
per unique series ticker (cached in the registry). Schema mismatches are recorded in the
registry (`schema_mismatches` table) and the offending payload is skipped (fail closed).
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .client import KalshiRestClient
from .eligibility import Tier
from .models import series_ticker_of
from .registry import MarketRegistry
from .schemas import STATS as SCHEMA_STATS, SchemaMismatch


@dataclass
class DiscoveryReport:
    started_at: float
    finished_at: float = 0.0
    markets_seen: int = 0
    markets_upserted: int = 0
    series_fetched: int = 0
    series_failed: int = 0
    schema_mismatches: int = 0
    tiers: Dict[str, int] = field(default_factory=dict)
    durations: Dict[str, Dict[str, int]] = field(default_factory=dict)
    rejections: Dict[str, int] = field(default_factory=dict)
    unknown_fields: Dict[str, int] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)
    truncated: bool = False
    series_errors: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__


def _ensure_mismatch_table(reg: MarketRegistry) -> None:
    with reg._conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS schema_mismatches (ts REAL, kind TEXT, context TEXT, problems TEXT, keys TEXT)")


def record_mismatches(reg: MarketRegistry, items: List[Dict[str, Any]]) -> None:
    if not items:
        return
    _ensure_mismatch_table(reg)
    with reg._conn() as c:
        c.executemany("INSERT INTO schema_mismatches VALUES (?,?,?,?,?)",
                      [(time.time(), i["kind"], i["context"], json.dumps(i["problems"]), json.dumps(i["keys"])) for i in items])


MAX_MARKET_PAGES = 1000   # 1,000,000 markets per status; live demo had ~118k (2026-11-09)


def _say(progress, msg: str) -> None:
    if progress:
        progress(msg)


async def discover(client: KalshiRestClient, reg: MarketRegistry, *, statuses: tuple = ("open", "unopened"),
                   max_series: Optional[int] = None, progress=None) -> DiscoveryReport:
    rep = DiscoveryReport(started_at=time.time())
    markets: List[Dict[str, Any]] = []
    for st in statuses:
        _say(progress, f"listing markets (status={st}) ...")
        try:
            got = await client.list_markets(status=st, progress=progress, max_pages=MAX_MARKET_PAGES)
            markets += got
            if len(got) >= MAX_MARKET_PAGES * 1000:
                rep.notes.insert(0, f"UNIVERSE TRUNCATED: status={st} hit the {MAX_MARKET_PAGES}-page cap; raise MAX_MARKET_PAGES")
                rep.truncated = True
        except Exception as exc:
            rep.notes.append(f"list_markets(status={st}) failed: {type(exc).__name__}: {str(exc)[:120]}")
            _say(progress, f"  failed: {type(exc).__name__}: {str(exc)[:120]}")
    rep.markets_seen = len(markets)
    _say(progress, f"{len(markets)} markets listed")

    needed: Set[str] = {m.get("series_ticker") or series_ticker_of(m["ticker"]) for m in markets}
    needed -= set(reg.series)
    # Bulk first: GET /series (paginated) is a handful of requests instead of one per series.
    if needed:
        _say(progress, f"fetching series metadata in bulk ({len(needed)} series needed) ...")
        try:
            bulk = await client.list_series(progress=progress)
            with reg.batch():
                for sd in bulk:
                    if sd["ticker"] in needed:
                        reg.upsert_series(sd)
                        rep.series_fetched += 1
        except Exception as exc:
            rep.notes.append(f"bulk series list failed ({type(exc).__name__}); falling back to per-series fetch")
            _say(progress, f"  bulk series failed: {type(exc).__name__}; falling back")
        needed -= set(reg.series)
    # Per-series fallback only for whatever the bulk listing did not include.
    for i, st in enumerate(sorted(needed)):
        if max_series is not None and i >= max_series:
            rep.notes.append(f"per-series fetch capped at {max_series}; {len(needed) - i} series left undecided")
            break
        if i % 25 == 0:
            _say(progress, f"per-series fetch {i}/{len(needed)} ...")
        try:
            reg.upsert_series(await client.get_series(st))
            rep.series_fetched += 1
        except SchemaMismatch:
            rep.series_failed += 1
        except Exception as exc:
            rep.series_failed += 1
            msg = str(exc)
            key = msg.split(":", 1)[0][:40] if msg.startswith("HTTP") else type(exc).__name__
            rep.series_errors[key] = rep.series_errors.get(key, 0) + 1
            if len(rep.notes) < 60:
                rep.notes.append(f"series {st}: {type(exc).__name__}: {msg[:80]}")

    _say(progress, f"saving {len(markets)} markets with eligibility decisions ...")
    undecided = 0
    with reg.batch():
        for i, m in enumerate(markets):
            st = m.get("series_ticker") or series_ticker_of(m["ticker"])
            if st not in reg.series:
                undecided += 1
                if undecided <= 20:
                    rep.notes.append(f"{m['ticker']}: series {st} metadata unavailable; market stored undecided")
                reg.upsert_market(m, decide=False)
            else:
                reg.upsert_market(m)
                rep.markets_upserted += 1
            if progress and i and i % 5000 == 0:
                _say(progress, f"  saved {i}/{len(markets)}")
    if undecided > 20:
        rep.notes.append(f"... {undecided} markets in total stored undecided (series metadata unavailable)")

    record_mismatches(reg, client.mismatches)
    rep.schema_mismatches = len(client.mismatches)
    client.mismatches.clear()
    summ = reg.summary()
    rep.tiers = summ["tiers"]
    rep.durations = summ["durations"]
    rep.rejections = summ["rejections"]
    rep.unknown_fields = dict(SCHEMA_STATS.unknown_fields)
    rep.finished_at = time.time()
    return rep


async def reconcile(client: KalshiRestClient, reg: MarketRegistry, tickers: List[str]) -> int:
    """Re-fetch specific markets (e.g. ones the lifecycle channel mentioned but we don't know)."""
    n = 0
    for t in tickers:
        try:
            reg.upsert_market(await client.get_market(t))
            n += 1
        except SchemaMismatch:
            pass
    record_mismatches(reg, client.mismatches)
    client.mismatches.clear()
    return n
