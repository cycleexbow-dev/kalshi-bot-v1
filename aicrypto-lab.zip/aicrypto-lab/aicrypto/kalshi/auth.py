"""Kalshi request signing (Ed25519 or RSA-PSS). Credentials come from the environment only.

    KALSHI_API_KEY_ID        key id (UUID)
    KALSHI_PRIVATE_KEY_PATH  PEM file, mode 0600, outside the repository
    KALSHI_ENV               demo | production  (must match config/kalshi.yaml `environment`)

String to sign: f"{timestamp_ms}{METHOD}{path_without_query}".
Headers: KALSHI-ACCESS-KEY, KALSHI-ACCESS-TIMESTAMP (ms), KALSHI-ACCESS-SIGNATURE (base64).
Verified against docs.kalshi.com/getting_started/api_keys (2026-11-08).

Nothing in this module logs or formats key material. DO NOT MODIFY without human review
(CLAUDE.md rule 8).
"""
from __future__ import annotations

import base64
import os
import stat
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa

API_PREFIX = "/trade-api/v2"
WS_PATH = "/trade-api/ws/v2"

HOSTS = {
    "demo": {"rest": "https://demo-api.kalshi.co/trade-api/v2", "ws": "wss://demo-api.kalshi.co/trade-api/ws/v2"},
    "production": {"rest": "https://api.elections.kalshi.com/trade-api/v2", "ws": "wss://api.elections.kalshi.com/trade-api/ws/v2"},
}
PUBLIC_REST = {"demo": "https://demo-api.kalshi.co/trade-api/v2", "production": "https://external-api.kalshi.com/trade-api/v2"}


class CredentialError(RuntimeError):
    pass


@dataclass
class Credentials:
    key_id: str
    private_key_path: Path
    env: str

    @classmethod
    def from_env(cls, config_env: str, repo_root: Optional[Path] = None, environ: Optional[Dict[str, str]] = None) -> "Credentials":
        e = environ if environ is not None else os.environ
        env = e.get("KALSHI_ENV", config_env).strip().lower()
        if env not in HOSTS:
            raise CredentialError(f"KALSHI_ENV must be demo or production, got {env!r}")
        if env != config_env:
            raise CredentialError(f"KALSHI_ENV={env} disagrees with config environment={config_env}; refusing")
        key_id = e.get("KALSHI_API_KEY_ID", "").strip()
        path = e.get("KALSHI_PRIVATE_KEY_PATH", "").strip()
        if not key_id or not path:
            raise CredentialError("KALSHI_API_KEY_ID and KALSHI_PRIVATE_KEY_PATH must be set (see docs/KALSHI_DEMO_KEY.md)")
        p = Path(path).expanduser()
        if not p.exists():
            raise CredentialError("private key file not found")
        mode = stat.S_IMODE(p.stat().st_mode)
        if mode & 0o077:
            raise CredentialError(f"private key file must be mode 0600 (is {oct(mode)})")
        if repo_root is not None:
            try:
                p.resolve().relative_to(Path(repo_root).resolve())
                raise CredentialError("private key file must live outside the repository")
            except ValueError:
                pass
        return cls(key_id=key_id, private_key_path=p, env=env)

    def __repr__(self) -> str:  # never reveal the key id
        return f"Credentials(env={self.env!r}, key_id='***', private_key_path='***')"


class KalshiSigner:
    def __init__(self, key_id: str, private_key):
        self._key_id = key_id
        self._key = private_key
        if isinstance(private_key, ed25519.Ed25519PrivateKey):
            self.key_type = "ed25519"
        elif isinstance(private_key, rsa.RSAPrivateKey):
            self.key_type = "rsa"
        else:
            raise CredentialError("unsupported key type (need Ed25519 or RSA)")

    @classmethod
    def from_pem_bytes(cls, key_id: str, pem: bytes) -> "KalshiSigner":
        key = serialization.load_pem_private_key(pem, password=None)
        return cls(key_id, key)

    @classmethod
    def from_credentials(cls, creds: Credentials) -> "KalshiSigner":
        return cls.from_pem_bytes(creds.key_id, creds.private_key_path.read_bytes())

    def sign(self, message: str) -> str:
        data = message.encode("utf-8")
        if self.key_type == "ed25519":
            sig = self._key.sign(data)
        else:
            sig = self._key.sign(data, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=hashes.SHA256.digest_size), hashes.SHA256())
        return base64.b64encode(sig).decode("ascii")

    def headers(self, method: str, path: str, timestamp_ms: Optional[int] = None) -> Dict[str, str]:
        """`path` must be the full API path without query, e.g. /trade-api/v2/markets or /trade-api/ws/v2."""
        if "?" in path:
            path = path.split("?", 1)[0]
        ts = str(timestamp_ms if timestamp_ms is not None else int(time.time() * 1000))
        return {
            "KALSHI-ACCESS-KEY": self._key_id,
            "KALSHI-ACCESS-TIMESTAMP": ts,
            "KALSHI-ACCESS-SIGNATURE": self.sign(f"{ts}{method.upper()}{path}"),
        }

    def public_key_pem(self) -> bytes:
        return self._key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)

    def verify(self, message: str, signature_b64: str) -> bool:
        """Self-check used by `aicrypto kalshi auth-check`."""
        sig = base64.b64decode(signature_b64)
        pub = self._key.public_key()
        try:
            if self.key_type == "ed25519":
                pub.verify(sig, message.encode())
            else:
                pub.verify(sig, message.encode(), padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=hashes.SHA256.digest_size), hashes.SHA256())
            return True
        except Exception:
            return False

    def __repr__(self) -> str:
        return f"KalshiSigner(key_type={self.key_type!r}, key_id='***')"

    __str__ = __repr__


def redact_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: ("***" if k.upper().startswith("KALSHI-ACCESS") or k.lower() == "authorization" else v) for k, v in headers.items()}
