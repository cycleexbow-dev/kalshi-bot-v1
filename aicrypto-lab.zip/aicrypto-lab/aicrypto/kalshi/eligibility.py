"""Market eligibility: allowlist-driven, reason-coded, enforced everywhere.

Decision tiers
    TRADEABLE    all checks pass and the settlement reference feed is validated
    RECORD_ONLY  financially eligible, but the settlement reference feed is unavailable
                 (e.g. Pyth off). Discovered, recorded, shown in the scanner; never
                 strategy-evaluated or paper-traded. Reconsidered automatically when the
                 feed becomes available (reason code preserved).
    REJECTED     fails a hard check (category, strike type, rules, status, metadata)

Every decision carries stable reason codes so the registry can explain itself and so
markets can be re-evaluated later under new config without losing history.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

from .durations import DurationInfo, classify
from .models import ContractStructure, MarketInfo, MarketStatus, SeriesInfo, StrikeType
from .settings import KalshiSettings
from .settlement_map import ReferenceStatus, SettlementReference, resolve


class Tier(str, Enum):
    TRADEABLE = "tradeable"
    RECORD_ONLY = "record_only"
    REJECTED = "rejected"


class Reason(str, Enum):
    # rejections
    CATEGORY_DENIED = "category_denied"
    CATEGORY_NOT_ALLOWED = "category_not_allowed"
    TAG_DENIED = "tag_denied"
    ASSET_NOT_ALLOWED = "asset_not_allowed"
    ASSET_UNPARSEABLE = "asset_unparseable"
    MARKET_TYPE_NOT_ALLOWED = "market_type_not_allowed"
    STRIKE_TYPE_NOT_ALLOWED = "strike_type_not_allowed"
    STRIKE_MISSING = "strike_missing"
    SETTLEMENT_SOURCE_MISSING = "settlement_source_missing"
    SETTLEMENT_UNMAPPED = "settlement_unmapped"
    RULES_TEMPLATE_UNRECOGNISED = "rules_template_unrecognised"
    TIMESTAMPS_MISSING = "timestamps_missing"
    PROVISIONAL = "provisional_market"
    STATUS_NOT_TRADEABLE = "status_not_tradeable"        # informational for terminal/inactive markets
    CADENCE_DISAGREEMENT = "cadence_disagreement"        # informational
    # record-only
    REFERENCE_FEED_UNAVAILABLE = "reference_feed_unavailable"
    STRIKE_PENDING = "strike_pending"     # queued up/down window: target is stamped when it opens
    TEST_SERIES = "test_series"           # exchange test/sharding series; never tradeable
    # pass
    OK = "ok"


@dataclass
class Decision:
    ticker: str
    tier: Tier
    reasons: List[Reason]
    notes: List[str]
    asset: str
    asset_class: str
    duration: DurationInfo
    reference: SettlementReference
    rules_hash: str
    config_hash: str

    @property
    def accepted(self) -> bool:
        return self.tier is Tier.TRADEABLE

    @property
    def discoverable(self) -> bool:
        return self.tier in (Tier.TRADEABLE, Tier.RECORD_ONLY)

    def to_dict(self) -> dict:
        return {
            "ticker": self.ticker, "tier": self.tier.value, "reasons": [r.value for r in self.reasons], "notes": self.notes,
            "asset": self.asset, "asset_class": self.asset_class, "duration": self.duration.to_dict(),
            "reference": self.reference.to_dict(), "rules_hash": self.rules_hash, "config_hash": self.config_hash,
        }


def config_fingerprint(settings: KalshiSettings) -> str:
    blob = settings.eligibility.model_dump_json() + settings.reference_feeds.model_dump_json()
    return hashlib.sha256(blob.encode()).hexdigest()[:12]


def _norm(s: str) -> str:
    return s.strip().lower()


def evaluate(series: SeriesInfo, market: MarketInfo, settings: KalshiSettings) -> Decision:
    rules = settings.eligibility
    reasons: List[Reason] = []
    notes: List[str] = []
    duration = classify(market, series.frequency)
    rules_hash = hashlib.sha256(f"{market.rules_primary}|{market.rules_secondary}".encode()).hexdigest()[:12]
    cfg_hash = config_fingerprint(settings)

    # 1. category / tags (official metadata, not title keywords)
    cats = {_norm(series.category)} | {_norm(c) for c in series.categories}
    denied = {_norm(c) for c in rules.denied_categories}
    allowed = {_norm(c) for c in rules.allowed_categories}
    if cats & denied:
        reasons.append(Reason.CATEGORY_DENIED); notes.append(f"category in denylist: {sorted(cats & denied)}")
    elif not (cats & allowed):
        reasons.append(Reason.CATEGORY_NOT_ALLOWED); notes.append(f"category not in allowlist: {sorted(cats)}")
    tags = {_norm(t) for t in series.tags}
    denied_tags = {_norm(t) for t in rules.denied_tags}
    if tags & denied_tags:
        reasons.append(Reason.TAG_DENIED); notes.append(f"tags in denylist: {sorted(tags & denied_tags)}")

    # 1b. exchange test series (observed live: KXMAXSHARDINGTEST filed under "Crypto")
    if "TEST" in series.ticker.upper() or "test" in series.title.lower() or "test" in series.category.lower():
        reasons.append(Reason.TEST_SERIES); notes.append("series looks like an exchange test series")

    # 2. asset: from the settlement reference (source link / rules), ticker prefix only as fallback
    reference = resolve(series, market, settings)
    asset = reference.asset or rules.asset_from_ticker(series.ticker)
    asset_class = rules.asset_class_of(asset) if asset else None
    if not asset:
        reasons.append(Reason.ASSET_UNPARSEABLE); notes.append(f"cannot parse asset from series {series.ticker}")
    elif asset_class is None:
        reasons.append(Reason.ASSET_NOT_ALLOWED); notes.append(f"asset {asset} not in allowlist")

    # 3. contract structure
    if market.market_type not in rules.allowed_market_types:
        reasons.append(Reason.MARKET_TYPE_NOT_ALLOWED); notes.append(f"market_type={market.market_type}")
    short_window = duration.bucket.value in ("<=5m", "15m", "30m") or duration.series_cadence.value in ("<=5m", "15m", "30m")
    no_strike_yet = market.strike_type is StrikeType.UNKNOWN and market.floor_strike is None and market.cap_strike is None
    strike_pending = False
    if market.strike_type.value not in rules.allowed_strike_types:
        # Live data: commodity 15-min windows are listed ACTIVE ~1 day early with no strike at all;
        # crypto windows are listed INITIALIZED. Both get their target stamped at window start.
        if short_window and (market.status.value in ("initialized", "inactive") or no_strike_yet):
            strike_pending = True     # re-decided when the lifecycle feed reports activation/metadata
            notes.append(f"strike_type={market.strike_type.value} before open; target is set when the window opens")
        else:
            reasons.append(Reason.STRIKE_TYPE_NOT_ALLOWED); notes.append(f"strike_type={market.strike_type.value}")
    else:
        if market.strike_type is StrikeType.BETWEEN and (market.floor_strike is None or market.cap_strike is None):
            reasons.append(Reason.STRIKE_MISSING)
        elif market.strike_type is not StrikeType.BETWEEN and market.floor_strike is None and market.cap_strike is None:
            if short_window and market.status.value in ("initialized", "inactive"):
                strike_pending = True
            else:
                reasons.append(Reason.STRIKE_MISSING)

    # 4. timestamps / provisional
    if market.open_time is None or market.close_time is None:
        reasons.append(Reason.TIMESTAMPS_MISSING)
    if market.is_provisional:
        reasons.append(Reason.PROVISIONAL)

    # 5. settlement source + rules template + reference mapping
    if rules.require_settlement_source and not series.settlement_sources:
        reasons.append(Reason.SETTLEMENT_SOURCE_MISSING)
    if reference.status is ReferenceStatus.UNMAPPED:
        if "method not recognised" in " ".join(reference.notes) and rules.require_rules_template_match:
            reasons.append(Reason.RULES_TEMPLATE_UNRECOGNISED)
        reasons.append(Reason.SETTLEMENT_UNMAPPED)
        notes.extend(reference.notes)

    # informational
    if duration.disagreement:
        notes.append(f"series cadence {duration.series_cadence.value} vs listing {duration.bucket.value}")
    if not market.status.is_tradeable:
        notes.append(f"status={market.status.value}")

    hard_fail = [r for r in reasons if r not in (Reason.CADENCE_DISAGREEMENT, Reason.STATUS_NOT_TRADEABLE)]
    if hard_fail:
        return Decision(market.ticker, Tier.REJECTED, reasons, notes, asset, asset_class or "", duration, reference, rules_hash, cfg_hash)

    record_reasons = []
    if reference.status is ReferenceStatus.FEED_UNAVAILABLE:
        notes.extend(reference.notes)
        record_reasons.append(Reason.REFERENCE_FEED_UNAVAILABLE)
    if strike_pending:
        record_reasons.append(Reason.STRIKE_PENDING)
    if record_reasons:
        return Decision(market.ticker, Tier.RECORD_ONLY, record_reasons, notes, asset, asset_class or "",
                        duration, reference, rules_hash, cfg_hash)

    return Decision(market.ticker, Tier.TRADEABLE, [Reason.OK], notes, asset, asset_class or "", duration, reference, rules_hash, cfg_hash)


def assert_tradeable(decision: Optional[Decision], ticker: str) -> None:
    """Single enforcement point used by subscription, strategy evaluation, replay and
    paper execution. Raises if a market is not TRADEABLE."""
    if decision is None:
        raise PermissionError(f"{ticker}: no eligibility decision on record")
    if decision.tier is not Tier.TRADEABLE:
        raise PermissionError(f"{ticker}: tier={decision.tier.value} reasons={[r.value for r in decision.reasons]}")
