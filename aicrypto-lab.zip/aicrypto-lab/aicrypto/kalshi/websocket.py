"""Persistent, authenticated Kalshi WebSocket client (market data only).

Responsibilities
  * authenticated handshake (signed headers for GET /trade-api/ws/v2)
  * subscribe / unsubscribe / update_subscription through the command allowlist
  * heartbeat: answer server pings (websockets does this automatically), send our own
    pings, detect a stale socket (no frame for `stale_after_s`) and reconnect
  * reconnect with exponential backoff + jitter; resubscribe everything tracked
  * per-subscription `seq` checks; on a gap -> invalidate affected books and request
    `get_snapshot` (resync) instead of trusting the stream
  * bounded inbound queue with explicit drop accounting (books/lifecycle are applied
    synchronously in the reader and never dropped; only the fan-out to slow consumers is)
  * every inbound frame is stamped with t_recv_ns before decoding (latency stage 1)

Nothing here can send an order. The command allowlist rejects any cmd outside
subscribe/unsubscribe/update_subscription/list_subscriptions and any non-market-data
channel; `tests/test_kalshi_ws.py` proves it.
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set

import websockets
from websockets.asyncio.client import connect

from .auth import WS_PATH, HOSTS, KalshiSigner, redact_headers
from .orderbook import BookSet
from .paths import RequestAllowlist, RequestNotAllowed
from .schemas import SchemaMismatch, validate_ws_envelope

log = logging.getLogger("aicrypto.kalshi.ws")

Handler = Callable[["InboundMessage"], Awaitable[None]]


@dataclass
class InboundMessage:
    raw: str
    t_recv_ns: int
    t_decoded_ns: int = 0
    data: Dict[str, Any] = field(default_factory=dict)
    type: str = ""
    sid: Optional[int] = None
    seq: Optional[int] = None


@dataclass
class Subscription:
    channels: List[str]
    market_tickers: List[str] = field(default_factory=list)
    index_ids: List[str] = field(default_factory=list)
    underlying_tickers: List[str] = field(default_factory=list)
    sid: Optional[int] = None          # server-assigned after 'subscribed'
    cmd_id: Optional[int] = None


@dataclass
class WsStats:
    connects: int = 0
    reconnects: int = 0
    disconnects: int = 0
    frames: int = 0
    messages_by_type: Dict[str, int] = field(default_factory=dict)
    schema_mismatches: int = 0
    seq_gaps: int = 0
    resyncs: int = 0
    stale_events: int = 0
    errors: List[Dict[str, Any]] = field(default_factory=list)
    dropped_fanout: int = 0
    queue_high_water: int = 0
    last_frame_mono: float = 0.0
    last_close: Dict[str, Any] = field(default_factory=dict)


class KalshiWebSocket:
    def __init__(self, signer: KalshiSigner, env: str = "demo", *, url: Optional[str] = None,
                 allowlist: Optional[RequestAllowlist] = None, books: Optional[BookSet] = None,
                 queue_max: int = 0, stale_after_s: float = 30.0, ping_interval_s: float = 10.0,
                 max_backoff_s: float = 60.0, connect_kwargs: Optional[Dict[str, Any]] = None):
        self.signer = signer
        self.url = url or HOSTS[env]["ws"]
        if url is None and env not in HOSTS:
            raise ValueError(env)
        self.allowlist = allowlist or RequestAllowlist()
        self.books = books or BookSet()
        # optional fan-out queue for an external consumer; 0 = none (handlers run inline).
        # Without a reader an always-on queue only fills up and reports false drops.
        self.queue: Optional[asyncio.Queue] = asyncio.Queue(maxsize=queue_max) if queue_max > 0 else None
        self.stale_after_s = stale_after_s
        self.ping_interval_s = ping_interval_s
        self.max_backoff_s = max_backoff_s
        self.connect_kwargs = connect_kwargs or {}
        self.stats = WsStats()
        self.subscriptions: List[Subscription] = []
        self._sid_to_sub: Dict[int, Subscription] = {}
        self._pending: Dict[int, Subscription] = {}   # cmd_id -> subscription awaiting 'subscribed'
        self._cmd_id = 0
        self._ws = None
        self._stop = asyncio.Event()
        self._connected = asyncio.Event()
        self.handlers: List[Handler] = []
        self.on_resync_needed: Optional[Callable[[List[str]], Awaitable[None]]] = None

    # ---- lifecycle -------------------------------------------------------------------------
    async def run(self) -> None:
        """Run forever (until stop()) with reconnects. Safe to cancel."""
        attempt = 0
        while not self._stop.is_set():
            try:
                await self._session()
                attempt = 0
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # connection-level failure
                self.stats.disconnects += 1
                self._connected.clear()
                log.warning("ws session ended: %s", type(exc).__name__)
            if self._stop.is_set():
                break
            attempt += 1
            delay = min(self.max_backoff_s, 0.5 * (2 ** min(attempt, 8))) * (0.7 + 0.6 * random.random())
            self.stats.reconnects += 1
            await asyncio.sleep(delay)

    async def stop(self) -> None:
        self._stop.set()
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                pass

    @property
    def is_connected(self) -> bool:
        return self._connected.is_set()

    async def wait_connected(self, timeout: float = 10.0) -> None:
        await asyncio.wait_for(self._connected.wait(), timeout)

    def _auth_headers(self) -> Dict[str, str]:
        return self.signer.headers("GET", WS_PATH)

    async def _session(self) -> None:
        headers = self._auth_headers()
        log.info("connecting %s headers=%s", self.url, redact_headers(headers))
        async with connect(self.url, additional_headers=headers, ping_interval=self.ping_interval_s,
                           ping_timeout=self.stale_after_s, max_size=8 * 1024 * 1024, **self.connect_kwargs) as ws:
            self._ws = ws
            self.stats.connects += 1
            self.stats.last_frame_mono = time.monotonic()
            # Every reconnect invalidates all books: the stream resumed from an unknown point.
            self.books.invalidate_all()
            self._sid_to_sub.clear()
            self._pending.clear()
            for sub in self.subscriptions:
                sub.sid = None
                await self._send_subscribe(sub)
            self._connected.set()
            watchdog = asyncio.create_task(self._watchdog())
            try:
                async for frame in ws:
                    await self._on_frame(frame)
            finally:
                watchdog.cancel()
                self._connected.clear()
                self._ws = None
                # who closed it and why (Kalshi closes cleanly from time to time); diagnostics only
                code, reason = getattr(ws, "close_code", None), getattr(ws, "close_reason", None)
                self.stats.last_close = {"t": time.time(), "code": code, "reason": (reason or "")[:200]}
                log.info("ws closed: code=%s reason=%s", code, (reason or "")[:200])

    async def _watchdog(self) -> None:
        while True:
            await asyncio.sleep(max(1.0, self.stale_after_s / 3))
            idle = time.monotonic() - self.stats.last_frame_mono
            if idle > self.stale_after_s and self._ws is not None:
                self.stats.stale_events += 1
                log.warning("stale socket (%.1fs idle); forcing reconnect", idle)
                try:
                    await self._ws.close(code=4000, reason="stale")
                except Exception:
                    pass
                return

    # ---- outbound (allowlisted) -------------------------------------------------------------
    def _next_id(self) -> int:
        self._cmd_id += 1
        return self._cmd_id

    async def _send(self, message: Dict[str, Any]) -> None:
        self.allowlist.check_ws_command(message)      # raises RequestNotAllowed
        if self._ws is None:
            raise ConnectionError("not connected")
        await self._ws.send(json.dumps(message))

    async def _send_subscribe(self, sub: Subscription) -> None:
        cid = self._next_id()
        sub.cmd_id = cid
        params: Dict[str, Any] = {"channels": sub.channels}
        if sub.market_tickers:
            params["market_tickers"] = sub.market_tickers
        if sub.index_ids:
            params["index_ids"] = sub.index_ids
        if sub.underlying_tickers:
            params["underlying_tickers"] = sub.underlying_tickers
        self._pending[cid] = sub
        await self._send({"id": cid, "cmd": "subscribe", "params": params})

    async def subscribe(self, channels: List[str], market_tickers: Optional[List[str]] = None,
                        index_ids: Optional[List[str]] = None, underlying_tickers: Optional[List[str]] = None) -> Subscription:
        sub = Subscription(list(channels), list(market_tickers or []), list(index_ids or []), list(underlying_tickers or []))
        self.subscriptions.append(sub)
        if self._ws is not None:
            await self._send_subscribe(sub)
        return sub

    async def unsubscribe(self, sub: Subscription) -> None:
        if sub in self.subscriptions:
            self.subscriptions.remove(sub)
        if sub.sid is not None and self._ws is not None:
            await self._send({"id": self._next_id(), "cmd": "unsubscribe", "params": {"sids": [sub.sid]}})
            self._sid_to_sub.pop(sub.sid, None)

    async def update_markets(self, sub: Subscription, add: List[str] = (), delete: List[str] = ()) -> None:
        if sub.sid is None:
            # not yet acknowledged: mutate the desired set, the (re)subscribe will carry it
            sub.market_tickers = [t for t in sub.market_tickers if t not in delete] + [t for t in add if t not in sub.market_tickers]
            return
        if delete:
            await self._send({"id": self._next_id(), "cmd": "update_subscription",
                              "params": {"sid": sub.sid, "action": "delete_markets", "market_tickers": list(delete)}})
            sub.market_tickers = [t for t in sub.market_tickers if t not in delete]
            for t in delete:
                self.books.drop(t)        # a dropped subscription must not leave a stale book behind
        if add:
            await self._send({"id": self._next_id(), "cmd": "update_subscription",
                              "params": {"sid": sub.sid, "action": "add_markets", "market_tickers": list(add)}})
            sub.market_tickers += [t for t in add if t not in sub.market_tickers]

    async def request_snapshot(self, sub: Subscription, tickers: List[str]) -> None:
        if sub.sid is None or not tickers:
            return
        self.stats.resyncs += 1
        await self._send({"id": self._next_id(), "cmd": "update_subscription",
                          "params": {"sid": sub.sid, "action": "get_snapshot", "market_tickers": list(tickers)}})

    async def list_subscriptions(self) -> None:
        await self._send({"id": self._next_id(), "cmd": "list_subscriptions"})

    # ---- inbound ------------------------------------------------------------------------------
    async def _on_frame(self, frame) -> None:
        t_recv = time.monotonic_ns()
        self.stats.frames += 1
        self.stats.last_frame_mono = time.monotonic()
        raw = frame if isinstance(frame, str) else frame.decode("utf-8", "replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            self.stats.schema_mismatches += 1
            return
        msg = InboundMessage(raw=raw, t_recv_ns=t_recv, t_decoded_ns=time.monotonic_ns(), data=data,
                             type=str(data.get("type", "")), sid=data.get("sid"), seq=data.get("seq"))
        self.stats.messages_by_type[msg.type] = self.stats.messages_by_type.get(msg.type, 0) + 1
        try:
            validate_ws_envelope(data)
        except SchemaMismatch as exc:
            self.stats.schema_mismatches += 1
            log.warning("schema mismatch dropped: %s", exc)
            return
        await self._handle_control(msg)
        if msg.type in ("orderbook_snapshot", "orderbook_delta"):
            await self._handle_book(msg)
        elif msg.sid is not None and msg.seq is not None:
            if not self.books.check_seq(msg.sid, msg.seq):
                self.stats.seq_gaps += 1
                # non-book channels: a gap means missed events, nothing to resync but worth counting
        await self._fanout(msg)

    async def _handle_control(self, msg: InboundMessage) -> None:
        t, d = msg.type, msg.data
        if t == "subscribed":
            sid = int(d["msg"]["sid"])
            sub = self._pending.pop(d.get("id"), None)
            if sub is None:  # match by channel if ids were not echoed
                sub = next((s for s in self.subscriptions if s.sid is None and d["msg"]["channel"] in s.channels), None)
            if sub is not None:
                sub.sid = sid
                self._sid_to_sub[sid] = sub
        elif t == "error":
            code = d["msg"].get("code")
            self.stats.errors.append({"code": code, "msg": d["msg"].get("msg"), "id": d.get("id"), "t": time.time()})
            if code == 9:
                log.error("channel requires authentication (code 9); check KALSHI_* credentials")
            sub = self._pending.pop(d.get("id"), None)
            if sub is not None and sub in self.subscriptions:
                self.subscriptions.remove(sub)   # don't retry a rejected subscription forever
        elif t == "unsubscribed":
            self._sid_to_sub.pop(d.get("sid"), None)

    async def _handle_book(self, msg: InboundMessage) -> None:
        m = msg.data["msg"]
        ticker = m["market_ticker"]
        book = self.books.book(ticker)
        in_order = self.books.check_seq(msg.sid, msg.seq)
        if msg.type == "orderbook_snapshot":
            book.apply_snapshot(m, msg.t_recv_ns)
            return
        if not in_order:
            self.stats.seq_gaps += 1
            book.invalidate()
        applied = book.apply_delta(m, msg.t_recv_ns)
        if not applied and not book.valid:
            sub = self._sid_to_sub.get(msg.sid) if msg.sid is not None else None
            if sub is not None:
                await self.request_snapshot(sub, [ticker])
            if self.on_resync_needed is not None:
                await self.on_resync_needed([ticker])

    async def _fanout(self, msg: InboundMessage) -> None:
        for h in self.handlers:
            try:
                await h(msg)
            except Exception as exc:  # a consumer bug must not kill the feed
                log.exception("handler failed: %s", exc)
        if self.queue is None:
            return
        try:
            self.queue.put_nowait(msg)
            self.stats.queue_high_water = max(self.stats.queue_high_water, self.queue.qsize())
        except asyncio.QueueFull:
            self.stats.dropped_fanout += 1
