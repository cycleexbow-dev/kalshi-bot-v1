"""Response-schema verification against the Phase 2 models.

Kalshi's documentation (read 2026-11-08) is the source of the expected shapes. Every
REST/WS payload we ingest is checked here first. A mismatch (missing required field,
wrong type, unparseable fixed-point string, unknown enum value) is recorded in the
registry's `schema_mismatches` table and the payload is **not ingested** (fail closed).
Unknown *extra* fields are tolerated and counted so we notice API additions.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from .models import MarketStatus, StrikeType

_FP4 = re.compile(r"^-?\d+\.\d{4}$")
_FP2 = re.compile(r"^-?\d+\.\d{2}$")
_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$")


class SchemaMismatch(ValueError):
    def __init__(self, kind: str, problems: List[str], payload_keys: List[str]):
        super().__init__(f"{kind}: " + "; ".join(problems[:6]))
        self.kind = kind
        self.problems = problems
        self.payload_keys = payload_keys


@dataclass
class SchemaStats:
    checked: int = 0
    mismatches: int = 0
    unknown_fields: Dict[str, int] = field(default_factory=dict)


STATS = SchemaStats()


def _t_str(v): return isinstance(v, str)
def _t_int(v): return isinstance(v, int) and not isinstance(v, bool)
def _t_bool(v): return isinstance(v, bool)
def _t_num(v): return isinstance(v, (int, float)) and not isinstance(v, bool)
def _t_list(v): return isinstance(v, list)
def _t_obj(v): return isinstance(v, dict)
def _t_fp4(v): return isinstance(v, str) and bool(_FP4.match(v))
def _t_fp2(v): return isinstance(v, str) and bool(_FP2.match(v))
def _t_iso(v): return isinstance(v, str) and bool(_ISO.match(v))
def _t_status(v): return isinstance(v, str) and MarketStatus.parse(v) is not MarketStatus.UNKNOWN
def _t_strike(v): return isinstance(v, str) and StrikeType.parse(v) is not StrikeType.UNKNOWN
def _opt(fn): return lambda v: v is None or fn(v)


# field -> (required, type check)
MARKET_SCHEMA: Dict[str, Tuple[bool, Callable[[Any], bool]]] = {
    "ticker": (True, _t_str), "event_ticker": (True, _t_str), "market_type": (True, _t_str), "status": (True, _t_status),
    "open_time": (True, _t_iso), "close_time": (True, _t_iso),
    "expected_expiration_time": (False, _opt(_t_iso)), "latest_expiration_time": (False, _opt(_t_iso)),
    "settlement_timer_seconds": (False, _t_int), "can_close_early": (False, _t_bool),
    "strike_type": (False, _opt(_t_strike)), "floor_strike": (False, _opt(_t_num)), "cap_strike": (False, _opt(_t_num)),
    "rules_primary": (False, _t_str), "rules_secondary": (False, _t_str),
    "yes_bid_dollars": (False, _opt(_t_fp4)), "yes_ask_dollars": (False, _opt(_t_fp4)),
    "no_bid_dollars": (False, _opt(_t_fp4)), "no_ask_dollars": (False, _opt(_t_fp4)), "last_price_dollars": (False, _opt(_t_fp4)),
    "yes_bid_size_fp": (False, _opt(_t_fp2)), "yes_ask_size_fp": (False, _opt(_t_fp2)),
    "volume_fp": (False, _opt(_t_fp2)), "volume_24h_fp": (False, _opt(_t_fp2)), "open_interest_fp": (False, _opt(_t_fp2)),
    "notional_value_dollars": (False, _opt(_t_fp4)), "price_ranges": (False, _t_list),
    "result": (False, _t_str), "settlement_value_dollars": (False, _opt(_t_fp4)), "settlement_ts": (False, _opt(_t_iso)),
    "is_provisional": (False, _t_bool),
}
KNOWN_MARKET_EXTRA = {"title", "subtitle", "yes_sub_title", "no_sub_title", "mve_collection_ticker", "mve_selected_legs",
                      "primary_participant_key", "exchange_index", "created_time", "updated_time", "expiration_time",
                      "occurrence_datetime", "fee_waiver_expiration_time", "early_close_condition", "previous_yes_bid_dollars",
                      "previous_yes_ask_dollars", "previous_price_dollars", "price_level_structure", "functional_strike",
                      "custom_strike", "expiration_value", "settlement_bounds_type", "settlement_floor_dollars",
                      "series_ticker", "category", "response_price_units", "yes_bid", "yes_ask", "no_bid", "no_ask",
                      "last_price", "volume", "volume_24h", "open_interest", "liquidity", "liquidity_dollars", "tick_size",
                      "risk_limit_cents", "strike_date", "strike_period", "market_type_v2"}

SERIES_SCHEMA: Dict[str, Tuple[bool, Callable[[Any], bool]]] = {
    "ticker": (True, _t_str), "title": (True, _t_str), "category": (True, _t_str), "frequency": (False, _t_str),
    "categories": (False, _opt(_t_list)), "tags": (False, _opt(_t_list)), "settlement_sources": (False, _opt(_t_list)),
    "fee_type": (True, _t_str), "fee_multiplier": (True, _t_num), "contract_url": (False, _t_str),
    "contract_terms_url": (False, _t_str), "additional_prohibitions": (False, _opt(_t_list)),
}
KNOWN_SERIES_EXTRA = {"product_metadata", "volume_fp", "last_updated_ts", "exchange_index", "volume", "settlement_source_url"}
ALLOWED_FEE_TYPES = {"quadratic", "quadratic_with_maker_fees", "quadratic_with_combo_maker_fees", "flat"}

ORDERBOOK_SNAPSHOT_MSG = {"market_ticker": (True, _t_str), "market_id": (False, _t_str), "clock": (True, _t_int),
                          "yes_dollars_fp": (False, _t_list), "no_dollars_fp": (False, _t_list)}
ORDERBOOK_DELTA_MSG = {"market_ticker": (True, _t_str), "market_id": (False, _t_str), "clock": (True, _t_int),
                       "price_dollars": (True, _t_fp4), "delta_fp": (True, _t_fp2), "side": (True, lambda v: v in ("yes", "no")),
                       "ts_ms": (False, _t_int)}
TICKER_MSG = {"market_ticker": (True, _t_str), "price_dollars": (False, _opt(_t_fp4)), "yes_bid_dollars": (False, _opt(_t_fp4)),
              "yes_ask_dollars": (False, _opt(_t_fp4)), "volume_fp": (False, _opt(_t_fp2)), "open_interest_fp": (False, _opt(_t_fp2)),
              "yes_bid_size_fp": (False, _opt(_t_fp2)), "yes_ask_size_fp": (False, _opt(_t_fp2)), "ts_ms": (False, _t_int)}
LIFECYCLE_MSG = {"market_ticker": (True, _t_str), "event_type": (True, lambda v: v in {
    "created", "activated", "deactivated", "close_date_updated", "determined", "settled", "price_level_structure_updated", "metadata_updated"})}
CF_VALUE_MSG = {"index_id": (True, _t_str), "value_usd": (False, _t_str), "source_ts_ms": (False, _t_int), "received_at": (False, _t_int),
                "avg_60s_data": (False, _t_obj)}


def _check(kind: str, payload: Dict[str, Any], schema: Dict[str, Tuple[bool, Callable]], known_extra: Optional[set] = None) -> Dict[str, Any]:
    STATS.checked += 1
    if not isinstance(payload, dict):
        STATS.mismatches += 1
        raise SchemaMismatch(kind, ["payload is not an object"], [])
    problems: List[str] = []
    for key, (required, check) in schema.items():
        if key not in payload:
            if required:
                problems.append(f"missing required field {key}")
            continue
        if not check(payload[key]):
            problems.append(f"field {key} has unexpected shape: {type(payload[key]).__name__}={str(payload[key])[:40]!r}")
    if known_extra is not None:
        for k in payload:
            if k not in schema and k not in known_extra:
                STATS.unknown_fields[f"{kind}.{k}"] = STATS.unknown_fields.get(f"{kind}.{k}", 0) + 1
    if problems:
        STATS.mismatches += 1
        raise SchemaMismatch(kind, problems, sorted(payload.keys()))
    return payload


def validate_market(d: Dict[str, Any]) -> Dict[str, Any]:
    d = d.get("market", d) if isinstance(d, dict) else d
    out = _check("market", d, MARKET_SCHEMA, KNOWN_MARKET_EXTRA)
    for r in out.get("price_ranges") or []:
        if not (isinstance(r, dict) and _t_fp4(r.get("start")) and _t_fp4(r.get("end")) and _t_fp4(r.get("step"))):
            STATS.mismatches += 1
            raise SchemaMismatch("market.price_ranges", [f"bad range {r!r}"], sorted(out.keys()))
    return out


def validate_series(d: Dict[str, Any]) -> Dict[str, Any]:
    d = d.get("series", d) if isinstance(d, dict) else d
    out = _check("series", d, SERIES_SCHEMA, KNOWN_SERIES_EXTRA)
    if out["fee_type"] not in ALLOWED_FEE_TYPES:
        STATS.mismatches += 1
        raise SchemaMismatch("series.fee_type", [f"unknown fee_type {out['fee_type']!r}"], sorted(out.keys()))
    for src in out.get("settlement_sources") or []:
        if not isinstance(src, dict) or not isinstance(src.get("name", ""), str):
            STATS.mismatches += 1
            raise SchemaMismatch("series.settlement_sources", [f"bad source {src!r}"], sorted(out.keys()))
    return out


def validate_ws_envelope(m: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(m, dict) or not isinstance(m.get("type"), str):
        STATS.mismatches += 1
        raise SchemaMismatch("ws.envelope", ["missing type"], sorted(m.keys()) if isinstance(m, dict) else [])
    t = m["type"]
    if t in ("orderbook_snapshot", "orderbook_delta", "ticker", "trade", "market_lifecycle_v2", "event_lifecycle",
             "cfbenchmarks_value", "cfbenchmarks_value_5hz", "pyth_value"):
        for k in ("sid", "msg"):
            if k not in m:
                STATS.mismatches += 1
                raise SchemaMismatch(f"ws.{t}", [f"missing {k}"], sorted(m.keys()))
        if t != "ticker" and "seq" not in m:  # ticker docs show no seq; everything else sequences
            STATS.mismatches += 1
            raise SchemaMismatch(f"ws.{t}", ["missing seq"], sorted(m.keys()))
        schema = {"orderbook_snapshot": ORDERBOOK_SNAPSHOT_MSG, "orderbook_delta": ORDERBOOK_DELTA_MSG, "ticker": TICKER_MSG,
                  "market_lifecycle_v2": LIFECYCLE_MSG, "cfbenchmarks_value": CF_VALUE_MSG, "cfbenchmarks_value_5hz": CF_VALUE_MSG}.get(t)
        if schema:
            _check(f"ws.{t}.msg", m["msg"], schema)
        if t == "orderbook_snapshot":
            for side in ("yes_dollars_fp", "no_dollars_fp"):
                for lvl in m["msg"].get(side) or []:
                    if not (isinstance(lvl, list) and len(lvl) == 2 and _t_fp4(lvl[0]) and _t_fp2(lvl[1])):
                        STATS.mismatches += 1
                        raise SchemaMismatch("ws.orderbook_snapshot.level", [f"bad level {lvl!r}"], [side])
    elif t in ("subscribed", "unsubscribed", "ok", "error"):
        if t == "subscribed" and not (isinstance(m.get("msg"), dict) and "sid" in m["msg"] and "channel" in m["msg"]):
            STATS.mismatches += 1
            raise SchemaMismatch("ws.subscribed", ["msg must have channel and sid"], sorted(m.keys()))
        if t == "error" and not (isinstance(m.get("msg"), dict) and "code" in m["msg"]):
            STATS.mismatches += 1
            raise SchemaMismatch("ws.error", ["msg must have code"], sorted(m.keys()))
    return m
