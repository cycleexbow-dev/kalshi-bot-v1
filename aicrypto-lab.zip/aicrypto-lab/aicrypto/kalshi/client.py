"""Read-only Kalshi REST client (market data + own rate-limit info).

Everything goes through GuardedTransport; there is no method here that could place,
amend or cancel an order, and the transport would refuse the path anyway.
All responses are schema-checked before being returned (fail closed).
"""
from __future__ import annotations

from typing import Any, AsyncIterator, Dict, List, Optional

from .auth import HOSTS, PUBLIC_REST, KalshiSigner
from .schemas import SchemaMismatch, validate_market, validate_series
from .transport import GuardedTransport


class KalshiRestClient:
    def __init__(self, env: str = "demo", signer: Optional[KalshiSigner] = None, *, public: Optional[bool] = None,
                 requests_per_second: float = 5.0, transport: Optional[GuardedTransport] = None, **transport_kw):
        if env not in HOSTS:
            raise ValueError(f"unknown env {env!r}")
        self.env = env
        use_public = (signer is None) if public is None else public
        base = PUBLIC_REST[env] if use_public else HOSTS[env]["rest"]
        self.transport = transport or GuardedTransport(base, signer=None if use_public else signer,
                                                       requests_per_second=requests_per_second, **transport_kw)
        self.mismatches: List[Dict[str, Any]] = []

    async def aclose(self) -> None:
        await self.transport.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.aclose()

    # ---- helpers --------------------------------------------------------------------------
    def _record_mismatch(self, exc: SchemaMismatch, context: str) -> None:
        self.mismatches.append({"kind": exc.kind, "problems": exc.problems, "keys": exc.payload_keys, "context": context})

    async def _paginate(self, path: str, key: str, params: Dict[str, Any], limit: int, max_pages: int,
                        progress=None) -> AsyncIterator[Dict[str, Any]]:
        cursor: Optional[str] = None
        total = 0
        for n in range(max_pages):
            page = await self.transport.request("GET", path, {**params, "limit": limit, "cursor": cursor})
            items = page.get(key) or []
            total += len(items)
            if progress:
                progress(f"{path} page {n + 1}: +{len(items)} (total {total})")
            for it in items:
                yield it
            cursor = page.get("cursor") or None
            if not cursor or not items:
                return

    # ---- exchange / account -----------------------------------------------------------------
    async def exchange_status(self) -> Dict[str, Any]:
        return await self.transport.request("GET", "/exchange/status")

    async def exchange_schedule(self) -> Dict[str, Any]:
        return await self.transport.request("GET", "/exchange/schedule")

    async def account_limits(self) -> Dict[str, Any]:
        """Authenticated: our tier and token budgets. Read-only."""
        return await self.transport.request("GET", "/account/limits")

    # ---- series -----------------------------------------------------------------------------
    async def get_series(self, series_ticker: str) -> Dict[str, Any]:
        raw = await self.transport.request("GET", f"/series/{series_ticker}")
        try:
            return validate_series(raw)
        except SchemaMismatch as exc:
            self._record_mismatch(exc, f"series/{series_ticker}")
            raise

    async def list_series(self, category: Optional[str] = None, max_pages: int = 50, progress=None) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        async for s in self._paginate("/series", "series", {"category": category}, 1000, max_pages, progress):
            try:
                out.append(validate_series(s))
            except SchemaMismatch as exc:
                self._record_mismatch(exc, f"series list item {s.get('ticker') if isinstance(s, dict) else '?'}")
        return out

    # ---- events / markets -------------------------------------------------------------------
    async def get_event(self, event_ticker: str, with_nested_markets: bool = False) -> Dict[str, Any]:
        return await self.transport.request("GET", f"/events/{event_ticker}", {"with_nested_markets": str(with_nested_markets).lower()})

    async def get_market(self, ticker: str) -> Dict[str, Any]:
        raw = await self.transport.request("GET", f"/markets/{ticker}")
        try:
            return validate_market(raw)
        except SchemaMismatch as exc:
            self._record_mismatch(exc, f"markets/{ticker}")
            raise

    async def list_markets(self, *, status: Optional[str] = "open", series_ticker: Optional[str] = None,
                           event_ticker: Optional[str] = None, min_close_ts: Optional[int] = None,
                           max_close_ts: Optional[int] = None, max_pages: int = 100, progress=None) -> List[Dict[str, Any]]:
        """All markets matching the filters (paginated, 1000/page). Invalid items are skipped
        and recorded; valid items are returned."""
        out: List[Dict[str, Any]] = []
        params = {"status": status, "series_ticker": series_ticker, "event_ticker": event_ticker,
                  "min_close_ts": min_close_ts, "max_close_ts": max_close_ts}
        async for m in self._paginate("/markets", "markets", params, 1000, max_pages, progress):
            try:
                out.append(validate_market(m))
            except SchemaMismatch as exc:
                self._record_mismatch(exc, f"markets list item {m.get('ticker') if isinstance(m, dict) else '?'}")
        return out

    async def get_orderbook(self, ticker: str, depth: Optional[int] = None) -> Dict[str, Any]:
        return await self.transport.request("GET", f"/markets/{ticker}/orderbook", {"depth": depth})

    async def get_candlesticks(self, series_ticker: str, ticker: str, start_ts: int, end_ts: int, period_interval: int = 1) -> Dict[str, Any]:
        """period_interval: 1 (1m), 60 (1h), 1440 (1d). Path form per docs: /series/{s}/markets/{t}/candlesticks
        is NOT on our allowlist; the allowlisted form is /markets/{ticker}/candlesticks."""
        return await self.transport.request("GET", f"/markets/{ticker}/candlesticks",
                                            {"start_ts": start_ts, "end_ts": end_ts, "period_interval": period_interval})

    async def get_candlesticks_multi(self, tickers: List[str], start_ts: int, end_ts: int, period_interval: int = 1) -> Dict[str, Any]:
        """Documented batch form GET /markets/candlesticks?market_tickers=a,b (max 100); allowlisted."""
        return await self.transport.request("GET", "/markets/candlesticks",
                                            {"market_tickers": ",".join(tickers[:100]), "start_ts": start_ts, "end_ts": end_ts,
                                             "period_interval": period_interval})

    async def get_trades(self, ticker: Optional[str] = None, limit: int = 1000, cursor: Optional[str] = None) -> Dict[str, Any]:
        return await self.transport.request("GET", "/markets/trades", {"ticker": ticker, "limit": limit, "cursor": cursor})
