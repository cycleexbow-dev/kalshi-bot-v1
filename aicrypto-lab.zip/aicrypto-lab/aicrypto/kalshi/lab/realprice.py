"""Score every lab rule against the REAL Kalshi exchange's public prices (owner decision 2026-11-10).

Read-only and shadow-only: prices and results come from Kalshi's public market-data host
(PUBLIC_REST["production"]) through the same guarded, GET-only KalshiRestClient the app already
uses. No account, no keys, no signer, no orders. This lab has no bot and can never trade; its
only output is a second scoreboard that says whether a rule's demo results hold up at the prices
real traders actually pay. The settlement index (CF Benchmarks) and the market tickers are the
same on both exchanges; only the Kalshi prices differ.
"""
from __future__ import annotations

import asyncio
import logging
import time
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..models import MarketStatus
from .engine import LiveLab

log = logging.getLogger("aicrypto.lab.real")

POLL_S = 2.0
REAL_QUOTE_MAX_AGE_S = 8.0
BATCH = 50


class _NoBotSettings:
    practice = False
    stake_pct = 0.0
    max_positions = 0


class NoBot:
    """The real-price lab never trades. It has the attributes the lab loop reads; switching it on is refused."""
    on = False
    last_error = ""
    last_size = 0
    settings = _NoBotSettings()

    def may_trade(self, *a, **k) -> bool:
        return False

    def turn_on(self) -> None:
        raise RuntimeError("the real-price lab is read-only and has no bot")

    def turn_off(self, why: str = "") -> None:
        pass

    async def submit(self, *a, **k):
        raise RuntimeError("the real-price lab is read-only and cannot place orders")


def _p4(v: Any) -> Optional[int]:
    try:
        x = Decimal(str(v))
    except Exception:
        return None
    return int((x * 10000).to_integral_value()) if x > 0 else None


class RealPriceLab(LiveLab):
    def __init__(self, svc, store_path: Path, clock=time.time, client_factory: Optional[Callable[[], Any]] = None):
        super().__init__(svc, store_path, clock, with_bot=False)
        self.bot = NoBot()
        self._client_factory = client_factory
        self._client = None
        # ticker -> (monotonic time, yes_bid_p4, yes_ask_p4, bid_size, ask_size, strike)
        self.quotes: Dict[str, Tuple[float, Optional[int], Optional[int], float, float, Optional[float]]] = {}
        self.results: Dict[str, str] = {}
        self.shards: Dict[str, int] = {}       # ticker -> exchange_index ON THE REAL EXCHANGE (differs from demo)
        self.polls = 0

    def client(self):
        if self._client is None:
            if self._client_factory is not None:
                self._client = self._client_factory()
            else:
                from ..client import KalshiRestClient
                # public, unsigned, GET-only market data from the real exchange
                self._client = KalshiRestClient("production", signer=None, public=True, requests_per_second=2.0,
                                                timeout_s=6.0, max_retries=1)
        return self._client

    async def _markets(self, tickers: List[str]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for i in range(0, len(tickers), BATCH):
            chunk = tickers[i:i + BATCH]
            data = await self.client().transport.request("GET", "/markets", {"tickers": ",".join(chunk), "limit": len(chunk)})
            out += [m for m in (data or {}).get("markets", []) if isinstance(m, dict)]
        return out

    def _live_windows(self, now: float) -> List[str]:
        reg = self.svc.reg
        out = []
        for t in self.focus_markets():
            m = reg.markets.get(t)
            if (m and m.open_time and m.close_time and m.status is MarketStatus.ACTIVE and m.floor_strike is not None
                    and m.open_time.timestamp() <= now < m.close_time.timestamp()):
                out.append(t)                  # the same windows the demo lab can trade (window_view's checks)
        return out

    async def poll(self) -> int:
        a = time.monotonic()
        ts = self._live_windows(self.clock())
        if not ts:
            return 0
        b = time.monotonic()
        got = await self._markets(ts)
        self.poll_parts = {"scan_ms": round((b - a) * 1000), "http_ms": round((time.monotonic() - b) * 1000), "tickers": len(ts)}
        n = 0
        for m in got:
            t = m.get("ticker")
            if not t or (m.get("status") or "").lower() not in ("active", "open"):
                continue
            yb, ya = _p4(m.get("yes_bid_dollars")), _p4(m.get("yes_ask_dollars"))
            try:
                ybs, yas = float(m.get("yes_bid_size_fp") or 0), float(m.get("yes_ask_size_fp") or 0)
            except (TypeError, ValueError):
                ybs = yas = 0.0
            if m.get("exchange_index") is not None:
                self.shards[t] = int(m["exchange_index"])
            strike = m.get("floor_strike")
            self.quotes[t] = (time.monotonic(), yb, ya if ya and ya < 10000 else None, ybs, yas,
                              float(strike) if strike is not None else None)
            n += 1
        self.polls += 1
        return n

    async def real_shard(self, t: str) -> Optional[int]:
        """The exchange shard a market trades on at the REAL exchange (fetched if not seen yet)."""
        if t not in self.shards:
            try:
                for m in await self._markets([t]):
                    if m.get("ticker") == t and m.get("exchange_index") is not None:
                        self.shards[t] = int(m["exchange_index"])
            except Exception:
                return None
        return self.shards.get(t)

    def _quote(self, t: str):
        q = self.quotes.get(t)
        if q is None or time.monotonic() - q[0] > REAL_QUOTE_MAX_AGE_S:
            return None
        return q[1], q[2], q[3], q[4]

    def window_view(self, t: str, now: float):
        q = self.quotes.get(t)
        m = self.svc.reg.markets.get(t) if self.svc.reg else None
        if q is not None and q[5] is not None and m is not None and m.floor_strike is not None:
            if abs(float(m.floor_strike) - q[5]) > 1e-6 * max(1.0, abs(q[5])):
                return None                    # target differs between the exchanges: not comparable
        return super().window_view(t, now)

    async def settle(self) -> int:
        now = self.clock()
        pending: Dict[str, float] = {}
        for tr in self.store.open_trades():
            pending.setdefault(tr["ticker"], tr["close_ts"])
        due = [t for t, c in pending.items() if now >= c + 5 and t not in self.results]
        if due:
            try:
                for m in await self._markets(due):
                    r = (m.get("result") or "").lower()
                    if r in ("yes", "no"):
                        self.results[m["ticker"]] = r
            except Exception as e:
                self.last_error = f"real result lookup: {type(e).__name__}"
        done = 0
        for t, c in pending.items():
            r = self.results.get(t)
            if r:
                done += self.store.settle(t, r, now)
            elif now > c + 6 * 3600:
                self.store.void(t, now)
        return done

    async def run(self) -> None:
        last_slow = last_poll = 0.0
        while True:
            try:
                if self.svc.reg is not None and self.svc.load.phase == "ready":
                    if not self.cands:
                        self.setup()
                    t0 = time.monotonic()
                    if self.clock() - last_poll >= POLL_S:
                        last_poll = self.clock()
                        await self.poll()
                    t1 = time.monotonic()
                    await self.tick()
                    t2 = time.monotonic()
                    self.timing = {"poll_ms": round((t1 - t0) * 1000), "tick_ms": round((t2 - t1) * 1000)}
                    if self.clock() - last_slow > 15:
                        last_slow = self.clock()
                        await self.settle()
                        self.promote()
                        self.refresh_stats()
                        self.timing["slow_ms"] = round((time.monotonic() - t2) * 1000)
            except Exception as e:  # never let the lab take the backend down
                self.last_error = f"{type(e).__name__}: {e}"
                log.warning("real-price lab: %s", self.last_error)
            await asyncio.sleep(1.0)

    def summary(self) -> Dict[str, Any]:
        s = super().summary()
        s.pop("bot", None)
        s.update(data_source="real exchange public prices (read-only)", polls=self.polls, timing={**getattr(self, "timing", {}), **getattr(self, "poll_parts", {})},
                 live_quotes=sum(1 for q in self.quotes.values() if time.monotonic() - q[0] <= REAL_QUOTE_MAX_AGE_S))
        return s
