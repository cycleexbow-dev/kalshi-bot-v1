"""Live strategy lab + demo bot for 15-minute crypto and commodity windows.

The lab watches live markets, lets every candidate rule "shadow trade" (1 contract, taker at
the ask, Kalshi taker fee rounded up), scores each trade when Kalshi settles the window, and
moves candidates through stages using pre-set statistical gates:

  exploring  --(>=150 trades, mean > 0, t >= 2.0)-->                         shortlisted
  shortlisted --(>=250 NEW trades, mean >= +0.5c, t >= Bonferroni z, both halves > 0)--> proven
  shortlisted --(fails the above, or t <= -1 after 100)-->                  rejected
  exploring  --(>=600 trades and mean <= 0)-->                              retired
  proven     --(last 200 trades t <= -1.5)-->                               retired

Only trades placed AFTER a candidate was shortlisted count towards proving it, so the data
that selected it never confirms it. The Bonferroni z grows with every candidate ever
shortlisted, which corrects for trying many ideas. Thresholds are fixed constants: the lab
never tunes a rule's parameters on its own results.

The bot ("Toggle bot") is off at every start. When on, it sends a demo order (through
DemoTrader.place, with all its checks and risk limits) when a PROVEN candidate signals.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import sqlite3
import statistics
import time
from collections import deque
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

from ..models import MarketStatus
from .candidates import Candidate, WindowView, build, taker_fee
from .candidates import LAB_FIRST
from .features import move_pct, prob_up_avg_settle, realized_sigma

log = logging.getLogger("aicrypto.lab")

DISCOVERY_MIN, DISCOVERY_T = 150, 2.0
CONFIRM_MIN, CONFIRM_MEAN = 250, 0.005
EARLY_REJECT_MIN, EARLY_REJECT_T = 100, -1.0
RETIRE_EXPLORE_MIN = 600
LIVE_WINDOW, LIVE_DEMOTE_T = 200, -1.5
ALPHA = 0.05
QUOTE_MAX_AGE_S = 30.0
REF_MAX_AGE_S = 5.0
FOCUS_CLASSES = ("crypto", "metals", "energy")
LAB_VERSION = "1"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (cid TEXT PRIMARY KEY, family TEXT, asset TEXT, params TEXT, needs_ref INTEGER,
  stage TEXT, stage_since REAL, created_at REAL, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY AUTOINCREMENT, cid TEXT, ticker TEXT, side TEXT, price TEXT, fee TEXT,
  t_entry REAL, close_ts REAL, phase TEXT, result TEXT, pnl TEXT, settled_at REAL, UNIQUE(cid, ticker));
CREATE INDEX IF NOT EXISTS idx_trades_open ON trades(settled_at);
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, t REAL, cid TEXT, message TEXT);
"""

PHASE_FOR_STAGE = {"exploring": "disc", "shortlisted": "conf", "proven": "live"}


def tstat(xs: List[float]) -> Tuple[float, float]:
    if len(xs) < 2:
        return (xs[0] if xs else 0.0), 0.0
    m = statistics.fmean(xs)
    sd = statistics.stdev(xs)
    return m, (m / (sd / math.sqrt(len(xs))) if sd > 0 else (math.inf if m > 0 else -math.inf if m < 0 else 0.0))


class LabStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._c() as c:
            c.executescript(_SCHEMA)

    def _c(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")           # small, frequent writes from the event loop
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    def sync_candidates(self, cands: List[Candidate], now: float) -> None:
        with self._c() as c:
            for k in cands:
                c.execute("INSERT OR IGNORE INTO candidates VALUES (?,?,?,?,?,?,?,?,?)",
                          (k.cid, k.family, k.asset, json.dumps(k.params), int(k.needs_reference), "exploring", now, now, ""))

    def stages(self) -> Dict[str, str]:
        with self._c() as c:
            return {r["cid"]: r["stage"] for r in c.execute("SELECT cid, stage FROM candidates")}

    def set_stage(self, cid: str, stage: str, note: str, now: float) -> None:
        with self._c() as c:
            c.execute("UPDATE candidates SET stage=?, stage_since=?, note=? WHERE cid=?", (stage, now, note, cid))
            c.execute("INSERT INTO events (t, cid, message) VALUES (?,?,?)", (now, cid, f"{stage}: {note}"))

    def add_trade(self, cid, ticker, side, price: Decimal, fee: Decimal, t, close_ts, phase) -> bool:
        with self._c() as c:
            cur = c.execute("INSERT OR IGNORE INTO trades (cid, ticker, side, price, fee, t_entry, close_ts, phase) VALUES (?,?,?,?,?,?,?,?)",
                            (cid, ticker, side, str(price), str(fee), t, close_ts, phase))
            return cur.rowcount > 0

    def entered(self) -> set:
        with self._c() as c:
            return {(r["cid"], r["ticker"]) for r in c.execute("SELECT cid, ticker FROM trades WHERE t_entry > ?", (time.time() - 3 * 3600,))}

    def open_trades(self) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT * FROM trades WHERE settled_at IS NULL")]

    def settle(self, ticker: str, result: str, now: float) -> int:
        n = 0
        with self._c() as c:
            for r in c.execute("SELECT id, side, price, fee FROM trades WHERE ticker=? AND settled_at IS NULL", (ticker,)).fetchall():
                win = r["side"] == result
                pnl = (Decimal(1) if win else Decimal(0)) - Decimal(r["price"]) - Decimal(r["fee"])
                c.execute("UPDATE trades SET result=?, pnl=?, settled_at=? WHERE id=?", (result, str(pnl), now, r["id"]))
                n += 1
        return n

    def void(self, ticker: str, now: float) -> None:
        with self._c() as c:
            c.execute("UPDATE trades SET result='void', pnl='0', settled_at=? WHERE ticker=? AND settled_at IS NULL", (now, ticker))

    def pnls(self, cid: str, phase: Optional[str] = None, since: float = 0.0) -> List[float]:
        q = "SELECT pnl FROM trades WHERE cid=? AND settled_at IS NOT NULL AND result != 'void' AND t_entry >= ?"
        args: list = [cid, since]
        if phase:
            q += " AND phase=?"
            args.append(phase)
        with self._c() as c:
            return [float(r["pnl"]) for r in c.execute(q + " ORDER BY t_entry", args)]

    def scoreboard(self) -> List[Dict[str, Any]]:
        with self._c() as c:
            cands = [dict(r) for r in c.execute("SELECT * FROM candidates")]
            agg = {r["cid"]: dict(r) for r in c.execute(
                "SELECT cid, COUNT(*) n, SUM(CASE WHEN result=side THEN 1 ELSE 0 END) wins, SUM(CAST(pnl AS REAL)) pnl,"
                " SUM(CAST(pnl AS REAL)*CAST(pnl AS REAL)) pnl2, SUM(CAST(price AS REAL)+CAST(fee AS REAL)) paid"
                " FROM trades WHERE settled_at IS NOT NULL AND result != 'void' GROUP BY cid")}
            opn = {r["cid"]: r["k"] for r in c.execute("SELECT cid, COUNT(*) k FROM trades WHERE settled_at IS NULL GROUP BY cid")}
        out = []
        for k in cands:
            a = agg.get(k["cid"], {})
            n = a.get("n") or 0
            mean = (a["pnl"] / n) if n else None
            t = None
            if n >= 2:
                var = max(0.0, (a["pnl2"] - n * mean * mean) / (n - 1))
                t = mean / math.sqrt(var / n) if var > 0 else None
            paid = a.get("paid") or 0.0
            out.append({**k, "params": json.loads(k["params"]), "n": n, "wins": a.get("wins") or 0, "net_total": a.get("pnl") or 0.0,
                        "return_pct": round(100 * a["pnl"] / paid, 1) if paid > 0 else None,
                        "net_per_trade": mean, "t": t, "open": opn.get(k["cid"], 0)})
        return out

    def events(self, limit=100) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))]


@dataclass
class BotSettings:
    practice: bool = True            # also trade rules still being tested (demo money is the tuition)
    stake_pct: float = 2.0           # % of the demo account staked per trade: sizes compound with the balance
    max_positions: int = 8
    max_orders_per_min: int = 6


STAKE_MIN, STAKE_MAX = 0.5, 10.0
MIN_STAKE = Decimal("1.00")           # owner decision: no bot trade under $1
PRACTICE_MIN_N = 10                  # a learning rule with this many results and no profit is not traded
REAL_MIN_N = 20                      # ...nor one with this many results at REAL-exchange prices and no profit
STAGE_RANK = {"proven": 0, "shortlisted": 1, "exploring": 2}


class Bot:
    """'Toggle bot': per-session, demo-only. Off at every start and after any emergency stop.
    Proven rules always trade; in practice mode rules still being tested trade too, unless their
    results so far are losing. Size = a fixed share of the account, so it compounds."""

    def __init__(self, trader, clock=time.time):
        self.trader, self.clock = trader, clock
        self.on = False
        self.settings = BotSettings()
        try:
            v = trader.ledger.get("bot_practice")
            if v is not None:
                self.settings.practice = v == "1"
            v = trader.ledger.get("bot_stake_pct")
            if v is not None:
                self.settings.stake_pct = min(STAKE_MAX, max(STAKE_MIN, float(v)))
        except Exception:
            pass
        self.sent: List[float] = []
        self.last_error = ""
        self.last_size = 0
        trader.on_kill.append(self.turn_off)

    def configure(self, practice: Optional[bool] = None, stake_pct: Optional[float] = None) -> None:
        if practice is not None:
            self.settings.practice = bool(practice)
            self.trader.ledger.put("bot_practice", "1" if practice else "0")
        if stake_pct is not None:
            self.settings.stake_pct = min(STAKE_MAX, max(STAKE_MIN, float(stake_pct)))
            self.trader.ledger.put("bot_stake_pct", str(self.settings.stake_pct))
        self.trader.ledger.event("bot", f"bot settings: practice={'on' if self.settings.practice else 'off'}, stake {self.settings.stake_pct}% of account")

    def turn_on(self) -> None:
        from ..demo_exec.trader import OrderRefused
        errs = []
        if self.trader.state != "connected":
            errs.append("Not connected to the Kalshi demo account.")
        if self.trader.kill_on():
            errs.append("Emergency stop is on. Reset it first.")
        if errs:
            raise OrderRefused(errs)
        self.on = True
        self.trader.ledger.event("bot", "BOT ON (demo only)")

    def turn_off(self, why: str = "user") -> None:
        if self.on:
            self.trader.ledger.event("bot", f"BOT OFF ({why})")
        self.on = False

    def _busy_tickers(self) -> set:
        from ..demo_exec.ledger import OPEN_STATES
        mine = {o["ticker"] for o in self.trader.ledger.orders(states=OPEN_STATES, origin_prefix="bot:")}
        # a bot order that already filled counts too: the account's position list refreshes only every
        # few seconds, and in that gap a second rule once bought the opposite side of the same market
        cutoff = self.trader.clock() - 16 * 60
        filled = {o["ticker"] for o in self.trader.ledger.orders(origin_prefix="bot:", limit=100)
                  if (o["filled_c2"] or 0) > 0 and (o["created_at"] or 0) >= cutoff}
        return mine | filled | {p["ticker"] for p in self.trader.account.get("positions", [])}

    def may_trade(self, stage: str, n: int, mean: Optional[float], real: Optional[Tuple[int, Optional[float]]] = None) -> bool:
        """Learning rules keep trading only while the evidence is not against them: neither the demo
        practice record nor (once there is enough of it) the record at real-exchange prices may be
        losing. The lab keeps paper-trading every rule, so a skipped rule comes back if it recovers."""
        if stage == "proven":
            return True
        if not self.settings.practice or stage not in STAGE_RANK:
            return False
        if n >= PRACTICE_MIN_N and (mean or 0.0) <= 0:
            return False
        if real is not None and real[0] >= REAL_MIN_N and (real[1] or 0.0) <= 0:
            return False
        return True

    def size(self, price: Decimal, available: float) -> int:
        """Contracts for one trade: stake_pct of account value (cash + positions) but never under
        MIN_STAKE dollars. 0 = skip (a trade of at least MIN_STAKE is not possible right now)."""
        import math
        acct = self.trader.account
        cash = Decimal(str(acct.get("balance") or "0"))
        equity = cash + Decimal(str(acct.get("portfolio_value") or "0"))
        if price is None or price <= 0:
            return 0
        floor_n = math.ceil(MIN_STAKE / price)
        n = max(int(equity * Decimal(str(self.settings.stake_pct)) / 100 / price), floor_n)
        n = min(n, int(cash / price), 500)
        limit = self.trader.budget()               # optional spending limit: stay inside its 1% per-market cap
        if limit:
            n = min(n, int(limit / 100 / price))
        if available >= 1:
            n = min(n, int(available))
        return n if n >= floor_n else 0

    async def submit(self, cand: Candidate, w: WindowView, side: str, price: Decimal, learning: bool = False) -> Optional[str]:
        from ..demo_exec.trader import Intent, OrderRefused
        if not self.on or self.trader.kill_on():
            return None
        now = self.clock()
        self.sent = [t for t in self.sent if now - t < 60]
        if len(self.sent) >= self.settings.max_orders_per_min:
            return "rate limit"
        busy = self._busy_tickers()
        if w.ticker in busy:
            return "already in this market"
        if len(busy) >= self.settings.max_positions:
            return "max positions"
        n = self.size(price, w.yes_ask_size if side == "yes" else w.yes_bid_size)
        if n < 1:
            self.last_error = "Skipped a trade: at least $1 could not be placed (not enough offered at the price, or not enough cash)."
            return "too small"
        self.last_size = n
        it = Intent(w.ticker, side, price, n, origin=f"bot:{cand.cid}@lab{LAB_VERSION}",
                    reason=f"{cand.family} signal{' (practice)' if learning else ''}, {w.t_left:.0f}s left")
        try:
            r = await self.trader.place(it, automated=True, feed_free=not cand.needs_reference)
        except OrderRefused as e:
            self.last_error = "; ".join(e.errors)
            return "refused"
        self.sent.append(now)
        return r["state"]


class LiveLab:
    def __init__(self, svc, store_path: Path, clock=time.time, with_bot: bool = True):
        self.svc, self.clock = svc, clock
        self.store = LabStore(store_path)
        self.bot = Bot(svc.demo, clock) if with_bot else None
        self.cands: List[Candidate] = []
        self.by_asset: Dict[str, List[Candidate]] = {}
        self.stage: Dict[str, str] = {}
        self.entered: set = set()
        self.mids: Dict[str, Deque[Tuple[float, float]]] = {}
        self.focus: Dict[str, List[str]] = {}
        self.result_checked: Dict[str, float] = {}
        self.ticks = 0
        self.last_error = ""
        self.stats: Dict[str, Tuple[int, Optional[float]]] = {}     # cid -> (settled trades, net per trade)
        self.tstats: Dict[str, Optional[float]] = {}                # cid -> confidence (t)
        # cid -> (n, net per trade, t) of the same rule scored at REAL-exchange prices (set by the service)
        self.real_evidence = lambda: {}

    def refresh_stats(self) -> None:
        sb = self.store.scoreboard()
        self.stats = {r["cid"]: (r["n"], r["net_per_trade"]) for r in sb}
        self.tstats = {r["cid"]: r["t"] for r in sb}

    def evidence_score(self, cid: str, real: Dict[str, Tuple[int, Optional[float], Optional[float]]]) -> float:
        """How strongly the results so far support a rule (its t value): real-exchange results once
        there are enough of them, otherwise demo practice results; 0 while there is too little data."""
        r = real.get(cid)
        if r and r[0] >= REAL_MIN_N and r[2] is not None:
            return float(r[2])
        n, _ = self.stats.get(cid, (0, None))
        t = self.tstats.get(cid)
        return float(t) if (n >= PRACTICE_MIN_N and t is not None) else 0.0

    # ---------------------------------------------------------------- setup
    FOCUS_TTL_S = 30.0

    def focus_markets(self) -> List[str]:
        """15-minute crypto/commodity markets. Scanning all ~233k decisions every tick froze the event
        loop, so the list is kept for FOCUS_TTL_S seconds (new windows are listed minutes ahead)."""
        reg = self.svc.reg
        now = time.monotonic()
        hit = getattr(self, "_focus_cache", None)
        if hit and hit[0] is reg and hit[1] is self.svc.access and now - hit[2] < self.FOCUS_TTL_S:
            return hit[3]
        out = []
        for t, d in reg.decisions.items():
            if d.duration.bucket.value == "15m" and d.asset_class in FOCUS_CLASSES and t in self.svc.access:
                out.append(t)
        self._focus_cache = (reg, self.svc.access, now, out)
        return out

    def setup(self) -> None:
        assets: Dict[str, set] = {}
        for t in self.focus_markets():
            d = self.svc.reg.decisions[t]
            assets.setdefault("crypto" if d.asset_class == "crypto" else "commodity", set()).add(d.asset)
        self.focus = {k: sorted(v) for k, v in assets.items()}
        self.cands = build(self.focus)
        self.by_asset = {}
        for c in self.cands:
            self.by_asset.setdefault(c.asset, []).append(c)
        self.store.sync_candidates(self.cands, self.clock())
        self.stage = self.store.stages()
        self.entered = self.store.entered()

    # ---------------------------------------------------------------- live view of one window
    def _quote(self, t: str):
        ws = self.svc.ws
        b = ws.books.books.get(t) if ws is not None else None
        if b is not None and b.valid:
            yb, ya = b.best_yes_bid, b.best_yes_ask
            ybs = (b.yes_bids.get(yb, 0) / 100) if yb else 0.0
            nb = (10000 - ya) if ya else None
            yas = (b.no_bids.get(nb, 0) / 100) if nb else 0.0
            return yb, ya, ybs, yas
        ls = self.svc.reg.liquidity.get(t)
        if ls is None or not ls.last_update_mono or time.monotonic() - ls.last_update_mono > QUOTE_MAX_AGE_S:
            return None
        return ls.yes_bid_p4, ls.yes_ask_p4, ls.bid_size_c2 / 100, ls.ask_size_c2 / 100

    def window_view(self, t: str, now: float) -> Optional[WindowView]:
        reg = self.svc.reg
        m = reg.markets.get(t)
        d = reg.decisions.get(t)
        if m is None or d is None or m.status is not MarketStatus.ACTIVE or not m.close_time or not m.open_time:
            return None
        close_ts, open_ts = m.close_time.timestamp(), m.open_time.timestamp()
        if not (open_ts <= now < close_ts) or m.floor_strike is None:
            return None
        q = self._quote(t)
        if q is None:
            return None
        yb, ya, ybs, yas = q
        P4 = Decimal("0.0001")
        yes_bid = Decimal(yb) * P4 if yb else None
        yes_ask = Decimal(ya) * P4 if ya and ya < 10000 else None
        mid = float((yes_bid + yes_ask) / 2) if (yes_bid is not None and yes_ask is not None) else None
        hist = self.mids.setdefault(t, deque(maxlen=400))
        if mid is not None and (not hist or now - hist[-1][0] >= 1.0):
            hist.append((now, mid))
        past = [v for ts, v in hist if ts <= now - 120]
        w = WindowView(t, d.asset, d.asset_class, now, close_ts, open_ts, yes_bid, yes_ask, ybs, yas,
                       mid_change_120s=(mid - past[-1]) if (mid is not None and past) else None)
        if d.asset_class == "crypto" and d.reference.status.value == "validated":
            idx = d.reference.instrument
            last = self.svc.ref_last.get(idx)
            prints = list(self.svc.ref.get(idx, []))
            if last and now - last[0] <= REF_MAX_AGE_S and len(prints) > 60:
                sigma = realized_sigma(prints, now=now)
                if sigma:
                    win = [v for ts, v in prints if close_ts - 60 <= ts <= now]
                    w.p_up = prob_up_avg_settle(now=now, close_ts=close_ts, target=float(m.floor_strike), spot=last[1],
                                                sigma=sigma, window_prints=win)
                w.move_3m_pct = move_pct(prints, now, 180)
        return w

    # ---------------------------------------------------------------- loop parts
    async def tick(self) -> int:
        now = self.clock()
        n = 0
        real = self.real_evidence() if (self.bot is not None and self.bot.on) else {}
        for t in self.focus_markets():
            w = self.window_view(t, now)
            if w is None:
                continue
            fired = []
            for c in self.by_asset.get(w.asset, []):
                st = self.stage.get(c.cid, "exploring")
                if st not in PHASE_FOR_STAGE or (c.cid, t) in self.entered:
                    continue
                side = c.signal(w)
                if not side:
                    continue
                price = w.ask(side)
                if self.store.add_trade(c.cid, t, side, price, taker_fee(price), now, w.close_ts, PHASE_FOR_STAGE[st]):
                    n += 1
                self.entered.add((c.cid, t))
                k, mean = self.stats.get(c.cid, (0, None))
                rv = real.get(c.cid)
                if c.family in LAB_FIRST and not (rv and rv[0] >= REAL_MIN_N and (rv[1] or 0.0) > 0):
                    continue                       # paper only until it is profitable at real prices
                if self.bot is not None and self.bot.on and self.bot.may_trade(st, k, mean, (rv[0], rv[1]) if rv else None):
                    fired.append((STAGE_RANK[st], -self.evidence_score(c.cid, real), c.cid, c, side, price, st))
            if fired:                              # one demo order per market: the best-supported rule that fired
                fired.sort(key=lambda x: x[:3])
                _, _, _, c, side, price, st = fired[0]
                await self.bot.submit(c, w, side, price, learning=st != "proven")
        self.ticks += 1
        return n

    async def settle(self) -> int:
        now = self.clock()
        reg = self.svc.reg
        done = 0
        pending = {}
        for tr in self.store.open_trades():
            pending.setdefault(tr["ticker"], tr["close_ts"])
        for t, close_ts in pending.items():
            if now < close_ts + 5:
                continue
            m = reg.markets.get(t)
            res = (m.result or "").lower() if m else ""
            if res not in ("yes", "no") and now - self.result_checked.get(t, 0) > 30:
                self.result_checked[t] = now
                try:
                    data = await self.svc._rest().get_market(t)
                    res = ((data.get("market") if isinstance(data.get("market"), dict) else data).get("result") or "").lower()   # client returns the bare market
                except Exception as e:
                    self.last_error = f"result lookup {t}: {type(e).__name__}"
            if res in ("yes", "no"):
                done += self.store.settle(t, res, now)
            elif now > close_ts + 6 * 3600:
                self.store.void(t, now)        # never resolved within 6 h: excluded, never counted
        return done

    def promote(self) -> List[Tuple[str, str]]:
        now = self.clock()
        changes = []
        stages = self.store.stages()
        m = max(1, sum(1 for s in stages.values() if s in ("shortlisted", "proven", "rejected", "retired_live")))
        z = statistics.NormalDist().inv_cdf(1 - ALPHA / m)
        with self.store._c() as c:
            since = {r["cid"]: r["stage_since"] for r in c.execute("SELECT cid, stage_since FROM candidates")}
        for cid, st in stages.items():
            if st == "exploring":
                xs = self.store.pnls(cid, "disc")
                mean, t = tstat(xs)
                if len(xs) >= DISCOVERY_MIN and mean > 0 and t >= DISCOVERY_T:
                    changes.append((cid, "shortlisted", f"{len(xs)} trades, {mean * 100:+.2f} points/trade, t={t:.2f}; now proving on new trades only"))
                elif len(xs) >= RETIRE_EXPLORE_MIN and mean <= 0:
                    changes.append((cid, "retired", f"{len(xs)} trades, {mean * 100:+.2f} points/trade: no edge"))
            elif st == "shortlisted":
                xs = self.store.pnls(cid, "conf", since.get(cid, 0))
                mean, t = tstat(xs)
                if len(xs) >= EARLY_REJECT_MIN and t <= EARLY_REJECT_T:
                    changes.append((cid, "rejected", f"failed confirmation early: {len(xs)} trades, t={t:.2f}"))
                elif len(xs) >= CONFIRM_MIN:
                    h = len(xs) // 2
                    halves = statistics.fmean(xs[:h]) > 0 and statistics.fmean(xs[h:]) > 0
                    if mean >= CONFIRM_MEAN and t >= z and halves:
                        changes.append((cid, "proven", f"confirmed on {len(xs)} new trades: {mean * 100:+.2f} points/trade, t={t:.2f} >= {z:.2f}"))
                    else:
                        changes.append((cid, "rejected", f"confirmation failed: {len(xs)} trades, {mean * 100:+.2f} points/trade, t={t:.2f} (needed {z:.2f})"))
            elif st == "proven":
                xs = self.store.pnls(cid, "live")[-LIVE_WINDOW:]
                mean, t = tstat(xs)
                if len(xs) >= 50 and t <= LIVE_DEMOTE_T:
                    changes.append((cid, "retired_live", f"stopped working: last {len(xs)} trades {mean * 100:+.2f} points/trade, t={t:.2f}"))
        for cid, st, note in changes:
            self.store.set_stage(cid, st, note, now)
            self.stage[cid] = st
        return changes

    async def run(self) -> None:
        last_slow = 0.0
        while True:
            try:
                if self.svc.reg is not None and self.svc.load.phase == "ready":
                    if not self.cands:
                        self.setup()
                    await self.tick()
                    if self.clock() - last_slow > 15:
                        last_slow = self.clock()
                        await self.settle()
                        self.promote()
                        self.refresh_stats()
            except Exception as e:  # never let the lab take the backend down
                self.last_error = f"{type(e).__name__}: {e}"
                log.exception("lab loop")
            await asyncio.sleep(1.0)

    # ---------------------------------------------------------------- views
    def summary(self) -> Dict[str, Any]:
        sb = self.store.scoreboard()
        by = {}
        for r in sb:
            by[r["stage"]] = by.get(r["stage"], 0) + 1
        settled = sum(r["n"] for r in sb)
        return {"focus": self.focus, "candidates": len(sb), "stages": by, "settled_trades": settled,
                "open_trades": sum(r["open"] for r in sb), "bot": {"on": self.bot.on, **self.bot.settings.__dict__, "last_size": self.bot.last_size,
                                                                   "last_error": self.bot.last_error},
                "gates": {"discovery": f">= {DISCOVERY_MIN} trades, mean > 0, t >= {DISCOVERY_T}",
                          "confirmation": f">= {CONFIRM_MIN} new trades, >= {CONFIRM_MEAN * 100:.1f} points/trade, t >= Bonferroni z, both halves > 0",
                          "retire_live": f"last {LIVE_WINDOW} trades t <= {LIVE_DEMOTE_T}"},
                "data_source": self.svc.env, "last_error": self.last_error, "ticks": self.ticks}
