"""Live features for 15-minute up/down windows.

Crypto windows (KX*15M) settle on the simple average of the 60 one-second CF Benchmarks
index prints before the close, compared with the target (the previous window's average).
Commodity windows (gold, silver, copper, WTI) settle on a Pyth 1-minute candle close; the
lab has no licensed Pyth feed, so commodity features use Kalshi prices/order book only.
"""
from __future__ import annotations

import math
from typing import List, Optional, Sequence, Tuple

AVG_WINDOW_S = 60


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def realized_sigma(prints: Sequence[Tuple[float, float]], lookback_s: float = 900.0, now: Optional[float] = None) -> Optional[float]:
    """Per-sqrt-second volatility of log prices from ~1-second prints (time, value)."""
    if len(prints) < 30:
        return None
    now = now if now is not None else prints[-1][0]
    pts = [(t, v) for t, v in prints if now - t <= lookback_s and v > 0]
    if len(pts) < 30:
        return None
    acc, n = 0.0, 0
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        dt = t1 - t0
        if 0.2 <= dt <= 5.0:
            r = math.log(v1 / v0)
            acc += r * r / dt
            n += 1
    if n < 20:
        return None
    return math.sqrt(acc / n)


def prob_up_avg_settle(*, now: float, close_ts: float, target: float, spot: float, sigma: float,
                       window_prints: List[float]) -> float:
    """P(60-second average at close >= target) under a driftless lognormal (normal approx.).

    Before the averaging minute: A ~ S*exp(N(0, sigma^2 * (tau + 60/3))).
    Inside it: k prints are fixed (window_prints), the remaining n are a random walk from S.
    """
    t_left = close_ts - now
    if sigma <= 0 or spot <= 0 or target <= 0:
        return 0.5
    if t_left > AVG_WINDOW_S:
        tau = (t_left - AVG_WINDOW_S) + AVG_WINDOW_S / 3.0
        z = math.log(spot / target) / (sigma * math.sqrt(tau))
        return norm_cdf(z)
    k = len(window_prints)
    n = max(0, AVG_WINDOW_S - k)
    if n == 0:
        avg = sum(window_prints) / k
        return 1.0 if avg >= target else 0.0
    mean = (sum(window_prints) + n * spot) / AVG_WINDOW_S
    var_sum = n * (n + 1) * (2 * n + 1) / 6.0            # Var(sum of n random-walk steps) / sigma^2
    sd = spot * sigma * math.sqrt(var_sum) / AVG_WINDOW_S
    if sd <= 0:
        return 1.0 if mean >= target else 0.0
    return norm_cdf((mean - target) / sd)


def move_pct(prints: Sequence[Tuple[float, float]], now: float, lookback_s: float) -> Optional[float]:
    """Percent change of the index over the last lookback_s seconds."""
    past = [v for t, v in prints if t <= now - lookback_s]
    if not past or not prints:
        return None
    return (prints[-1][1] / past[-1] - 1.0) * 100.0
