"""Candidate strategy families for 15-minute windows, grounded in published research
(see docs/STRATEGY_RESEARCH.md). Every candidate is a fixed rule with fixed parameters; the
lab only measures them, it never tunes a parameter on results (that would leak).

Each candidate enters at most once per window, as a taker at the current ask, 1 contract.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Dict, List, Optional

from ...terminal.fees import fee_estimate

ONE = Decimal(1)


@dataclass
class WindowView:
    """Everything a rule may look at, for one open 15-minute market at one instant."""
    ticker: str
    asset: str
    asset_class: str
    now: float
    close_ts: float
    open_ts: float
    yes_bid: Optional[Decimal]
    yes_ask: Optional[Decimal]
    yes_bid_size: float
    yes_ask_size: float
    mid_change_120s: Optional[float] = None       # Kalshi YES mid change over 2 minutes (dollars)
    # crypto only (CF Benchmarks settlement index available)
    p_up: Optional[float] = None                  # model probability that the window settles YES
    move_3m_pct: Optional[float] = None

    @property
    def t_left(self) -> float:
        return self.close_ts - self.now

    def ask(self, side: str) -> Optional[Decimal]:
        if side == "yes":
            return self.yes_ask
        return (ONE - self.yes_bid) if self.yes_bid is not None else None

    def ask_size(self, side: str) -> float:
        return self.yes_ask_size if side == "yes" else self.yes_bid_size


def taker_fee(price: Decimal) -> Decimal:
    return fee_estimate(ONE, price)          # rounded up to the cent: conservative


@dataclass
class Candidate:
    cid: str
    family: str
    asset: str
    params: Dict[str, Any]
    needs_reference: bool                    # True = relies on the settlement index (crypto only)
    description: str = ""

    def signal(self, w: WindowView) -> Optional[str]:
        return FAMILIES[self.family](self.params, w)


# ------------------------------------------------------------------ rule families
def _in(t_left: float, rng) -> bool:
    return rng[1] <= t_left <= rng[0]


def _edge_side(w: WindowView, min_edge: float, fav_only: bool) -> Optional[str]:
    if w.p_up is None:
        return None
    best, best_edge = None, None
    for side, p in (("yes", w.p_up), ("no", 1 - w.p_up)):
        a = w.ask(side)
        if a is None or w.ask_size(side) < 1 or not (Decimal("0.01") <= a <= Decimal("0.98")):
            continue
        if fav_only and p < 0.5:
            continue
        edge = p - float(a) - float(taker_fee(a))
        if edge >= min_edge and (best_edge is None or edge > best_edge):
            best, best_edge = side, edge
    return best


def f_lock(p, w):        # final-minute "locked share" of the 60-s average (crypto)
    return _edge_side(w, p["edge"], True) if w.t_left <= p["last_s"] and w.t_left >= 3 else None


def f_fair(p, w):        # mid-window fair value vs ask (crypto)
    return _edge_side(w, p["edge"], False) if _in(w.t_left, p["window"]) else None


def f_momentum(p, w):    # 3-minute index move, take the side it moved toward if cheap (crypto)
    if not _in(w.t_left, p["window"]) or w.move_3m_pct is None or abs(w.move_3m_pct) < p["move"]:
        return None
    side = "yes" if w.move_3m_pct > 0 else "no"
    a = w.ask(side)
    if a is None or w.ask_size(side) < 1 or a + taker_fee(a) > Decimal(str(p["cap"])):
        return None
    return side


def f_favorite(p, w):    # favourite–longshot: buy the favourite inside a price band late
    if not _in(w.t_left, p["window"]):
        return None
    lo, hi = Decimal(str(p["band"][0])), Decimal(str(p["band"][1]))
    for side in ("yes", "no"):
        a = w.ask(side)
        if a is not None and lo <= a <= hi and w.ask_size(side) >= 1:
            return side
    return None


def f_imbalance(p, w):   # one-sided top of book: follow the heavier bid
    if not _in(w.t_left, p["window"]) or w.yes_bid_size <= 0 or w.yes_ask_size <= 0:
        return None
    r = w.yes_bid_size / w.yes_ask_size
    side = "yes" if r >= p["ratio"] else ("no" if 1 / r >= p["ratio"] else None)
    if side is None:
        return None
    a = w.ask(side)
    return side if (a is not None and a <= Decimal(str(p["cap"])) and w.ask_size(side) >= 1) else None


def f_kmomentum(p, w):   # Kalshi price momentum (no index needed)
    if not _in(w.t_left, p["window"]) or w.mid_change_120s is None or abs(w.mid_change_120s) < p["move"]:
        return None
    side = "yes" if w.mid_change_120s > 0 else "no"
    a = w.ask(side)
    return side if (a is not None and a <= Decimal(str(p["cap"])) and w.ask_size(side) >= 1) else None


FAMILIES = {"lock": f_lock, "fair": f_fair, "momentum": f_momentum, "favorite": f_favorite,
            "imbalance": f_imbalance, "kmomentum": f_kmomentum,
            "favmid": f_favorite}          # owner idea 2026-11-19: the favourite at 70-90% with 2-7 minutes left

GRID: Dict[str, Dict[str, List[Any]]] = {
    "lock": {"last_s": [45, 30, 15], "edge": [0.01, 0.02, 0.04]},
    "fair": {"window": [(600, 300), (300, 120)], "edge": [0.02, 0.04, 0.06]},
    "momentum": {"window": [(300, 120), (120, 60)], "move": [0.02, 0.036, 0.06], "cap": [0.55, 0.65]},
    "favorite": {"window": [(120, 60), (60, 10)], "band": [(0.80, 0.89), (0.90, 0.94), (0.95, 0.98)]},
    "imbalance": {"window": [(600, 60)], "ratio": [3, 5], "cap": [0.60, 0.75]},
    "kmomentum": {"window": [(480, 120)], "move": [0.10, 0.20], "cap": [0.70]},
    "favmid": {"window": [(420, 120)], "band": [(0.70, 0.90)]},
}
# Families the bots may not trade until the lab has shown them profitable at REAL-exchange prices
# (REAL_MIN_N results, positive average). Owner, 2026-11-19: "test it" before it trades.
LAB_FIRST = {"favmid"}
NEEDS_REFERENCE = {"lock", "fair", "momentum"}
DESCRIPTIONS = {
    "lock": "Final seconds: buy the favourite when the part of the 60-s average already fixed makes it underpriced after fees",
    "fair": "Mid-window: buy whichever side the volatility model prices above the ask plus fee",
    "momentum": "Index moved over the last 3 minutes: buy the side it moved toward if still cheap",
    "favorite": "Favourite–longshot bias: buy the favourite inside a price band late in the window",
    "imbalance": "Top of book heavily one-sided: follow the heavier bid",
    "kmomentum": "Kalshi price moved over the last 2 minutes: follow it if still cheap",
    "favmid": "Owner idea: buy the favourite priced 70-90% with 2-7 minutes left (tested before it may trade)",
}


def _fmt(v):
    return f"{v[0]}-{v[1]}" if isinstance(v, (tuple, list)) else str(v)


def build(assets_by_class: Dict[str, List[str]]) -> List[Candidate]:
    """All candidates for the focus assets. Reference-dependent families only for crypto."""
    out: List[Candidate] = []
    for fam, grid in GRID.items():
        keys = list(grid)
        for combo in itertools.product(*(grid[k] for k in keys)):
            params = dict(zip(keys, combo))
            for cls, assets in assets_by_class.items():
                if fam in NEEDS_REFERENCE and cls != "crypto":
                    continue
                for a in assets:
                    cid = f"{fam}:{a}:" + ",".join(f"{k}={_fmt(params[k])}" for k in keys)
                    out.append(Candidate(cid, fam, a, params, fam in NEEDS_REFERENCE, DESCRIPTIONS[fam]))
    return out
