"""Real-money trading (owner decision 2026-11-19, CLAUDE.md rule 21).

RealTrader = the demo trader's tested order management (validation, fat-finger and freshness checks,
single submission, reconciliation, emergency stop) on the real account, plus the owner's hard limits:

  * every trade costs at least MIN_TRADE ($1)                         (owner, 2026-11-19)
  * one trade costs at most PER_TRADE_MAX (10%) of the account value   (owner, 2026-11-19)
  * no daily spending limit (PER_DAY_MAX = None)                      (owner, 2026-11-19: first 30%, then
    removed the same day: "get rid of the 30% limit, no limit")
  * no daily loss stop                                                  (owner, 2026-11-19)

These limits are module constants. Nothing in the app, the bot or the research code can change them;
only a human editing this file can.

Prices: real orders are checked and priced against the REAL exchange's quotes (RealContext.fresh_book),
never the demo order book. RealBot trades the same rules as the demo bot's practice mode (owner choice
2026-11-19), judged on their record at real prices. It is off at every start and after any emergency
stop, and turning it on needs the owner to type ARM_PHRASE.

Credentials: a separate file the owner creates (REAL_ENV_FILE, mode 0600, outside the repository):
    KALSHI_REAL_API_KEY_ID=<key id>
    KALSHI_REAL_PRIVATE_KEY_PATH=/root/.config/aicrypto/kalshi_real.pem   (mode 0600)
The demo key and its environment variables are not touched. Key material is never logged or returned.
"""
from __future__ import annotations

import os
import stat
import time
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo

from ..demo_exec.ledger import DemoLedger
from ..demo_exec.trader import DemoTrader, Intent, OrderRefused, _d

MIN_TRADE = Decimal("1.00")
PER_TRADE_MAX = Decimal("0.10")
PER_DAY_MAX: Optional[Decimal] = None        # no daily spending limit (owner, 2026-11-19); a Decimal re-enables it
ARM_PHRASE = "REAL MONEY"
# Automatic cash-out (owner request 2026-11-19: "if a position looks like we are going to lose for sure, cash out").
# A position is sold when its side's best bid is at or under CASHOUT_PCT_DEFAULT % (owner-adjustable, 0 = off) AND
# under half of what was paid per contract (so deliberately cheap long-shot buys aren't sold straight away), and the
# sale would bring back at least CASHOUT_MIN_PROCEEDS.
CASHOUT_PCT_DEFAULT = 10.0
CASHOUT_PCT_MAX = 50.0
CASHOUT_MIN_PROCEEDS = Decimal("0.10")
CASHOUT_AUTO_SLIPPAGE = Decimal("0.02")        # automatic sells go no lower than 2c under the best bid
CASHOUT_RETRY_S = 20.0
REAL_ENV_FILE = Path(os.path.expanduser("~/.config/aicrypto/kalshi_real.env"))
REAL_QUOTE_MAX_AGE_S = 8.0
ET = ZoneInfo("America/New_York")


# ---------------------------------------------------------------------------- credentials
def load_real_credentials(env_file: Path = REAL_ENV_FILE, repo_root: Optional[Path] = None):
    """Production credentials from the owner's real-account file, or None if it is absent.
    Raises CredentialError for an unsafe or malformed setup (reported in the app, never the key)."""
    from ..auth import CredentialError, Credentials
    p = Path(env_file)
    if not p.exists():
        return None
    if stat.S_IMODE(p.stat().st_mode) & 0o077:
        raise CredentialError("the real-account settings file must be mode 0600")
    vals: Dict[str, str] = {}
    for line in p.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            vals[k.strip()] = v.strip().strip('"').strip("'")
    environ = {"KALSHI_ENV": "production", "KALSHI_API_KEY_ID": vals.get("KALSHI_REAL_API_KEY_ID", ""),
               "KALSHI_PRIVATE_KEY_PATH": vals.get("KALSHI_REAL_PRIVATE_KEY_PATH", "")}
    return Credentials.from_env("production", repo_root=repo_root, environ=environ)


def real_exchange_factory(repo_root: Optional[Path] = None, env_file: Path = REAL_ENV_FILE):
    def make():
        from .exchange import RealExchange
        creds = load_real_credentials(env_file, repo_root)
        return RealExchange.from_credentials(creds) if creds is not None else None
    return make


# ---------------------------------------------------------------------------- market context
class RealContext:
    """The app's market metadata (same tickers on both exchanges) with REAL-exchange quotes."""

    def __init__(self, svc, quotes_fn, shard_fn=None):
        self.svc = svc
        self.quotes_fn = quotes_fn          # -> {ticker: (monotonic_t, yes_bid_p4, yes_ask_p4, bid_size, ask_size, strike)}
        self.shard_fn = shard_fn            # async ticker -> exchange_index on the REAL exchange
        self.pnl_today = None

    def market_access(self, ticker: str):
        return self.svc.market_access(ticker)

    def market(self, ticker: str):
        return self.svc.market(ticker)

    def series_for(self, ticker: str):
        return self.svc.series_for(ticker)

    def now_fn(self):
        return self.svc.now_fn()

    async def market_shard(self, ticker: str):
        """The REAL exchange's shard for this market. Never the demo registry's: the two exchanges number
        them differently (2026-11-19: a natural-gas market was shard 0 on demo, 2 on the real exchange)."""
        return await self.shard_fn(ticker) if self.shard_fn is not None else None

    async def fresh_book(self, ticker: str) -> Dict[str, Any]:
        q = (self.quotes_fn() or {}).get(ticker)
        if q is None:
            return {"valid": False, "source": "real", "error": "no real-exchange quote"}
        age = time.monotonic() - q[0]
        if age > REAL_QUOTE_MAX_AGE_S or (q[1] is None and q[2] is None):
            return {"valid": False, "source": "real", "age_s": age, "error": "stale real-exchange quote"}
        return {"valid": True, "source": "real", "age_s": age, "best_yes_bid": q[1], "best_yes_ask": q[2]}


# ---------------------------------------------------------------------------- limits
def day_key(t: float) -> str:
    return datetime.fromtimestamp(t, ET).strftime("%Y-%m-%d")


def day_start_ts(t: float) -> float:
    d = datetime.fromtimestamp(t, ET)
    return d.replace(hour=0, minute=0, second=0, microsecond=0).timestamp()


def limit_errors(*, cost: Decimal, max_loss: Decimal, equity: Decimal, day_equity: Decimal, spent_today: Decimal) -> List[str]:
    """The owner's real-money limits. Pure; amounts in dollars."""
    e: List[str] = []
    if cost < MIN_TRADE:
        e.append(f"A real trade must cost at least ${MIN_TRADE:.2f} (this one ${cost:.2f}).")
    if equity <= 0:
        e.append("Real account value is unknown or zero.")
    elif cost > equity * PER_TRADE_MAX:
        e.append(f"This trade costs ${cost:.2f}, over the {PER_TRADE_MAX:.0%} per-trade limit (${equity * PER_TRADE_MAX:.2f}).")
    if PER_DAY_MAX is not None and day_equity > 0 and spent_today + max_loss > day_equity * PER_DAY_MAX:
        e.append(f"Daily limit: ${spent_today:.2f} of ${day_equity * PER_DAY_MAX:.2f} ({PER_DAY_MAX:.0%} of the account at the start "
                 f"of the day) already spent; this trade (${max_loss:.2f} with fees) would go over. New trades resume tomorrow.")
    return e


class RealTrader(DemoTrader):
    def __init__(self, ks, ledger: DemoLedger, ctx: RealContext, exchange_factory, clock=time.time):
        super().__init__(ks, ledger, ctx, exchange_factory, clock)

    def exchange(self):
        if self.ex is None:
            try:
                self.ex = self.exchange_factory()
            except Exception as e:                    # unsafe file, bad key, wrong env: reported, never the key itself
                self.state, self.last_error = "error", f"{type(e).__name__}: {e}"
                return None
            if self.ex is None:
                self.state = "no_credentials"
        return self.ex

    def budget(self) -> Optional[Decimal]:
        return None                                   # the owner's limits below replace the demo budget

    def equity(self) -> Decimal:
        return _d(self.account.get("balance") or "0") + _d(self.account.get("portfolio_value") or "0")

    def day_equity(self) -> Decimal:
        """Account value when the US-Eastern day's first check ran (the base for the 30% daily limit)."""
        today = day_key(self.clock())
        if self.ledger.get("day_key") != today and self.equity() > 0:
            self.ledger.put("day_key", today)
            self.ledger.put("day_equity", str(self.equity()))
            self.ledger.event("limits", f"new day: account value ${self.equity():.2f}, daily limit "
                                          + (f"${self.equity() * PER_DAY_MAX:.2f}" if PER_DAY_MAX is not None else "none"))
        return _d(self.ledger.get("day_equity", "0")) if self.ledger.get("day_key") == today else Decimal(0)

    def spent_today(self) -> Decimal:
        """Money put into buy orders since US-Eastern midnight, fees included: open orders count in full,
        canceled ones only for what filled, rejected/failed ones not at all."""
        start = day_start_ts(self.clock())
        tot = Decimal(0)
        for o in self.ledger.orders(limit=2000):
            if (o["created_at"] or 0) < start or (o["action"] or "buy") != "buy":
                continue
            ml = _d(o["max_loss"])
            if o["state"] in ("REJECTED", "FAILED"):
                continue
            if o["state"] == "CANCELED":
                ml = ml * Decimal(o["filled_c2"] or 0) / Decimal(o["count_c2"] or 1)
            tot += ml
        return tot

    async def validate(self, it: Intent, *, automated: bool, feed_free: bool = False) -> Dict[str, Any]:
        v = await super().validate(it, automated=automated, feed_free=feed_free)
        v["errors"] = [e.replace("demo account", "REAL account").replace("demo cash", "real cash").replace("demo balance", "real balance")
                       for e in v["errors"]]
        v["errors"] += limit_errors(cost=v["cost"], max_loss=v["max_loss"], equity=self.equity(), day_equity=self.day_equity(),
                                    spent_today=self.spent_today())
        return v

    async def ensure_shard_funds(self, ticker: str, need: Decimal) -> None:
        """Move the account's own cash to the market's shard first. If the REAL shard can't be confirmed, refuse
        rather than guess (a wrong guess moves the cash away from where the order needs it)."""
        if self.exchange() is not None and self.shards and await self.ctx.market_shard(ticker) is None:
            raise OrderRefused(["Couldn't confirm which part of the real exchange this market trades on; order not sent."])
        await super().ensure_shard_funds(ticker, need)

    # ------------------------------------------------------------------ automatic cash-out
    def cashout_pct(self) -> float:
        v = self.ledger.get("real_cashout_pct")
        try:
            return min(CASHOUT_PCT_MAX, max(0.0, float(v))) if v is not None else CASHOUT_PCT_DEFAULT
        except (TypeError, ValueError):
            return CASHOUT_PCT_DEFAULT

    def set_cashout_pct(self, pct: float) -> None:
        pct = min(CASHOUT_PCT_MAX, max(0.0, float(pct)))
        self.ledger.put("real_cashout_pct", str(pct))
        self.ledger.event("bot", "automatic cash-out " + (f"when a position's chance drops to {pct:g}% or less" if pct > 0 else "off"))

    def cashout_decision(self, pos: Dict[str, Any], bid: Optional[Decimal]) -> Optional[str]:
        """Why this position should be cashed out now, or None. Pure apart from the setting."""
        pct = self.cashout_pct()
        if pct <= 0 or bid is None:
            return None
        n = _d(pos["contracts"])
        if n < 1:
            return None
        paid = _d(pos["exposure"]).copy_abs() / n
        if bid * 100 > Decimal(str(pct)) or bid * 2 > paid or bid * int(n) < CASHOUT_MIN_PROCEEDS:
            return None
        return f"chance fell to {bid * 100:.0f}% (paid {paid * 100:.0f}%)"

    async def auto_cashout(self) -> List[Dict[str, Any]]:
        """Sell positions that look lost (see cashout_decision). Runs from the service's real-account loop."""
        if self.exchange() is None or self.cashout_pct() <= 0:
            return []
        if not hasattr(self, "_cashout_tried"):
            self._cashout_tried: Dict[str, float] = {}
        now, done = time.monotonic(), []
        for pos in list(self.account.get("positions", [])):
            t = pos["ticker"]
            if now - self._cashout_tried.get(t, -1e9) < CASHOUT_RETRY_S:
                continue
            book = await self.ctx.fresh_book(t)
            if not book.get("valid"):
                continue
            bid_p4 = book.get("best_yes_bid") if pos["side"] == "yes" else (10000 - book["best_yes_ask"] if book.get("best_yes_ask") else None)
            bid = Decimal(bid_p4) / 10000 if bid_p4 else None
            why = self.cashout_decision(pos, bid)
            if why is None:
                continue
            self._cashout_tried[t] = now
            self.ledger.event("cashout", f"automatic cash-out of {pos['side'].upper()} {t}: {why}", origin="auto-cashout")
            try:
                done.append(await self.cashout(t, origin="auto", slippage=CASHOUT_AUTO_SLIPPAGE))
            except OrderRefused as e:
                self.ledger.event("refused", "automatic cash-out not done: " + "; ".join(e.errors)[:300], origin="auto-cashout")
            except Exception as e:  # never let one market stop the loop
                self.ledger.event("refused", f"automatic cash-out failed: {type(e).__name__}: {e}"[:300], origin="auto-cashout")
        return done

    async def prepare(self, it: Intent) -> Dict[str, Any]:
        raise OrderRefused(["Manual real-money orders are not available; only the real bot trades the real account."])

    def limits_status(self) -> Dict[str, Any]:
        eq, de, sp = self.equity(), self.day_equity(), self.spent_today()
        lim = de * PER_DAY_MAX if PER_DAY_MAX is not None else None
        return {"min_trade": str(MIN_TRADE), "per_trade_pct": float(PER_TRADE_MAX * 100),
                "per_day_pct": float(PER_DAY_MAX * 100) if PER_DAY_MAX is not None else None,
                "daily_loss_stop": None, "account_value": f"{eq:.2f}", "day_start_value": f"{de:.2f}",
                "spent_today": f"{sp:.2f}", "daily_limit": f"{lim:.2f}" if lim is not None else None,
                "left_today": f"{max(Decimal(0), lim - sp):.2f}" if lim is not None else None}


# ---------------------------------------------------------------------------- bot
def make_real_bot(trader: RealTrader, clock=time.time):
    from ..lab.engine import Bot

    class RealBot(Bot):
        """The real-money bot. Same rules as demo practice mode, judged at real prices. Off at every start
        and after any emergency stop; turning it on needs ARM_PHRASE."""
        real = True

        def __init__(self, tr, clk):
            super().__init__(tr, clk)
            self.settings.practice = True             # owner choice 2026-11-19: same rules as demo practice

        def configure(self, practice: Optional[bool] = None, stake_pct: Optional[float] = None) -> None:
            super().configure(practice=None, stake_pct=stake_pct)

        def turn_on(self, phrase: str = "") -> None:
            errs = []
            if (phrase or "").strip().upper() != ARM_PHRASE:
                errs.append(f'Type {ARM_PHRASE} to turn on real-money trading.')
            if self.trader.state != "connected":
                errs.append("Not connected to the REAL Kalshi account." + (f" ({self.trader.last_error})" if self.trader.last_error else ""))
            if self.trader.kill_on():
                errs.append("Real emergency stop is on. Reset it first.")
            if errs:
                raise OrderRefused(errs)
            self.on = True
            self.trader.ledger.event("bot", f"REAL-MONEY BOT ON (stake {self.settings.stake_pct}% per trade, "
                                            f"max {PER_TRADE_MAX:.0%} per trade, "
                                            f"{'no daily limit' if PER_DAY_MAX is None else f'{PER_DAY_MAX:.0%} per day'})")

        def turn_off(self, why: str = "user") -> None:
            if self.on:
                self.trader.ledger.event("bot", f"REAL-MONEY BOT OFF ({why})")
            self.on = False

    return RealBot(trader, clock)
