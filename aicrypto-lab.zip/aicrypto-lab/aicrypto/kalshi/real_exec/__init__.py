"""Real-money execution (owner decision 2026-11-19, CLAUDE.md rule 21)."""
