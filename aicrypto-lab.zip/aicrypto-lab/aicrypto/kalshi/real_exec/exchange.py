"""Kalshi REAL-MONEY exchange client (owner decision 2026-11-19, see CLAUDE.md rule 21).

Same request surface as the demo client (aicrypto/kalshi/demo_exec/exchange.py), reusing its allowlist,
order translation and response handling, but pinned to Kalshi's production trading host:
  * The base URL is a module constant (auth.HOSTS["production"]); no parameter, setting or environment
    variable changes it. Redirects are refused.
  * Only production credentials loaded from the owner's separate real-account file are accepted.
  * Allowlist (unchanged from demo): balance, positions, orders (list/get; V2 create/cancel), moving the
    account's OWN event-contract cash between its exchange shards, fills. No withdrawals, deposits,
    transfers to anyone, API-key, subaccount, margin, batch, amend or RFQ endpoints.
  * Order creation is never retried automatically (UncertainOutcome -> reconcile first).
Nothing here logs or returns key material, headers or signatures.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, Dict, Optional
from urllib.parse import urlsplit

import httpx

from ..auth import API_PREFIX, HOSTS, Credentials, KalshiSigner
from ..demo_exec.exchange import DemoExchange, DemoOnlyViolation, ExchangeError, UncertainOutcome, check_demo_request

REAL_BASE = HOSTS["production"]["rest"]
REAL_HOST = urlsplit(REAL_BASE).hostname


class RealExchangeViolation(DemoOnlyViolation):
    """Anything that is not an allowlisted request to the production trading host."""


def _assert_real_url(url: str) -> None:
    host = (urlsplit(url).hostname or "").lower()
    if host != REAL_HOST:
        raise RealExchangeViolation(f"refusing host {host!r}")


class RealExchange(DemoExchange):
    def __init__(self, signer: KalshiSigner, *, http_transport: Optional[httpx.AsyncBaseTransport] = None,
                 timeout_s: float = 8.0, _credentials_env: str = "production"):
        if _credentials_env != "production":
            raise RealExchangeViolation("real-money execution requires the real account's credentials")
        if signer is None:
            raise RealExchangeViolation("a signer is required")
        _assert_real_url(REAL_BASE)
        self._signer = signer
        self._client = httpx.AsyncClient(base_url=REAL_BASE, timeout=timeout_s, transport=http_transport,
                                         headers={"User-Agent": "aicrypto-lab-real/0.1", "Accept": "application/json"},
                                         follow_redirects=False)
        self.calls: list = []

    @classmethod
    def from_credentials(cls, creds: Credentials, **kw) -> "RealExchange":
        if creds.env != "production":
            raise RealExchangeViolation(f"refusing {creds.env!r} credentials for the real account")
        return cls(KalshiSigner.from_credentials(creds), _credentials_env=creds.env, **kw)

    async def _request(self, method: str, path: str, *, params: Optional[Dict[str, Any]] = None,
                       body: Optional[Dict[str, Any]] = None, retry_get: int = 1) -> Dict[str, Any]:
        path = check_demo_request(method, path)          # the same allowlist as demo
        _assert_real_url(REAL_BASE + path)
        query = {k: v for k, v in (params or {}).items() if v is not None}
        attempt = 0
        while True:
            headers = self._signer.headers(method.upper(), API_PREFIX + path)
            if body is not None:
                headers["Content-Type"] = "application/json"
            self.calls.append((method.upper(), path))
            try:
                resp = await self._client.request(method.upper(), path, params=query or None,
                                                  content=json.dumps(body) if body is not None else None, headers=headers)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                if method.upper() == "GET" and attempt < retry_get:
                    attempt += 1
                    await asyncio.sleep(0.5)
                    continue
                if method.upper() == "GET":
                    raise ExchangeError(0, f"network error ({type(exc).__name__})")
                raise UncertainOutcome(f"{method} {path}: {type(exc).__name__}") from None
            if resp.is_redirect:
                raise RealExchangeViolation("redirects are not followed")
            if resp.status_code >= 500:
                if method.upper() == "GET" and attempt < retry_get:
                    attempt += 1
                    await asyncio.sleep(0.5)
                    continue
                if method.upper() != "GET":
                    raise UncertainOutcome(f"{method} {path}: HTTP {resp.status_code}")
            if resp.status_code >= 400:
                try:
                    j = resp.json()
                except ValueError:
                    j = {}
                err = j.get("error") if isinstance(j, dict) else None
                msg = (err.get("message") if isinstance(err, dict) else None) or (err if isinstance(err, str) else None) or resp.text[:200]
                raise ExchangeError(resp.status_code, msg or "request failed", j)
            if resp.status_code == 204 or not resp.content:
                return {}
            try:
                return resp.json()
            except ValueError:
                if method.upper() == "GET":
                    raise ExchangeError(resp.status_code, "invalid JSON")
                raise UncertainOutcome(f"{method} {path}: unreadable response")
