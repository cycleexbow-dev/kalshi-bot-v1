"""Token-bucket rate limiter matching Kalshi's model (tokens/s budget, burst = N seconds).
Default: 10 tokens per request; Basic tier 200 read tokens/s => 20 req/s. We run far below
that by default (configurable) and leave headroom for the WebSocket control commands."""
from __future__ import annotations

import asyncio
import time


class TokenBucket:
    def __init__(self, tokens_per_second: float, burst_seconds: float = 1.0, cost_per_request: float = 10.0):
        self.rate = float(tokens_per_second)
        self.capacity = self.rate * burst_seconds
        self.cost = float(cost_per_request)
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self.waits = 0
        self.total_wait_s = 0.0

    def _refill(self) -> None:
        now = time.monotonic()
        self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
        self.updated = now

    def try_acquire(self) -> float:
        """Consume if possible; return 0.0, else the seconds to wait."""
        self._refill()
        if self.tokens >= self.cost:
            self.tokens -= self.cost
            return 0.0
        return (self.cost - self.tokens) / self.rate

    async def acquire(self) -> None:
        while True:
            wait = self.try_acquire()
            if wait <= 0:
                return
            self.waits += 1
            self.total_wait_s += wait
            await asyncio.sleep(wait)

    def acquire_blocking(self) -> None:
        while True:
            wait = self.try_acquire()
            if wait <= 0:
                return
            self.waits += 1
            self.total_wait_s += wait
            time.sleep(wait)
