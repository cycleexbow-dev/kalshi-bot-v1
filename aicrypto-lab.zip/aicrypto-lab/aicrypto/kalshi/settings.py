"""Typed Kalshi settings loaded from config/kalshi.yaml (independent of research.yaml)."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Literal, Optional

import yaml
from pydantic import BaseModel, Field, field_validator

from ..settings import PROJECT_ROOT

DEFAULT_KALSHI_CONFIG = PROJECT_ROOT / "config" / "kalshi.yaml"


class KalshiCapital(BaseModel):
    starting_balance: float = 700.0
    currency: str = "USD"


class KalshiRisk(BaseModel):
    max_loss_per_position: float = 0.01
    max_aggregate_planned_loss: float = 0.05
    daily_realized_loss_stop: float = 0.03
    leverage: float = 1.0
    allow_risk_budget_increase: bool = False

    @field_validator("leverage")
    @classmethod
    def _no_leverage(cls, v: float) -> float:
        if v != 1.0:
            raise ValueError("leverage must be exactly 1.0 (no leverage, no borrowing)")
        return v

    @field_validator("max_loss_per_position", "max_aggregate_planned_loss", "daily_realized_loss_stop")
    @classmethod
    def _sane(cls, v: float) -> float:
        if not 0 < v <= 0.10:
            raise ValueError("risk fractions must be in (0, 0.10]")
        return v


class Subscriptions(BaseModel):
    max_orderbooks: int = Field(default=24, ge=1, le=200)
    ticker_all_markets: bool = True
    rotation_seconds: int = 60
    min_rank_improvement_to_swap: float = 0.15


class FeedToggle(BaseModel):
    enabled: bool = False


class CfBenchmarksFeed(FeedToggle):
    channel: str = "cfbenchmarks_value_5hz"
    fallback_channel: str = "cfbenchmarks_value"


class PythFeed(FeedToggle):
    kalshi_relay_channel: str = "pyth_value"
    alternative_candidates: List[Dict[str, str]] = []


class ReferenceFeeds(BaseModel):
    cfbenchmarks: CfBenchmarksFeed = CfBenchmarksFeed(enabled=True)
    exchange_spot: Dict[str, FeedToggle] = {"coinbase": FeedToggle(enabled=True), "kraken": FeedToggle(enabled=True)}
    pyth: PythFeed = PythFeed(enabled=False)
    staleness_seconds: Dict[str, float] = {"cfbenchmarks": 3, "exchange_spot": 5, "pyth": 10}
    max_jump_fraction: float = 0.05


class EligibilityRules(BaseModel):
    allowed_categories: List[str]
    denied_categories: List[str]
    denied_tags: List[str]
    allowed_assets: Dict[str, List[str]]
    ticker_aliases: Dict[str, str] = {}
    allowed_strike_types: List[str]
    allowed_market_types: List[str] = ["binary"]
    require_settlement_source: bool = True
    require_rules_template_match: bool = True

    def asset_class_of(self, asset: str) -> Optional[str]:
        for cls, names in self.allowed_assets.items():
            if asset.upper() in names:
                return cls
        return None

    def asset_from_ticker(self, series_ticker: str) -> str:
        """Longest-prefix match of the series ticker (after 'KX') against allowlisted assets and
        aliases. Used only when the settlement reference does not identify the asset."""
        t = series_ticker.upper()
        t = t[2:] if t.startswith("KX") else t
        names = {a: a for v in self.allowed_assets.values() for a in v}
        names.update({k.upper(): v for k, v in self.ticker_aliases.items()})
        best = ""
        for prefix in names:
            if t.startswith(prefix) and len(prefix) > len(best):
                best = prefix
        return names.get(best, "")


class Recorder(BaseModel):
    dir: str = "user_data/kalshi/recordings"
    segment_minutes: int = 15
    queue_max_events: int = 50000
    retain_days_raw: int = 30


class KalshiPaths(BaseModel):
    registry_db: str = "user_data/kalshi/registry.sqlite"
    ledger_db: str = "user_data/kalshi/paper_ledger.sqlite"


class KalshiSettings(BaseModel):
    paper_only: Literal[True]                    # the only accepted value
    environment: Literal["demo", "production"] = "demo"
    capital: KalshiCapital = KalshiCapital()
    risk: KalshiRisk = KalshiRisk()
    subscriptions: Subscriptions = Subscriptions()
    reference_feeds: ReferenceFeeds = ReferenceFeeds()
    eligibility: EligibilityRules
    recorder: Recorder = Recorder()
    paths: KalshiPaths = KalshiPaths()
    root: Path = PROJECT_ROOT

    def path(self, name: str) -> Path:
        return (self.root / getattr(self.paths, name)).resolve()


def load_kalshi_settings(path: Path | str | None = None, root: Path | None = None) -> KalshiSettings:
    p = Path(path) if path else DEFAULT_KALSHI_CONFIG
    with open(p, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    s = KalshiSettings(**data)
    if root is not None:
        s.root = Path(root)
    return s
