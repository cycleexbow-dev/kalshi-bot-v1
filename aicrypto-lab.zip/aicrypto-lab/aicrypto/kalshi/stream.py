"""Read-only market-data streaming session (Phase 3 scope).

Wires the WebSocket client to the registry:
  * ticker (all markets)      -> liquidity stats for ranking
  * market_lifecycle_v2       -> registry lifecycle updates; unknown tickers -> REST reconcile
  * cfbenchmarks_value(_5hz)  -> reference-value counters (full feed handling is Phase 4)
  * orderbook_delta           -> ≤ max_orderbooks TRADEABLE markets, rotated by rank

It also writes every raw frame (with receive timestamp) to a gzip JSONL file so Phase 6's
recorder/replay has real data to start from. No strategy logic, no paper execution.
"""
from __future__ import annotations

import asyncio
import gzip
import logging
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .client import KalshiRestClient
from .discovery import reconcile
from .models import dollars_to_p4, fp_to_c2
from .registry import MarketRegistry
from .settings import KalshiSettings
from .settlement_map import CF_5HZ_ASSETS, CF_INDEX_BY_ASSET
from .websocket import InboundMessage, KalshiWebSocket, Subscription

log = logging.getLogger("aicrypto.kalshi.stream")


@dataclass
class StreamStats:
    ticker_updates: int = 0
    lifecycle_events: int = 0
    cf_values: int = 0
    book_messages: int = 0
    reconciled: int = 0
    rotations: int = 0
    frames_recorded: int = 0
    by_index: Dict[str, int] = field(default_factory=dict)


class StreamSession:
    def __init__(self, settings: KalshiSettings, reg: MarketRegistry, ws: KalshiWebSocket, rest: Optional[KalshiRestClient] = None,
                 record_dir: Optional[Path] = None):
        self.s = settings
        self.reg = reg
        self.ws = ws
        self.rest = rest
        self.stats = StreamStats()
        self.book_sub: Optional[Subscription] = None
        self._rec = None
        if record_dir is not None:
            record_dir.mkdir(parents=True, exist_ok=True)
            self._rec = gzip.open(record_dir / f"kalshi-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}.jsonl.gz", "at")
        ws.handlers.append(self._on_message)

    # ---- subscriptions ----------------------------------------------------------------------
    async def start(self) -> None:
        if self.s.subscriptions.ticker_all_markets:
            await self.ws.subscribe(["ticker"])
        await self.ws.subscribe(["market_lifecycle_v2"])
        if self.s.reference_feeds.cfbenchmarks.enabled:
            assets = {d.asset for d in self.reg.decisions.values() if d.asset_class == "crypto"} or {"BTC", "ETH", "SOL"}
            fast = sorted(CF_INDEX_BY_ASSET[a] for a in assets if a in CF_5HZ_ASSETS)
            slow = sorted(CF_INDEX_BY_ASSET[a] for a in assets if a in CF_INDEX_BY_ASSET and a not in CF_5HZ_ASSETS)
            if fast:
                await self.ws.subscribe([self.s.reference_feeds.cfbenchmarks.channel], index_ids=fast)
            if slow:
                await self.ws.subscribe([self.s.reference_feeds.cfbenchmarks.fallback_channel], index_ids=slow)
        subs, _, _ = self.reg.schedule_subscriptions()
        if subs:
            self.book_sub = await self.ws.subscribe(["orderbook_delta"], market_tickers=subs)

    async def rotate(self) -> None:
        """Apply the registry's bounded subscription schedule to the live book subscription."""
        subs, add, rem = self.reg.schedule_subscriptions()
        if self.book_sub is None:
            if subs:
                self.book_sub = await self.ws.subscribe(["orderbook_delta"], market_tickers=subs)
            return
        if add or rem:
            await self.ws.update_markets(self.book_sub, add=add, delete=rem)
            self.stats.rotations += 1

    def status_line(self, elapsed: float) -> str:
        st, w = self.stats, self.ws.stats
        live = len(self.book_sub.market_tickers) if self.book_sub else 0
        return (f"[{elapsed:5.0f}s] frames {w.frames} · books live {live} (held {len(self.ws.books.books)}) · "
                f"cf {st.cf_values} · ticker {st.ticker_updates} · seq_gaps {w.seq_gaps} · reconnects {w.reconnects}")

    async def run(self, seconds: float, progress: Optional[Callable[[str], None]] = None, every_s: float = 15.0) -> None:
        task = asyncio.create_task(self.ws.run())
        try:
            await self.ws.wait_connected(timeout=20)
            if progress:
                progress("connected; subscribing")
            await self.start()
            t0 = time.monotonic()
            t_end = t0 + seconds
            next_rot = t0 + self.s.subscriptions.rotation_seconds
            next_msg = t0 + every_s
            while time.monotonic() < t_end:
                now = time.monotonic()
                await asyncio.sleep(max(0.05, min(next_rot, next_msg, t_end) - now))
                now = time.monotonic()
                if now >= next_rot and now < t_end:
                    await self.rotate()
                    next_rot = now + self.s.subscriptions.rotation_seconds
                if progress and now >= next_msg:
                    progress(self.status_line(now - t0))
                    next_msg = now + every_s
        finally:
            await self.ws.stop()
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
            if self._rec:
                self._rec.close()

    # ---- inbound -----------------------------------------------------------------------------
    def _reconcile_later(self, ticker: str) -> None:
        """Look up an unknown market in the background. Awaiting the REST call here stalled the
        socket reader for seconds; Kalshi's pings then went unanswered and the feed dropped
        ("keepalive ping timeout")."""
        pending = self.__dict__.setdefault("_reconciling", {})
        if ticker in pending:
            return

        async def run():
            try:
                self.stats.reconciled += await reconcile(self.rest, self.reg, [ticker])
            except Exception as exc:  # never let a lookup failure touch the feed
                log.warning("market lookup %s failed: %s", ticker, type(exc).__name__)
            finally:
                pending.pop(ticker, None)
        pending[ticker] = asyncio.create_task(run())

    async def _on_message(self, msg: InboundMessage) -> None:
        if self._rec is not None:
            self._rec.write(json.dumps({"t_recv_ns": msg.t_recv_ns, "t_wall": time.time(), "raw": msg.raw}) + "\n")
            self.stats.frames_recorded += 1
        t, d = msg.type, msg.data
        if t == "ticker":
            m = d["msg"]
            self.stats.ticker_updates += 1
            self.reg.update_liquidity(
                m["market_ticker"], yes_bid_p4=dollars_to_p4(m.get("yes_bid_dollars")), yes_ask_p4=dollars_to_p4(m.get("yes_ask_dollars")),
                bid_size_c2=fp_to_c2(m.get("yes_bid_size_fp")) or 0, ask_size_c2=fp_to_c2(m.get("yes_ask_size_fp")) or 0,
                volume_24h_c2=fp_to_c2(m.get("volume_fp")) or 0, open_interest_c2=fp_to_c2(m.get("open_interest_fp")) or 0,
                last_update_mono=time.monotonic())
        elif t == "market_lifecycle_v2":
            self.stats.lifecycle_events += 1
            res = self.reg.apply_lifecycle(d)
            if res is None and self.rest is not None:
                self._reconcile_later(d["msg"]["market_ticker"])
        elif t in ("cfbenchmarks_value", "cfbenchmarks_value_5hz"):
            self.stats.cf_values += 1
            idx = d["msg"].get("index_id", "?")
            self.stats.by_index[idx] = self.stats.by_index.get(idx, 0) + 1
        elif t in ("orderbook_snapshot", "orderbook_delta"):
            self.stats.book_messages += 1

    def summary(self) -> Dict:
        books = {t: b.snapshot_dict() for t, b in self.ws.books.books.items()}
        return {"stream": self.stats.__dict__, "ws": {k: v for k, v in self.ws.stats.__dict__.items() if k != "errors"},
                "ws_errors": self.ws.stats.errors[-10:],
                "live_book_subscriptions": len(self.book_sub.market_tickers) if self.book_sub else 0,
                "book_budget": self.s.subscriptions.max_orderbooks, "books_valid": sum(b["valid"] for b in books.values()),
                "books": books, "seq_gaps": self.ws.books.gaps, "registry": self.reg.summary()}
