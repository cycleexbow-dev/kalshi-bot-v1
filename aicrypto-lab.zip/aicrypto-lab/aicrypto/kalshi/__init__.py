"""Kalshi financial-markets research & paper-trading engine.

PAPER ONLY. This package contains no order placement, modification or cancellation
code, and its request allowlist (paths.py) rejects every write endpoint at runtime.
"""
