"""Settlement-reference mapping.

For every series we must know *exactly* what settles the contract: provider,
instrument, observation method, quote currency, and whether we have a validated live
feed for it. A contract whose reference we cannot map, or whose reference feed is not
enabled/validated, is never strategy-evaluated. It is still discovered and recorded,
with the reason preserved, so it can be reconsidered when valid data arrives.

Mappings are derived from (1) `series.settlement_sources[].name`, (2) the rules text
template, (3) the asset parsed from the series ticker — never from keywords alone, and
all three must agree or the mapping is UNMAPPED.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

from .durations import asset_from_series, cadence_from_series, DurationBucket
from .models import MarketInfo, SeriesInfo
from .settings import KalshiSettings


class Provider(str, Enum):
    CF_BENCHMARKS = "cf_benchmarks"
    PYTH = "pyth"
    ICE = "ice"
    UNSPECIFIED = "unspecified"   # source named only by example ("For example, Google Finance")
    US_TREASURY = "us_treasury"   # home.treasury.gov daily par yield curve
    UNKNOWN = "unknown"


class Method(str, Enum):
    AVG_60S_BEFORE_TIME = "avg_60s_before_time"          # crypto hourly/daily: mean of 60 one-second RTI prints
    WINDOW_COMPARE_AVG_60S = "window_compare_avg_60s"    # crypto 15M: avg(last min) vs avg(min before open)
    CANDLE_1M_CLOSE = "candle_1m_close"                  # Pyth commodities: close of the 1-minute candle at time T
    WINDOW_COMPARE_CANDLE_1M = "window_compare_candle_1m"
    DAILY_SETTLEMENT_PRICE = "daily_settlement_price"    # exchange official settlement (ICE/CME)
    VALUE_AT_TIME = "value_at_time"                      # published value at a stated time (Pyth yields, index levels)
    WINDOW_COMPARE_VALUE = "window_compare_value"        # value at end >= value at start (Pyth FX 15-min)
    ANY_DAY_TOUCH = "any_day_touch"                      # official daily value crosses a level on any business day in a period
    UNKNOWN = "unknown"


class ReferenceStatus(str, Enum):
    VALIDATED = "validated"            # mapped and a validated live feed is enabled
    FEED_UNAVAILABLE = "feed_unavailable"   # mapped, but no enabled feed (record-only; reconsider later)
    UNMAPPED = "unmapped"              # cannot determine the reference → reject


@dataclass(frozen=True)
class SettlementReference:
    provider: Provider
    instrument: str               # e.g. 'BRTI', 'ETHUSD_RTI', 'Metal.XAU/USD'
    method: Method
    quote_currency: str = "USD"
    price_type: str = "index"     # index | spot | settlement
    status: ReferenceStatus = ReferenceStatus.UNMAPPED
    feed_name: str = ""           # which configured feed would supply it
    notes: Tuple[str, ...] = field(default_factory=tuple)
    asset: str = ""               # canonical asset resolved from the settlement reference

    def to_dict(self) -> dict:
        return {"provider": self.provider.value, "instrument": self.instrument, "method": self.method.value,
                "quote_currency": self.quote_currency, "price_type": self.price_type, "status": self.status.value,
                "feed_name": self.feed_name, "notes": list(self.notes), "asset": self.asset}


# ---- knowledge tables (verified against Kalshi docs/help centre 2026-11-08) ----------

CF_INDEX_BY_ASSET: Dict[str, str] = {
    "BTC": "BRTI", "ETH": "ETHUSD_RTI", "SOL": "SOLUSD_RTI", "XRP": "XRPUSD_RTI", "DOGE": "DOGEUSD_RTI",
    "BNB": "BNBUSD_RTI", "ADA": "ADAUSD_RTI", "LTC": "LTCUSD_RTI", "LINK": "LINKUSD_RTI", "BCH": "BCHUSD_RTI",
    "DOT": "DOTUSD_RTI", "NEAR": "NEARUSD_RTI", "SUI": "SUIUSD_RTI", "HYPE": "HYPEUSD_RTI", "ZEC": "ZECUSD_RTI",
    "XLM": "XLMUSD_RTI", "AVAX": "AVAXUSD_RTI",
}
CF_ALIASES = {"BRTI": "BTC", "ERTI": "ETH"}   # rules text sometimes names the short index


def cf_instrument_to_asset(inst: str) -> str:
    inst = inst.upper()
    if inst in CF_ALIASES:
        return CF_ALIASES[inst]
    m = re.match(r"^([A-Z0-9]+?)USD_?RTI$", inst)
    return m.group(1) if m else ""


# 5 Hz channel covers only these; others fall back to the 1 Hz channel.
CF_5HZ_ASSETS = {"BTC", "ETH", "SOL", "XRP", "DOGE"}

PYTH_SYMBOL_BY_ASSET: Dict[str, str] = {
    "GOLD": "Metal.XAU/USD", "SILVER": "Metal.XAG/USD", "PLATINUM": "Metal.XPT/USD", "PALLADIUM": "Metal.XPD/USD",
    "COPPER": "Metal.HG/USD", "WTI": "Commodities.WTI/USD", "BRENT": "Commodities.BRENT/USD", "OIL": "Commodities.WTI/USD",
    "NATGAS": "Commodities.NG/USD", "US30": "Index.US30/USD", "DJI": "Index.US30/USD",
}

# Pyth instrument (from Kalshi's settlement-source link) -> canonical asset. Verified against
# live demo series 2026-11-09 (gold = Metal.Index.1OZGOLD/USD, silver = Metal.Index.SILVER/USD,
# WTI = Commodities.Index.PYTHOIL/USD, yields = InterestRate.US{2,5,10,30}Y).
_PYTH_INSTRUMENT_ASSET = [
    (re.compile(r"XAU|GOLD", re.I), "GOLD"), (re.compile(r"XAG|SILVER", re.I), "SILVER"),
    (re.compile(r"XPT|PLATINUM", re.I), "PLATINUM"), (re.compile(r"XPD|PALLADIUM", re.I), "PALLADIUM"),
    (re.compile(r"COPPER|\bHG\b|XCU", re.I), "COPPER"), (re.compile(r"BRENT", re.I), "BRENT"),
    (re.compile(r"WTI|PYTHOIL|\bCL\b", re.I), "WTI"), (re.compile(r"NATGAS|NATURAL ?GAS|\bNG\b|HENRY", re.I), "NATGAS"),
    (re.compile(r"US30\b|DJI|DOW", re.I), "DJI"),
    (re.compile(r"US2Y|2Y UST|2-YEAR", re.I), "UST2Y"), (re.compile(r"US5Y|5Y UST|5-YEAR", re.I), "UST5Y"),
    (re.compile(r"US7Y|7Y UST|7-YEAR", re.I), "UST7Y"), (re.compile(r"US10Y|10Y UST|10-YEAR", re.I), "UST10Y"),
    (re.compile(r"US30Y|30Y UST|30-YEAR", re.I), "UST30Y"),
    (re.compile(r"EUR/?USD", re.I), "EURUSD"), (re.compile(r"GBP/?USD", re.I), "GBPUSD"), (re.compile(r"AUD/?USD", re.I), "AUDUSD"),
    (re.compile(r"USD/?JPY", re.I), "USDJPY"), (re.compile(r"USD/?CAD", re.I), "USDCAD"), (re.compile(r"USD/?MXN", re.I), "USDMXN"),
]
# Index names in rules text for markets whose source is non-specific.
_INDEX_NAMES = [(re.compile(r"S&P ?500", re.I), "SPX"), (re.compile(r"Nasdaq[- ]?100", re.I), "NDX"),
                (re.compile(r"Dow Jones|\bDow\b|\bDJIA\b", re.I), "DJI"), (re.compile(r"Russell ?2000", re.I), "RUSSELL")]


def pyth_asset(text: str) -> str:
    for rx, asset in _PYTH_INSTRUMENT_ASSET:
        if rx.search(text):
            return asset
    return ""


def instrument_from_sources(series: SeriesInfo) -> str:
    """Pull the instrument id out of the settlement-source link, e.g.
    https://www.cfbenchmarks.com/data/indices/ETHUSD_RTI -> ETHUSD_RTI,
    https://app.pyth.com/explore/Metal.Index.1OZGOLD%2FUSD?... -> Metal.Index.1OZGOLD/USD."""
    from urllib.parse import unquote, urlsplit
    for src in series.settlement_sources:
        url = src.url or ""
        if not url:
            continue
        path = unquote(urlsplit(url).path)
        m = re.search(r"/indices/([A-Za-z0-9_]+)", path)
        if m:
            return m.group(1).upper()
        m = re.search(r"ids(?:\[\]|%5B%5D)=([0-9a-fA-F]{64})", url)
        if m:
            return f"pyth-id:{m.group(1).lower()}"
        m = re.search(r"/explore/(?:all/)?([^/]+/[A-Za-z]+|[^/]+)$", path)
        if m and "." in m.group(1):
            return m.group(1)
    return ""


_PROVIDER_PATTERNS = [
    (re.compile(r"cf\s*benchmarks|brti|real[- ]time index|\brti\b", re.I), Provider.CF_BENCHMARKS),
    (re.compile(r"\bpyth\b", re.I), Provider.PYTH),
    (re.compile(r"\bice\b|intercontinental exchange|theice\.com", re.I), Provider.ICE),
    (re.compile(r"for example", re.I), Provider.UNSPECIFIED),
    (re.compile(r"treasury\.gov|department of the treasury", re.I), Provider.US_TREASURY),
]

_RULES_PATTERNS: List[Tuple[re.Pattern, Method]] = [
    # live demo wordings (2026-11-09), most specific first
    (re.compile(r"is at least the close (price|yield) of the 1-minute", re.I), Method.WINDOW_COMPARE_CANDLE_1M),
    (re.compile(r"is at least the value of the .{0,60} as published by Pyth", re.I | re.S), Method.WINDOW_COMPARE_VALUE),
    (re.compile(r"daily published par yield .{0,80} on any business day between", re.I | re.S), Method.ANY_DAY_TOUCH),
    (re.compile(r"end-of-day .{0,40}index value on", re.I), Method.VALUE_AT_TIME),
    (re.compile(r"value of the [A-Za-z0-9./ ]{2,40} is (at least|above|below|at most) \$?[\d,.]+ at ", re.I), Method.VALUE_AT_TIME),
    (re.compile(r"(average|mean).{0,40}(60|sixty)\s*seconds?.{0,80}(before|prior to).{0,40}(open|start).{0,120}(before|prior to).{0,40}(close|end)", re.I | re.S),
     Method.WINDOW_COMPARE_AVG_60S),
    (re.compile(r"(60|sixty)[- ]second.{0,40}(average|mean).{0,80}(before|prior).{0,60}(open|start).{0,160}(close|end)", re.I | re.S),
     Method.WINDOW_COMPARE_AVG_60S),
    (re.compile(r"(average|mean).{0,40}(60|sixty)\s*seconds?|(60|sixty)[- ]second.{0,20}(average|mean)|one minute \(60 seconds\)", re.I),
     Method.AVG_60S_BEFORE_TIME),
    (re.compile(r"close price of the 1-minute candlestick.{0,200}(end of the|15-minute|window)", re.I | re.S),
     Method.WINDOW_COMPARE_CANDLE_1M),
    (re.compile(r"close price of the 1-minute candlestick.{0,160}is at least the close price of the 1-minute", re.I | re.S),
     Method.WINDOW_COMPARE_CANDLE_1M),
    (re.compile(r"close price of the 1-minute candlestick", re.I), Method.CANDLE_1M_CLOSE),
    (re.compile(r"(official )?(daily )?settlement price", re.I), Method.DAILY_SETTLEMENT_PRICE),
    (re.compile(r"pyth security yield|yield for the .{0,40}treasury", re.I), Method.VALUE_AT_TIME),
    (re.compile(r"index value on .{0,60} at \d", re.I), Method.VALUE_AT_TIME),
]


def provider_from_sources(series: SeriesInfo) -> Provider:
    found = set()
    for src in series.settlement_sources:
        text = f"{src.name} {src.url}"
        for rx, prov in _PROVIDER_PATTERNS:
            if rx.search(text):
                found.add(prov)
    if len(found) > 1 and Provider.UNSPECIFIED in found:
        found.discard(Provider.UNSPECIFIED)
    if len(found) == 1:
        return found.pop()
    return Provider.UNKNOWN  # none, or conflicting providers


def provider_from_rules(rules: str) -> Provider:
    found = {prov for rx, prov in _PROVIDER_PATTERNS if rx.search(rules)}
    return found.pop() if len(found) == 1 else Provider.UNKNOWN


def method_from_rules(rules: str, cadence: DurationBucket) -> Method:
    for rx, method in _RULES_PATTERNS:
        if rx.search(rules):
            # A 15M series using the 60s-average language is a window comparison.
            if method is Method.AVG_60S_BEFORE_TIME and cadence in (DurationBucket.M15, DurationBucket.ULTRA_SHORT, DurationBucket.M30):
                return Method.WINDOW_COMPARE_AVG_60S
            return method
    return Method.UNKNOWN


def feed_status(provider: Provider, asset: str, settings: KalshiSettings) -> Tuple[ReferenceStatus, str, Tuple[str, ...]]:
    rf = settings.reference_feeds
    if provider is Provider.CF_BENCHMARKS:
        if rf.cfbenchmarks.enabled and asset in CF_INDEX_BY_ASSET:
            ch = rf.cfbenchmarks.channel if asset in CF_5HZ_ASSETS else rf.cfbenchmarks.fallback_channel
            return ReferenceStatus.VALIDATED, ch, ()
        return ReferenceStatus.FEED_UNAVAILABLE, "", ("cfbenchmarks feed disabled or asset not in CF index table",)
    if provider is Provider.PYTH:
        if rf.pyth.enabled:
            return ReferenceStatus.VALIDATED, rf.pyth.kalshi_relay_channel, ()
        return ReferenceStatus.FEED_UNAVAILABLE, "", ("pyth feed disabled (decision 2026-11-08: no paid feeds); reconsider when an appropriately licensed Pyth Core feed is validated",)
    if provider is Provider.ICE:
        return ReferenceStatus.FEED_UNAVAILABLE, "", ("ICE settlement data is licensed; no feed configured",)
    if provider is Provider.US_TREASURY:
        return ReferenceStatus.FEED_UNAVAILABLE, "", ("official Treasury daily par-yield series; no feed configured",)
    if provider is Provider.UNSPECIFIED:
        return ReferenceStatus.FEED_UNAVAILABLE, "", ("settlement source is non-specific ('for example ...'); "
                                                      "record-only until an exact official source and feed are validated",)
    return ReferenceStatus.UNMAPPED, "", ("provider unknown",)


def resolve(series: SeriesInfo, market: MarketInfo, settings: KalshiSettings) -> SettlementReference:
    """Map a (series, market) to its settlement reference. Provider must agree between the
    series' declared sources and the rules text; the instrument comes from the source link
    or the rules text; the asset is derived from the instrument (ticker only as fallback)."""
    cadence = cadence_from_series(series.ticker)
    rules = f"{market.rules_primary}\n{market.rules_secondary}"
    p_src = provider_from_sources(series)
    p_rules = provider_from_rules(rules)
    notes: List[str] = []

    if p_src is Provider.UNKNOWN and p_rules is Provider.UNKNOWN:
        return SettlementReference(Provider.UNKNOWN, "", Method.UNKNOWN, status=ReferenceStatus.UNMAPPED,
                                   notes=("no recognised settlement source in series metadata or rules",))
    if (p_src not in (Provider.UNKNOWN, Provider.UNSPECIFIED) and p_rules not in (Provider.UNKNOWN, Provider.UNSPECIFIED)
            and p_src != p_rules):
        return SettlementReference(Provider.UNKNOWN, "", Method.UNKNOWN, status=ReferenceStatus.UNMAPPED,
                                   notes=(f"settlement source conflict: metadata={p_src.value} rules={p_rules.value}",))
    provider = p_src if p_src is not Provider.UNKNOWN else p_rules
    if p_src is Provider.UNKNOWN:
        notes.append("provider inferred from rules text only (series metadata had no recognised source)")

    method = method_from_rules(rules, cadence)
    if method is Method.UNKNOWN:
        return SettlementReference(provider, "", Method.UNKNOWN, status=ReferenceStatus.UNMAPPED,
                                   notes=tuple(notes + ["observation method not recognised in rules text"]))

    src_inst = instrument_from_sources(series)
    ticker_asset = settings.eligibility.asset_from_ticker(series.ticker)
    if provider is Provider.CF_BENCHMARKS:
        if re.search(r"\bEUR\b|€|\beuro|\bGBP\b|£|EUR_RTI|BRTI[_ ]?EUR", rules + " " + " ".join(x.url for x in series.settlement_sources), re.I):
            return SettlementReference(provider, "", method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + ["non-USD quote currency; only USD CF indices are mapped"]))
        m = re.search(r"\b([A-Z0-9]+?USD_?RTI|BRTI|ERTI)\b", rules)
        rules_inst = m.group(1) if m else ""
        if rules_inst and "_" not in rules_inst and rules_inst.endswith("USDRTI"):
            rules_inst = rules_inst[:-6] + "USD_RTI"      # live 15-min rules write 'ZECUSDRTI'
        if "asset taken from ticker" in notes:
            pass
        inst = src_inst or rules_inst
        asset = cf_instrument_to_asset(inst) if inst else ""
        if rules_inst and src_inst and cf_instrument_to_asset(rules_inst) != cf_instrument_to_asset(src_inst):
            return SettlementReference(provider, inst, method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + [f"index mismatch: source={src_inst} rules={rules_inst}"]))
        if not asset:
            asset = ticker_asset
            notes.append("asset taken from ticker (no index id in source link or rules)")
        instrument = CF_INDEX_BY_ASSET.get(asset, inst)
        if not instrument:
            return SettlementReference(provider, "", method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + [f"asset {asset!r} has no CF index mapping"]), asset=asset)
        price_type = "index"
    elif provider is Provider.PYTH:
        name_text = " ".join(f"{x.name} {x.url}" for x in series.settlement_sources)
        asset = pyth_asset(src_inst) or pyth_asset(name_text) or pyth_asset(rules) or ""
        asset = asset or (ticker_asset if ticker_asset in PYTH_SYMBOL_BY_ASSET else "")
        instrument = src_inst or PYTH_SYMBOL_BY_ASSET.get(asset, "") or (f"pyth:{asset}" if asset else "")
        if not src_inst:
            notes.append("Pyth instrument not in source link; symbol inferred from asset name (verify before enabling)")
        if not instrument or not asset:
            return SettlementReference(provider, instrument, method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + ["Pyth instrument/asset could not be determined"]), asset=asset)
        price_type = "yield" if asset.startswith("UST") else "index"
    elif provider is Provider.US_TREASURY:
        asset = pyth_asset(rules) or ticker_asset
        instrument = f"UST-PAR:{asset}" if asset else ""
        price_type = "yield"
        if not asset:
            return SettlementReference(provider, "", method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + ["Treasury tenor not recognised in rules"]))
    elif provider is Provider.ICE:
        asset = pyth_asset(rules) or ticker_asset
        instrument = f"ICE:{asset}"
        price_type = "settlement"
    else:  # UNSPECIFIED (e.g. "For example, Google Finance")
        asset = next((a for rx, a in _INDEX_NAMES if rx.search(rules)), "") or ticker_asset
        instrument = f"INDEX:{asset}" if asset else ""
        price_type = "index"
        if not asset:
            return SettlementReference(provider, "", method, status=ReferenceStatus.UNMAPPED,
                                       notes=tuple(notes + ["non-specific source and no recognised index in rules"]))

    status, feed, feed_notes = feed_status(provider, asset, settings)
    return SettlementReference(provider, instrument, method, "USD", price_type, status, feed, tuple(notes) + feed_notes, asset)
