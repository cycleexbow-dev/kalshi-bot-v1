"""One request budget for the real exchange's PUBLIC market data, shared by every process on this machine.

Kalshi limits public requests per client, not per process, so independent per-process limits can add up
past it (2026-11-11: recorder + discovery together drew ~240 rate-limit errors). Every GuardedTransport
talking to the production public host draws from this one budget, kept in a small state file under a
file lock, with priorities:

  high        the market recorder: may use the whole budget
  normal      the app's real-price lab: leaves NORMAL_RESERVE of the bucket for the recorder
  background  discovery, backfills, research downloads: only uses what is left above BACKGROUND_RESERVE,
              so it pauses whenever the recorder is busy

When Kalshi answers 429, everyone backs off: a shared cool-down grows exponentially with each consecutive
rate-limit (with jitter). Background work waits it out fully; the recorder only briefly. Read-only market
data only: this module sends nothing itself.
"""
from __future__ import annotations

import asyncio
import fcntl
import json
import os
import random
import time
from pathlib import Path
from typing import Dict, Optional

RATE_PER_S = 6.0              # whole machine; 429s seen at ~10 requests/s and on bursts
CAPACITY = 4.0                # small burst: simultaneous requests also drew 429s
NORMAL_RESERVE = 1.0
BACKGROUND_RESERVE = 2.5
MAX_COOLDOWN_S = 60.0
# Background work also has its own adaptive allowance (additive increase, multiplicative decrease):
# every rate-limit answer halves it and pauses background work; it creeps back up only slowly.
BG_RATE_MAX = 0.3              # at most one background request every ~3 s (measured: 1/s still cost the recorder ~1 retry/min)
BG_RATE_MIN = 0.05             # one background request every 20 s at worst
BG_PAUSE_S = 30.0
BG_RECOVER_PER_OK = 0.002      # per successful request (any process): ~8 min from minimum back to maximum
PRIORITIES = ("high", "normal", "background")


def default_path() -> Path:
    d = os.environ.get("AICRYPTO_RUN_DIR")
    base = Path(d) if d else Path(__file__).resolve().parents[2] / "run"
    base.mkdir(parents=True, exist_ok=True)
    return base / "kalshi_public_budget.json"


class SharedBudget:
    def __init__(self, path: Optional[Path] = None, rate: float = RATE_PER_S, capacity: float = CAPACITY,
                 clock=time.time, rng: Optional[random.Random] = None):
        self.path = Path(path) if path else default_path()
        self.lock_path = self.path.with_suffix(".lock")
        self.rate, self.capacity, self.clock = rate, capacity, clock
        self.rng = rng or random.Random()
        self.waits: Dict[str, float] = {p: 0.0 for p in PRIORITIES}

    # ---- state under an exclusive file lock (held for microseconds) ----------------------
    def _locked(self, fn):
        with open(self.lock_path, "a+") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                try:
                    st = json.loads(self.path.read_text())
                except (FileNotFoundError, json.JSONDecodeError):
                    st = {}
                now = self.clock()
                st.setdefault("tokens", self.capacity)
                st.setdefault("updated", now)
                st.setdefault("cooldown_until", 0.0)
                st.setdefault("strikes", 0)
                st.setdefault("rate_limited_total", 0)
                st.setdefault("by_priority", {})
                st.setdefault("bg_rate", BG_RATE_MAX)
                st.setdefault("bg_tokens", 1.0)
                st.setdefault("bg_pause_until", 0.0)
                st["bg_tokens"] = min(1.0, st["bg_tokens"] + max(0.0, now - st["updated"]) * st["bg_rate"])
                st["tokens"] = min(self.capacity, st["tokens"] + max(0.0, now - st["updated"]) * self.rate)
                st["updated"] = now
                out = fn(st, now)
                tmp = self.path.with_suffix(".tmp")
                tmp.write_text(json.dumps(st))
                tmp.replace(self.path)
                return out
            finally:
                fcntl.flock(lk, fcntl.LOCK_UN)

    def try_acquire(self, priority: str = "normal") -> float:
        """Take one request if allowed now (returns 0), else the seconds to wait before trying again."""
        if priority not in PRIORITIES:
            raise ValueError(priority)
        reserve = {"high": 0.0, "normal": NORMAL_RESERVE, "background": BACKGROUND_RESERVE}[priority]

        def fn(st, now):
            cool = st["cooldown_until"] - now
            if cool > 0:
                if priority == "background":
                    return cool
                if priority == "normal":
                    return min(cool, 5.0)
                if cool > 0 and st["tokens"] < 1.0:          # recorder: short pause only while drained
                    return min(cool, 1.0)
            if priority == "background":
                if now < st["bg_pause_until"]:
                    return st["bg_pause_until"] - now
                if st["bg_tokens"] < 1.0:
                    return (1.0 - st["bg_tokens"]) / st["bg_rate"]
            if st["tokens"] - 1.0 >= reserve:
                st["tokens"] -= 1.0
                if priority == "background":
                    st["bg_tokens"] -= 1.0
                return 0.0
            return (1.0 + reserve - st["tokens"]) / self.rate
        return self._locked(fn)

    async def acquire(self, priority: str = "normal") -> None:
        while True:
            wait = self.try_acquire(priority)
            if wait <= 0:
                return
            wait *= 0.8 + 0.4 * self.rng.random()                  # jitter: processes do not wake in lockstep
            self.waits[priority] += wait
            await asyncio.sleep(wait)

    def report_429(self, priority: str = "normal") -> float:
        """A rate-limit answer: shared exponential cool-down with jitter; background allowance halved and
        background work paused. Returns the cool-down length."""
        def fn(st, now):
            st["strikes"] = min(st["strikes"] + 1, 10)
            st["rate_limited_total"] += 1
            st["by_priority"][priority] = st["by_priority"].get(priority, 0) + 1
            st["bg_rate"] = max(BG_RATE_MIN, st["bg_rate"] / 2)
            st["bg_tokens"] = 0.0
            st["bg_pause_until"] = max(st["bg_pause_until"], now + BG_PAUSE_S * (0.8 + 0.4 * self.rng.random()))
            length = min(MAX_COOLDOWN_S, 0.5 * (2 ** st["strikes"])) * (0.8 + 0.4 * self.rng.random())
            st["cooldown_until"] = max(st["cooldown_until"], now + length)
            st["tokens"] = 0.0
            return length
        return self._locked(fn)

    def report_ok(self) -> None:
        def fn(st, now):
            if st["strikes"] and now > st["cooldown_until"]:
                st["strikes"] -= 1
            if now > st["bg_pause_until"]:
                st["bg_rate"] = min(BG_RATE_MAX, st["bg_rate"] + BG_RECOVER_PER_OK)
        self._locked(fn)

    def snapshot(self) -> Dict[str, float]:
        return self._locked(lambda st, now: dict(st))


_shared: Optional[SharedBudget] = None


def shared() -> SharedBudget:
    global _shared
    if _shared is None:
        _shared = SharedBudget()
    return _shared
