"""Market registry: the discovery universe, eligibility history, and the bounded
subscription scheduler.

Discovery is unbounded: every market Kalshi lists is recorded with its series, its
duration classification and its eligibility decision (tier + reasons). The
subscription budget (`max_orderbooks`) only limits which *tradeable* markets get a
live L2 book at any moment; it never trims the universe.

Persistence: SQLite (one file). Hot reads come from in-memory dicts; writes go through
`upsert_*` so the ingest loop can batch them off the hot path later (Phase 5/6).
"""
from __future__ import annotations

import json
import logging
import queue
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .durations import DurationBucket
from .eligibility import Decision, Tier, evaluate
from .models import MarketInfo, MarketStatus, SeriesInfo, event_ticker_of, series_ticker_of, parse_ts
from .settings import KalshiSettings

_SCHEMA = """
CREATE TABLE IF NOT EXISTS series (
    ticker TEXT PRIMARY KEY, category TEXT, categories TEXT, tags TEXT, fee_type TEXT, fee_multiplier REAL,
    settlement_sources TEXT, frequency TEXT, updated_at REAL, raw TEXT
);
CREATE TABLE IF NOT EXISTS markets (
    ticker TEXT PRIMARY KEY, event_ticker TEXT, series_ticker TEXT, status TEXT, market_type TEXT, strike_type TEXT,
    floor_strike TEXT, cap_strike TEXT, open_time TEXT, close_time TEXT, expected_expiration_time TEXT,
    duration_bucket TEXT, structure TEXT, asset TEXT, asset_class TEXT,
    yes_bid_p4 INTEGER, yes_ask_p4 INTEGER, yes_bid_size_c2 INTEGER, yes_ask_size_c2 INTEGER,
    volume_24h_c2 INTEGER, open_interest_c2 INTEGER, result TEXT, settlement_value_p4 INTEGER,
    first_seen REAL, last_seen REAL, raw TEXT
);
CREATE INDEX IF NOT EXISTS idx_markets_series ON markets(series_ticker);
CREATE INDEX IF NOT EXISTS idx_markets_event ON markets(event_ticker);
CREATE INDEX IF NOT EXISTS idx_markets_status ON markets(status);
CREATE TABLE IF NOT EXISTS eligibility (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, decided_at REAL, tier TEXT, reasons TEXT, notes TEXT,
    reference TEXT, rules_hash TEXT, config_hash TEXT, is_current INTEGER
);
CREATE INDEX IF NOT EXISTS idx_elig_ticker ON eligibility(ticker, is_current);
CREATE TABLE IF NOT EXISTS lifecycle_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ticker TEXT, event_type TEXT, received_at REAL, payload TEXT
);
"""


@dataclass
class LiquidityStats:
    """Live-updated by the ticker channel (Phase 3+). Defaults make unseen markets rank low."""
    yes_bid_p4: Optional[int] = None
    yes_ask_p4: Optional[int] = None
    bid_size_c2: int = 0
    ask_size_c2: int = 0
    volume_24h_c2: int = 0
    open_interest_c2: int = 0
    last_update_mono: float = 0.0
    feed_healthy: bool = True
    processing_cost_us: float = 0.0   # measured per-market processing cost (Phase 5)

    @property
    def spread_p4(self) -> Optional[int]:
        if self.yes_bid_p4 is None or self.yes_ask_p4 is None:
            return None
        return self.yes_ask_p4 - self.yes_bid_p4


@dataclass
class RankedMarket:
    ticker: str
    score: float
    components: Dict[str, float] = field(default_factory=dict)


class WriteBehind:
    """Single background writer thread for the registry database.

    The live feed updates the registry many times a second; doing each SQLite write on the event loop
    froze it for seconds whenever the 1.8 GB file was slow to write. Writes are queued here and applied
    in order, in small transactions, by one thread with its own connection. In-memory state (what the
    app reads) is updated immediately as before; only the disk copy lags, by well under a second.
    """

    def __init__(self, db_path: Path, max_batch: int = 500):
        self.db_path, self.max_batch = db_path, max_batch
        self.q: "queue.Queue" = queue.Queue()
        self.errors = 0
        self.written = 0
        self._t = threading.Thread(target=self._run, name="registry-writer", daemon=True)
        self._t.start()

    def put(self, statements) -> None:
        self.q.put(statements)

    def _run(self) -> None:
        c = sqlite3.connect(self.db_path, timeout=60)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        while True:
            item = self.q.get()
            items = [item]
            while item is not None and len(items) < self.max_batch:
                try:
                    nxt = self.q.get_nowait()
                except queue.Empty:
                    break
                items.append(nxt)
                if nxt is None:
                    break
            try:
                with c:
                    for st in items:
                        if st is None:
                            continue
                        for sql, params in st:
                            c.execute(sql, params)
                self.written += sum(1 for st in items if st is not None)
            except Exception as e:                      # keep going; the in-memory state is unaffected
                self.errors += 1
                logging.getLogger("aicrypto.kalshi.registry").error("registry write failed: %s", e)
            for _ in items:
                self.q.task_done()
            if None in items:
                break
        c.close()

    def flush(self) -> None:
        self.q.join()

    def stop(self) -> None:
        self.q.put(None)
        self._t.join(timeout=30)


class MarketRegistry:
    def __init__(self, settings: KalshiSettings, db_path: Optional[Path] = None, series_filter=None, progress=None):
        self.s = settings
        self.db_path = Path(db_path) if db_path else settings.path("registry_db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.series: Dict[str, SeriesInfo] = {}
        self.markets: Dict[str, MarketInfo] = {}
        self.decisions: Dict[str, Decision] = {}
        self.liquidity: Dict[str, LiquidityStats] = {}
        self.subscribed: List[str] = []
        self._batch = None
        self._wb: Optional[WriteBehind] = None
        self._persisted: Dict[str, Tuple[str, str, str, str]] = {}
        with self._conn() as c:
            c.executescript(_SCHEMA)
        self._series_filter = series_filter
        self._progress = progress
        self._load()

    def _conn(self):
        if getattr(self, "_batch", None) is not None:
            return self._batch
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        # WAL: readers never block writers and commits need far fewer disk syncs (the default rollback
        # journal made single inserts on this 1.8 GB file take seconds and froze the live feed)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    def start_write_behind(self) -> None:
        """Move all later registry writes to a background thread (the live app calls this)."""
        if self._wb is None:
            self._wb = WriteBehind(self.db_path)

    def stop_write_behind(self) -> None:
        if self._wb is not None:
            self._wb.stop()
            self._wb = None

    def _write(self, statements) -> None:
        """Run [(sql, params), ...] in order: on the writer thread when enabled (and not inside batch())."""
        if self._wb is not None and getattr(self, "_batch", None) is None:
            self._wb.put(statements)
            return
        with self._conn() as c:
            for sql, params in statements:
                c.execute(sql, params)

    def batch(self):
        """Group many writes into one transaction (discovery upserts tens of thousands of
        markets; one commit per market is far too slow on WSL disks)."""
        reg = self

        class _Batch:
            def __enter__(self_):
                conn = sqlite3.connect(reg.db_path, timeout=30)
                conn.row_factory = sqlite3.Row
                conn.execute("PRAGMA synchronous=NORMAL")

                class _Shared:
                    # `with reg._conn() as c:` inside a batch must neither commit nor close
                    def __enter__(s2):
                        return conn
                    def __exit__(s2, *exc):
                        return False
                    def execute(s2, *a, **k):
                        return conn.execute(*a, **k)
                    def executemany(s2, *a, **k):
                        return conn.executemany(*a, **k)
                    def executescript(s2, *a, **k):
                        return conn.executescript(*a, **k)

                self_.conn = conn
                reg._batch = _Shared()
                return reg

            def __exit__(self_, exc_type, *exc):
                reg._batch = None
                if exc_type is None:
                    self_.conn.commit()
                else:
                    self_.conn.rollback()
                self_.conn.close()
                return False

        return _Batch()

    def _load(self) -> None:
        with self._conn() as c:
            for r in c.execute("SELECT raw FROM series"):
                s = SeriesInfo.from_api(json.loads(r["raw"]))
                self.series[s.ticker] = s
            keep = None
            if self._series_filter is not None:     # partial load (terminal UI): only the series it needs
                keep = [t for t, s in self.series.items() if self._series_filter(s)]
                c.execute("CREATE TEMP TABLE IF NOT EXISTS _keep_series (t TEXT PRIMARY KEY)")
                c.execute("DELETE FROM _keep_series")
                c.executemany("INSERT OR IGNORE INTO _keep_series VALUES (?)", [(t,) for t in keep])
                total = c.execute("SELECT COUNT(*) FROM markets WHERE series_ticker IN (SELECT t FROM _keep_series)").fetchone()[0]
                rows = c.execute("SELECT raw FROM markets WHERE series_ticker IN (SELECT t FROM _keep_series)")
            else:
                total = c.execute("SELECT COUNT(*) FROM markets").fetchone()[0]
                rows = c.execute("SELECT raw FROM markets")
            for i, r in enumerate(rows):
                m = MarketInfo.from_api(json.loads(r["raw"]))
                self.markets[m.ticker] = m
                if self._progress is not None and i % 5000 == 0:
                    self._progress(i, total)
            for r in c.execute("SELECT ticker, tier, reasons, config_hash, rules_hash FROM eligibility WHERE is_current=1"):
                self._persisted[r["ticker"]] = (r["tier"], r["reasons"], r["config_hash"], r["rules_hash"])
        # decisions are recomputed on load (config may have changed) — see reevaluate_all.
        # History is only appended when the result differs from the persisted current row.

    # ---- upserts -------------------------------------------------------------------
    def upsert_series(self, payload: Dict[str, Any]) -> SeriesInfo:
        s = SeriesInfo.from_api(payload)
        self.series[s.ticker] = s
        self._write([("INSERT OR REPLACE INTO series VALUES (?,?,?,?,?,?,?,?,?,?)",
                      (s.ticker, s.category, json.dumps(s.categories), json.dumps(s.tags), s.fee_type, s.fee_multiplier,
                       json.dumps([x.__dict__ for x in s.settlement_sources]), s.frequency, time.time(), json.dumps(s.raw)))])
        return s

    def upsert_market(self, payload: Dict[str, Any], decide: bool = True) -> Tuple[MarketInfo, Optional[Decision]]:
        m = MarketInfo.from_api(payload)
        is_new = m.ticker not in self.markets
        self.markets[m.ticker] = m
        decision = None
        series = self.series.get(m.series_ticker)
        if decide and series is not None:
            decision = self._decide(series, m)
        elif decide and series is None:
            decision = None  # series metadata not yet known; caller should fetch series then re-decide
        now = time.time()
        d = decision
        self._write([(
                "INSERT INTO markets VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(ticker) DO UPDATE SET status=excluded.status, strike_type=excluded.strike_type, floor_strike=excluded.floor_strike, "
                "cap_strike=excluded.cap_strike, close_time=excluded.close_time, expected_expiration_time=excluded.expected_expiration_time, "
                "duration_bucket=excluded.duration_bucket, structure=excluded.structure, asset=excluded.asset, asset_class=excluded.asset_class, "
                "yes_bid_p4=excluded.yes_bid_p4, yes_ask_p4=excluded.yes_ask_p4, yes_bid_size_c2=excluded.yes_bid_size_c2, "
                "yes_ask_size_c2=excluded.yes_ask_size_c2, volume_24h_c2=excluded.volume_24h_c2, open_interest_c2=excluded.open_interest_c2, "
                "result=excluded.result, settlement_value_p4=excluded.settlement_value_p4, last_seen=excluded.last_seen, raw=excluded.raw",
                (m.ticker, m.event_ticker, m.series_ticker, m.status.value, m.market_type, m.strike_type.value,
                 str(m.floor_strike) if m.floor_strike is not None else None, str(m.cap_strike) if m.cap_strike is not None else None,
                 m.open_time.isoformat() if m.open_time else None, m.close_time.isoformat() if m.close_time else None,
                 m.expected_expiration_time.isoformat() if m.expected_expiration_time else None,
                 d.duration.bucket.value if d else None, d.duration.structure.value if d else None, d.asset if d else None,
                 d.asset_class if d else None, m.yes_bid_p4, m.yes_ask_p4, m.yes_bid_size_c2, m.yes_ask_size_c2,
                 m.volume_24h_c2, m.open_interest_c2, m.result, m.settlement_value_p4, now, now, json.dumps(m.raw, default=str)),
            )])
        if is_new and m.ticker not in self.liquidity:
            self.liquidity[m.ticker] = LiquidityStats(m.yes_bid_p4, m.yes_ask_p4, m.yes_bid_size_c2 or 0, m.yes_ask_size_c2 or 0,
                                                      m.volume_24h_c2, m.open_interest_c2)
        return m, decision

    def _decide(self, series: SeriesInfo, m: MarketInfo) -> Decision:
        d = evaluate(series, m, self.s)
        prev = self.decisions.get(m.ticker)
        self.decisions[m.ticker] = d
        fp = (d.tier.value, json.dumps([r.value for r in d.reasons]), d.config_hash, d.rules_hash)
        if prev is not None:
            changed = prev.tier != d.tier or prev.reasons != d.reasons or prev.config_hash != d.config_hash or prev.rules_hash != d.rules_hash
        else:
            changed = self._persisted.get(m.ticker) != fp
        if changed:
            self._persisted[m.ticker] = fp
            self._write([("UPDATE eligibility SET is_current=0 WHERE ticker=? AND is_current=1", (m.ticker,)),
                         ("INSERT INTO eligibility (ticker, decided_at, tier, reasons, notes, reference, rules_hash, config_hash, is_current) "
                          "VALUES (?,?,?,?,?,?,?,?,1)",
                          (m.ticker, time.time(), d.tier.value, json.dumps([r.value for r in d.reasons]), json.dumps(d.notes),
                           json.dumps(d.reference.to_dict()), d.rules_hash, d.config_hash))])
        return d

    def reevaluate_all(self, progress=None) -> Dict[str, int]:
        """Re-run eligibility for every known market (e.g. after a config change such as a
        reference feed becoming available). Returns tier counts. History is preserved."""
        counts: Dict[str, int] = {}
        with self.batch():
            ms = list(self.markets.values())
            for i, m in enumerate(ms):
                if progress is not None and i % 5000 == 0:
                    progress(i, len(ms))
                s = self.series.get(m.series_ticker)
                if s is None:
                    continue
                d = self._decide(s, m)
                counts[d.tier.value] = counts.get(d.tier.value, 0) + 1
        return counts

    # ---- lifecycle events ---------------------------------------------------------------
    def apply_lifecycle(self, message: Dict[str, Any]) -> Optional[MarketInfo]:
        msg = message.get("msg", message)
        ticker = msg["market_ticker"]
        et = msg.get("event_type")
        self._write([("INSERT INTO lifecycle_log (ticker, event_type, received_at, payload) VALUES (?,?,?,?)",
                      (ticker, et, time.time(), json.dumps(msg, default=str)))])
        if et == "created":
            meta = msg.get("additional_metadata", {}) or {}
            payload = {
                "ticker": ticker, "event_ticker": meta.get("event_ticker") or event_ticker_of(ticker), "market_type": "binary",
                "status": "initialized", "title": meta.get("title", ""), "yes_sub_title": meta.get("yes_sub_title", ""),
                "open_time": msg.get("open_ts"), "close_time": msg.get("close_ts"),
                "expected_expiration_time": meta.get("expected_expiration_ts"), "can_close_early": meta.get("can_close_early", False),
                "strike_type": meta.get("strike_type"), "floor_strike": meta.get("floor_strike"), "cap_strike": meta.get("cap_strike"),
                "rules_primary": meta.get("rules_primary", ""), "rules_secondary": meta.get("rules_secondary", ""),
                "price_ranges": msg.get("price_ranges") or [], "is_provisional": meta.get("is_provisional", False),
            }
            m, _ = self.upsert_market(payload)
            return m
        m = self.markets.get(ticker)
        if m is None:
            return None  # unknown market; caller should REST-fetch it
        raw = dict(m.raw)
        if et == "activated":
            raw["status"] = "active"
        elif et == "deactivated":
            raw["status"] = "inactive" if msg.get("is_deactivated", True) else "active"
        elif et == "close_date_updated":
            raw["close_time"] = msg.get("close_ts", raw.get("close_time"))
        elif et == "determined":
            raw["status"] = "determined"; raw["result"] = msg.get("result", ""); raw["settlement_value_dollars"] = msg.get("settlement_value")
        elif et == "settled":
            raw["status"] = "finalized"; raw["settlement_ts"] = msg.get("settled_ts")
        elif et == "metadata_updated":
            for k in ("strike_type", "floor_strike", "cap_strike", "custom_strike", "yes_sub_title"):
                if k in msg:
                    raw[k] = msg[k]
        elif et == "price_level_structure_updated":
            raw["price_ranges"] = msg.get("price_ranges", raw.get("price_ranges"))
        m2, _ = self.upsert_market(raw)
        if m2.status.is_terminal or m2.status in (MarketStatus.CLOSED, MarketStatus.INACTIVE):
            self.subscribed = [t for t in self.subscribed if t != ticker]
        return m2

    # ---- queries ------------------------------------------------------------------------
    def decision(self, ticker: str) -> Optional[Decision]:
        return self.decisions.get(ticker)

    def by_tier(self, tier: Tier) -> List[MarketInfo]:
        return [self.markets[t] for t, d in self.decisions.items() if d.tier is tier and t in self.markets]

    def active_tradeable(self, now: Optional[datetime] = None) -> List[MarketInfo]:
        now = now or datetime.now(timezone.utc)
        out = []
        for m in self.by_tier(Tier.TRADEABLE):
            if m.status.is_tradeable and (m.close_time is None or m.close_time > now):
                out.append(m)
        return out

    def ladders(self, discoverable_only: bool = True) -> Dict[str, List[MarketInfo]]:
        """Strike ladders: markets sharing an event (same underlying, same observation)."""
        groups: Dict[str, List[MarketInfo]] = {}
        for m in self.markets.values():
            d = self.decisions.get(m.ticker)
            if discoverable_only and (d is None or not d.discoverable):
                continue
            groups.setdefault(m.event_ticker, []).append(m)
        return {k: sorted(v, key=lambda x: (x.floor_strike if x.floor_strike is not None else -1)) for k, v in groups.items() if len(v) > 1}

    def overlapping(self, asset: str, now: Optional[datetime] = None) -> List[MarketInfo]:
        """Open contracts on one asset with different close times (cross-timeframe analysis)."""
        now = now or datetime.now(timezone.utc)
        return sorted([m for t, m in self.markets.items() if self.decisions.get(t) and self.decisions[t].asset == asset
                       and self.decisions[t].discoverable and m.status.is_tradeable and m.close_time and m.close_time > now], key=lambda m: m.close_time)

    def durations_available(self) -> Dict[str, Dict[str, int]]:
        """asset -> duration bucket -> count of discoverable markets (what Kalshi actually lists)."""
        out: Dict[str, Dict[str, int]] = {}
        for t, d in self.decisions.items():
            if not d.discoverable:
                continue
            out.setdefault(d.asset, {})
            out[d.asset][d.duration.bucket.value] = out[d.asset].get(d.duration.bucket.value, 0) + 1
        return out

    def eligibility_history(self, ticker: str) -> List[Dict[str, Any]]:
        if self._wb is not None:
            self._wb.flush()                      # history must include queued writes
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM eligibility WHERE ticker=? ORDER BY decided_at", (ticker,))]

    def rejection_summary(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for d in self.decisions.values():
            if d.tier is not Tier.TRADEABLE:
                for r in d.reasons:
                    out[r.value] = out.get(r.value, 0) + 1
        return out

    # ---- ranking & bounded subscription -----------------------------------------------------
    def update_liquidity(self, ticker: str, **kw) -> None:
        ls = self.liquidity.setdefault(ticker, LiquidityStats())
        for k, v in kw.items():
            setattr(ls, k, v)

    def rank(self, now: Optional[datetime] = None) -> List[RankedMarket]:
        now = now or datetime.now(timezone.utc)
        ranked: List[RankedMarket] = []
        for m in self.active_tradeable(now):
            ls = self.liquidity.get(m.ticker, LiquidityStats())
            comp: Dict[str, float] = {}
            depth = (ls.bid_size_c2 + ls.ask_size_c2) / 100.0
            comp["depth"] = min(depth / 500.0, 1.0)
            sp = ls.spread_p4
            comp["spread"] = 0.0 if sp is None else max(0.0, 1.0 - sp / 1000.0)        # 10c spread -> 0
            comp["volume"] = min((ls.volume_24h_c2 / 100.0) / 5000.0, 1.0)
            ttc = (m.close_time - now).total_seconds() / 60.0 if m.close_time else 1e9
            # Prefer markets whose settlement window is approaching (where lead/lag lives),
            # but not those closing in the next 30 seconds.
            comp["time_to_close"] = 0.0 if ttc < 0.5 else (1.0 if ttc <= 20 else max(0.1, 1.0 - (ttc - 20) / (24 * 60)))
            comp["feed_health"] = 1.0 if ls.feed_healthy else 0.0
            comp["processing_cost"] = max(0.0, 1.0 - ls.processing_cost_us / 2000.0)
            score = (0.30 * comp["depth"] + 0.20 * comp["spread"] + 0.15 * comp["volume"] + 0.20 * comp["time_to_close"]
                     + 0.10 * comp["feed_health"] + 0.05 * comp["processing_cost"])
            if not ls.feed_healthy:
                score *= 0.5
            ranked.append(RankedMarket(m.ticker, round(score, 6), comp))
        ranked.sort(key=lambda r: (-r.score, r.ticker))
        return ranked

    def schedule_subscriptions(self, now: Optional[datetime] = None) -> Tuple[List[str], List[str], List[str]]:
        """Return (subscribed, to_add, to_remove) under the book budget with hysteresis.
        Discovery universe is untouched; this only picks which TRADEABLE books are live."""
        budget = self.s.subscriptions.max_orderbooks
        ranked = self.rank(now)
        scores = {r.ticker: r.score for r in ranked}
        desired = [r.ticker for r in ranked[:budget]]
        current = [t for t in self.subscribed if t in scores]  # drop closed/ineligible automatically
        keep = []
        for t in current:
            if t in desired:
                keep.append(t)
            else:
                # hysteresis: keep a current subscription unless a challenger beats it by the margin
                challenger = next((d for d in desired if d not in current and d not in keep), None)
                if challenger is None or scores[challenger] - scores[t] < self.s.subscriptions.min_rank_improvement_to_swap:
                    keep.append(t)
        slots = budget - len(keep)
        to_add = [d for d in desired if d not in keep][:max(slots, 0)]
        new = keep + to_add
        to_remove = [t for t in self.subscribed if t not in new]
        self.subscribed = new
        for t in new:
            from .eligibility import assert_tradeable
            assert_tradeable(self.decisions.get(t), t)   # enforcement at subscription
        return new, to_add, to_remove

    def summary(self) -> Dict[str, Any]:
        tiers = {t.value: 0 for t in Tier}
        for d in self.decisions.values():
            tiers[d.tier.value] += 1
        return {"series": len(self.series), "markets": len(self.markets), "tiers": tiers, "subscribed": len(self.subscribed),
                "budget": self.s.subscriptions.max_orderbooks, "durations": self.durations_available(),
                "rejections": self.rejection_summary()}
