"""Local order books with exact integer arithmetic and integrity tracking.

Kalshi publishes **bids only** for each side. A YES ask at price p is a NO bid at 1-p
and vice versa, so each market is fully described by two bid ladders:
    yes_bids: price_p4 -> qty_c2        (buyers of YES)
    no_bids:  price_p4 -> qty_c2        (buyers of NO)
Best YES ask = 10000 - best NO bid; best NO ask = 10000 - best YES bid.

Integrity: a book is `valid` only after a snapshot and while every delta's `clock` is
>= the last one (clocks are monotonic per market outside maintenance) and the
subscription's `seq` has no gaps. On a gap the book is invalidated and the owner must
request `get_snapshot`. Trading logic must check `book.valid` (Phase 7).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .models import ONE_DOLLAR_P4, dollars_to_p4, fp_to_c2


@dataclass
class BookStats:
    snapshots: int = 0
    deltas: int = 0
    invalidations: int = 0
    clock_regressions: int = 0
    duplicate_deltas: int = 0
    negative_levels_clamped: int = 0


@dataclass
class OrderBook:
    ticker: str
    yes_bids: Dict[int, int] = field(default_factory=dict)
    no_bids: Dict[int, int] = field(default_factory=dict)
    clock: int = -1
    valid: bool = False
    last_update_ns: int = 0
    stats: BookStats = field(default_factory=BookStats)
    _last_delta_key: Optional[Tuple[int, int, str, int]] = None

    # ---- mutation --------------------------------------------------------------------------
    def apply_snapshot(self, msg: Dict, t_ns: int = 0) -> None:
        self.yes_bids = {dollars_to_p4(p): fp_to_c2(q) for p, q in (msg.get("yes_dollars_fp") or [])}
        self.no_bids = {dollars_to_p4(p): fp_to_c2(q) for p, q in (msg.get("no_dollars_fp") or [])}
        self.yes_bids = {p: q for p, q in self.yes_bids.items() if q > 0}
        self.no_bids = {p: q for p, q in self.no_bids.items() if q > 0}
        self.clock = int(msg.get("clock", 0))
        self.valid = True
        self.last_update_ns = t_ns
        self._last_delta_key = None
        self.stats.snapshots += 1

    def apply_delta(self, msg: Dict, t_ns: int = 0) -> bool:
        """Returns True if applied. Deltas before a snapshot, or with a regressing clock,
        invalidate the book (caller must resync)."""
        if not self.valid:
            return False
        clock = int(msg.get("clock", 0))
        if clock < self.clock:
            self.stats.clock_regressions += 1
            self.invalidate()
            return False
        price = dollars_to_p4(msg["price_dollars"])
        delta = fp_to_c2(msg["delta_fp"])
        side = msg["side"]
        key = (clock, price, side, delta)
        if key == self._last_delta_key and clock == self.clock:
            # Same exchange action re-delivered (e.g. after a reconnect replay): ignore.
            self.stats.duplicate_deltas += 1
            return False
        book = self.yes_bids if side == "yes" else self.no_bids
        new = book.get(price, 0) + delta
        if new < 0:
            self.stats.negative_levels_clamped += 1
            new = 0
        if new == 0:
            book.pop(price, None)
        else:
            book[price] = new
        self.clock = clock
        self._last_delta_key = key
        self.last_update_ns = t_ns
        self.stats.deltas += 1
        return True

    def invalidate(self) -> None:
        if self.valid:
            self.stats.invalidations += 1
        self.valid = False

    # ---- views ------------------------------------------------------------------------------
    @property
    def best_yes_bid(self) -> Optional[int]:
        return max(self.yes_bids) if self.yes_bids else None

    @property
    def best_no_bid(self) -> Optional[int]:
        return max(self.no_bids) if self.no_bids else None

    @property
    def best_yes_ask(self) -> Optional[int]:
        nb = self.best_no_bid
        return None if nb is None else ONE_DOLLAR_P4 - nb

    @property
    def best_no_ask(self) -> Optional[int]:
        yb = self.best_yes_bid
        return None if yb is None else ONE_DOLLAR_P4 - yb

    @property
    def spread_p4(self) -> Optional[int]:
        b, a = self.best_yes_bid, self.best_yes_ask
        return None if b is None or a is None else a - b

    @property
    def mid_p4(self) -> Optional[int]:
        b, a = self.best_yes_bid, self.best_yes_ask
        return None if b is None or a is None else (a + b) // 2

    def depth_c2(self, side: str, levels: int = 5) -> int:
        book = self.yes_bids if side == "yes" else self.no_bids
        return sum(q for _, q in sorted(book.items(), reverse=True)[:levels])

    def yes_asks(self) -> List[Tuple[int, int]]:
        """Implied YES ask ladder (price ascending) from NO bids."""
        return sorted(((ONE_DOLLAR_P4 - p, q) for p, q in self.no_bids.items()))

    def crossed(self) -> bool:
        b, a = self.best_yes_bid, self.best_yes_ask
        return b is not None and a is not None and b >= a

    def snapshot_dict(self) -> Dict:
        return {"ticker": self.ticker, "valid": self.valid, "clock": self.clock,
                "yes_bid": self.best_yes_bid, "yes_ask": self.best_yes_ask, "spread": self.spread_p4,
                "yes_depth5": self.depth_c2("yes"), "no_depth5": self.depth_c2("no"), "levels": len(self.yes_bids) + len(self.no_bids)}


class BookSet:
    """All subscribed books plus per-subscription sequence tracking."""

    def __init__(self):
        self.books: Dict[str, OrderBook] = {}
        self.seq_by_sid: Dict[int, int] = {}
        self.gaps: int = 0
        self.gap_events: List[Tuple[int, int, int]] = []   # (sid, expected, got)

    def book(self, ticker: str) -> OrderBook:
        if ticker not in self.books:
            self.books[ticker] = OrderBook(ticker)
        return self.books[ticker]

    def check_seq(self, sid: int, seq: Optional[int]) -> bool:
        """Return False (and record a gap) when `seq` is not last+1 for this subscription.
        First message for a sid is always accepted."""
        if seq is None:
            return True
        last = self.seq_by_sid.get(sid)
        self.seq_by_sid[sid] = seq
        if last is None or seq == last + 1:
            return True
        if seq <= last:
            return True  # duplicate/replay: tolerated here, de-duplicated at the book level
        self.gaps += 1
        if len(self.gap_events) < 100:
            self.gap_events.append((sid, last + 1, seq))
        return False

    def drop(self, ticker: str) -> None:
        self.books.pop(ticker, None)

    def invalidate_all(self) -> None:
        for b in self.books.values():
            b.invalidate()
        self.seq_by_sid.clear()

    def invalid_tickers(self) -> List[str]:
        return [t for t, b in self.books.items() if not b.valid]
