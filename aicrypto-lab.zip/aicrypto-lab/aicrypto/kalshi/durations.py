"""Contract-duration discovery. Nothing is hard-coded to a fixed list of timeframes.

Order of evidence (verified against live demo data 2026-11-09):
  1. the series' own `frequency` field from Kalshi (e.g. "hourly", "daily") — authoritative;
  2. the market's open->close listing window;
  3. the series-ticker suffix — cross-check only.
Many ladders are *listed* a day or more before their observation (e.g. KXBTCD hourly
events open ~1 day early), so listing length alone mislabels them.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import timedelta
from enum import Enum
from typing import Optional

from .models import ContractStructure, MarketInfo


class DurationBucket(str, Enum):
    ULTRA_SHORT = "<=5m"
    M15 = "15m"
    M30 = "30m"
    H1 = "1h"
    MULTI_HOUR = "multi_hour"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    LONG = "longer"
    UNKNOWN = "unknown"


def bucket_for(d: Optional[timedelta]) -> DurationBucket:
    if d is None:
        return DurationBucket.UNKNOWN
    m = d.total_seconds() / 60.0
    if m <= 5.5:
        return DurationBucket.ULTRA_SHORT
    if m <= 20:
        return DurationBucket.M15
    if m <= 45:
        return DurationBucket.M30
    if m <= 90:
        return DurationBucket.H1
    if m <= 24 * 60 * 1.5:
        return DurationBucket.MULTI_HOUR if m < 18 * 60 else DurationBucket.DAILY
    if m <= 24 * 60 * 10:
        return DurationBucket.WEEKLY
    if m <= 24 * 60 * 45:
        return DurationBucket.MONTHLY
    if m <= 24 * 60 * 120:
        return DurationBucket.QUARTERLY
    return DurationBucket.LONG


# Series-ticker cadence suffixes observed in Kalshi listings (cross-check only).
_SUFFIX = [
    (re.compile(r"(?<!\d)5M$"), DurationBucket.ULTRA_SHORT),
    (re.compile(r"(15M)$"), DurationBucket.M15),
    (re.compile(r"(30M)$"), DurationBucket.M30),
    (re.compile(r"(H|1H|HR|HOURLY)$"), DurationBucket.H1),
    (re.compile(r"(D|DAILY)$"), DurationBucket.DAILY),
    (re.compile(r"(W|WK|WEEKLY)$"), DurationBucket.WEEKLY),
    (re.compile(r"(MON|M|MONTHLY)$"), DurationBucket.MONTHLY),
    (re.compile(r"(Q|QTR)$"), DurationBucket.QUARTERLY),
    (re.compile(r"(Y|YR|DIRY|ANNUAL)$"), DurationBucket.LONG),
]

_ASSET_PREFIX = re.compile(r"^KX([A-Z]+?)(5M|15M|30M|H|HR|D|W|WK|MON|M|Q|Y|YR|DIRY)?$")


def cadence_from_series(series_ticker: str) -> DurationBucket:
    for rx, b in _SUFFIX:
        if rx.search(series_ticker):
            return b
    return DurationBucket.UNKNOWN


def asset_from_series(series_ticker: str) -> Optional[str]:
    """'KXBTC15M' -> 'BTC', 'KXGOLDD' -> 'GOLD', 'KXETH' -> 'ETH'. None if not KX-prefixed."""
    m = _ASSET_PREFIX.match(series_ticker)
    return m.group(1) if m else None


@dataclass(frozen=True)
class DurationInfo:
    bucket: DurationBucket                 # from timestamps (authoritative)
    series_cadence: DurationBucket         # from suffix (cross-check)
    listing_minutes: Optional[float]
    structure: ContractStructure
    disagreement: bool

    def to_dict(self) -> dict:
        return {"bucket": self.bucket.value, "series_cadence": self.series_cadence.value,
                "listing_minutes": self.listing_minutes, "structure": self.structure.value,
                "disagreement": self.disagreement}


def bucket_from_frequency(freq: str) -> DurationBucket:
    f = (freq or "").strip().lower().replace("_", " ").replace("-", " ")
    if not f:
        return DurationBucket.UNKNOWN
    if ("15" in f and "min" in f) or "fifteen" in f:
        return DurationBucket.M15
    if ("5" in f and "min" in f and "15" not in f) or "five min" in f:
        return DurationBucket.ULTRA_SHORT
    if ("30" in f and "min" in f) or "half hour" in f:
        return DurationBucket.M30
    if "hour" in f:
        return DurationBucket.H1
    if "day" in f or "daily" in f:
        return DurationBucket.DAILY
    if "week" in f:
        return DurationBucket.WEEKLY
    if "month" in f:
        return DurationBucket.MONTHLY
    if "quarter" in f:
        return DurationBucket.QUARTERLY
    if "year" in f or "annual" in f:
        return DurationBucket.LONG
    return DurationBucket.UNKNOWN


def classify(m: MarketInfo, series_frequency: str = "") -> DurationInfo:
    d = m.listing_duration
    b = bucket_for(d)
    freq_b = bucket_from_frequency(series_frequency)
    cad = freq_b if freq_b is not DurationBucket.UNKNOWN else cadence_from_series(m.series_ticker)
    structure = m.structure
    # 15-minute / hourly up-down series: a single-strike window whose YES is "at or
    # above a stamped target" is an UP_DOWN_WINDOW rather than a ladder leg.
    if cad in (DurationBucket.M15, DurationBucket.ULTRA_SHORT, DurationBucket.M30) and \
            structure is ContractStructure.THRESHOLD_ABOVE:
        structure = ContractStructure.UP_DOWN_WINDOW
    # Daily/weekly ladders are often *listed* well before their observation window;
    # a 'D' series with a multi-day listing is still a daily-observation contract.
    disagreement = cad is not DurationBucket.UNKNOWN and b is not DurationBucket.UNKNOWN and cad != b
    if freq_b is not DurationBucket.UNKNOWN:
        bucket = freq_b                     # Kalshi's own cadence wins
    else:
        bucket = cad if (disagreement and cad in (DurationBucket.DAILY, DurationBucket.WEEKLY, DurationBucket.MONTHLY,
                                                  DurationBucket.QUARTERLY, DurationBucket.LONG)
                         and b.value not in ("<=5m", "15m", "30m", "1h")) else b
    return DurationInfo(bucket, cad, d.total_seconds() / 60.0 if d else None, structure, disagreement)
