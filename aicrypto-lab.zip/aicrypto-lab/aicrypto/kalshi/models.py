"""Typed models for Kalshi series / markets with exact integer arithmetic.

Units
-----
Prices  : int in units of $0.0001 ("p4"). "0.5600" -> 5600. $1.00 -> 10000.
Counts  : int in hundredths of a contract ("c2"). "300.00" -> 30000.
These mirror Kalshi's fixed-point strings (`*_dollars` 4 dp, `*_fp` 2 dp) exactly,
so no float ever touches a price or quantity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_EVEN
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

ONE_DOLLAR_P4 = 10_000
ONE_CONTRACT_C2 = 100


def dollars_to_p4(s: Any) -> Optional[int]:
    if s is None or s == "":
        return None
    d = Decimal(str(s)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_EVEN)
    return int(d * ONE_DOLLAR_P4)


def p4_to_dollars(p4: int) -> str:
    return f"{Decimal(p4) / ONE_DOLLAR_P4:.4f}"


def fp_to_c2(s: Any) -> Optional[int]:
    if s is None or s == "":
        return None
    d = Decimal(str(s)).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
    return int(d * ONE_CONTRACT_C2)


def c2_to_fp(c2: int) -> str:
    return f"{Decimal(c2) / ONE_CONTRACT_C2:.2f}"


def parse_ts(s: Any) -> Optional[datetime]:
    if not s:
        return None
    if isinstance(s, (int, float)):
        return datetime.fromtimestamp(float(s), tz=timezone.utc)
    txt = str(s).replace("Z", "+00:00")
    dt = datetime.fromisoformat(txt)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


class MarketStatus(str, Enum):
    INITIALIZED = "initialized"
    INACTIVE = "inactive"
    ACTIVE = "active"
    CLOSED = "closed"
    DETERMINED = "determined"
    DISPUTED = "disputed"
    AMENDED = "amended"
    FINALIZED = "finalized"
    UNKNOWN = "unknown"

    @classmethod
    def parse(cls, v: Any) -> "MarketStatus":
        try:
            return cls(str(v).lower())
        except ValueError:
            # Kalshi's list endpoint also uses 'open'/'settled' in filters/legacy payloads
            return {"open": cls.ACTIVE, "settled": cls.FINALIZED}.get(str(v).lower(), cls.UNKNOWN)

    @property
    def is_tradeable(self) -> bool:
        return self is MarketStatus.ACTIVE

    @property
    def is_terminal(self) -> bool:
        return self in (MarketStatus.DETERMINED, MarketStatus.FINALIZED, MarketStatus.AMENDED)


class StrikeType(str, Enum):
    GREATER = "greater"
    GREATER_OR_EQUAL = "greater_or_equal"
    LESS = "less"
    LESS_OR_EQUAL = "less_or_equal"
    BETWEEN = "between"
    FUNCTIONAL = "functional"
    CUSTOM = "custom"
    STRUCTURED = "structured"
    UNKNOWN = "unknown"

    @classmethod
    def parse(cls, v: Any) -> "StrikeType":
        try:
            return cls(str(v).lower()) if v else cls.UNKNOWN
        except ValueError:
            return cls.UNKNOWN


class ContractStructure(str, Enum):
    """How the YES condition is formed. Derived from strike fields + series naming."""
    UP_DOWN_WINDOW = "up_down_window"      # 15M-style: end-of-window avg >= start-of-window avg (target stamped)
    THRESHOLD_ABOVE = "threshold_above"    # price >= / > strike at observation time (ladder leg)
    THRESHOLD_BELOW = "threshold_below"
    RANGE = "range"                        # floor <= price <= cap
    OTHER = "other"


@dataclass(frozen=True)
class SettlementSource:
    name: str
    url: str = ""


@dataclass
class SeriesInfo:
    ticker: str
    title: str = ""
    category: str = ""
    categories: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    frequency: str = ""
    settlement_sources: List[SettlementSource] = field(default_factory=list)
    fee_type: str = "quadratic"
    fee_multiplier: float = 1.0
    contract_url: str = ""
    contract_terms_url: str = ""
    additional_prohibitions: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_api(cls, d: Dict[str, Any]) -> "SeriesInfo":
        d = d.get("series", d)
        return cls(
            ticker=d["ticker"], title=d.get("title", ""), category=d.get("category", "") or "",
            categories=list(d.get("categories") or []), tags=list(d.get("tags") or []),
            frequency=d.get("frequency", "") or "",
            settlement_sources=[SettlementSource(x.get("name", ""), x.get("url", "")) for x in (d.get("settlement_sources") or [])],
            fee_type=d.get("fee_type", "quadratic") or "quadratic", fee_multiplier=float(d.get("fee_multiplier", 1.0) or 1.0),
            contract_url=d.get("contract_url", "") or "", contract_terms_url=d.get("contract_terms_url", "") or "",
            additional_prohibitions=list(d.get("additional_prohibitions") or []), raw=d,
        )


def series_ticker_of(market_ticker: str) -> str:
    return market_ticker.split("-", 1)[0]


def event_ticker_of(market_ticker: str) -> str:
    parts = market_ticker.split("-")
    return "-".join(parts[:2]) if len(parts) >= 2 else market_ticker


@dataclass
class MarketInfo:
    ticker: str
    event_ticker: str
    series_ticker: str
    market_type: str
    status: MarketStatus
    title: str
    yes_sub_title: str
    strike_type: StrikeType
    floor_strike: Optional[Decimal]
    cap_strike: Optional[Decimal]
    open_time: Optional[datetime]
    close_time: Optional[datetime]
    expected_expiration_time: Optional[datetime]
    settlement_timer_seconds: int
    can_close_early: bool
    rules_primary: str
    rules_secondary: str
    yes_bid_p4: Optional[int]
    yes_ask_p4: Optional[int]
    no_bid_p4: Optional[int]
    no_ask_p4: Optional[int]
    yes_bid_size_c2: Optional[int]
    yes_ask_size_c2: Optional[int]
    last_price_p4: Optional[int]
    volume_c2: int
    volume_24h_c2: int
    open_interest_c2: int
    tick_p4: int
    notional_p4: int
    result: str
    settlement_value_p4: Optional[int]
    settlement_ts: Optional[datetime]
    expiration_value: str
    is_provisional: bool
    raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_api(cls, d: Dict[str, Any]) -> "MarketInfo":
        d = d.get("market", d)
        ranges = d.get("price_ranges") or []
        tick = min((dollars_to_p4(r.get("step")) for r in ranges if r.get("step")), default=100)  # default 1c
        def dec(v):
            return None if v is None or v == "" else Decimal(str(v))
        return cls(
            ticker=d["ticker"], event_ticker=d.get("event_ticker") or event_ticker_of(d["ticker"]),
            series_ticker=d.get("series_ticker") or series_ticker_of(d["ticker"]),
            market_type=(d.get("market_type") or "binary").lower(), status=MarketStatus.parse(d.get("status")),
            title=d.get("title", "") or "", yes_sub_title=d.get("yes_sub_title", "") or "",
            strike_type=StrikeType.parse(d.get("strike_type")), floor_strike=dec(d.get("floor_strike")), cap_strike=dec(d.get("cap_strike")),
            open_time=parse_ts(d.get("open_time")), close_time=parse_ts(d.get("close_time")),
            expected_expiration_time=parse_ts(d.get("expected_expiration_time") or d.get("expiration_time")),
            settlement_timer_seconds=int(d.get("settlement_timer_seconds") or 0), can_close_early=bool(d.get("can_close_early", False)),
            rules_primary=d.get("rules_primary", "") or "", rules_secondary=d.get("rules_secondary", "") or "",
            yes_bid_p4=dollars_to_p4(d.get("yes_bid_dollars")), yes_ask_p4=dollars_to_p4(d.get("yes_ask_dollars")),
            no_bid_p4=dollars_to_p4(d.get("no_bid_dollars")), no_ask_p4=dollars_to_p4(d.get("no_ask_dollars")),
            yes_bid_size_c2=fp_to_c2(d.get("yes_bid_size_fp")), yes_ask_size_c2=fp_to_c2(d.get("yes_ask_size_fp")),
            last_price_p4=dollars_to_p4(d.get("last_price_dollars")),
            volume_c2=fp_to_c2(d.get("volume_fp")) or 0, volume_24h_c2=fp_to_c2(d.get("volume_24h_fp")) or 0,
            open_interest_c2=fp_to_c2(d.get("open_interest_fp")) or 0, tick_p4=tick,
            notional_p4=dollars_to_p4(d.get("notional_value_dollars")) or ONE_DOLLAR_P4,
            result=d.get("result", "") or "", settlement_value_p4=dollars_to_p4(d.get("settlement_value_dollars")),
            settlement_ts=parse_ts(d.get("settlement_ts")), expiration_value=str(d.get("expiration_value", "") or ""),
            is_provisional=bool(d.get("is_provisional", False)), raw=d,
        )

    # ---- derived ------------------------------------------------------------
    @property
    def spread_p4(self) -> Optional[int]:
        if self.yes_bid_p4 is None or self.yes_ask_p4 is None:
            return None
        return self.yes_ask_p4 - self.yes_bid_p4

    @property
    def listing_duration(self):
        if self.open_time and self.close_time:
            return self.close_time - self.open_time
        return None

    @property
    def structure(self) -> ContractStructure:
        st = self.strike_type
        if st in (StrikeType.GREATER, StrikeType.GREATER_OR_EQUAL):
            # 15M windows are also 'greater_or_equal' against a stamped target; the
            # series naming tells them apart (handled in durations.classify).
            return ContractStructure.THRESHOLD_ABOVE
        if st in (StrikeType.LESS, StrikeType.LESS_OR_EQUAL):
            return ContractStructure.THRESHOLD_BELOW
        if st is StrikeType.BETWEEN:
            return ContractStructure.RANGE
        return ContractStructure.OTHER

    def yes_condition(self) -> str:
        """Human-readable settlement condition derived from strike fields (for logs/UI)."""
        op = {StrikeType.GREATER: ">", StrikeType.GREATER_OR_EQUAL: ">=", StrikeType.LESS: "<", StrikeType.LESS_OR_EQUAL: "<="}.get(self.strike_type)
        if op and self.floor_strike is not None:
            return f"value {op} {self.floor_strike}"
        if op and self.cap_strike is not None:
            return f"value {op} {self.cap_strike}"
        if self.strike_type is StrikeType.BETWEEN:
            return f"{self.floor_strike} <= value <= {self.cap_strike}"
        return f"{self.strike_type.value}: {self.yes_sub_title}"
