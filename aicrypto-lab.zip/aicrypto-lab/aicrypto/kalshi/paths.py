"""Runtime request allowlist for the Kalshi REST/WebSocket client (Phase 3 uses it).

Source-code token scans are a tripwire, not a control. This module is the control:
every outbound request is checked against an explicit allowlist of (method, path)
patterns *before* it is signed or sent. Anything else — order placement, amendment,
cancellation, batch orders, order groups, RFQ/quotes, API-key management, FIX — is
refused with `RequestNotAllowed`, and refused attempts are counted so the Safety tab
can show them.

WebSocket subscriptions are checked the same way: only market-data channels.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple
from urllib.parse import urlsplit

API_PREFIX = "/trade-api/v2"
WS_PATH = "/trade-api/ws/v2"


class RequestNotAllowed(PermissionError):
    pass


# (METHOD, compiled path regex) — read-only market data + own rate-limit lookup.
_ALLOWED: List[Tuple[str, re.Pattern]] = [
    ("GET", re.compile(r"^/series$")),
    ("GET", re.compile(r"^/series/[A-Z0-9_.-]+$")),
    ("GET", re.compile(r"^/series/fee_changes$")),
    ("GET", re.compile(r"^/events$")),
    ("GET", re.compile(r"^/events/[A-Z0-9_.-]+$")),
    ("GET", re.compile(r"^/events/[A-Z0-9_.-]+/metadata$")),
    ("GET", re.compile(r"^/events/[A-Z0-9_.-]+/fee_changes$")),
    ("GET", re.compile(r"^/markets$")),
    ("GET", re.compile(r"^/markets/[A-Z0-9_.-]+$")),
    ("GET", re.compile(r"^/markets/[A-Z0-9_.-]+/orderbook$")),
    ("GET", re.compile(r"^/markets/orderbooks$")),
    ("GET", re.compile(r"^/markets/[A-Z0-9_.-]+/candlesticks$")),
    ("GET", re.compile(r"^/markets/candlesticks$")),
    ("GET", re.compile(r"^/markets/trades$")),
    ("GET", re.compile(r"^/historical/(cutoff|markets|trades)$")),
    ("GET", re.compile(r"^/historical/markets/[A-Z0-9_.-]+(/candlesticks)?$")),
    ("GET", re.compile(r"^/exchange/(status|schedule|announcements)$")),
    ("GET", re.compile(r"^/account/limits$")),
    ("GET", re.compile(r"^/account/endpoint_costs$")),
]

# Patterns that are refused even if a future allowlist edit accidentally matched them.
_HARD_DENY = re.compile(r"/portfolio/|/orders|/order_groups|/rfq|/quotes|/api_keys|/block_trade|/margin|/perps|/fix", re.I)

ALLOWED_WS_CHANNELS = frozenset({
    "orderbook_delta", "ticker", "trade", "market_lifecycle_v2", "market_lifecycle", "event_lifecycle",
    "cfbenchmarks_value", "cfbenchmarks_value_5hz", "pyth_value",
})
ALLOWED_WS_COMMANDS = frozenset({"subscribe", "unsubscribe", "update_subscription", "list_subscriptions"})


@dataclass
class AllowlistStats:
    allowed: int = 0
    refused: int = 0
    refused_examples: List[str] = field(default_factory=list)


class RequestAllowlist:
    def __init__(self):
        self.stats = AllowlistStats()

    @staticmethod
    def normalise(path: str) -> str:
        """Strip scheme/host/query/fragment and the API prefix; collapse '//' and resolve '..'
        so that traversal tricks cannot smuggle a write path past the regexes."""
        p = urlsplit(path).path if "://" in path else path.split("?", 1)[0].split("#", 1)[0]
        p = re.sub(r"/{2,}", "/", p)
        parts: List[str] = []
        for seg in p.split("/"):
            if seg in ("", "."):
                continue
            if seg == "..":
                if parts:
                    parts.pop()
                continue
            parts.append(seg)
        p = "/" + "/".join(parts)
        if p.startswith(API_PREFIX):
            p = p[len(API_PREFIX):] or "/"
        return p

    def check_rest(self, method: str, path: str) -> str:
        """Return the normalised path if allowed, else raise RequestNotAllowed."""
        m = method.upper()
        norm = self.normalise(path)
        if m != "GET" or _HARD_DENY.search(norm) or _HARD_DENY.search(path):
            return self._refuse(f"{m} {path}")
        for am, rx in _ALLOWED:
            if am == m and rx.match(norm):
                self.stats.allowed += 1
                return norm
        return self._refuse(f"{m} {path}")

    def check_ws_command(self, message: Dict) -> Dict:
        cmd = str(message.get("cmd", ""))
        if cmd not in ALLOWED_WS_COMMANDS:
            return self._refuse(f"ws cmd {cmd!r}")
        params = message.get("params", {}) or {}
        for ch in params.get("channels", []) or []:
            if ch not in ALLOWED_WS_CHANNELS:
                return self._refuse(f"ws channel {ch!r}")
        if "orders" in json_lower(message) or "order_group" in json_lower(message):
            return self._refuse(f"ws payload mentions orders: {cmd}")
        self.stats.allowed += 1
        return message

    def _refuse(self, what: str):
        self.stats.refused += 1
        if len(self.stats.refused_examples) < 20:
            self.stats.refused_examples.append(what)
        raise RequestNotAllowed(f"refused by paper-only allowlist: {what}")


def json_lower(obj) -> str:
    import json
    return json.dumps(obj, sort_keys=True).lower()
