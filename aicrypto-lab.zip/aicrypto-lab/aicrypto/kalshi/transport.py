"""The ONLY HTTP transport in the Kalshi package.

Every request passes through `GuardedTransport.request()`, which:
  1. checks (method, path) against the runtime allowlist *before* building the URL,
  2. rate-limits,
  3. signs (if a signer is present) with the normalised path,
  4. sends with retries/backoff for 429 / 5xx / connection errors,
  5. never logs auth headers.

No other module in `aicrypto.kalshi` may import httpx, requests, urllib or aiohttp;
`tests/test_kalshi_transport.py::test_transport_is_the_only_http_import` enforces that.
The constructor refuses a base URL that is not one of the known Kalshi hosts.
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import httpx

from .auth import API_PREFIX, HOSTS, PUBLIC_REST, KalshiSigner, redact_headers
from .paths import RequestAllowlist, RequestNotAllowed
from .ratelimit import TokenBucket

log = logging.getLogger("aicrypto.kalshi.transport")

KNOWN_BASES = {v["rest"] for v in HOSTS.values()} | set(PUBLIC_REST.values())


class TransportError(RuntimeError):
    pass


class RateLimited(TransportError):
    pass


@dataclass
class TransportStats:
    requests: int = 0
    retries: int = 0
    rate_limited: int = 0
    refused: int = 0
    server_errors: int = 0
    last_status: Optional[int] = None
    bytes_in: int = 0
    latencies_ms: list = field(default_factory=list)


class GuardedTransport:
    def __init__(self, base_url: str, signer: Optional[KalshiSigner] = None, *, requests_per_second: float = 5.0,
                 timeout_s: float = 10.0, max_retries: int = 4, allowlist: Optional[RequestAllowlist] = None,
                 http_transport: Optional[httpx.AsyncBaseTransport] = None, user_agent: str = "aicrypto-lab-paper/0.1",
                 priority: Optional[str] = None, shared_budget=None):
        base_url = base_url.rstrip("/")
        if base_url not in KNOWN_BASES:
            raise TransportError(f"refusing unknown base URL {base_url!r}")
        self.base_url = base_url
        self.signer = signer
        self.allowlist = allowlist or RequestAllowlist()
        self.bucket = TokenBucket(tokens_per_second=requests_per_second * 10.0, burst_seconds=1.0, cost_per_request=10.0)
        # The real exchange's public data is one quota for the whole machine: every process draws from the
        # same file-backed budget, the recorder first (see ratebudget.py).
        self.priority = priority or "normal"
        if shared_budget is None and base_url == PUBLIC_REST["production"]:
            from .ratebudget import shared
            shared_budget = shared()
        self.shared = shared_budget
        self.max_retries = max_retries
        self.stats = TransportStats()
        self._client = httpx.AsyncClient(timeout=timeout_s, transport=http_transport, headers={"User-Agent": user_agent, "Accept": "application/json"})

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.aclose()

    # ---- the single entry point --------------------------------------------------------
    async def request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        try:
            norm = self.allowlist.check_rest(method, path)   # raises RequestNotAllowed
        except RequestNotAllowed:
            self.stats.refused += 1
            raise
        if method.upper() != "GET":  # belt and braces: allowlist already enforces GET-only
            self.stats.refused += 1
            raise RequestNotAllowed(f"transport is read-only; {method} refused")
        full_path = API_PREFIX + norm
        url = self.base_url + norm
        query = {k: v for k, v in (params or {}).items() if v is not None}
        attempt = 0
        while True:
            if self.shared is not None:
                await self.shared.acquire(self.priority)
            await self.bucket.acquire()
            headers = self.signer.headers("GET", full_path) if self.signer else {}
            t0 = asyncio.get_event_loop().time()
            try:
                resp = await self._client.get(url, params=query, headers=headers)
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                attempt += 1
                self.stats.retries += 1
                if attempt > self.max_retries:
                    raise TransportError(f"network error after {attempt} attempts: {type(exc).__name__}") from None
                await asyncio.sleep(self._backoff(attempt))
                continue
            dt = (asyncio.get_event_loop().time() - t0) * 1000.0
            self.stats.requests += 1
            self.stats.last_status = resp.status_code
            self.stats.latencies_ms.append(dt)
            if len(self.stats.latencies_ms) > 1000:
                del self.stats.latencies_ms[:500]
            self.stats.bytes_in += len(resp.content)
            log.debug("GET %s %s -> %s in %.1fms headers=%s", norm, urlencode(query), resp.status_code, dt, redact_headers(headers))
            if resp.status_code == 429:
                self.stats.rate_limited += 1
                if self.shared is not None:
                    self.shared.report_429(self.priority)
                attempt += 1
                if attempt > self.max_retries:
                    raise RateLimited(f"429 after {attempt} attempts for {norm}")
                retry_after = resp.headers.get("Retry-After")
                await asyncio.sleep(float(retry_after) if retry_after and retry_after.replace(".", "", 1).isdigit() else self._backoff(attempt))
                continue
            if 500 <= resp.status_code < 600:
                self.stats.server_errors += 1
                attempt += 1
                if attempt > self.max_retries:
                    raise TransportError(f"server error {resp.status_code} for {norm}")
                await asyncio.sleep(self._backoff(attempt))
                continue
            if self.shared is not None and resp.status_code < 400:
                self.shared.report_ok()
            if resp.status_code >= 400:
                raise TransportError(f"HTTP {resp.status_code} for {norm}: {resp.text[:200]}")
            try:
                return resp.json()
            except json.JSONDecodeError:
                raise TransportError(f"non-JSON response for {norm}")

    @staticmethod
    def _backoff(attempt: int) -> float:
        return min(30.0, 0.5 * (2 ** (attempt - 1))) * (0.7 + 0.6 * random.random())


def run_sync(coro):
    """Run a coroutine from synchronous CLI code."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    raise RuntimeError("run_sync called inside a running event loop")
