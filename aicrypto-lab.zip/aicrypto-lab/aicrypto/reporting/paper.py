"""Read Freqtrade's dry-run trade database (read-only)."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

from ..settings import Settings


@dataclass
class PaperSummary:
    db_path: str
    available: bool
    starting_balance: float
    closed_trades: int = 0
    open_trades: int = 0
    realized_pnl: float = 0.0
    win_rate: float = 0.0
    max_drawdown: float = 0.0
    equity_curve: List[Dict[str, Any]] = field(default_factory=list)  # [{t, equity}]
    open_positions: List[Dict[str, Any]] = field(default_factory=list)
    recent_closed: List[Dict[str, Any]] = field(default_factory=list)
    strategies: List[str] = field(default_factory=list)
    note: str = ""


def read_paper_trades(settings: Settings, db_path: Path | None = None, recent: int = 20) -> PaperSummary:
    db = db_path or settings.path("user_data") / "tradesv3.dryrun.sqlite"
    start = settings.capital.starting_balance
    if not db.exists():
        return PaperSummary(str(db), False, start, note="no dry-run database yet (bot not started)")
    uri = f"file:{db}?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        closed = [dict(r) for r in con.execute(
            "SELECT id, pair, strategy, open_date, close_date, open_rate, close_rate, stake_amount, "
            "close_profit, close_profit_abs, exit_reason, leverage, is_short FROM trades WHERE is_open=0 ORDER BY close_date")]
        opened = [dict(r) for r in con.execute(
            "SELECT id, pair, strategy, open_date, open_rate, stake_amount, amount, stop_loss, leverage, is_short "
            "FROM trades WHERE is_open=1 ORDER BY open_date")]
    except sqlite3.OperationalError as exc:
        return PaperSummary(str(db), False, start, note=f"unreadable: {exc}")
    finally:
        con.close()

    # paper-only invariants: spot long only
    assert all((t.get("leverage") or 1.0) <= 1.0 and not t.get("is_short") for t in closed + opened), \
        "non-spot trade found in dry-run db"

    eq = start
    curve = [{"t": None, "equity": start}]
    peak, mdd = start, 0.0
    wins = 0
    for t in closed:
        pnl = float(t["close_profit_abs"] or 0.0)
        eq += pnl
        wins += pnl > 0
        peak = max(peak, eq)
        mdd = max(mdd, 1 - eq / peak if peak > 0 else 0.0)
        curve.append({"t": t["close_date"], "equity": round(eq, 4)})
    return PaperSummary(
        db_path=str(db), available=True, starting_balance=start, closed_trades=len(closed), open_trades=len(opened),
        realized_pnl=round(eq - start, 4), win_rate=(wins / len(closed)) if closed else 0.0, max_drawdown=mdd,
        equity_curve=curve, open_positions=opened, recent_closed=closed[-recent:],
        strategies=sorted({t["strategy"] for t in closed + opened if t.get("strategy")}),
    )
