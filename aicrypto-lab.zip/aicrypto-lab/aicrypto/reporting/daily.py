"""Daily Markdown report: research activity, promotion gate outcomes, paper P&L,
data health, safety attestation. Wording deliberately avoids profitability claims."""
from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List

from .. import safety
from ..data import fingerprint, load_ohlcv, DataIntegrityError
from ..experiments import Tracker
from ..settings import Settings
from .paper import read_paper_trades

DISCLAIMER = (
    "> **Read this first.** Every figure below describes *simulated* behaviour on *past* data under a "
    "modelled cost assumption (fee {fee:.2%} per side, slippage {slip} bps per side). Passing the promotion "
    "gates means a candidate was **not rejected** by these checks; it is not evidence that it is profitable "
    "or will be. No real funds are connected and no code path in this system can place a live order."
)


def _pct(x: float) -> str:
    return f"{x:+.2%}"


def data_health(settings: Settings) -> List[Dict]:
    rows = []
    data_dir = settings.path("user_data") / "data" / settings.markets.exchange
    for tf in settings.markets.timeframes:
        for pair in settings.markets.pairs:
            try:
                df = load_ohlcv(data_dir, pair, tf)
                fp = fingerprint(df, pair, tf)
                age_h = (time.time() - df["date"].iloc[-1].timestamp()) / 3600
                rows.append({"pair": pair, "tf": tf, "rows": fp.rows, "last": fp.end[:16], "age_h": round(age_h, 1), "ok": True, "note": ""})
            except FileNotFoundError:
                rows.append({"pair": pair, "tf": tf, "rows": 0, "last": "", "age_h": None, "ok": False, "note": "missing"})
            except DataIntegrityError as exc:
                rows.append({"pair": pair, "tf": tf, "rows": 0, "last": "", "age_h": None, "ok": False, "note": str(exc)[:60]})
    return rows


def build_daily_report(settings: Settings, tracker: Tracker, day: str | None = None) -> str:
    day = day or time.strftime("%Y-%m-%d")
    lines: List[str] = [f"# aicrypto-lab daily report — {day}", ""]
    lines.append(DISCLAIMER.format(fee=settings.costs.fee_pct, slip=settings.costs.slippage_bps))
    lines.append("")

    # Safety
    reps = safety.scan_configs(settings.path("user_data"))
    compose = settings.root / "docker-compose.yml"
    compose_ok = compose.exists() and safety.compose_is_dry_run(compose.read_text())
    lines += ["## Safety attestation", ""]
    lines.append(f"- Configs scanned: {len(reps)}; all paper-only: **{'yes' if all(r.ok for r in reps) else 'NO — see below'}**")
    for r in reps:
        if not r.ok:
            lines.append(f"  - ⚠ {r.path}: {'; '.join(r.problems)}")
    lines.append(f"- docker-compose forces `--dry-run`: **{'yes' if compose_ok else 'NO'}**")
    lines.append("- Lifecycle states in use: CANDIDATE / VALIDATED / PAPER / RETIRED (no live state exists)")
    lines.append("")

    # Research activity
    summ = tracker.summary()
    sessions = tracker.sessions(5)
    lines += ["## Research activity", ""]
    lines.append(f"- Total runs: {summ['runs']}  ·  passed all gates: {summ['runs_passed']}")
    lines.append(f"- Lifecycle: " + ", ".join(f"{k} {v}" for k, v in summ["lifecycle"].items()))
    if sessions:
        lines.append("")
        lines.append("| session | started | candidates | passed |")
        lines.append("|---|---|---|---|")
        for s in sessions:
            lines.append(f"| {s['session_id']} | {time.strftime('%Y-%m-%d %H:%M', time.localtime(s['started_at']))} | {s['candidates']} | {s['passed']} |")
    lines.append("")

    # Best recent runs (by OOS Sharpe) — labelled as descriptive, not predictive
    runs = tracker.list_runs(limit=500)
    ranked = sorted([r for r in runs if r["n_folds"] > 0], key=lambda r: -r["oos_sharpe"])[:10]
    lines += ["## Top walk-forward candidates (descriptive, out-of-sample on past data)", ""]
    if ranked:
        lines.append("| spec | family | tf | OOS Sharpe | OOS return | OOS max DD | trades | folds + | gates |")
        lines.append("|---|---|---|---|---|---|---|---|---|")
        for r in ranked:
            lines.append(
                f"| `{r['spec_hash']}` | {r['family']} | {r['timeframe']} | {r['oos_sharpe']:.2f} | {_pct(r['oos_return'])} | "
                f"{r['oos_max_dd']:.1%} | {r['oos_trades']} | {r['positive_fold_fraction']:.0%} | "
                f"{'pass' if r['gates_passed'] else 'fail'} |")
    else:
        lines.append("_No walk-forward runs yet._")
    lines.append("")

    # Paper trading
    paper = read_paper_trades(settings)
    lines += ["## Paper trading (Freqtrade dry-run)", ""]
    if not paper.available:
        lines.append(f"_Not available: {paper.note}_")
    else:
        lines.append(f"- Strategies: {', '.join(paper.strategies) or '—'}")
        lines.append(f"- Closed trades: {paper.closed_trades}  ·  open: {paper.open_trades}")
        lines.append(f"- Simulated realized P&L: {paper.realized_pnl:+.2f} {settings.capital.stake_currency} "
                     f"on {paper.starting_balance:.0f} starting (win rate {paper.win_rate:.0%}, max DD {paper.max_drawdown:.1%})")
        if paper.open_positions:
            lines.append("")
            lines.append("| pair | opened | stake | stop |")
            lines.append("|---|---|---|---|")
            for t in paper.open_positions:
                lines.append(f"| {t['pair']} | {str(t['open_date'])[:16]} | {t['stake_amount']:.2f} | {t['stop_loss']:.4f} |")
    lines.append("")

    # Data health
    lines += ["## Data health", ""]
    rows = data_health(settings)
    if rows:
        lines.append("| pair | tf | rows | last candle (UTC) | age (h) | status |")
        lines.append("|---|---|---|---|---|---|")
        for r in rows:
            lines.append(f"| {r['pair']} | {r['tf']} | {r['rows']} | {r['last']} | {r['age_h'] if r['age_h'] is not None else '—'} | "
                         f"{'ok' if r['ok'] else '⚠ ' + r['note']} |")
    lines.append("")
    lines.append("## Resource bounds in force")
    b = settings.budget
    lines.append(f"- research: ≤{b.max_candidates} candidates / ≤{b.max_minutes:g} min per session, {b.workers} worker, "
                 f"soft memory {b.soft_memory_gb:g} GB; history ≤{settings.markets.history_days} days; Freqtrade container 2 GB")
    lines.append("")
    return "\n".join(lines)


def write_daily_report(settings: Settings, tracker: Tracker, day: str | None = None) -> Path:
    day = day or time.strftime("%Y-%m-%d")
    out = settings.path("reports")
    out.mkdir(parents=True, exist_ok=True)
    p = out / f"daily-{day}.md"
    p.write_text(build_daily_report(settings, tracker, day), encoding="utf-8")
    (out / "latest.md").write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    return p
