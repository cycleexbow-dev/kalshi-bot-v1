"""Discover, classify and rate every asset x contract duration on the real exchange (read-only).

    python -m aicrypto.timeframes discover     # ~1,650 series, a few minutes at 4 requests/s
    python -m aicrypto.timeframes report       # print the latest registry

Output: user_data/kalshi/timeframes/registry.json plus a dated copy (reproducibility).
"""
from __future__ import annotations

import asyncio
import json
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..kalshi.eligibility import Tier, evaluate
from ..kalshi.models import MarketInfo, SeriesInfo

CATEGORIES = ("Crypto", "Commodities", "Financials")
PRIORITY = {"crypto": ["BTC", "ETH", "SOL", "XRP", "DOGE"], "commodity": ["GOLD", "SILVER", "COPPER", "WTI"]}
BUCKET_ORDER = ["<=5m", "15m", "30m", "1h", "multi_hour", "daily", "weekly", "monthly", "quarterly", "longer", "unknown"]


def registry_dir(root: Path) -> Path:
    d = Path(root) / "user_data" / "kalshi" / "timeframes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _f(x: Any) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def summarize_markets(raws: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Liquidity of a set of open markets from the list endpoint (top of book only)."""
    spreads, two_sided, vol, oi = [], 0, 0.0, 0.0
    closes = []
    for m in raws:
        b, a = _f(m.get("yes_bid_dollars")), _f(m.get("yes_ask_dollars"))
        if b and a and 0 < b < a < 1:
            two_sided += 1
            spreads.append(a - b)
        vol += _f(m.get("volume_24h_fp")) or 0.0
        oi += _f(m.get("open_interest_fp")) or 0.0
        if m.get("close_time"):
            closes.append(m["close_time"])
    return {"open_markets": len(raws), "two_sided": two_sided, "median_spread": statistics.median(spreads) if spreads else None,
            "volume_24h": round(vol, 2), "open_interest": round(oi, 2), "next_close": min(closes) if closes else None}


def rate(asset_class: str, bucket: str, reference_status: str, recorded: Dict[str, Any]) -> Dict[str, Any]:
    """Data-quality grade and which research methods the recorded data can support today.

    A: 1 s quotes + order-book depth + the settlement index recorded (execution-realistic research)
    B: 1-minute top-of-book quotes + settlements; settlement index recorded (crypto) -> probability-model research,
       exploratory fills only
    C: 1-minute quotes + settlements, but no validated settlement reference recorded (e.g. commodities, Pyth off)
       -> market-price-only research
    D: not recorded
    """
    stream = recorded.get("stream")
    if not stream:
        return {"grade": "D", "supports": [], "missing": ["not recorded"]}
    crypto_index = asset_class == "crypto"
    if stream == "kalshi_real" and crypto_index:
        return {"grade": "A", "supports": ["probability models", "final-minute models", "execution-realistic fills"], "missing": []}
    if crypto_index:
        return {"grade": "B", "supports": ["probability models vs market prices", "exploratory fills"],
                "missing": ["order-book depth", "sub-minute quotes (needed for realistic fills)"]}
    return {"grade": "C", "supports": ["market-price-only models"],
            "missing": ["validated settlement reference (Pyth feed is off by owner decision)", "order-book depth"]
            + (["sub-minute quotes"] if stream == "kalshi_real_long" else [])}


def recorded_streams(root: Optional[Path] = None) -> Dict[str, Dict[str, Any]]:
    """Which series the recorder covers, and how (the hourly/daily recorder follows the last registry)."""
    from ..recorder.kalshi_real import COMMODITY, CRYPTO, series_for
    from ..recorder.longer import interval_for, series_plan
    out = {series_for(a): {"stream": "kalshi_real", "quotes": "~1 s", "depth": "10 levels"} for a in CRYPTO + COMMODITY}
    for s, p in series_plan(root).items():
        out.setdefault(s, {"stream": "kalshi_real_long", "quotes": f"{int(interval_for(p['bucket']))} s", "depth": "top of book"})
    return out


def recording_days(root: Path) -> Dict[str, int]:
    base = Path(root) / "user_data" / "kalshi" / "recordings" / "real"
    days: Dict[str, set] = defaultdict(set)
    if base.exists():
        for d in base.iterdir():
            for f in d.glob("*.jsonl.gz"):
                days[f.name.rsplit("-", 1)[0]].add(d.name)
    return {k: len(v) for k, v in days.items()}


PRIORITY_PATTERNS = {"BTC": ("BTC", "BITCOIN"), "ETH": ("ETH", "ETHEREUM"), "SOL": ("SOL", "SOLANA"), "XRP": ("XRP",),
                     "DOGE": ("DOGE", "DOGECOIN"), "GOLD": ("GOLD",), "SILVER": ("SILVER",), "COPPER": ("COPPER",),
                     "WTI": ("WTI", "CRUDE", "OIL")}
NON_FINANCIAL_REASONS = {"category_denied", "category_not_allowed", "tag_denied"}
RECHECK_REJECTED_S = 7 * 86400        # unchanged series that were rejected: re-check weekly
RECHECK_EMPTY_S = 86400               # series with nothing open: daily (new events get listed)
CHECKPOINT_EVERY = 25


def _priority_asset(s: SeriesInfo, dec_asset: str) -> Optional[str]:
    if dec_asset in PRIORITY_PATTERNS:
        return dec_asset
    text = f"{s.ticker} {s.title}".upper()
    for a, pats in PRIORITY_PATTERNS.items():
        if any(p in text for p in pats):
            return a
    return None


def _meta_hash(sd: Dict[str, Any]) -> str:
    import hashlib
    keep = {k: sd.get(k) for k in ("ticker", "title", "category", "categories", "tags", "frequency", "settlement_sources",
                                   "fee_type", "fee_multiplier")}
    return hashlib.sha256(json.dumps(keep, sort_keys=True, default=str).encode()).hexdigest()[:16]


async def _get_all(client, path: str, params: Dict[str, Any], key: str, max_pages: int = 50) -> List[Dict[str, Any]]:
    """Every page (cursor pagination): no 200 / 1,000 cap. Rate limits are handled by the transport and the
    shared budget (exponential backoff with jitter); a final failure raises."""
    out: List[Dict[str, Any]] = []
    cursor = None
    for _ in range(max_pages):
        p = dict(params, cursor=cursor) if cursor else dict(params)
        d = await client.transport.request("GET", path, p)
        out += [x for x in (d or {}).get(key, []) if isinstance(x, dict)]
        cursor = (d or {}).get("cursor")
        if not cursor:
            break
    return out


def _series_rows(s: SeriesInfo, decided) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Counter]:
    """Eligible rows by duration, plus priority-asset durations that are listed but not eligible (with reasons)."""
    rows, unsupported, rejected = [], [], Counter()
    ok = [(m, dec) for m, dec in decided if dec.tier is not Tier.REJECTED]
    bad = [(m, dec) for m, dec in decided if dec.tier is Tier.REJECTED]
    for _, dec in bad:
        rejected[",".join(r.value for r in dec.reasons[:2]) or "rejected"] += 1
    by_bucket: Dict[str, List] = defaultdict(list)
    for m, dec in ok:
        by_bucket[dec.duration.bucket.value].append((m, dec))
    for bucket, items in by_bucket.items():
        dec0 = items[0][1]
        horizons = [dec.duration.listing_minutes / 60 for _, dec in items if dec.duration.listing_minutes]
        ev_close: Dict[str, str] = {}
        for m, _ in items:
            ev_close[m.get("event_ticker") or m["ticker"]] = m.get("close_time")
        rows.append({"series": s.ticker, "title": s.title, "frequency": s.frequency, "category": s.category,
                     "asset": dec0.asset, "asset_class": dec0.asset_class, "bucket": bucket,
                     "structures": sorted({dec.duration.structure.value for _, dec in items}),
                     "tiers": dict(Counter(dec.tier.value for _, dec in items)),
                     "reference": {"provider": dec0.reference.provider.value, "instrument": dec0.reference.instrument,
                                   "method": dec0.reference.method.value, "status": dec0.reference.status.value},
                     "events": len(ev_close), "event_closes": sorted(c for c in ev_close.values() if c)[:12],
                     "listing_hours_median": round(statistics.median(horizons), 2) if horizons else None,
                     **summarize_markets([m for m, _ in items])})
    by_b2: Dict[str, List] = defaultdict(list)
    for m, dec in bad:
        reasons = {r.value for r in dec.reasons}
        if reasons & NON_FINANCIAL_REASONS:
            continue                                     # sports, politics, weather, ...: never kept
        a = _priority_asset(s, dec.asset)
        if a:
            by_b2[dec.duration.bucket.value].append((m, dec, a))
    for bucket, items in by_b2.items():
        unsupported.append({"series": s.ticker, "title": s.title, "frequency": s.frequency, "asset": items[0][2], "bucket": bucket,
                            "open_markets": len(items),
                            "reasons": dict(Counter(r.value for _, dec, _ in items for r in dec.reasons).most_common(4))})
    return rows, unsupported, rejected


async def discover(root: Path, ks=None, client=None, progress=print, now: Optional[float] = None, full: bool = False) -> Dict[str, Any]:
    """Incremental, resumable discovery. Results per series are cached in timeframes/cache.json (checkpointed
    every CHECKPOINT_EVERY series). Eligible series are refreshed every run (their markets change); unchanged
    rejected series are re-checked weekly, empty ones daily; failed lookups are always retried."""
    from ..kalshi.settings import load_kalshi_settings
    ks = ks or load_kalshi_settings(root=root)
    now = time.time() if now is None else now
    d = registry_dir(root)
    cache_p = d / "cache.json"
    try:
        cache = json.loads(cache_p.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        cache = {}
    cache.setdefault("series", {})
    own = client is None
    if client is None:
        from ..kalshi.client import KalshiRestClient
        # background priority: draws only spare capacity from the machine-wide budget the recorder relies on
        client = KalshiRestClient("production", signer=None, public=True, requests_per_second=2.0, timeout_s=15.0, max_retries=4,
                                  priority="background")
    stats = Counter()

    def save():
        tmp = cache_p.with_suffix(".tmp")
        tmp.write_text(json.dumps(cache, default=str))
        tmp.replace(cache_p)

    try:
        series: List[Dict[str, Any]] = []
        for cat in CATEGORIES:
            series += await _get_all(client, "/series", {"category": cat}, "series")
        stats["series_listed"] = len(series)
        progress(f"{len(series)} series in {', '.join(CATEGORIES)}")
        for i, sd in enumerate(series):
            if i and i % 200 == 0:
                progress(f"  {i}/{len(series)} series ({stats['checked']} checked, {stats['skipped_cached']} unchanged)")
            t = sd.get("ticker")
            if not t:
                continue
            mh = _meta_hash(sd)
            c = cache["series"].get(t)
            if c and not full and c.get("meta_hash") == mh:
                age = now - c.get("checked_at", 0)
                if (c["status"] == "rejected" and age < RECHECK_REJECTED_S) or (c["status"] == "no_open_markets" and age < RECHECK_EMPTY_S):
                    stats["skipped_cached"] += 1
                    continue
            try:
                s = SeriesInfo.from_api(sd)
            except Exception:
                cache["series"][t] = {"meta_hash": mh, "checked_at": now, "status": "rejected", "rejected": {"series_unparseable": 1}}
                continue
            try:
                raws = await _get_all(client, "/markets", {"series_ticker": s.ticker, "status": "open", "limit": 1000}, "markets")
            except Exception as e:
                cache["series"][t] = {"meta_hash": mh, "checked_at": now, "status": "failed", "error": type(e).__name__}
                stats["failed"] += 1
                continue
            stats["checked"] += 1
            if not raws:
                cache["series"][t] = {"meta_hash": mh, "checked_at": now, "status": "no_open_markets"}
            else:
                decided = []
                for m in raws:
                    try:
                        decided.append((m, evaluate(s, MarketInfo.from_api(m), ks)))
                    except Exception:
                        pass
                rows, unsupported, rej = _series_rows(s, decided)
                cache["series"][t] = {"meta_hash": mh, "checked_at": now, "status": "eligible" if rows else "rejected",
                                      "rows": rows, "unsupported": unsupported, "rejected": dict(rej), "open_markets": len(raws)}
            if stats["checked"] % CHECKPOINT_EVERY == 0:
                save()
        save()
    finally:
        if own:
            await client.aclose()
    return build_registry(root, cache, stats, now)


def build_registry(root: Path, cache: Dict[str, Any], stats: Counter, now: float) -> Dict[str, Any]:
    rows, unsupported, rejected, failed = [], [], Counter(), []
    for t, c in cache["series"].items():
        rows += c.get("rows", [])
        unsupported += c.get("unsupported", [])
        for k, v in (c.get("rejected") or {}).items():
            rejected[k] += v
        if c["status"] == "failed":
            failed.append(t)
        elif c["status"] == "no_open_markets":
            rejected["no_open_markets"] += 1
    rec = recorded_streams(root)
    days = recording_days(root)
    for r in rows:
        cov = rec.get(r["series"], {})
        r["recorded"] = {**cov, "days": days.get(cov.get("stream", ""), 0)} if cov else {}
        r["data_quality"] = rate(r["asset_class"], r["bucket"], r["reference"]["status"], r["recorded"])
        g = r["data_quality"]["grade"]
        r["research_status"] = {"A": "research-ready (execution-realistic)", "B": "research-ready (exploratory)",
                                "C": "market-price-only research", "D": "discoverable, not recorded"}[g]
    out = {"discovered_at": now, "series_checked": len(cache["series"]), "eligible_rows": len(rows), "run": dict(stats),
           "rejected": dict(rejected.most_common(25)), "lookup_failed": failed, "unsupported_priority": unsupported,
           "rows": sorted(rows, key=lambda r: (r["asset_class"], r["asset"], BUCKET_ORDER.index(r["bucket"]) if r["bucket"] in BUCKET_ORDER else 99, r["series"]))}
    d = registry_dir(root)
    (d / "registry.json").write_text(json.dumps(out, indent=1, default=str))
    (d / f"registry-{datetime.fromtimestamp(now, timezone.utc).strftime('%Y%m%d')}.json").write_text(json.dumps(out, default=str))
    return out


def by_asset_timeframe(reg: Dict[str, Any]) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """asset -> bucket -> combined view (series, markets, liquidity, best data grade)."""
    grade_rank = {"A": 0, "B": 1, "C": 2, "D": 3}
    out: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(dict)
    for r in reg.get("rows", []):
        cell = out[r["asset"]].setdefault(r["bucket"], {"series": [], "open_markets": 0, "two_sided": 0, "volume_24h": 0.0, "spreads": [],
                                                        "grade": "D", "asset_class": r["asset_class"], "structures": set(), "recorded_series": 0,
                                                        "tradeable": 0, "record_only": 0})
        cell["tradeable"] += r["tiers"].get("tradeable", 0)
        cell["record_only"] += r["tiers"].get("record_only", 0)
        cell["series"].append(r["series"])
        cell["open_markets"] += r["open_markets"]
        cell["two_sided"] += r["two_sided"]
        cell["volume_24h"] += r["volume_24h"]
        cell["structures"].update(r["structures"])
        if r["median_spread"] is not None:
            cell["spreads"].append(r["median_spread"])
        if r["recorded"]:
            cell["recorded_series"] += 1
        if grade_rank[r["data_quality"]["grade"]] < grade_rank[cell["grade"]]:
            cell["grade"] = r["data_quality"]["grade"]
    for a in out.values():
        for c in a.values():
            c["median_spread"] = statistics.median(c.pop("spreads")) if c.get("spreads") else None
            c["structures"] = sorted(c["structures"])
    return out


def load(root: Path) -> Dict[str, Any]:
    p = registry_dir(root) / "registry.json"
    return json.loads(p.read_text()) if p.exists() else {}


def report(reg: Dict[str, Any], priority_only: bool = False) -> str:
    view = by_asset_timeframe(reg)
    status = {"A": "ready: execution-realistic", "B": "ready: exploratory", "C": "market-price only", "D": "not recorded"}
    lines = [f"discovered {datetime.fromtimestamp(reg['discovered_at']).strftime('%Y-%m-%d %H:%M')} · {reg['series_checked']} series known · "
             f"{reg['eligible_rows']} eligible series x duration rows · this run: {reg.get('run', {})}",
             "asset    duration    series  open  tradeable  record-only  two-sided  24h volume  spread  grade  research status"]
    pri = set(PRIORITY["crypto"] + PRIORITY["commodity"])
    for asset in sorted(view, key=lambda a: (a not in pri, a)):
        if priority_only and asset not in pri:
            continue
        for b in sorted(view[asset], key=lambda b: BUCKET_ORDER.index(b) if b in BUCKET_ORDER else 99):
            c = view[asset][b]
            sp = f"{c['median_spread'] * 100:.1f}pt" if c["median_spread"] is not None else "—"
            lines.append(f"{asset:8} {b:10} {len(c['series']):6d} {c['open_markets']:5d} {c['tradeable']:10d} {c['record_only']:12d} "
                         f"{c['two_sided']:10d} {c['volume_24h']:11.0f} {sp:>7}  {c['grade']:>5}  {status[c['grade']]}")
    un = [u for u in reg.get("unsupported_priority", []) if not priority_only or u["asset"] in pri]
    if un:
        lines.append("listed but not eligible for automated research (priority assets):")
        for u in sorted(un, key=lambda u: (u["asset"], u["bucket"], u["series"])):
            lines.append(f"  {u['asset']:7} {u['bucket']:10} {u['series']:16} {u['open_markets']:4d} markets  reasons: {u['reasons']}")
    if reg.get("lookup_failed"):
        lines.append(f"still unavailable after retries: {reg['lookup_failed']}")
    return "\n".join(lines)
