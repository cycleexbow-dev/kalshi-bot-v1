"""Multi-timeframe research foundation (owner request 2026-11-11, Phase A).

Discovers every financial-market contract duration the REAL exchange actually lists, from official series and
market metadata (read-only, unsigned public client), classifies each with the app's existing eligibility and
duration rules (financial only; sports, politics, weather, entertainment and other non-financial markets are
rejected there), and maps each asset x duration to its series, settlement reference, liquidity, recorder
coverage and a data-quality / research-readiness rating. Nothing here trades or changes any strategy.
"""
