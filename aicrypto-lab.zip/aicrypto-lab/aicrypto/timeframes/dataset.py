"""Research dataset from the hourly backfill, plus a market-calibration baseline (Phase B -> C foundation).

    python -m aicrypto.timeframes calibration [--series KXBTCD,KXETHD,KXSOLD]

Offline: reads user_data/kalshi/timeframes/history only. One row per market per minute in the final hour:
asset, event, strike, minutes left, yes bid/ask (as probabilities 0-1), underlying Coinbase price at that minute,
and the result (1 = Yes won). Rows without a two-sided quote are kept but flagged, never filled in.

The calibration baseline asks: when the market's mid price said X%, how often did Yes actually win? It is the
benchmark any model has to beat. Groups are by asset and by time left. Reported per group: number of
market-minutes, number of distinct events (the honest sample size, since minutes of one event are not
independent), Brier score of the market mid, and a reliability table by 10% bins. No strategy, no fills, no
profitability claim: that is Phase C, with the fixed validation gates.
"""
from __future__ import annotations

import bisect
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .backfill import DEFAULT_SERIES, history_dir, load, strike_point

TIME_GROUPS = ((60, 30), (30, 10), (10, 0))


def _spot_index(root: Path, asset: str):
    f = history_dir(root) / "spot" / f"{asset}_coinbase.json.gz"
    if not f.exists():
        return None
    rows = load(f)                                      # [start, low, high, open, close, volume], ascending
    return [r[0] for r in rows], [r[4] for r in rows]


def _spot_at(idx, ts: float) -> Optional[float]:
    """Close of the last complete Coinbase minute at or before ts (never a later minute)."""
    if not idx:
        return None
    starts, closes = idx
    i = bisect.bisect_right(starts, ts - 60) - 1
    if i < 0 or ts - 60 - starts[i] > 120:
        return None
    return closes[i]


def rows(root: Path, series: Iterable[str] = DEFAULT_SERIES) -> Iterable[Dict[str, Any]]:
    spots: Dict[str, Any] = {}
    for s in series:
        d = history_dir(root) / s
        if not d.exists():
            continue
        for f in sorted(d.glob("*.json.gz")):
            ev = load(f)
            a = ev.get("asset")
            if a not in spots:
                spots[a] = _spot_index(root, a)
            terms = {m["ticker"]: m for m in ev["markets"]}
            for t, cs in ev.get("candles", {}).items():
                m = terms.get(t)
                if not m or m["result"] not in ("yes", "no"):
                    continue
                for c in cs:
                    end = c.get("end")
                    if end is None:
                        continue
                    left = (ev["close_ts"] - end) / 60
                    if left < 0 or left > 60:
                        continue
                    bid, ask = c.get("bid_c"), c.get("ask_c")
                    two_sided = bid is not None and ask is not None and 0 < bid <= ask < 1
                    yield {"asset": a, "series": s, "event": ev["event"], "ticker": t, "strike_type": m["strike_type"],
                           "strike": strike_point(m), "minutes_left": left, "bid": bid, "ask": ask,
                           "mid": (bid + ask) / 2 if two_sided else None, "two_sided": two_sided,
                           "spot": _spot_at(spots[a], end), "settle": ev["settle"], "y": 1 if m["result"] == "yes" else 0}


def calibration(rs: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    groups: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"n": 0, "brier": 0.0, "events": set(), "bins": defaultdict(lambda: [0, 0, 0.0]),
                                                             "one_sided": 0})
    for r in rs:
        tg = next(f"{hi}-{lo} min" for hi, lo in TIME_GROUPS if lo < r["minutes_left"] <= hi or (lo == 0 and r["minutes_left"] == 0))
        for key in (f"{r['asset']} | all", f"{r['asset']} | {tg}", f"ALL | {tg}"):
            g = groups[key]
            if not r["two_sided"]:
                g["one_sided"] += 1
                continue
            p = r["mid"]
            g["n"] += 1
            g["brier"] += (p - r["y"]) ** 2
            g["events"].add(r["event"])
            b = g["bins"][min(9, int(p * 10))]
            b[0] += 1
            b[1] += r["y"]
            b[2] += p
    out = {}
    for k, g in sorted(groups.items()):
        out[k] = {"market_minutes": g["n"], "events": len(g["events"]), "one_sided_skipped": g["one_sided"],
                  "brier": round(g["brier"] / g["n"], 4) if g["n"] else None,
                  "bins": {f"{10 * i}-{10 * i + 10}%": {"n": b[0], "market_said": round(100 * b[2] / b[0], 1),
                                                       "yes_won": round(100 * b[1] / b[0], 1)}
                           for i, b in sorted(g["bins"].items()) if b[0]}}
    return out


def report(cal: Dict[str, Any]) -> str:
    lines = []
    for k, g in cal.items():
        lines.append(f"{k:22} {g['market_minutes']:7} market-minutes  {g['events']:5} events  Brier {g['brier']}  "
                     f"(one-sided skipped {g['one_sided_skipped']})")
        if k.endswith("| all") or k.startswith("ALL"):
            lines.append("    " + "  ".join(f"{b}: said {v['market_said']}% won {v['yes_won']}% (n={v['n']})" for b, v in g["bins"].items()))
    return "\n".join(lines)
