"""python -m aicrypto.timeframes discover [--full] [--all] | report [--all] | quality [--days N] | backfill ... | calibration"""
import asyncio
import sys
from pathlib import Path

from .registry import discover, load, report

ROOT = Path(__file__).resolve().parents[2]


def _arg(name, default):
    return type(default)(sys.argv[sys.argv.index(name) + 1]) if name in sys.argv else default


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "report"
    if cmd == "discover":
        reg = asyncio.run(discover(ROOT, full="--full" in sys.argv))
        print(report(reg, priority_only="--all" not in sys.argv))
        print("rejected (top):", reg["rejected"])
    elif cmd == "quality":
        from . import quality
        print(quality.report(quality.build(ROOT, days=_arg("--days", 2))))
    elif cmd == "backfill":
        from . import backfill
        series = _arg("--series", ",".join(backfill.DEFAULT_SERIES)).split(",")
        print(backfill.summary(asyncio.run(backfill.run(ROOT, series, days=_arg("--days", 30), near=_arg("--near", 10)))))
    elif cmd == "calibration":
        import json
        from . import dataset
        from .backfill import DEFAULT_SERIES
        series = _arg("--series", ",".join(DEFAULT_SERIES)).split(",")
        cal = dataset.calibration(dataset.rows(ROOT, series))
        (ROOT / "user_data" / "kalshi" / "timeframes" / "calibration.json").write_text(json.dumps(cal, indent=1))
        print(dataset.report(cal))
    else:
        reg = load(ROOT)
        print(report(reg, priority_only="--all" not in sys.argv) if reg else "no registry yet: run discover")
