"""Historical backfill of hourly (and other ladder) markets from the real exchange's 1-minute candles (Phase B).

    python -m aicrypto.timeframes backfill [--series KXBTCD,KXETHD,KXSOLD] [--days 30] [--near 10]

Public, unsigned, GET-only, at BACKGROUND priority on the machine-wide request budget, so it always yields to the
recorder. Per settled event it stores, in user_data/kalshi/timeframes/history/<series>/<event>.json.gz:

* every market's terms and result (strike type, floor/cap, result, settlement value): from the settled list, free
* 1-minute yes bid/ask/last candles for the final CANDLE_WINDOW_S of the `near` markets whose strikes were closest
  to the settlement value (the ones whose prices carry information; deep in/out-of-the-money strikes sit at 0-1%)

Underlying 1-minute Coinbase candles (separate public host, not Kalshi's budget) are stored per asset in
history/spot/<asset>_coinbase.json.gz and extended incrementally.

Resumable and incremental: an event whose file exists is never fetched again. Limits, reported not hidden:
candles carry best bid/ask only (no depth), and the official settlement index is not available historically, only
each event's settlement value. Read-only: this module never sends anything but GET requests.
"""
from __future__ import annotations

import asyncio
import gzip
import json
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

DEFAULT_SERIES = ("KXBTCD", "KXETHD", "KXSOLD")
CANDLE_WINDOW_S = 3600
ASSET_OF = {"BTC": "BTC", "ETH": "ETH", "SOL": "SOL", "XRP": "XRP", "DOGE": "DOGE"}


def history_dir(root: Path) -> Path:
    d = Path(root) / "user_data" / "kalshi" / "timeframes" / "history"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ts(iso: Optional[str]) -> Optional[float]:
    if not iso:
        return None
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _f(x: Any) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _save(path: Path, obj: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(tmp, "wt") as f:
        json.dump(obj, f, separators=(",", ":"))
    tmp.replace(path)


def load(path: Path) -> Any:
    with gzip.open(path, "rt") as f:
        return json.load(f)


def asset_of(series: str) -> Optional[str]:
    for a in ASSET_OF:
        if series.upper().startswith("KX" + a):
            return a
    return None


def market_row(m: Dict[str, Any]) -> Dict[str, Any]:
    return {"ticker": m.get("ticker"), "strike_type": m.get("strike_type"), "floor": _f(m.get("floor_strike")),
            "cap": _f(m.get("cap_strike")), "result": (m.get("result") or "").lower(), "settle": _f(m.get("expiration_value")),
            "open_ts": _ts(m.get("open_time")), "close_ts": _ts(m.get("close_time")), "volume": _f(m.get("volume_fp") or m.get("volume"))}


def strike_point(r: Dict[str, Any]) -> Optional[float]:
    if r["floor"] is not None and r["cap"] is not None:
        return (r["floor"] + r["cap"]) / 2
    return r["floor"] if r["floor"] is not None else r["cap"]


def nearest(rows: List[Dict[str, Any]], settle: Optional[float], n: int) -> List[Dict[str, Any]]:
    """The n markets whose strike was closest to the settlement value (all of them when it is unknown and n >= len)."""
    pts = [(abs(strike_point(r) - settle), r["ticker"], r) for r in rows if settle is not None and strike_point(r) is not None]
    return [r for _, _, r in sorted(pts)[:n]]


def candle(c: Dict[str, Any]) -> Dict[str, Any]:
    ya, yb, pr = c.get("yes_ask") or {}, c.get("yes_bid") or {}, c.get("price") or {}
    return {"end": c.get("end_period_ts"), "ask_o": _f(ya.get("open_dollars")), "ask_h": _f(ya.get("high_dollars")),
            "ask_l": _f(ya.get("low_dollars")), "ask_c": _f(ya.get("close_dollars")),
            "bid_o": _f(yb.get("open_dollars")), "bid_h": _f(yb.get("high_dollars")), "bid_l": _f(yb.get("low_dollars")),
            "bid_c": _f(yb.get("close_dollars")), "last": _f(pr.get("close_dollars")), "vol": _f(c.get("volume_fp"))}


def _client():
    from ..kalshi.client import KalshiRestClient
    return KalshiRestClient("production", signer=None, public=True, requests_per_second=1.0, priority="background", max_retries=4)


async def backfill_series(root: Path, series: str, days: int, near: int, client, now: float, progress=print) -> Dict[str, Any]:
    out = history_dir(root) / series
    out.mkdir(parents=True, exist_ok=True)
    have = {p.name.split(".json")[0] for p in out.glob("*.json.gz")}
    raws = await client.list_markets(status="settled", series_ticker=series, min_close_ts=int(now - days * 86400), max_pages=400)
    events: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for m in raws:
        if m.get("event_ticker"):
            events[m["event_ticker"]].append(m)
    stats = {"series": series, "events_listed": len(events), "already_had": 0, "saved": 0, "no_settlement": 0, "failed": 0,
             "markets": len(raws), "with_candles": 0}
    for ev in sorted(events, key=lambda e: min(_ts(m.get("close_time")) or 0 for m in events[e])):
        if ev in have:
            stats["already_had"] += 1
            continue
        rows = [market_row(m) for m in events[ev]]
        rows = [r for r in rows if r["result"] in ("yes", "no")]
        settle = next((r["settle"] for r in rows if r["settle"] is not None), None)
        close = max((r["close_ts"] or 0) for r in rows) if rows else 0
        if not rows or settle is None or not close:
            stats["no_settlement"] += 1
            continue
        pick = nearest(rows, settle, near)
        candles: Dict[str, List[Dict[str, Any]]] = {}
        try:
            data = await client.get_candlesticks_multi([r["ticker"] for r in pick], int(close - CANDLE_WINDOW_S - 60), int(close + 60), 1)
            for m in data.get("markets", []):
                candles[m.get("market_ticker") or m.get("ticker")] = [candle(c) for c in m.get("candlesticks", [])]
        except Exception as e:                       # recorded as a failure; the event is retried on the next run
            stats["failed"] += 1
            progress(f"{series} {ev}: candles failed ({type(e).__name__})")
            continue
        stats["with_candles"] += sum(1 for v in candles.values() if v)
        _save(out / f"{ev}.json.gz", {"event": ev, "series": series, "asset": asset_of(series), "close_ts": close, "settle": settle,
                                      "markets": rows, "near": [r["ticker"] for r in pick], "candles": candles,
                                      "candle_window_s": CANDLE_WINDOW_S, "fetched_at": now})
        stats["saved"] += 1
        if stats["saved"] % 50 == 0:
            progress(f"{series}: {stats['saved']} events saved")
    return stats


async def backfill_spot(root: Path, asset: str, start_ts: int, now: float) -> Dict[str, Any]:
    from ..research15.data import coinbase_minutes
    p = history_dir(root) / "spot"
    p.mkdir(exist_ok=True)
    f = p / f"{asset}_coinbase.json.gz"
    rows = load(f) if f.exists() else []
    have_from = rows[0][0] if rows else None
    have_to = rows[-1][0] if rows else None
    new: List[List[float]] = []
    if have_from is None or start_ts < have_from:
        new += await coinbase_minutes(asset, start_ts, int(have_from or now))
    if have_to is not None:
        new += await coinbase_minutes(asset, int(have_to) + 60, int(now))
    merged = {int(r[0]): r for r in rows + new}
    rows = [merged[k] for k in sorted(merged)]
    _save(f, rows)
    return {"asset": asset, "minutes": len(rows), "added": len(new)}


async def run(root: Path, series: List[str], days: int = 30, near: int = 10, client=None, progress=print,
              now: Optional[float] = None, spot: bool = True) -> Dict[str, Any]:
    now = now or time.time()
    own = client is None
    client = client or _client()
    res: Dict[str, Any] = {"started_at": now, "days": days, "near": near, "series": [], "spot": []}
    try:
        for s in series:
            progress(f"{s}: listing settled markets ({days} days)")
            res["series"].append(await backfill_series(root, s, days, near, client, now, progress))
    finally:
        if own:
            await client.aclose()
    if spot:
        for a in sorted({asset_of(s) for s in series} - {None}):
            progress(f"{a}: Coinbase 1-minute candles")
            res["spot"].append(await backfill_spot(root, a, int(now - days * 86400 - 6 * 3600), now))
    res["finished_at"] = time.time()
    _save(history_dir(root) / "last_run.json.gz", res)
    return res


def summary(res: Dict[str, Any]) -> str:
    lines = [f"backfill: {res['days']} days, {res['near']} nearest strikes per event, {round((res['finished_at'] - res['started_at']) / 60)} min"]
    for s in res["series"]:
        lines.append(f"  {s['series']:10} events {s['events_listed']:5}  saved {s['saved']:5}  already had {s['already_had']:5}  "
                     f"failed {s['failed']:3}  no settlement {s['no_settlement']:3}  markets {s['markets']}")
    for s in res["spot"]:
        lines.append(f"  spot {s['asset']:5} {s['minutes']} minutes (+{s['added']})")
    return "\n".join(lines)
