"""Data-quality report per asset x duration (Phase B): what was recorded, what is missing, disk space.

    python -m aicrypto.timeframes quality [--days 2]

Reads the recordings only (no network). Everything it reports is measured from the files:

* recorder uptime: gaps between the recorder's 10-second health lines (a gap > 60 s is downtime) and restarts
* 15-minute stream: poll errors from the recorder's health lines
* hourly/daily stream: one "cycle" line per poll round (written since 2026-11-12); a series is missing a minute
  when its round failed, and the stream is missing time when rounds stop. Older data without cycle lines is
  judged by quote and settlement records only, and says so.
* settlement completeness: hourly/daily markets whose close time has passed by more than 1 hour, recorded
  (market_meta) but with no settlement line
* settlement index: gap events by index from the CF index stream
* disk: recordings size per day, free space, days of space left at the current rate, and an alert below
  DISK_ALERT_GB free or DISK_ALERT_DAYS left. Nothing is ever deleted automatically (retention = keep all).
"""
from __future__ import annotations

import json
import shutil
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from ..recorder.store import read, recordings_dir

DOWNTIME_GAP_S = 60.0
DISK_ALERT_GB = 20.0
DISK_ALERT_DAYS = 30.0
SETTLE_GRACE_S = 3600.0


def _days(root: Path, days: int) -> List[Path]:
    base = recordings_dir(root)
    return sorted(p for p in base.iterdir() if p.is_dir())[-days:]


def _read(dirs: Iterable[Path], src: str) -> Iterable[Dict[str, Any]]:
    for d in dirs:
        for p in sorted(d.glob(f"{src}-*.jsonl.gz")):
            yield from read(p)


def recorder_uptime(dirs: List[Path]) -> Dict[str, Any]:
    last, down, gaps, starts, first = None, 0.0, [], 0, None
    errors_15m = {"first": None, "last": None}
    for r in _read(dirs, "recorder"):
        t = r.get("t")
        if r.get("k") == "start":
            starts += 1
        if r.get("k") != "health" or t is None:
            continue
        first = first if first is not None else t
        if last is not None and t - last > DOWNTIME_GAP_S:
            down += t - last
            gaps.append({"from": round(last), "seconds": round(t - last)})
        last = t
        e = (r.get("kalshi_real") or {}).get("errors")
        if e is not None:
            errors_15m["first"] = e if errors_15m["first"] is None else errors_15m["first"]
            errors_15m["last"] = e
    span = (last - first) if first is not None and last is not None else 0.0
    return {"span_h": round(span / 3600, 1), "downtime_min": round(down / 60, 1), "outages": gaps[-10:], "n_outages": len(gaps),
            "restarts": max(0, starts - 1),
            "uptime_pct": round(100 * (1 - down / span), 2) if span else None,
            "note": "15-minute stream poll errors are counted per recorder run (reset at restart)",
            "errors_15m_last_run": errors_15m["last"]}


def longer_stream(dirs: List[Path], now: float) -> Dict[str, Any]:
    series_info: Dict[str, List[str]] = {}
    per: Dict[str, Dict[str, Any]] = defaultdict(lambda: Counter())
    seen_m: Dict[str, set] = defaultdict(set)
    seen_s: Dict[str, set] = defaultdict(set)
    meta: Dict[str, Dict[str, Any]] = {}
    settled: set = set()
    cycles, cycle_ts, failed_rounds = 0, [], Counter()
    errors = Counter()
    for r in _read(dirs, "kalshi_real_long"):
        k = r.get("k")
        if k == "series_set":
            series_info.update(r.get("series") or {})
        elif k == "market_meta":
            meta[r["ticker"]] = {"series": r.get("series"), "asset": r.get("asset"), "close_ts": r.get("close_ts")}
            seen_m[r.get("series")].add(r["ticker"])                # unique: a restart re-records market terms
        elif k == "quote":
            s = (meta.get(r.get("ticker")) or {}).get("series")
            per[s]["quotes"] += 1
        elif k == "settled":
            settled.add(r.get("ticker"))
            seen_s[r.get("series")].add(r.get("ticker"))             # unique: a restart re-reads 6 h of settlements
        elif k == "cycle":
            cycles += 1
            cycle_ts.append(r["t"])
            for s in r.get("failed") or []:
                failed_rounds[s] += 1
        elif k == "error":
            errors[(r.get("what") or "").split(" ")[0]] += 1
    for s in set(seen_m) | set(seen_s):
        per[s]["markets"] = len(seen_m.get(s, ()))
        per[s]["settled"] = len(seen_s.get(s, ()))
    unsettled = [t for t, m in meta.items() if m.get("close_ts") and m["close_ts"] < now - SETTLE_GRACE_S and t not in settled]
    stalls = [round(b - a) for a, b in zip(cycle_ts, cycle_ts[1:]) if b - a > 3 * 60]
    return {"cycles": cycles, "cycle_stalls_s": stalls[-10:], "n_cycle_stalls": len(stalls),
            "failed_rounds_by_series": dict(failed_rounds), "errors": dict(errors),
            "markets_seen": len(meta), "settled": len(settled),
            "closed_but_no_settlement": len(unsettled), "closed_but_no_settlement_examples": sorted(unsettled)[:5],
            "per_series": {s: dict(c) for s, c in per.items() if s}, "series_buckets": series_info,
            "has_cycle_lines": cycles > 0}


def cf_gaps(dirs: List[Path]) -> Dict[str, Any]:
    by, secs, reconnects = Counter(), Counter(), 0
    for r in _read(dirs, "cfindex"):
        k = r.get("k")
        if k == "gap":
            by[r.get("index")] += 1
            secs[r.get("index")] += r.get("seconds") or 0
        elif k == "reconnect":
            reconnects += 1
    return {"gaps": dict(by), "gap_seconds": {k: round(v, 1) for k, v in secs.items()}, "reconnects": reconnects}


def disk(root: Path) -> Dict[str, Any]:
    base = recordings_dir(root)
    per_day = {d.name: sum(f.stat().st_size for f in d.glob("*")) for d in sorted(base.iterdir()) if d.is_dir()}
    du = shutil.disk_usage(base)
    full_days = list(per_day.values())[:-1] or list(per_day.values())          # today is partial
    rate = (sum(full_days) / len(full_days)) if full_days else 0
    free_gb = du.free / 1e9
    days_left = (du.free / rate) if rate else None
    alerts = []
    if free_gb < DISK_ALERT_GB:
        alerts.append(f"only {free_gb:.0f} GB free")
    if days_left is not None and days_left < DISK_ALERT_DAYS:
        alerts.append(f"disk full in about {days_left:.0f} days at the current rate")
    return {"recordings_mb_by_day": {k: round(v / 1e6, 1) for k, v in per_day.items()}, "mb_per_day": round(rate / 1e6, 1),
            "free_gb": round(free_gb, 1), "days_left": round(days_left) if days_left else None, "alerts": alerts,
            "retention": "keep everything (no automatic deletion)"}


def by_asset_duration(root: Path, longer: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Join the registry's asset x duration rows with what was actually recorded."""
    try:
        reg = json.loads((Path(root) / "user_data" / "kalshi" / "timeframes" / "registry.json").read_text())
    except (OSError, ValueError):
        return []
    from ..recorder.longer import PRIORITY_ASSETS, series_plan
    out: Dict[tuple, Dict[str, Any]] = {}
    rows = [r for r in reg.get("rows", []) if r.get("asset") in PRIORITY_ASSETS]
    listed = {r["series"] for r in rows}
    for s, p in series_plan(root).items():              # recorded but not eligible in the registry (e.g. DOGE hourly)
        if s not in listed and longer["per_series"].get(s):
            rows.append({"series": s, "asset": p["asset"], "bucket": p["bucket"], "data_quality": {"grade": "B*"},
                         "research_status": "recorded; registry lists it as not eligible (see unsupported list)"})
    for r in rows:
        key = (r["asset"], r["bucket"])
        row = out.setdefault(key, {"asset": r["asset"], "duration": r["bucket"], "series": [], "grade": r["data_quality"]["grade"],
                                   "markets_recorded": 0, "quotes": 0, "settled": 0, "failed_rounds": 0, "research": r.get("research_status"),
                                   "stream": "15-minute recorder (~1 s quotes, depth)" if r["bucket"] == "15m" else "hourly/daily recorder"})
        row["series"].append(r["series"])
        ps = longer["per_series"].get(r["series"], {})
        row["markets_recorded"] += ps.get("markets", 0)
        row["quotes"] += ps.get("quotes", 0)
        row["settled"] += ps.get("settled", 0)
        row["failed_rounds"] += longer["failed_rounds_by_series"].get(r["series"], 0)
    return sorted(out.values(), key=lambda x: (x["asset"], x["duration"]))


def build(root: Path, days: int = 2, now: Optional[float] = None) -> Dict[str, Any]:
    now = now or time.time()
    dirs = _days(root, days)
    longer = longer_stream(dirs, now)
    rep = {"built_at": now, "days": [d.name for d in dirs], "recorder": recorder_uptime(dirs), "hourly_daily": longer,
           "settlement_index": cf_gaps(dirs), "disk": disk(root), "by_asset_duration": by_asset_duration(root, longer)}
    out = Path(root) / "user_data" / "kalshi" / "timeframes" / "quality.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rep, indent=1, default=str))
    return rep


def report(rep: Dict[str, Any]) -> str:
    r, h, c, d = rep["recorder"], rep["hourly_daily"], rep["settlement_index"], rep["disk"]
    lines = [f"days: {', '.join(rep['days'])}",
             f"recorder: {r['span_h']} h covered, uptime {r['uptime_pct']}%, downtime {r['downtime_min']} min in {r['n_outages']} outage(s), "
             f"{r['restarts']} restart(s)",
             f"hourly/daily: {h['cycles']} poll rounds, {h['n_cycle_stalls']} stall(s) > 3 min, failed series-rounds "
             f"{sum(h['failed_rounds_by_series'].values())}, markets {h['markets_seen']}, settled {h['settled']}, "
             f"closed > 1 h without a settlement line: {h['closed_but_no_settlement']}",
             f"settlement index gaps: {sum(c['gaps'].values())} ({c['gap_seconds']} s), reconnects {c['reconnects']}",
             f"disk: {d['mb_per_day']} MB/day, {d['free_gb']} GB free, ~{d['days_left']} days left; alerts: {d['alerts'] or 'none'}",
             "", f"{'asset':7} {'duration':9} {'grade':5} {'markets':>8} {'quotes':>8} {'settled':>8} {'failed':>6}  series"]
    for x in rep["by_asset_duration"]:
        if x["duration"] == "15m":
            lines.append(f"{x['asset']:7} {x['duration']:9} {x['grade']:5} {'recorded by the 15-minute recorder (~1 s, depth)':>42}  "
                         f"{','.join(x['series'])}")
            continue
        lines.append(f"{x['asset']:7} {x['duration']:9} {x['grade']:5} {x['markets_recorded']:8} {x['quotes']:8} {x['settled']:8} "
                     f"{x['failed_rounds']:6}  {','.join(x['series'])}")
    return "\n".join(lines)
