"""Lookahead and recursive (warm-up path dependence) probes.

Lookahead probe
    Compute signals on the full series and on the series truncated at several
    cut points. For a causal strategy the signals on the overlap are identical.
    Any difference means the strategy used information from after the cut.

Recursive probe
    Compute signals/indicator-derived values with different warm-up lengths that
    all end at the same bar. Recursive indicators (EMA, Wilder RSI) converge but
    never exactly agree; we report the max relative drift of the signal-driving
    numbers over the last `tail` bars. Freqtrade's live loop only sees
    `startup_candle_count` bars, so a strategy whose signals flip with warm-up
    length will trade differently live than in backtest.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List

import numpy as np
import pandas as pd

from ..strategies import StrategySpec, compute_signals

SignalFn = Callable[[pd.DataFrame, StrategySpec], pd.DataFrame]


@dataclass
class LookaheadReport:
    cut_points: List[int]
    diffs_per_cut: List[int]
    total_diffs: int
    ok: bool
    detail: str = ""


@dataclass
class RecursiveReport:
    warmups: List[int]
    signal_flips: int
    max_rel_drift: float
    ok: bool
    detail: str = ""


def lookahead_probe(
    df: pd.DataFrame,
    spec: StrategySpec,
    signal_fn: SignalFn = compute_signals,
    n_cuts: int = 5,
    min_tail: int = 50,
) -> LookaheadReport:
    full = signal_fn(df, spec)[["enter_long", "exit_long"]].to_numpy(bool)
    n = len(df)
    warm = spec.startup_bars()
    lo = min(n - min_tail, max(warm + min_tail, n // 3))
    cuts = sorted(set(np.linspace(lo, n - min_tail, n_cuts, dtype=int).tolist()))
    diffs: List[int] = []
    rng = np.random.default_rng(0)
    cols = ["open", "high", "low", "close"]
    for c in cuts:
        # (a) truncation: a causal signal at bar c-1 must be identical whether or
        #     not bar c exists.
        part = signal_fn(df.iloc[:c].reset_index(drop=True), spec)[["enter_long", "exit_long"]].to_numpy(bool)
        d = int((part != full[:c]).sum())
        # (b) perturbation: scramble the future (bars >= c) and recompute. Signals
        #     before c must not move. Catches leaks that truncation can miss when
        #     the leaked comparison happens to evaluate the same way.
        pert = df.copy()
        scale = rng.uniform(0.8, 1.25, size=len(pert) - c)
        pert.loc[pert.index[c:], cols] = pert.loc[pert.index[c:], cols].to_numpy() * scale[:, None]
        pert.loc[pert.index[c:], "volume"] = pert["volume"].iloc[c:].to_numpy()[::-1]
        pert_sig = signal_fn(pert, spec)[["enter_long", "exit_long"]].to_numpy(bool)
        d += int((pert_sig[:c] != full[:c]).sum())
        diffs.append(d)
    total = sum(diffs)
    return LookaheadReport(cuts, diffs, total, total == 0,
                           "" if total == 0 else "signals changed when future bars were removed")


def recursive_probe(
    df: pd.DataFrame,
    spec: StrategySpec,
    signal_fn: SignalFn = compute_signals,
    warmups: List[int] | None = None,
    tail: int = 200,
) -> RecursiveReport:
    n = len(df)
    base = spec.startup_bars()
    warmups = warmups or [base, base * 2, base * 4, n]
    warmups = sorted({min(w, n) for w in warmups if w + tail <= n} | {n})
    if len(warmups) < 2:
        return RecursiveReport(warmups, 0, 0.0, True, "series too short for probe; skipped")

    # Reference: full history, standard warm-up mask (what the backtest saw).
    ref_sig = signal_fn(df, spec)
    ref_tail = ref_sig[["enter_long", "exit_long"]].iloc[-tail:].to_numpy(bool)
    ref_num = ref_sig["_score"].iloc[-tail:].to_numpy(float) if "_score" in ref_sig else None
    flips = 0
    max_drift = 0.0
    for w in warmups:
        if w >= n:
            continue
        # Emulate a live loop that only has `w` candles before the evaluation tail.
        sub = df.iloc[n - (w + tail):].reset_index(drop=True)
        try:
            sig = signal_fn(sub, spec, startup=w)
        except TypeError:  # signal_fn without startup kwarg
            sig = signal_fn(sub, spec)
        tail_sig = sig[["enter_long", "exit_long"]].iloc[-tail:].to_numpy(bool)
        flips += int((tail_sig != ref_tail).sum())
        if ref_num is not None and "_score" in sig:
            num = sig["_score"].iloc[-tail:].to_numpy(float)
            mask = np.isfinite(num) & np.isfinite(ref_num)
            if mask.any():
                # drift relative to the score's typical magnitude over the tail (not
                # pointwise: a score crossing zero would otherwise explode the ratio)
                scale = max(float(np.std(ref_num[mask])), 1e-12)
                max_drift = max(max_drift, float(np.max(np.abs(num[mask] - ref_num[mask])) / scale))
    ok = flips == 0
    return RecursiveReport(warmups, flips, max_drift, ok,
                           "" if ok else f"{flips} signal flips across warm-up lengths; raise startup_bars")
