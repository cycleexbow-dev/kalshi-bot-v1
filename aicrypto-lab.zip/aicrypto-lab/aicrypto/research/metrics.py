"""Performance metrics. All are descriptive statistics of a simulated past."""
from __future__ import annotations

import math
from typing import Dict

import numpy as np
import pandas as pd

from ..data.ohlcv import timeframe_to_minutes
from .backtest import BacktestResult

MINUTES_PER_YEAR = 365 * 24 * 60


def bars_per_year(timeframe: str) -> float:
    return MINUTES_PER_YEAR / timeframe_to_minutes(timeframe)


def max_drawdown(equity: pd.Series) -> float:
    peak = equity.cummax()
    dd = equity / peak - 1.0
    return float(-dd.min()) if len(dd) else 0.0


def compute_metrics(res: BacktestResult) -> Dict[str, float]:
    eq = res.equity.astype(float)
    start, end = float(eq.iloc[0]), float(eq.iloc[-1])
    rets = eq.pct_change().dropna()
    bpy = bars_per_year(res.timeframe)
    years = res.bars / bpy
    total_return = end / start - 1.0
    cagr = (end / start) ** (1 / years) - 1.0 if years > 0 and end > 0 else float("nan")
    vol = float(rets.std(ddof=1)) if len(rets) > 1 else 0.0
    sharpe = float(rets.mean() / vol * math.sqrt(bpy)) if vol > 0 else 0.0
    downside = rets[rets < 0]
    dvol = float(downside.std(ddof=1)) if len(downside) > 1 else 0.0
    sortino = float(rets.mean() / dvol * math.sqrt(bpy)) if dvol > 0 else 0.0
    mdd = max_drawdown(eq)

    tdf = res.trades_df
    n = len(tdf)
    wins = tdf[tdf["pnl"] > 0]["pnl"].sum() if n else 0.0
    losses = -tdf[tdf["pnl"] < 0]["pnl"].sum() if n else 0.0
    profit_factor = float(wins / losses) if losses > 0 else (float("inf") if wins > 0 else 0.0)
    win_rate = float((tdf["pnl"] > 0).mean()) if n else 0.0
    avg_trade_pct = float(tdf["pnl_pct"].mean()) if n else 0.0
    fees = float(tdf["fees"].sum()) if n else 0.0

    return {
        "start_equity": start,
        "end_equity": end,
        "total_return": float(total_return),
        "cagr": float(cagr) if not math.isnan(cagr) else 0.0,
        "sharpe": sharpe,
        "sortino": sortino,
        "max_drawdown": mdd,
        "calmar": float(cagr / mdd) if mdd > 0 and not math.isnan(cagr) else 0.0,
        "trades": int(n),
        "win_rate": win_rate,
        "profit_factor": profit_factor if np.isfinite(profit_factor) else 99.0,
        "avg_trade_pct": avg_trade_pct,
        "fees_paid": fees,
        "exposure": float(res.exposure),
        "bars": int(res.bars),
        "years": float(years),
    }
