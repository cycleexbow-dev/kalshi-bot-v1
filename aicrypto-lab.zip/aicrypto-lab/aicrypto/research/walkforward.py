"""Walk-forward validation with bounded in-sample optimisation.

For each fold: optimise the spec's parameters on the train window using a
seeded random search in the neighbourhood of the candidate (plus the candidate
itself), pick the best by in-sample objective, then evaluate that single choice on
the untouched test window. Report per-fold IS/OOS metrics; the stitched OOS
equity is built by chaining fold returns.

Memory: one fold's train+test slice per pair is resident at a time.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..settings import Capital, Costs, WalkForward
from ..strategies import StrategySpec, mutate_spec
from .backtest import backtest
from .metrics import compute_metrics


@dataclass
class Fold:
    index: int
    train_start: int
    train_end: int
    test_start: int
    test_end: int
    chosen: StrategySpec
    is_metrics: Dict[str, float]
    oos_metrics: Dict[str, float]


@dataclass
class WalkForwardResult:
    spec: StrategySpec
    folds: List[Fold]
    oos_equity: pd.Series
    oos_metrics: Dict[str, float]
    is_metrics_mean: Dict[str, float]
    positive_fold_fraction: float
    oos_is_ratio: float
    oos_trades: int
    warnings: List[str] = field(default_factory=list)

    @property
    def n_folds(self) -> int:
        return len(self.folds)


def objective(m: Dict[str, float]) -> float:
    """In-sample selection objective. Penalises few trades and deep drawdowns."""
    if m["trades"] < 10:
        return -1e9
    return m["sharpe"] - 2.0 * max(0.0, m["max_drawdown"] - 0.2)


def _slice(data: Dict[str, pd.DataFrame], a: int, b: int) -> Dict[str, pd.DataFrame]:
    return {p: df.iloc[a:b].reset_index(drop=True) for p, df in data.items()}


def make_folds(n: int, wf: WalkForward, warm: int):
    """Yield (train_start, train_end, test_start, test_end) index tuples.

    Test windows get `warm` bars of lead-in so indicators are settled at the
    start of the test period; those lead-in bars produce no trades (signals are
    masked during warm-up) so test performance is measured only on test bars.
    """
    folds = []
    train, test, step = wf.train_bars, wf.test_bars, wf.step_bars
    start = 0
    while True:
        tr_s = 0 if wf.scheme == "anchored" else start
        tr_e = start + train
        te_s = tr_e - warm
        te_e = tr_e + test
        if te_e > n or len(folds) >= wf.max_folds:
            break
        folds.append((tr_s, tr_e, max(te_s, 0), te_e))
        start += step
    return folds


def walk_forward(
    data: Dict[str, pd.DataFrame],
    spec: StrategySpec,
    capital: Capital,
    costs: Costs,
    wf: WalkForward,
    optimise: bool = True,
) -> WalkForwardResult:
    n = min(len(df) for df in data.values())
    warm = spec.startup_bars()
    fold_idx = make_folds(n, wf, warm)
    if not fold_idx:
        raise ValueError(f"not enough bars ({n}) for train={wf.train_bars} test={wf.test_bars}")

    rng = random.Random(wf.seed)
    folds: List[Fold] = []
    oos_curves: List[pd.Series] = []
    equity_level = capital.starting_balance
    warnings: List[str] = []

    for i, (tr_s, tr_e, te_s, te_e) in enumerate(fold_idx):
        train = _slice(data, tr_s, tr_e)
        candidates = [spec]
        if optimise:
            seen = {spec.spec_hash}
            for _ in range(wf.optimizer_samples):
                m = mutate_spec(spec, rng, n_changes=rng.choice([1, 2]))
                if m.spec_hash not in seen:
                    seen.add(m.spec_hash)
                    candidates.append(m)
        best, best_m, best_obj = None, None, -np.inf
        for c in candidates:
            try:
                m = compute_metrics(backtest(train, c, capital, costs))
            except ValueError:
                continue
            o = objective(m)
            if o > best_obj:
                best, best_m, best_obj = c, m, o
        if best is None:
            warnings.append(f"fold {i}: no valid candidate")
            continue

        test = _slice(data, te_s, te_e)
        cap_i = Capital(**{**capital.model_dump(), "starting_balance": equity_level})
        res = backtest(test, best, cap_i, costs)
        oos_m = compute_metrics(res)
        # keep only the true test bars of the equity curve (drop warm-up lead-in)
        lead = tr_e - te_s
        curve = res.equity.iloc[lead:]
        oos_curves.append(curve)
        equity_level = float(curve.iloc[-1]) if len(curve) else equity_level
        folds.append(Fold(i, tr_s, tr_e, te_s, te_e, best, best_m, oos_m))
        del train, test, res

    if not folds:
        raise ValueError("walk-forward produced no folds")

    oos_equity = pd.concat(oos_curves)
    oos_equity = oos_equity[~oos_equity.index.duplicated(keep="last")]
    # Build a pseudo-result for stitched metrics
    from .backtest import BacktestResult, Trade  # local import to avoid cycle noise

    all_trades: List[Trade] = []
    oos_trades = sum(f.oos_metrics["trades"] for f in folds)
    stitched = BacktestResult(oos_equity, all_trades, len(oos_equity), spec.timeframe, 0.0, sorted(data))
    oos_metrics = compute_metrics(stitched)
    oos_metrics["trades"] = int(oos_trades)
    oos_metrics["win_rate"] = float(np.mean([f.oos_metrics["win_rate"] for f in folds]))
    oos_metrics["profit_factor"] = float(np.mean([min(f.oos_metrics["profit_factor"], 10) for f in folds]))

    is_mean = {k: float(np.mean([f.is_metrics[k] for f in folds])) for k in folds[0].is_metrics}
    pos_frac = float(np.mean([f.oos_metrics["total_return"] > 0 for f in folds]))
    is_sharpe = is_mean["sharpe"]
    ratio = float(oos_metrics["sharpe"] / is_sharpe) if is_sharpe > 0 else (1.0 if oos_metrics["sharpe"] > 0 else 0.0)

    return WalkForwardResult(spec, folds, oos_equity, oos_metrics, is_mean, pos_frac, ratio, int(oos_trades), warnings)
