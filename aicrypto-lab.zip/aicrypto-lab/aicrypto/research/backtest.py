"""Portfolio backtester: spot-only, long-only, next-bar-open fills, explicit costs.

Execution model for bar t of a pair:
  1. If in a position: check hard stop / trailing stop against bar t's range
     (gap-through handled: fill at open if open already below the stop),
     then time exit, then signal exit from bar t-1 (filled at open[t]).
  2. If flat and `enter_long[t-1]` is true and a slot is free: buy at
     open[t] * (1 + slippage). Position notional = min(equity * risk / stop_pct,
     equity * max_alloc, cash). Fees charged on notional on both sides.
Equity is cash + marked-to-market positions at each close.

Signals are consumed one bar after they are generated. There is no code path that
reads bar t's close before deciding bar t's fill.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..settings import Capital, Costs
from ..strategies import StrategySpec, compute_signals


@dataclass
class Trade:
    pair: str
    entry_idx: int
    exit_idx: int
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    entry_price: float
    exit_price: float
    qty: float
    fees: float
    pnl: float            # net of fees and slippage
    pnl_pct: float
    reason: str
    bars_held: int


@dataclass
class BacktestResult:
    equity: pd.Series                      # indexed by date
    trades: List[Trade]
    bars: int
    timeframe: str
    exposure: float                        # fraction of bars with >=1 open position
    pairs: List[str]
    warnings: List[str] = field(default_factory=list)

    @property
    def trades_df(self) -> pd.DataFrame:
        if not self.trades:
            return pd.DataFrame(columns=[f.name for f in Trade.__dataclass_fields__.values()])
        return pd.DataFrame([t.__dict__ for t in self.trades])


def _align(data: Dict[str, pd.DataFrame]) -> pd.DatetimeIndex:
    idx = None
    for df in data.values():
        d = pd.DatetimeIndex(df["date"])
        idx = d if idx is None else idx.intersection(d)
    return idx


def backtest(
    data: Dict[str, pd.DataFrame],
    spec: StrategySpec,
    capital: Capital,
    costs: Costs,
    signals: Optional[Dict[str, pd.DataFrame]] = None,
) -> BacktestResult:
    if not data:
        raise ValueError("no data")
    idx = _align(data)
    if len(idx) < spec.startup_bars() + 10:
        raise ValueError("not enough bars after alignment for warm-up")

    pairs = sorted(data)
    arrays = {}
    for pair in pairs:
        df = data[pair].set_index("date").loc[idx]
        sig = (signals[pair] if signals is not None else compute_signals(data[pair], spec))
        sig = sig.set_index(pd.DatetimeIndex(data[pair]["date"])).loc[idx]
        arrays[pair] = dict(
            o=df["open"].to_numpy(np.float64),
            h=df["high"].to_numpy(np.float64),
            l=df["low"].to_numpy(np.float64),
            c=df["close"].to_numpy(np.float64),
            enter=sig["enter_long"].to_numpy(bool),
            exit=sig["exit_long"].to_numpy(bool),
        )

    n = len(idx)
    fee = costs.fee_pct
    slip = costs.slip_frac
    stop_pct = float(spec.exits["stop_pct"])
    trail_pct = float(spec.exits["trail_pct"])
    max_bars = int(spec.exits["max_bars"])

    cash = float(capital.starting_balance)
    pos: Dict[str, dict] = {}
    equity = np.empty(n)
    exposed = 0
    trades: List[Trade] = []

    def close_position(pair: str, t: int, px: float, reason: str):
        nonlocal cash
        p = pos.pop(pair)
        px_eff = px * (1 - slip)
        proceeds = p["qty"] * px_eff
        f = proceeds * fee
        cash += proceeds - f
        fees_total = p["fee_in"] + f
        pnl = proceeds - f - p["cost"]
        trades.append(
            Trade(
                pair, p["entry_idx"], t, idx[p["entry_idx"]], idx[t], p["entry_px"], px_eff, p["qty"],
                fees_total, pnl, pnl / p["cost"], reason, t - p["entry_idx"],
            )
        )

    for t in range(n):
        # ---- exits ---------------------------------------------------------
        for pair in pairs:
            if pair not in pos:
                continue
            a = arrays[pair]
            p = pos[pair]
            o, h, l = a["o"][t], a["h"][t], a["l"][t]
            stop = max(p["stop"], p["trail_stop"]) if trail_pct > 0 else p["stop"]
            if o <= stop:
                close_position(pair, t, o, "stop_gap")
                continue
            if l <= stop:
                close_position(pair, t, stop, "stop")
                continue
            if max_bars > 0 and (t - p["entry_idx"]) >= max_bars:
                close_position(pair, t, o, "time")
                continue
            if t > 0 and a["exit"][t - 1]:
                close_position(pair, t, o, "signal")
                continue
            if trail_pct > 0:
                p["trail_stop"] = max(p["trail_stop"], h * (1 - trail_pct))

        # ---- entries (signal from previous bar) --------------------------------
        if t > 0:
            for pair in pairs:
                if pair in pos or len(pos) >= capital.max_open_trades:
                    continue
                a = arrays[pair]
                if not a["enter"][t - 1]:
                    continue
                o = a["o"][t]
                px_eff = o * (1 + slip)
                # equity at previous close for sizing (no peeking at this bar's close)
                eq_prev = cash + sum(pos[q]["qty"] * arrays[q]["c"][t - 1] for q in pos)
                notional = min(eq_prev * capital.risk_per_trade / stop_pct, eq_prev * capital.max_alloc_per_trade)
                notional = min(notional, cash / (1 + fee))
                if notional < 10.0:  # exchange-style minimum notional
                    continue
                qty = notional / px_eff
                f = notional * fee
                cash -= notional + f
                pos[pair] = dict(
                    qty=qty, entry_px=px_eff, cost=notional + f, fee_in=f, entry_idx=t,
                    stop=px_eff * (1 - stop_pct), trail_stop=px_eff * (1 - trail_pct) if trail_pct > 0 else 0.0,
                )

        # ---- mark to market -------------------------------------------------
        mtm = cash + sum(pos[q]["qty"] * arrays[q]["c"][t] for q in pos)
        equity[t] = mtm
        if pos:
            exposed += 1

    # liquidate at final close for a clean equity figure (reported as 'end_of_data')
    last = n - 1
    for pair in list(pos):
        close_position(pair, last, arrays[pair]["c"][last], "end_of_data")
    equity[last] = cash

    warnings = []
    if not trades:
        warnings.append("no trades")
    return BacktestResult(
        equity=pd.Series(equity, index=idx, name="equity"),
        trades=trades,
        bars=n,
        timeframe=spec.timeframe,
        exposure=exposed / n,
        pairs=pairs,
        warnings=warnings,
    )
