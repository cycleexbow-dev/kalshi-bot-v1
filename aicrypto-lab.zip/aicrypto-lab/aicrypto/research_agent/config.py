"""Owner-controlled budgets and gates. Read-only from the research agent's point of view."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import List

import yaml

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "config" / "research_agent.yaml"
# Files the research agent may never modify; their hashes go into every ledger row.
PROTECTED = [CONFIG, Path(__file__), Path(__file__).with_name("harness.py"), Path(__file__).with_name("sandbox.py"),
             Path(__file__).with_name("_worker.py"), Path(__file__).with_name("__main__.py"),
             Path(__file__).with_name("ledger.py"), Path(__file__).with_name("harness_recorded.py")]


@dataclass(frozen=True)
class Budgets:
    max_experiments_per_day: int
    max_cpu_seconds_per_experiment: int
    max_memory_mb: int
    max_variants_per_hypothesis: int


@dataclass(frozen=True)
class Gates:
    alpha_total: float
    train_fraction: float
    min_test_trades: int
    min_test_days: int
    conservative_slippage: float
    max_drawdown_fraction: float
    require_both_halves_positive: bool
    require_beats_market_calibration: bool
    report_win_rate_target: float


@dataclass(frozen=True)
class Config:
    budgets: Budgets
    gates: Gates
    assets: List[str]
    hash: str


def load(path: Path = CONFIG) -> Config:
    raw = path.read_bytes()
    d = yaml.safe_load(raw)
    return Config(Budgets(**d["budgets"]), Gates(**d["gates"]), list(d["assets"]), hashlib.sha256(raw).hexdigest()[:16])


def protected_hash() -> str:
    h = hashlib.sha256()
    for p in PROTECTED:
        h.update(p.read_bytes())
    return h.hexdigest()[:16]
