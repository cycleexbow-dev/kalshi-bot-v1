"""Isolated worker: load one sandbox module by path, call probability() over the inputs twice
(original and reversed order), write the results. Started by sandbox.run with `python -I`, an empty
environment and resource limits. Imports nothing from the project."""
import importlib.util
import math
import pickle
import sys


def main(mod_path, inp, out):
    spec = importlib.util.spec_from_file_location("sandbox_module", mod_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    with open(inp, "rb") as f:
        ctxs = pickle.load(f)

    def call(c):
        v = mod.probability(dict(c))
        if v is None:
            return None
        v = float(v)
        return None if math.isnan(v) else v

    probs = [call(c) for c in ctxs]
    rev = [call(c) for c in reversed(ctxs)]
    rev.reverse()
    with open(out, "wb") as f:
        pickle.dump({"probs": probs, "probs_reversed": rev}, f)


if __name__ == "__main__":
    main(*sys.argv[1:4])
