"""Final-minute harness on the recorder's data (owner-controlled; the AI researcher must not edit it).

For every settled window of the allowed assets, decisions are taken LEADS seconds before the close.
The sandbox sees only what was known at that moment:
  known_prints   the official 1-second index prints already inside the 60-second settlement window
  n_known / n_expected, last_value / last_age_s, ret_1s (the last 300 one-second log returns)
  kalshi_avg60 / kalshi_avg60_n  Kalshi's own running 60-second average, if published
  ask_yes / bid_yes (None when that side cannot be bought) / ask_size / bid_size / mid / spread from the last real
                 order book before the decision
Decisions with incomplete index data or no fresh book are EXCLUDED and counted, never estimated.

Fills (fixed in advance): the order reaches the book LATENCY_S after the decision and walks the first
recorded book at or after that moment, taking DEPTH_SHARE of each displayed level, never paying more
than the decision ask + `conservative_slippage`. No fill -> no trade (the window may fire again later).
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..research15.recordings import Recorded, load, one_per_second
from .harness import fee1

LEADS = (50, 40, 30, 20, 10, 5)
LATENCY_S = 1.0
DEPTH_SHARE = 0.5
# The recorder writes a book only when its top 10 levels change, plus a full snapshot every 30 s, so the
# last record stays the book's state until the next one; older than this means polling stopped.
BOOK_MAX_AGE_S = 31.0
INDEX = {"BTC": "BRTI", "SOL": "SOLUSD_RTI", "ETH": "ETHUSD_RTI", "XRP": "XRPUSD_RTI", "DOGE": "DOGEUSD_RTI"}


def fill(asks: List[Tuple[float, float]], want: float, limit: float) -> Optional[Tuple[float, float]]:
    """(contracts filled, total cost) walking asks up to limit with DEPTH_SHARE of each level."""
    got, left, cost = 0.0, want, 0.0
    for p, s in asks:
        if p > limit + 1e-9 or left <= 0:
            break
        q = min(left, math.floor(s * DEPTH_SHARE))
        if q > 0:
            got += q
            cost += q * p
            left -= q
    return (got, cost) if got > 0 else None


def build(root: Path, assets: Sequence[str], leads: Sequence[int] = LEADS, rec: Optional[Recorded] = None):
    rec = rec or load(root)
    ctxs: List[Dict[str, Any]] = []
    labels: List[Dict[str, Any]] = []
    excluded = {"index_gap": 0, "no_book": 0, "short_history": 0}
    for t, s in rec.settled.items():
        m = rec.meta.get(t) or {}
        a = m.get("asset")
        if a not in assets or m.get("strike") is None or not m.get("close_ts") or s.get("result") not in ("yes", "no"):
            continue
        C, K = float(m["close_ts"]), float(m["strike"])
        per_s = one_per_second(rec.cf.get(INDEX[a], []), C - 900, C)
        avg = [x for x in rec.avg60.get(INDEX[a], [])]
        bs = rec.books.get(t)
        for lead in leads:
            now = int(C - lead)
            known = [per_s[x] for x in range(int(C) - 60, now) if x in per_s]
            expected = max(0, now - (int(C) - 60))
            last = max((x for x in per_s if x < now), default=None)
            if last is None or now - last > 2 or len(known) < expected - 1:
                excluded["index_gap"] += 1
                continue
            secs = [x for x in range(now - 300, now) if x in per_s and (x - 1) in per_s]
            if len(secs) < 120:
                excluded["short_history"] += 1
                continue
            i = bs.before(now) if bs is not None else None
            if i is None or now - bs.times[i] > BOOK_MAX_AGE_S:
                excluded["no_book"] += 1
                continue
            ya, na = bs.asks(i, "yes"), bs.asks(i, "no")
            if not ya and not na:
                excluded["no_book"] += 1
                continue
            # Near the close one side is often empty (nobody sells the near-certain side at any price).
            # Then only the other side can be bought, and the market's chance is taken halfway between the
            # best bid and certainty.
            ask_yes = ya[0][0] if ya else None
            bid_yes = round(1 - na[0][0], 4) if na else None
            if ask_yes is not None and bid_yes is not None:
                mid = (ask_yes + bid_yes) / 2
            elif bid_yes is not None:
                mid = (bid_yes + 1.0) / 2
            else:
                mid = ask_yes / 2
            j = bs.before(now + LATENCY_S)               # the book as it stood when the order arrives
            av = [x for x in avg if x.get("end_ms") and x["end_ms"] / 1000 <= now]
            ctxs.append({"asset": a, "t_left_s": lead, "strike": K, "known_prints": known, "n_known": len(known), "n_expected": expected,
                         "last_value": per_s[last], "last_age_s": now - last,
                         "ret_1s": [math.log(per_s[x] / per_s[x - 1]) for x in secs],
                         "kalshi_avg60": float(av[-1]["value"]) if av else None, "kalshi_avg60_n": av[-1].get("window_size") if av else None,
                         "ask_yes": ask_yes, "bid_yes": bid_yes, "ask_size": ya[0][1] if ya else 0.0, "bid_size": na[0][1] if na else 0.0,
                         "mid": mid, "spread": (ask_yes - bid_yes) if (ask_yes is not None and bid_yes is not None) else None})
            labels.append({"window": t, "close_ts": C, "lead": lead, "y": 1 if s["result"] == "yes" else 0,
                           "after_yes": bs.asks(j, "yes")[:10] if j is not None else [],
                           "after_no": bs.asks(j, "no")[:10] if j is not None else []})
    order = sorted(range(len(labels)), key=lambda k: (labels[k]["close_ts"], -labels[k]["lead"]))
    return [ctxs[k] for k in order], [labels[k] for k in order], excluded


def trades(ctxs, labels, probs, margin: float, slip: float) -> List[Dict[str, Any]]:
    done, out = set(), []
    for c, l, p in zip(ctxs, labels, probs):
        if p is None or l["window"] in done:
            continue
        best = None
        for side, prob, ask in (("yes", p, c["ask_yes"]), ("no", 1 - p, (1 - c["bid_yes"]) if c["bid_yes"] is not None else None)):
            if ask is None or not (0.0 < ask < 1.0):
                continue
            e = prob - ask - fee1(ask)
            if e >= margin and (best is None or e > best[1]):
                best = (side, e, ask)
        if best is None:
            continue
        side, _, ask = best
        f = fill(l["after_yes"] if side == "yes" else l["after_no"], 1, ask + slip)
        if f is None:
            continue                                         # not filled: no trade; a later decision may try again
        done.add(l["window"])
        got, cost = f
        vwap = cost / got
        win = 1.0 if (l["y"] == 1) == (side == "yes") else 0.0
        out.append({"day": datetime.fromtimestamp(l["close_ts"], timezone.utc).strftime("%Y-%m-%d"), "close_ts": l["close_ts"],
                    "side": side, "ask": ask, "win": win, "asset": c.get("asset"),
                    "pnl_cons": win - vwap - fee1(vwap), "paid_cons": vwap + fee1(vwap),
                    "pnl_opt": win - ask - fee1(ask), "paid_opt": ask + fee1(ask)})
    return out
