"""The fixed evaluation harness (owner-controlled; the AI researcher must not edit it).

Inputs: 30 days of real-exchange 15-minute windows (research15 cache): the Kalshi bid/ask of the last
complete minute before each decision, and Coinbase prices translated onto the settlement index level.
Decisions at 10, 5 and 2 minutes before close. Contexts contain only information available at the
decision time; outcomes are kept here and never passed to the sandbox.

Scoring (fixed in advance):
* one trade per window (the earliest decision that fires), because a window's decisions are correlated;
* entry if p - (ask + slippage) - fee >= margin, for YES or NO; conservative fills pay `conservative_slippage`
  above the displayed ask; optimistic fills (displayed ask) are reported alongside;
* chronological split: margins chosen on the first `train_fraction` of time, verdict on the rest;
* statistics clustered by day; Wilson interval for the win rate; day-block bootstrap for the return;
* multiple testing: the significance bar is Bonferroni over EVERY variant in the ledger plus this run;
* calibration: model Brier vs the market's mid on all test decisions, reliability bins;
* favourite trap: high win rate bought at prices where the model is no better calibrated than the market.
"""
from __future__ import annotations

import math
import random
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from ..research15 import data as Dd
from ..research15.features import Minutes, kalshi_quote

LEADS = (600, 300, 120)


def fee1(p: float) -> float:
    return math.ceil(0.07 * p * (1 - p) * 100 - 1e-9) / 100 if 0 < p < 1 else 0.0


def _ret(cb: Minutes, t: float, back: int, adj: float) -> Optional[float]:
    a, b = cb.close_at(t), cb.close_at(t - back * 60)
    return math.log(a / b) if (a and b) else None


def _vol(cb: Minutes, t: float, minutes: int) -> Optional[float]:
    r = cb.returns(t, minutes)
    if len(r) < max(3, minutes // 2):
        return None
    m = sum(r) / len(r)
    return math.sqrt(sum((x - m) ** 2 for x in r) / (len(r) - 1)) if len(r) > 1 else None


def build(root: Path, assets: Sequence[str], leads: Sequence[int] = LEADS) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Returns (contexts for the sandbox, labels kept by the harness), aligned by index."""
    d = Dd.cache_dir(root)
    ctxs, labels = [], []
    for a in assets:
        p = d / f"{a}_windows.json.gz"
        if not p.exists():
            continue
        cb = Minutes(Dd.load(d / f"{a}_coinbase.json.gz"))
        candles = Dd.load(d / f"{a}_kalshi_candles.json.gz")
        for w in Dd.load(p):
            kc = candles.get(w["ticker"]) or []
            open_px = cb.close_at(w["open_ts"])
            basis = math.log(open_px / w["strike"]) if open_px and w["strike"] > 0 else None
            for lead in leads:
                t = w["close_ts"] - lead
                q = kalshi_quote(kc, t)
                spot = cb.close_at(t)
                if q is None or spot is None or basis is None:
                    continue
                adj = math.exp(-basis)
                i = cb.idx_before(t)
                closes = [c * adj for c in cb.close[max(0, i - 59): i + 1]]
                ctxs.append({"asset": a, "lead_s": lead, "t_left_s": lead, "strike": w["strike"],
                             "ask_yes": q["ask"], "bid_yes": q["bid"], "mid": q["mid"], "spread": q["spread"],
                             "spot": spot * adj, "basis": basis, "closes_60m": closes,
                             "ret_1m": _ret(cb, t, 1, adj), "ret_5m": _ret(cb, t, 5, adj), "ret_15m": _ret(cb, t, 15, adj),
                             "ret_60m": _ret(cb, t, 60, adj), "ret_240m": _ret(cb, t, 240, adj),
                             "vol_5m": _vol(cb, t, 5), "vol_15m": _vol(cb, t, 15), "vol_60m": _vol(cb, t, 60),
                             "hour_utc": datetime.fromtimestamp(t, timezone.utc).hour})
                labels.append({"window": w["ticker"], "close_ts": w["close_ts"], "lead": lead, "y": 1 if w["result"] == "yes" else 0})
    order = sorted(range(len(labels)), key=lambda i: (labels[i]["close_ts"], -labels[i]["lead"]))
    return [ctxs[i] for i in order], [labels[i] for i in order]


# ------------------------------------------------------------------ scoring
def trades(ctxs, labels, probs, margin: float, slip: float) -> List[Dict[str, Any]]:
    done, out = set(), []
    for c, l, p in zip(ctxs, labels, probs):
        if p is None or l["window"] in done:
            continue
        best = None
        for side, prob, ask in (("yes", p, c["ask_yes"]), ("no", 1 - p, 1 - c["bid_yes"])):
            paid = min(0.99, ask + slip)
            e = prob - paid - fee1(paid)
            if e >= margin and (best is None or e > best[1]):
                best = (side, e, ask)
        if best is None:
            continue
        done.add(l["window"])
        side, _, ask = best
        win = 1.0 if (l["y"] == 1) == (side == "yes") else 0.0
        row = {"day": datetime.fromtimestamp(l["close_ts"], timezone.utc).strftime("%Y-%m-%d"), "close_ts": l["close_ts"],
               "side": side, "ask": ask, "win": win, "asset": c.get("asset")}
        for name, s in (("opt", 0.0), ("cons", slip)):
            paid = min(0.99, ask + s)
            row[f"pnl_{name}"] = win - paid - fee1(paid)
            row[f"paid_{name}"] = paid + fee1(paid)
        out.append(row)
    return out


def wilson(k: int, n: int, z: float = 1.96) -> Tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (c - h, c + h)


def summarize(tr: List[Dict[str, Any]], kind: str = "cons", boot: int = 1000, seed: int = 7) -> Dict[str, Any]:
    n = len(tr)
    if n == 0:
        return {"n": 0}
    pnl = [t[f"pnl_{kind}"] for t in tr]
    paid = [t[f"paid_{kind}"] for t in tr]
    wins = sum(t["win"] for t in tr)
    days = defaultdict(lambda: [0.0, 0.0])
    for t, x, p in zip(tr, pnl, paid):
        days[t["day"]][0] += x
        days[t["day"]][1] += p
    dr = [a / b for a, b in days.values() if b > 0]
    t_daily = (statistics.fmean(dr) / (statistics.stdev(dr) / math.sqrt(len(dr)))) if len(dr) > 2 and statistics.stdev(dr) > 0 else 0.0
    rng = random.Random(seed)
    vals = list(days.values())
    bs = []
    for _ in range(boot):
        smp = [vals[rng.randrange(len(vals))] for _ in vals]
        bs.append(sum(a for a, _ in smp) / sum(b for _, b in smp))
    bs.sort()
    eq = peak = mdd = 0.0
    for x in pnl:
        eq += x
        peak = max(peak, eq)
        mdd = max(mdd, peak - eq)
    half = n // 2
    gains, losses = sum(x for x in pnl if x > 0), -sum(x for x in pnl if x <= 0)
    lo, hi = wilson(int(wins), n)
    return {"n": n, "days": len(days), "win_rate": wins / n, "win_rate_ci": [lo, hi], "avg_price": statistics.fmean(t["ask"] for t in tr),
            "return": sum(pnl) / sum(paid), "return_ci": [bs[int(0.025 * boot)], bs[int(0.975 * boot)]], "t_daily": t_daily,
            "profit_factor": gains / losses if losses > 0 else math.inf, "max_drawdown_fraction": mdd / sum(paid),
            "halves": [sum(pnl[:half]) / max(1e-9, sum(paid[:half])), sum(pnl[half:]) / max(1e-9, sum(paid[half:]))]}


def calibration(probs: Sequence[Optional[float]], ctxs, labels, bins: int = 10) -> Dict[str, Any]:
    pts = [(p, c["mid"], l["y"]) for p, c, l in zip(probs, ctxs, labels) if p is not None]
    if not pts:
        return {"n": 0}
    brier = lambda k: statistics.fmean((x[k] - x[2]) ** 2 for x in pts)  # noqa: E731
    rel = []
    for b in range(bins):
        sel = [x for x in pts if b / bins <= x[0] < (b + 1) / bins or (b == bins - 1 and x[0] == 1.0)]
        if sel:
            rel.append({"bin": f"{b * 100 // bins}-{(b + 1) * 100 // bins}%", "n": len(sel), "predicted": statistics.fmean(x[0] for x in sel),
                        "observed": statistics.fmean(x[2] for x in sel), "market": statistics.fmean(x[1] for x in sel)})
    fav = [x for x in pts if max(x[1], 1 - x[1]) >= 0.8]
    fav_model = statistics.fmean((x[0] - x[2]) ** 2 for x in fav) if fav else None
    fav_market = statistics.fmean((x[1] - x[2]) ** 2 for x in fav) if fav else None
    return {"n": len(pts), "brier_model": brier(0), "brier_market": brier(1), "reliability": rel,
            "favourite_band": {"n": len(fav), "brier_model": fav_model, "brier_market": fav_market}}


def fee1_guess(paid: float) -> float:
    """Fee included in a paid amount (price + fee). Exact for prices on a 1-point grid."""
    for f in (0.01, 0.02):
        if abs(fee1(paid - f) - f) < 1e-9:
            return f
    return fee1(paid)


def per_asset(test_tr: List[Dict[str, Any]], tec, tel, tep) -> Dict[str, Any]:
    """Each asset separately: win rate (Wilson), net expectancy, fees, sample size, drawdown, calibration."""
    out: Dict[str, Any] = {}
    for a in sorted({c.get("asset") for c in tec}):
        tr = [t for t in test_tr if t.get("asset") == a]
        s = summarize(tr, "cons", boot=300)
        idx = [i for i, c in enumerate(tec) if c.get("asset") == a]
        cal = calibration([tep[i] for i in idx], [tec[i] for i in idx], [tel[i] for i in idx])
        out[a] = {"trades": s.get("n", 0), "win_rate": s.get("win_rate"), "win_rate_ci": s.get("win_rate_ci"),
                  "net_expectancy_return": s.get("return"), "return_ci": s.get("return_ci"),
                  "fees": round(sum(fee1_guess(t["paid_cons"]) for t in tr), 2), "max_drawdown_fraction": s.get("max_drawdown_fraction"),
                  "brier_model": cal.get("brier_model"), "brier_market": cal.get("brier_market"), "decisions": cal.get("n", 0)}
    return out


def correlation(test_tr: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Assets settle at the same moments and crypto moves together, so trades closing at the same time are not
    independent. Reports the number of independent settlement times, the average correlation of results between
    assets in the same window, and a t value clustered by settlement time (the gate itself uses the stricter
    clustering by day)."""
    by_close: Dict[float, Dict[str, float]] = defaultdict(dict)
    for t in test_tr:
        by_close[t["close_ts"]][t.get("asset")] = t["pnl_cons"] / t["paid_cons"]
    assets = sorted({a for v in by_close.values() for a in v})
    pairs = []
    for i, a in enumerate(assets):
        for b in assets[i + 1:]:
            xs = [(v[a], v[b]) for v in by_close.values() if a in v and b in v]
            if len(xs) >= 5:
                ma, mb = statistics.fmean(x for x, _ in xs), statistics.fmean(y for _, y in xs)
                sa = math.sqrt(sum((x - ma) ** 2 for x, _ in xs))
                sb = math.sqrt(sum((y - mb) ** 2 for _, y in xs))
                if sa > 0 and sb > 0:
                    pairs.append({"pair": f"{a}/{b}", "n": len(xs), "corr": sum((x - ma) * (y - mb) for x, y in xs) / (sa * sb)})
    cl = [sum(v.values()) / len(v) for v in by_close.values()]
    t_close = (statistics.fmean(cl) / (statistics.stdev(cl) / math.sqrt(len(cl)))) if len(cl) > 2 and statistics.stdev(cl) > 0 else 0.0
    return {"trades": len(test_tr), "independent_settlement_times": len(by_close), "pair_correlations": pairs,
            "avg_correlation": statistics.fmean(p["corr"] for p in pairs) if pairs else None, "t_by_settlement_time": t_close}


def evaluate(ctxs, labels, probs, margins: Sequence[float], gates, variants_before: int, trade_fn=None) -> Dict[str, Any]:
    trade_fn = trade_fn or trades
    ts = sorted({l["close_ts"] for l in labels})
    cut = ts[int(len(ts) * gates.train_fraction)] if ts else 0
    tr_idx = [i for i, l in enumerate(labels) if l["close_ts"] < cut]
    te_idx = [i for i, l in enumerate(labels) if l["close_ts"] >= cut]
    pick = lambda idx: ([ctxs[i] for i in idx], [labels[i] for i in idx], [probs[i] for i in idx])  # noqa: E731
    trc, trl, trp = pick(tr_idx)
    tec, tel, tep = pick(te_idx)
    per_margin = []
    for m in margins:
        s = summarize(trade_fn(trc, trl, trp, m, gates.conservative_slippage), boot=200)
        per_margin.append({"margin": m, "train": s})
    ok = [x for x in per_margin if x["train"].get("n", 0) >= max(30, gates.min_test_trades // 3)]
    chosen = max(ok, key=lambda x: x["train"]["return"])["margin"] if ok else None
    n_total = variants_before + len(margins)
    z = statistics.NormalDist().inv_cdf(1 - gates.alpha_total / max(1, n_total))
    test_tr = trade_fn(tec, tel, tep, chosen, gates.conservative_slippage) if chosen is not None else []
    cons, opt = summarize(test_tr, "cons"), summarize(test_tr, "opt")
    cal = calibration(tep, tec, tel)
    reasons = []
    if chosen is None:
        reasons.append("no margin produced enough trades in the training period")
    if cons.get("n", 0) < gates.min_test_trades:
        reasons.append(f"too few test trades ({cons.get('n', 0)} < {gates.min_test_trades})")
    if cons.get("days", 0) < gates.min_test_days:
        reasons.append(f"too few test days ({cons.get('days', 0)} < {gates.min_test_days})")
    if cons.get("n") and cons["return"] <= 0:
        reasons.append(f"negative return after conservative costs ({cons['return'] * 100:+.2f}%)")
    if cons.get("n") and cons["t_daily"] < z:
        reasons.append(f"not significant after {n_total} variants tested (t {cons['t_daily']:.2f} < {z:.2f})")
    if gates.require_both_halves_positive and cons.get("n") and min(cons["halves"]) <= 0:
        reasons.append("not positive in both halves of the test period")
    if cons.get("n") and cons["max_drawdown_fraction"] > gates.max_drawdown_fraction:
        reasons.append(f"drawdown too large ({cons['max_drawdown_fraction'] * 100:.0f}% of money paid)")
    if gates.require_beats_market_calibration and cal.get("n") and cal["brier_model"] >= cal["brier_market"]:
        reasons.append("probabilities no better calibrated than the market's own price")
    fb = cal.get("favourite_band") or {}
    trap = bool(cons.get("n") and cons["avg_price"] >= 0.8 and fb.get("n") and fb["brier_model"] >= fb["brier_market"])
    if trap:
        reasons.append("favourite trap: high win rate from favourites where the model is no better than the market")
    by_asset = per_asset(test_tr, tec, tel, tep)
    verdict = "PASSES offline gates: candidate for forward shadow testing (Phase 4), NOT for trading" if not reasons else "REJECTED"
    return {"verdict": verdict, "reasons": reasons, "variants_this_run": len(margins), "variants_total": n_total, "z_required": z,
            "chosen_margin": chosen, "train": per_margin, "test_conservative": cons, "test_optimistic": opt, "calibration": cal,
            "win_rate_target": gates.report_win_rate_target,
            "win_rate_target_met": bool(cons.get("n") and cons["win_rate"] >= gates.report_win_rate_target),
            "by_asset": by_asset, "combined_correlation": correlation(test_tr),
            "positive_assets": [a for a, v in by_asset.items() if (v["net_expectancy_return"] or 0) > 0],
            "test_period_start": cut}
