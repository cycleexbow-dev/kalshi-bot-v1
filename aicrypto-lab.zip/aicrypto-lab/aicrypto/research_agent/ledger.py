"""Append-only experiment ledger. Every attempt is recorded (started, finished, failed, refused).

Rows can be inserted but never updated or deleted: SQLite triggers abort any UPDATE or DELETE.
The ledger also counts every variant ever tested, which sets the multiple-testing threshold.
"""
from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import ROOT

DEFAULT = ROOT / "experiments" / "research_agent" / "ledger.sqlite"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, t REAL, day TEXT, event TEXT, hypothesis TEXT, spec_hash TEXT, code_hash TEXT,
  config_hash TEXT, protected_hash TEXT, variants INTEGER, status TEXT, verdict TEXT, detail TEXT);
CREATE TRIGGER IF NOT EXISTS no_update BEFORE UPDATE ON attempts BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_delete BEFORE DELETE ON attempts BEGIN SELECT RAISE(ABORT, 'ledger is append-only'); END;
"""


class Ledger:
    def __init__(self, path: Path = DEFAULT):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._c() as c:
            c.executescript(_SCHEMA)

    def _c(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    def add(self, event: str, hypothesis: str, *, spec_hash: str = "", code_hash: str = "", config_hash: str = "",
            protected_hash: str = "", variants: int = 0, status: str = "", verdict: str = "", detail: Any = None) -> int:
        now = time.time()
        with self._c() as c:
            cur = c.execute("INSERT INTO attempts (t, day, event, hypothesis, spec_hash, code_hash, config_hash, protected_hash, variants, "
                            "status, verdict, detail) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                            (now, datetime.fromtimestamp(now, timezone.utc).strftime("%Y-%m-%d"), event, hypothesis, spec_hash, code_hash,
                             config_hash, protected_hash, variants, status, verdict, json.dumps(detail, default=str) if detail is not None else None))
            return cur.lastrowid

    def started_today(self) -> int:
        day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        with self._c() as c:
            return c.execute("SELECT COUNT(*) FROM attempts WHERE day=? AND event='started'", (day,)).fetchone()[0]

    def variants_tested(self) -> int:
        """Every variant ever evaluated (finished attempts), the basis of the multiple-testing threshold."""
        with self._c() as c:
            return c.execute("SELECT COALESCE(SUM(variants), 0) FROM attempts WHERE event='finished'").fetchone()[0]

    def rows(self, limit: int = 200) -> List[Dict[str, Any]]:
        with self._c() as c:
            return [dict(r) for r in c.execute("SELECT * FROM attempts ORDER BY id DESC LIMIT ?", (limit,))]
