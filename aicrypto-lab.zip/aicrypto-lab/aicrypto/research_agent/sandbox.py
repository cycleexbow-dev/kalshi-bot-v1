"""Sandbox for AI-written research code.

A sandbox module must define `probability(ctx) -> float | None`: the chance that the window settles YES,
given ONLY the leakage-free inputs the harness puts in `ctx` (outcomes are never passed in).

Before it runs, the source is checked statically: only whitelisted imports; no file, network, process or
introspection built-ins; no dunder attribute access. It then runs in a separate Python process
(isolated mode, empty environment) under CPU and memory limits, and is called twice in different row
orders to catch hidden state. Any violation is recorded in the ledger as a failed attempt.
"""
from __future__ import annotations

import ast
import hashlib
import pickle
import resource
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

ALLOWED_IMPORTS = {"math", "statistics", "bisect", "itertools", "functools", "collections", "numpy"}
FORBIDDEN_NAMES = {"open", "exec", "eval", "compile", "__import__", "globals", "locals", "vars", "getattr", "setattr",
                   "delattr", "input", "breakpoint", "memoryview", "help", "exit", "quit", "dir", "type", "object",
                   "classmethod", "staticmethod", "super", "property"}
WORKER = Path(__file__).with_name("_worker.py")


class SandboxError(Exception):
    pass


def check_source(src: str) -> List[str]:
    """Static checks. Returns a list of problems (empty = allowed)."""
    problems: List[str] = []
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return [f"syntax error: {e}"]
    has_prob = False
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] not in ALLOWED_IMPORTS:
                    problems.append(f"import not allowed: {a.name}")
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "").split(".")[0] not in ALLOWED_IMPORTS or node.level:
                problems.append(f"import not allowed: from {node.module}")
        elif isinstance(node, ast.Name) and node.id in FORBIDDEN_NAMES:
            problems.append(f"name not allowed: {node.id}")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            problems.append(f"dunder attribute not allowed: {node.attr}")
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            problems.append("global/nonlocal state not allowed")
        elif isinstance(node, ast.FunctionDef) and node.name == "probability":
            has_prob = True
    if not has_prob:
        problems.append("module must define probability(ctx)")
    return problems


def code_hash(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()[:16]


def run(path: Path, ctxs: Sequence[Dict[str, Any]], cpu_seconds: int, memory_mb: int) -> List[Optional[float]]:
    """Run probability() over ctxs in an isolated, resource-limited process. Raises SandboxError."""
    src = Path(path).read_text()
    problems = check_source(src)
    if problems:
        raise SandboxError("; ".join(problems))
    with tempfile.TemporaryDirectory() as d:
        inp, out = Path(d) / "in.pkl", Path(d) / "out.pkl"
        inp.write_bytes(pickle.dumps(list(ctxs)))

        def limits():
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
            resource.setrlimit(resource.RLIMIT_AS, (memory_mb * 2**20, memory_mb * 2**20))

        try:
            p = subprocess.run([sys.executable, "-I", str(WORKER), str(path), str(inp), str(out)], env={}, cwd=d,
                               capture_output=True, text=True, timeout=cpu_seconds * 2 + 10, preexec_fn=limits)
        except subprocess.TimeoutExpired:
            raise SandboxError(f"time budget exceeded ({cpu_seconds} s CPU)")
        if p.returncode != 0:
            raise SandboxError(f"sandbox failed (code {p.returncode}): {(p.stderr or p.stdout)[-400:]}")
        res = pickle.loads(out.read_bytes())
    probs, again = res["probs"], res["probs_reversed"]
    if len(probs) != len(ctxs):
        raise SandboxError("wrong number of outputs")
    for a, b in zip(probs, again):
        if (a is None) != (b is None) or (a is not None and abs(a - b) > 1e-12):
            raise SandboxError("probability() depends on call order (hidden state): not allowed")
    for v in probs:
        if v is not None and not (0.0 <= v <= 1.0):
            raise SandboxError(f"probability out of range: {v}")
    return probs
