"""Phase 1 research agent infrastructure (owner request 2026-11-11). Offline research only.

A hypothesis (research/hypotheses/*.json) names a probability function written in a sandbox module
(research/sandbox/*.py). The fixed harness (harness.py) builds leakage-free inputs, runs the sandbox in
an isolated subprocess within the budgets of config/research_agent.yaml, scores the probabilities
chronologically out of sample with conservative fills, and applies fixed gates with multiple-testing
control across every variant ever recorded in the append-only ledger. Every attempt is recorded,
including failures. Passing the gates only makes a hypothesis a candidate for forward shadow testing;
nothing here can trade, promote a rule into the demo bot, or touch production.
"""
