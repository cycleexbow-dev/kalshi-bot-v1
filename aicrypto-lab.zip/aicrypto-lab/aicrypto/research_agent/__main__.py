"""Research agent command line (offline only; nothing here trades).

    python -m aicrypto.research_agent run research/hypotheses/<name>.json
    python -m aicrypto.research_agent ledger            # every attempt, newest first
"""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

from . import config as C
from . import harness as H
from . import harness_recorded as HR
from . import sandbox as S
from .ledger import Ledger


def run_hypothesis(spec_path: Path, ledger: Ledger = None, root: Path = C.ROOT) -> dict:
    ledger = ledger or Ledger()
    cfg = C.load()
    raw = Path(spec_path).read_bytes()
    spec = json.loads(raw)
    hid = spec.get("id") or Path(spec_path).stem
    meta = dict(spec_hash=hashlib.sha256(raw).hexdigest()[:16], config_hash=cfg.hash, protected_hash=C.protected_hash())
    if ledger.started_today() >= cfg.budgets.max_experiments_per_day:
        ledger.add("refused", hid, status="budget", detail="daily experiment budget used up", **meta)
        return {"verdict": "REFUSED", "reasons": ["daily experiment budget used up"]}
    sandbox_path = (root / spec["sandbox"]).resolve()
    meta["code_hash"] = S.code_hash(sandbox_path) if sandbox_path.exists() else ""
    margins = list(spec.get("margins", [0.0, 0.02, 0.04]))
    assets = [a for a in spec.get("assets", cfg.assets) if a in cfg.assets]
    problems = []
    if len(margins) > cfg.budgets.max_variants_per_hypothesis:
        problems.append(f"too many variants ({len(margins)} > {cfg.budgets.max_variants_per_hypothesis})")
    if not assets:
        problems.append("no allowed assets (allowed: " + ", ".join(cfg.assets) + ")")
    if root.resolve() / "research" / "sandbox" not in sandbox_path.parents:
        problems.append("sandbox code must live in research/sandbox/")
    if problems:
        ledger.add("refused", hid, status="invalid_spec", detail=problems, **meta)
        return {"verdict": "REFUSED", "reasons": problems}
    ledger.add("started", hid, variants=len(margins), detail={"title": spec.get("title"), "rationale": spec.get("rationale"),
                                                               "assets": assets, "margins": margins}, **meta)
    t0 = time.time()
    try:
        data = spec.get("data", "minute")
        excluded = None
        if data == "recorded":                 # recorder: second-level index + real order books (final minute)
            ctxs, labels, excluded = HR.build(root, assets, spec.get("leads", HR.LEADS))
            trade_fn = HR.trades
        else:                                  # 30 days of real-exchange 1-minute history
            ctxs, labels = H.build(root, assets, spec.get("leads", H.LEADS))
            trade_fn = H.trades
        probs = S.run(sandbox_path, ctxs, cfg.budgets.max_cpu_seconds_per_experiment, cfg.budgets.max_memory_mb)
    except S.SandboxError as e:
        ledger.add("failed", hid, variants=0, status="sandbox", verdict="REJECTED", detail=str(e), **meta)
        return {"verdict": "REJECTED", "reasons": [f"sandbox: {e}"]}
    except Exception as e:
        ledger.add("failed", hid, variants=0, status="error", verdict="ERROR", detail=f"{type(e).__name__}: {e}", **meta)
        raise
    res = H.evaluate(ctxs, labels, probs, margins, cfg.gates, ledger.variants_tested(), trade_fn)
    res.update(hypothesis=hid, assets=assets, data=data, decisions=len(ctxs), excluded=excluded,
               windows=len({l["window"] for l in labels}), seconds=round(time.time() - t0, 1))
    ledger.add("finished", hid, variants=len(margins), status="ok", verdict=res["verdict"], detail=res, **meta)
    return res


def _pct(x):
    return "—" if x is None else f"{x * 100:+.2f}%"


def report(res: dict) -> str:
    if res.get("verdict") in ("REFUSED",) or "test_conservative" not in res:
        return f"{res.get('verdict')}: " + "; ".join(res.get("reasons", []))
    c, o, cal = res["test_conservative"], res["test_optimistic"], res["calibration"]
    lines = [f"{res['hypothesis']}: {res['verdict']}"]
    for r in res["reasons"]:
        lines.append(f"  - {r}")
    if c.get("n"):
        lo, hi = c["win_rate_ci"]
        lines += [f"  test trades {c['n']} over {c['days']} days, chosen margin {res['chosen_margin']}",
                  f"  win rate {c['win_rate'] * 100:.1f}% (95% range {lo * 100:.1f}-{hi * 100:.1f}%), target {res['win_rate_target'] * 100:.0f}%, avg price {c['avg_price'] * 100:.1f}%",
                  f"  return per trade: conservative {_pct(c['return'])} (95% range {_pct(c['return_ci'][0])} to {_pct(c['return_ci'][1])}), optimistic {_pct(o['return'])}",
                  f"  profit factor {c['profit_factor']:.2f}, max drawdown {c['max_drawdown_fraction'] * 100:.1f}% of money paid, t(daily) {c['t_daily']:.2f} vs {res['z_required']:.2f} required"]
    lines.insert(1, f"  data: {res.get('data')}, {res.get('windows')} windows, {res.get('decisions')} decisions"
                    + (f", excluded (never estimated): {res['excluded']}" if res.get("excluded") else ""))
    if res.get("by_asset"):
        lines.append("  by asset (test, conservative): trades | win rate | net return | fees | drawdown | Brier model vs market")
        for a, v in res["by_asset"].items():
            wr = f"{v['win_rate'] * 100:.0f}%" if v["win_rate"] is not None else "—"
            lines.append(f"    {a:5} {v['trades']:5d} | {wr:>4} | {_pct(v['net_expectancy_return']):>8} | ${v['fees']:.2f} | "
                         f"{(v['max_drawdown_fraction'] or 0) * 100:.0f}% | "
                         + (f"{v['brier_model']:.4f} vs {v['brier_market']:.4f}" if v["brier_model"] is not None else "—"))
    cc = res.get("combined_correlation") or {}
    if cc.get("trades"):
        lines.append(f"  combined: {cc['trades']} trades at {cc['independent_settlement_times']} independent settlement times; "
                     f"avg correlation between assets {cc['avg_correlation'] if cc['avg_correlation'] is None else round(cc['avg_correlation'], 2)}; "
                     f"t by settlement time {cc['t_by_settlement_time']:.2f} (gate uses the stricter t by day)")
    if cal.get("n"):
        lines.append(f"  calibration (Brier, lower is better): model {cal['brier_model']:.4f} vs market {cal['brier_market']:.4f}")
        lines.append("  reliability (all test decisions): predicted -> actually happened (market said)")
        for b in cal["reliability"]:
            lines.append(f"    {b['bin']:>8}  n={b['n']:5d}  model {b['predicted'] * 100:5.1f}% -> {b['observed'] * 100:5.1f}%  (market {b['market'] * 100:5.1f}%)")
    return "\n".join(lines)


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "run":
        for p in sys.argv[2:]:
            print(report(run_hypothesis(Path(p))))
    elif len(sys.argv) >= 2 and sys.argv[1] == "ledger":
        for r in Ledger().rows():
            print(f"{r['id']:4d} {time.strftime('%m-%d %H:%M', time.localtime(r['t']))} {r['event']:8} {r['hypothesis']:28} {r['variants']:2} {r['verdict'] or r['status']}")
    else:
        print(__doc__)
