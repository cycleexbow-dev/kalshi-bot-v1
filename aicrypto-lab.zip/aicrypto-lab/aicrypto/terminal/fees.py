"""Order cost / fee estimates for the order ticket (Decimal arithmetic only).

Kalshi's published trading-fee schedule: fee = round_up(rate x C x P x (1 - P)) to the next
cent, with rate 0.07 for taker fills (scaled by the series fee_multiplier) and 0.0175 for
maker fills on series whose fee_type includes maker fees. These are ESTIMATES shown before an
order; the exchange's fill report is authoritative.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_CEILING, Decimal
from typing import List, Optional

TAKER_RATE = Decimal("0.07")
MAKER_RATE = Decimal("0.0175")
CENT = Decimal("0.01")
P4 = Decimal("0.0001")


def fee_estimate(count: Decimal, price: Decimal, *, maker: bool = False, fee_type: str = "quadratic",
                 multiplier: Decimal = Decimal(1)) -> Decimal:
    if count <= 0 or not (Decimal(0) < price < Decimal(1)):
        return Decimal(0)
    if fee_type == "flat":
        return Decimal(0)
    if maker and "maker" not in fee_type:
        return Decimal(0)
    rate = (MAKER_RATE if maker else TAKER_RATE) * multiplier
    raw = rate * count * price * (Decimal(1) - price)
    return raw.quantize(CENT, rounding=ROUND_CEILING)


@dataclass
class OrderPreview:
    side: str
    price: Decimal
    count: Decimal
    cost: Decimal
    fee_taker: Decimal
    fee_maker: Decimal
    max_loss: Decimal
    max_profit: Decimal
    errors: List[str]

    def to_dict(self) -> dict:
        s = lambda d: f"{d:.2f}"  # noqa: E731
        return {"side": self.side, "price": f"{self.price:.4f}", "count": f"{self.count:.2f}", "cost": s(self.cost),
                "fee_taker": s(self.fee_taker), "fee_maker": s(self.fee_maker), "max_loss": s(self.max_loss),
                "max_profit": s(self.max_profit), "errors": self.errors, "valid": not self.errors}


def preview(side: str, price_dollars: str, count: str, *, tick_p4: int = 100, fee_type: str = "quadratic",
            multiplier: float = 1.0, fractional: bool = False) -> OrderPreview:
    errors: List[str] = []
    side = (side or "").lower()
    if side not in ("yes", "no"):
        errors.append("side must be YES or NO")
    try:
        price = Decimal(str(price_dollars))
    except Exception:
        price, _ = Decimal(0), errors.append("price is not a number")
    try:
        qty = Decimal(str(count))
    except Exception:
        qty, _ = Decimal(0), errors.append("quantity is not a number")
    if not errors:
        if not (Decimal("0.01") <= price <= Decimal("0.99")):
            errors.append("price must be between $0.01 and $0.99")
        tick = Decimal(tick_p4 or 100) * P4
        if price % tick != 0:
            errors.append(f"price must be a multiple of the ${tick:.4f} tick")
        if qty <= 0:
            errors.append("quantity must be positive")
        elif not fractional and qty != qty.to_integral_value():
            errors.append("quantity must be a whole number of contracts")
    mult = Decimal(str(multiplier))
    cost = (price * qty).quantize(CENT, rounding=ROUND_CEILING) if not errors else Decimal(0)
    ft = fee_estimate(qty, price, fee_type=fee_type, multiplier=mult) if not errors else Decimal(0)
    fm = fee_estimate(qty, price, maker=True, fee_type=fee_type, multiplier=mult) if not errors else Decimal(0)
    max_loss = cost + ft
    max_profit = (qty - cost - ft) if not errors else Decimal(0)
    return OrderPreview(side, price, qty, cost, ft, fm, max_loss, max_profit, errors)


def p4_str(p4: Optional[int]) -> Optional[str]:
    return None if p4 is None else f"{Decimal(p4) * P4:.4f}"
