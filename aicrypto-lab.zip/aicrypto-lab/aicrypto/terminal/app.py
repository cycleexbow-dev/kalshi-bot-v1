"""AI Crypto Lab desktop terminal: FastAPI backend + static single-page UI.

Bind address is 127.0.0.1 only. Market data is read-only. Demo orders (Kalshi demo host only)
are handled by demo_api.py via aicrypto/kalshi/demo_exec. No key material, key id or key path
is ever returned by any endpoint.
"""
from __future__ import annotations

import asyncio
import contextlib
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .. import __version__
from ..kalshi.models import dollars_to_p4, fp_to_c2
from .fees import p4_str, preview
from .service import TerminalService

STATIC = Path(__file__).with_name("static")
TICKER_RE = re.compile(r"^[A-Z0-9_.-]{1,80}$")
INDEX_RE = re.compile(r"^[A-Z0-9_]{2,24}$")


def _parse_levels(levels) -> List[List[Any]]:
    out = []
    for lvl in levels or []:
        try:
            p, q = dollars_to_p4(lvl[0]), fp_to_c2(lvl[1])
        except (TypeError, IndexError, ValueError):
            continue
        if p is not None and q:
            out.append([p, q])
    return out


def book_payload(yes_bids: Dict[int, int], no_bids: Dict[int, int], source: str, age_s: Optional[float]) -> Dict[str, Any]:
    yb = sorted(yes_bids.items(), key=lambda x: -x[0])
    nb = sorted(no_bids.items(), key=lambda x: -x[0])
    best_yb = yb[0][0] if yb else None
    best_ya = (10000 - nb[0][0]) if nb else None
    fmt = lambda lv: [[p4_str(p), round(q / 100, 2)] for p, q in lv[:15]]  # noqa: E731
    return {"available": True, "source": source, "age_s": age_s, "yes_bids": fmt(yb), "no_bids": fmt(nb),
            "yes_asks": [[p4_str(10000 - p), round(q / 100, 2)] for p, q in nb[:15]],
            "best_yes_bid": p4_str(best_yb), "best_yes_ask": p4_str(best_ya),
            "spread": p4_str(best_ya - best_yb) if (best_ya and best_yb) else None,
            "yes_depth": round(sum(q for _, q in yb) / 100, 2), "no_depth": round(sum(q for _, q in nb) / 100, 2)}


def create_terminal_app(service: TerminalService, *, settings=None, legacy_app=None, pid_info: Optional[Dict[str, Any]] = None) -> FastAPI:
    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        boot = asyncio.create_task(service.start())     # health answers while the registry loads
        try:
            yield
        finally:
            boot.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await boot
            await service.stop()

    app = FastAPI(title="AI Crypto Lab terminal", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    started = time.time()

    def need_ready():
        if service.reg is None or service.load.phase != "ready":
            raise HTTPException(503, detail={"loading": True, "phase": service.load.phase, "progress": service.load.progress})

    def need_market(ticker: str):
        if not TICKER_RE.match(ticker or ""):
            raise HTTPException(400, "bad ticker")
        need_ready()
        if ticker not in service.access:      # non-financial / undecided markets are invisible
            raise HTTPException(404, "market not available in this terminal")
        return service.reg.markets[ticker]

    @app.middleware("http")
    async def no_cache(request, call_next):
        resp = await call_next(request)
        if request.url.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        elif request.url.path.startswith("/static/"):
            resp.headers["Cache-Control"] = "no-cache"      # revalidate: an app update shows without a manual refresh
        resp.headers["X-Content-Type-Options"] = "nosniff"
        return resp

    # ------------------------------------------------------------------ health (used by the launcher)
    @app.get("/api/health")
    async def health():
        return {"app": "aicrypto-lab", "component": "terminal", "version": __version__, "pid": os.getpid(),
                "started": started, "uptime_s": round(time.time() - started, 1), "phase": service.load.phase,
                "progress": round(service.load.progress, 3), "message": service.load.message, "error": service.load.error,
                "environment": service.env, "orders_enabled": service.demo.state == "connected", "order_host": "demo-api.kalshi.co",
                **(pid_info or {})}

    # ------------------------------------------------------------------ terminal data
    @app.get("/api/terminal/status")
    async def status():
        return service.status()

    @app.get("/api/terminal/cf_stream")
    async def cf_stream(request: Request):
        """Read-only stream of the CF Benchmarks index messages this app already receives (no keys, no
        account data). Lets the market recorder use the app's connection as a second, independent source."""
        import json as _json
        from fastapi.responses import StreamingResponse
        q = service.cf_subscribe()

        async def gen():
            try:
                while True:
                    if await request.is_disconnected():
                        break
                    try:
                        item = await asyncio.wait_for(q.get(), 15)
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
                        continue
                    yield "data: " + _json.dumps(item, separators=(",", ":")) + "\n\n"
            finally:
                service.cf_unsubscribe(q)
        return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-store"})

    @app.get("/api/terminal/loop")
    async def loop_health():
        lw = getattr(service, "loopwatch", None)
        ws = getattr(service, "ws", None)
        st = getattr(ws, "stats", None)
        return {"loop": lw.status() if lw else None,
                "ws": {k: getattr(st, k) for k in ("connects", "reconnects", "stale_events") if hasattr(st, k)} if st else None,
                "live": service.live.state}

    @app.get("/api/terminal/feeds")
    async def feeds():
        return {"feeds": service.feeds()}

    @app.get("/api/terminal/tabs")
    async def tabs():
        need_ready()
        return service.tabs()

    @app.get("/api/terminal/live15")
    async def live15(refresh: int = 0):
        need_ready()
        rep = None
        if refresh:
            try:
                rep = await service.refresh_15m(min_gap_s=2.0)
            except Exception as exc:
                rep = {"series": 0, "markets": 0, "failed": 1, "error": f"{type(exc).__name__}: {exc}"}
        return {"markets": service.live15(), "refresh": rep}

    @app.get("/api/terminal/markets")
    async def markets(tab: Optional[str] = None, q: str = "", duration: str = "", status: str = "open", access: str = "",
                      sort: str = "close", limit: int = Query(200, ge=1, le=500), offset: int = Query(0, ge=0)):
        need_ready()
        if status not in ("open", "upcoming", "closed", "all"):
            raise HTTPException(400, "bad status")
        return service.query(tab=tab, q=q[:80], duration=duration, status=status, access=access, sort=sort, limit=limit, offset=offset)

    @app.get("/api/terminal/market/{ticker}")
    async def market(ticker: str):
        m = need_market(ticker)
        reg = service.reg
        d = reg.decisions[ticker]
        s = reg.series.get(m.series_ticker)
        row = service.row(ticker)
        ref_idx = d.reference.instrument if d.reference.provider.value == "cf_benchmarks" else None
        ref_live = service.ref_last.get(ref_idx) if ref_idx else None
        hist = reg.eligibility_history(ticker)[-5:]
        return {**row,
                "rules_primary": m.rules_primary, "rules_secondary": m.rules_secondary, "can_close_early": m.can_close_early,
                "expected_expiration_time": m.expected_expiration_time.isoformat() if m.expected_expiration_time else None,
                "settlement_timer_seconds": m.settlement_timer_seconds, "tick": p4_str(m.tick_p4 or 100),
                "result": m.result or None, "settlement_value": p4_str(m.settlement_value_p4),
                "series_info": {"title": s.title if s else "", "category": s.category if s else "", "frequency": s.frequency if s else "",
                                "fee_type": s.fee_type if s else "", "fee_multiplier": s.fee_multiplier if s else 1.0,
                                "contract_url": s.contract_url if s else "", "contract_terms_url": s.contract_terms_url if s else "",
                                "sources": [{"name": x.name, "url": x.url} for x in (s.settlement_sources if s else [])]},
                "settlement": {**d.reference.to_dict(), "method_text": d.reference.method.value.replace("_", " ")},
                "duration_info": d.duration.to_dict(), "notes": d.notes,
                "reference_live": ({"index": ref_idx, "value": ref_live[1], "age_s": round(time.time() - ref_live[0], 1)}
                                   if ref_live else {"index": ref_idx, "value": None, "age_s": None}),
                "eligibility_history": hist,
                "position": {"kalshi_demo": None, "local_paper": None,
                             "note": "Positions appear here once demo trading (Milestone B) is enabled."},
                "orders_enabled": service.demo.state == "connected"}

    @app.get("/api/terminal/market/{ticker}/book")
    async def book(ticker: str):
        need_market(ticker)
        ws = service.ws
        b = ws.books.books.get(ticker) if ws is not None else None
        if b is not None and b.valid:
            age = round((time.monotonic_ns() - b.last_update_ns) / 1e9, 1) if b.last_update_ns else None
            return book_payload(b.yes_bids, b.no_bids, "live", age)
        try:
            data = await service.cached("book", ticker, 2.0, lambda: service._rest().get_orderbook(ticker, depth=20))
        except Exception as exc:
            return {"available": False, "error": f"order book unavailable ({type(exc).__name__})"}
        ob = data.get("orderbook_fp") or {}
        return book_payload(dict(_parse_levels(ob.get("yes_dollars"))), dict(_parse_levels(ob.get("no_dollars"))), "rest", None)

    @app.get("/api/terminal/market/{ticker}/history")
    async def history(ticker: str):
        m = need_market(ticker)
        now = int(time.time())
        span_short = (m.close_time and m.open_time and (m.close_time - m.open_time).total_seconds() <= 2 * 86400)
        interval, start = (1, now - 6 * 3600) if span_short else (60, now - 7 * 86400)
        if m.open_time:
            start = max(start, int(m.open_time.timestamp()) - 60)
        points, err = [], None
        try:
            data = await service.cached("candles", f"{ticker}:{interval}", 20.0,
                                        lambda: service._rest().get_candlesticks_multi([ticker], start, now, interval))
            mk = (data.get("markets") or [{}])
            entry = next((x for x in mk if x.get("market_ticker", x.get("ticker")) == ticker), mk[0] if mk else {})
            for c in entry.get("candlesticks") or []:
                ts = c.get("end_period_ts")
                yb = (c.get("yes_bid") or {}).get("close_dollars")
                ya = (c.get("yes_ask") or {}).get("close_dollars")
                px = (c.get("price") or {}).get("close_dollars")
                if ts:
                    points.append([int(ts), yb, ya, px])
        except Exception as exc:
            err = f"history unavailable ({type(exc).__name__})"
        live = [[int(t), p4_str(b), p4_str(a), p4_str(lp)] for t, b, a, lp in service.ticks.get(ticker, [])]
        return {"interval_min": interval, "candles": points, "live": live, "error": err}

    @app.get("/api/terminal/market/{ticker}/trades")
    async def trades(ticker: str):
        need_market(ticker)
        try:
            data = await service.cached("trades", ticker, 5.0, lambda: service._rest().get_trades(ticker=ticker, limit=50))
        except Exception as exc:
            return {"available": False, "trades": [], "error": f"trades unavailable ({type(exc).__name__})"}
        out = []
        for t in data.get("trades") or []:
            out.append({"time": t.get("created_time"), "yes_price": t.get("yes_price_dollars"), "no_price": t.get("no_price_dollars"),
                        "count": t.get("count_fp"), "taker_side": t.get("taker_side")})
        return {"available": True, "trades": out}

    @app.get("/api/terminal/market/{ticker}/preview")
    async def order_preview(ticker: str, side: str = "yes", price: str = "0.50", count: str = "1"):
        """Local estimate only. There is no order submission endpoint in Milestone A."""
        m = need_market(ticker)
        s = service.reg.series.get(m.series_ticker)
        pv = preview(side, price, count, tick_p4=m.tick_p4 or 100, fee_type=s.fee_type if s else "quadratic",
                     multiplier=s.fee_multiplier if s else 1.0, fractional=bool(m.raw.get("fractional_trading_enabled")))
        a = service.access[ticker]
        risk = service.ks.risk
        return {**pv.to_dict(), "access": a.to_dict(), "submission": "demo" if service.demo.state == "connected" else "unavailable",
                "submission_note": "Orders go to the Kalshi demo exchange only, after you confirm them.",
                "risk_note": f"Default demo limits: {risk.max_loss_per_position:.0%} per position, "
                             f"{risk.max_aggregate_planned_loss:.0%} aggregate, {risk.daily_realized_loss_stop:.0%} daily stop."}

    @app.get("/api/terminal/reference/{index_id}")
    async def reference(index_id: str):
        if not INDEX_RE.match(index_id):
            raise HTTPException(400, "bad index")
        pts = [[round(t, 1), v] for t, v in service.ref.get(index_id, [])]
        last = service.ref_last.get(index_id)
        return {"index": index_id, "points": pts, "last": last[1] if last else None,
                "age_s": round(time.time() - last[0], 1) if last else None}

    # ------------------------------------------------------------------ research / analytics (existing crypto lab, read-only)
    @app.get("/api/terminal/research")
    async def research():
        out: Dict[str, Any] = {"crypto_runs": [], "kalshi_strategies": [], "summary": None,
                               "kalshi_note": "Strategy generation, backtests and validation gates for Kalshi arrive in Milestone D."}
        if settings is None:
            return out
        try:
            import json as _j
            from ..experiments import Tracker
            tr = Tracker(settings.path("experiments"))
            runs = tr.list_runs(limit=60)
            for r in runs:
                r.pop("spec_json", None)
            out["crypto_runs"] = runs
            out["summary"] = tr.summary()
            lp = settings.path("experiments") / "last_promote.json"
            if lp.exists():
                out["last_promote"] = _j.loads(lp.read_text())
        except Exception as exc:
            out["error"] = f"research data unavailable ({type(exc).__name__})"
        return out

    @app.get("/api/terminal/analytics")
    async def analytics():
        out: Dict[str, Any] = {
            "crypto_paper": {"label": "Crypto spot paper (Freqtrade dry-run)", "available": False},
            "kalshi_local_paper": {"label": "Kalshi local paper simulation", "available": False,
                                   "note": "Recorder, replay and simulated fills arrive in Milestone C."},
            "kalshi_demo": {"label": "Kalshi demo fills", "available": False,
                            "note": "Demo orders and fills arrive in Milestone B."},
        }
        if settings is not None:
            try:
                from dataclasses import asdict
                from ..reporting import read_paper_trades
                ps = asdict(read_paper_trades(settings, recent=50))
                ps.pop("db_path", None)
                out["crypto_paper"].update(ps)
            except Exception as exc:
                out["crypto_paper"]["error"] = f"unavailable ({type(exc).__name__})"
        return out

    # ------------------------------------------------------------------ demo trading + automation
    from .demo_api import add_demo_routes
    add_demo_routes(app, service, port=(pid_info or {}).get("port"))

    # ------------------------------------------------------------------ UI
    if legacy_app is not None:
        app.mount("/legacy", legacy_app)
    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-store"})

    return app
