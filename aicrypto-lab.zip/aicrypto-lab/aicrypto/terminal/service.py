"""Backend state for the desktop terminal.

* Loads the financial part of the market registry in a worker thread (with progress), then
  serves every request from memory on the event loop - no locks needed.
* Optionally runs the existing read-only StreamSession (market data only) with a supervisor
  that reconnects. Opening the app never starts any trading: there is no execution here.
* Keeps small in-memory buffers for the UI: reference-index prices, per-market quote ticks,
  dispatch latency.
* Detail-page REST calls (order book, candlesticks, trades) go through the public, read-only
  GuardedTransport and are cached briefly.
"""
from __future__ import annotations

import asyncio
import logging
import statistics
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

from ..kalshi.eligibility import Tier
from ..kalshi.models import MarketInfo, MarketStatus, dollars_to_p4, fp_to_c2
from ..kalshi.registry import MarketRegistry
from ..kalshi.settings import KalshiSettings
from ..kalshi.settlement_map import CF_INDEX_BY_ASSET
from .access import TABS, Access, classify, is_financial_series
from .fees import p4_str

log = logging.getLogger("aicrypto.terminal")

ASSET_BY_CF_INDEX = {v: k for k, v in CF_INDEX_BY_ASSET.items()}


@dataclass
class LoadState:
    phase: str = "starting"          # starting | loading | evaluating | ready | error
    progress: float = 0.0
    message: str = "Starting"
    error: str = ""
    started: float = field(default_factory=time.time)
    ready_at: Optional[float] = None


@dataclass
class LiveState:
    state: str = "off"               # off | no_credentials | connecting | live | error
    detail: str = ""
    last_error: str = ""
    started_at: Optional[float] = None
    attempts: int = 0
    not_live_since: Optional[float] = None    # when the feed last stopped being live



def market_payload(data: Any) -> Dict[str, Any]:
    """KalshiRestClient.get_market returns the bare market; tolerate the wrapped {'market': ...} form too."""
    if not isinstance(data, dict):
        return {}
    inner = data.get("market")
    return inner if isinstance(inner, dict) else data


def _settled_pnl(side: str, result: str, contracts: Any, cost: Any, realized: Any) -> "Decimal":
    """P/L (before fees) of a position held to settlement. `realized` is Kalshi's realized P/L on the
    same market, e.g. from YES and NO contracts that cancelled each other out before the end."""
    from decimal import Decimal
    n, c, r = Decimal(str(contracts or 0)), Decimal(str(cost or 0)), Decimal(str(realized or 0))
    return (n if side == result else Decimal(0)) - c + r


class TerminalService:
    def __init__(self, ks: KalshiSettings, *, env: str = "demo", live: bool = True,
                 signer_factory: Optional[Callable[[], Any]] = None, registry: Optional[MarketRegistry] = None,
                 rest_factory: Optional[Callable[[], Any]] = None, demo_exchange_factory: Optional[Callable[[], Any]] = None,
                 demo_ledger_path=None, real_client_factory: Optional[Callable[[], Any]] = None,
                 real_exchange_factory: Optional[Callable[[], Any]] = None, real_ledger_path=None):
        self.ks = ks
        self.env = env
        self.live_enabled = live
        self.signer_factory = signer_factory
        self.rest_factory = rest_factory
        self.load = LoadState()
        self.live = LiveState()
        self.reg: Optional[MarketRegistry] = registry
        self.access: Dict[str, Access] = {}
        self.tab_stats: Dict[str, Dict[str, Any]] = {}
        self.ws = None
        self.sess = None
        self.rest = None
        self._tasks: List[asyncio.Task] = []
        self._cache: Dict[Tuple[str, str], Tuple[float, Any]] = {}
        # live buffers
        self.ref: Dict[str, Deque[Tuple[float, float]]] = {}
        self.ref_last: Dict[str, Tuple[float, float, Optional[float]]] = {}   # index -> (t_wall, value, source_ts)
        self.ticks: Dict[str, Deque[Tuple[float, Optional[int], Optional[int], Optional[int]]]] = {}
        self.dispatch_us: Deque[float] = deque(maxlen=5000)
        self.cf_lag_ms: Deque[float] = deque(maxlen=2000)
        self.frame_times: Deque[float] = deque(maxlen=20000)
        self.errors: Deque[Dict[str, Any]] = deque(maxlen=50)
        self.now_fn: Callable[[], datetime] = lambda: datetime.now(timezone.utc)
        # demo trading (Milestone B) + automation (armed per session)
        from ..kalshi.demo_exec.automation import AutomationEngine
        from ..kalshi.demo_exec.ledger import DemoLedger
        from ..kalshi.demo_exec.trader import DemoTrader
        self.demo_ledger = DemoLedger(demo_ledger_path or ks.path("registry_db").parent / "demo_ledger.sqlite")
        self.demo = DemoTrader(ks, self.demo_ledger, self, demo_exchange_factory or (lambda: None))
        self.auto = AutomationEngine(self.demo, self.demo_ledger, ks.root, self.auto_context)
        from ..kalshi.lab.engine import LiveLab
        from ..kalshi.lab.realprice import RealPriceLab
        self.lab = LiveLab(self, ks.path("registry_db").parent / "lab.sqlite")
        # the same rules scored at the REAL exchange's public prices (read-only, never trades)
        self.real_lab = RealPriceLab(self, ks.path("registry_db").parent / "lab_real.sqlite", client_factory=real_client_factory)
        self.lab.real_evidence = self._real_evidence
        # REAL-MONEY trading (owner decision 2026-11-19, CLAUDE.md rule 21): its own ledger, the owner's fixed
        # limits, priced from the real exchange's quotes; the bot is off at every start.
        from ..kalshi.real_exec.trader import RealContext, RealTrader, make_real_bot
        self.real_ledger = DemoLedger(real_ledger_path or ks.path("registry_db").parent / "real_ledger.sqlite")
        self.real = RealTrader(ks, self.real_ledger, RealContext(self, lambda: self.real_lab.quotes, self.real_lab.real_shard),
                               real_exchange_factory or (lambda: None))
        self.real_bot = make_real_bot(self.real)
        self.real_lab.bot = self.real_bot

    # ---------------------------------------------------------------- lifecycle
    async def start(self) -> None:
        if self.reg is None:
            try:
                await asyncio.to_thread(self._load_registry)
            except Exception as exc:  # surfaced in the UI; the server keeps running
                log.exception("registry load failed")
                self.load.phase, self.load.error = "error", f"{type(exc).__name__}: {exc}"
                self.load.message = "Could not load the market registry"
                return
        else:
            self.reg.reevaluate_all()
        self.recompute_access()
        if self.live_enabled:
            self.reg.start_write_behind()          # registry disk writes off the event loop
        self._freeze_heap()
        self.load.phase, self.load.progress, self.load.message = "ready", 1.0, "Ready"
        self.load.ready_at = time.time()
        from .loopwatch import LoopWatch
        self.loopwatch = LoopWatch()
        self._tasks.append(asyncio.create_task(self.loopwatch.heartbeat()))
        self._tasks.append(asyncio.create_task(self._access_refresher()))
        self._tasks.append(asyncio.create_task(self._demo_loop()))
        self._tasks.append(asyncio.create_task(self._real_loop()))
        if self.live_enabled:
            self._tasks.append(asyncio.create_task(self.lab.run()))
            self._tasks.append(asyncio.create_task(self.real_lab.run()))
            self._tasks.append(asyncio.create_task(self._refresh_15m_loop()))
        if self.live_enabled:
            self._tasks.append(asyncio.create_task(self._live_supervisor()))

    async def stop(self) -> None:
        try:
            await self.auto._halt()          # never leave automation running past shutdown
            self.lab.bot.turn_off("backend stopping")
            if self.reg is not None:
                await asyncio.to_thread(self.reg.stop_write_behind)   # flush queued registry writes
        except Exception:
            pass
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()
        if self.rest is not None:
            try:
                await self.rest.aclose()
            except Exception:
                pass

    def _load_registry(self) -> None:
        if not self.ks.path("registry_db").exists():
            raise FileNotFoundError("no market registry yet - run `aicrypto kalshi discover` once")
        self.load.phase, self.load.message = "loading", "Loading financial markets"

        def p_load(i, n):
            self.load.progress = 0.5 * i / max(n, 1)

        reg = MarketRegistry(self.ks, series_filter=lambda s: is_financial_series(s, self.ks), progress=p_load)
        self.load.phase, self.load.message, self.load.progress = "evaluating", f"Checking eligibility of {len(reg.markets):,} markets", 0.5

        def p_eval(i, n):
            self.load.progress = 0.5 + 0.5 * i / max(n, 1)

        reg.reevaluate_all(progress=p_eval)
        self.reg = reg

    ACCESS_CHUNK = 500

    def _series_ok(self) -> Dict[str, bool]:
        """is_financial_series per series ticker, recomputed only when the series set changes."""
        reg = self.reg
        key = (id(reg.series), len(reg.series))
        if getattr(self, "_series_ok_key", None) != key:
            self._series_ok_cache = {k: is_financial_series(v, self.ks) for k, v in reg.series.items()}
            self._series_ok_key = key
        return self._series_ok_cache

    def _access_steps(self):
        """Classify every market; yields every ACCESS_CHUNK markets so an async caller can let the
        event loop breathe (one 233k-market pass used to freeze the live feed for seconds)."""
        reg = self.reg
        now = self.now_fn()
        ok = self._series_ok()
        acc: Dict[str, Access] = {}
        stats: Dict[str, Dict[str, Any]] = {t: {"visible": 0, "open": 0, "manual": 0, "auto": 0, "durations": {}} for t in TABS}
        for i, (t, m) in enumerate(list(reg.markets.items())):
            if i and i % self.ACCESS_CHUNK == 0:
                yield
            sok = ok.get(m.series_ticker)
            if not sok:
                continue                       # unknown or non-financial series: hidden (same as classify)
            a = classify(reg.decisions.get(t), m, reg.series.get(m.series_ticker), self.ks, now, series_ok=True)
            if not a.visible:
                continue
            acc[t] = a
            st = stats[a.tab]
            st["visible"] += 1
            if m.status is MarketStatus.ACTIVE:
                st["open"] += 1
                b = reg.decisions[t].duration.bucket.value
                st["durations"][b] = st["durations"].get(b, 0) + 1
            st["manual"] += a.manual
            st["auto"] += a.auto
        self.access, self.tab_stats = acc, stats

    def recompute_access(self) -> None:
        if self.reg is None:
            return
        for _ in self._access_steps():
            pass

    async def recompute_access_async(self) -> None:
        if self.reg is None:
            return
        for _ in self._access_steps():
            await asyncio.sleep(0)

    @staticmethod
    def _freeze_heap() -> None:
        """The registry keeps ~2-3 GB of long-lived objects. Python's full garbage collections kept
        rescanning all of them and froze the event loop for seconds (up to 40 s) at a time. Freezing moves
        the objects alive now out of the collector's view; new objects are still collected normally."""
        import gc
        gc.collect()
        gc.freeze()

    async def _access_refresher(self) -> None:
        n = 0
        while True:
            await asyncio.sleep(15)
            try:
                await self.recompute_access_async()
            except Exception as exc:
                self._error("access refresh", exc)
            n += 1
            if n % 240 == 0:                     # hourly: newly listed markets join the frozen set
                import gc
                gc.freeze()

    # ---------------------------------------------------------------- live market data (read-only)
    async def _live_supervisor(self) -> None:
        from ..kalshi.stream import StreamSession
        from ..kalshi.websocket import KalshiWebSocket
        backoff = 5.0
        while True:
            signer = None
            try:
                signer = self.signer_factory() if self.signer_factory else None
            except Exception as exc:
                self.live.detail = str(exc)
            if signer is None:
                self.live.state = "no_credentials"
                self.live.detail = self.live.detail or "Demo API key not configured; live data is off (see docs/KALSHI_DEMO_KEY.md)"
                await asyncio.sleep(60)
                continue
            self.live.state, self.live.attempts = "connecting", self.live.attempts + 1
            if self.live.not_live_since is None:
                self.live.not_live_since = time.time()
            try:
                self.ws = KalshiWebSocket(signer, self.env)
                self.ws.handlers.append(self._on_message)
                self.sess = StreamSession(self.ks, self.reg, self.ws, rest=self._rest(), record_dir=None)
                self.live.started_at = time.time()
                runner = asyncio.create_task(self.sess.run(seconds=10 ** 9))
                while not runner.done():
                    await asyncio.sleep(1)
                    self.live.state = "live" if self.ws.is_connected else "connecting"
                    if self.ws.is_connected:
                        self.live.not_live_since = None
                    elif self.live.not_live_since is None:
                        self.live.not_live_since = time.time()
                    if self.ws.is_connected:
                        backoff = 5.0
                runner.result()
            except asyncio.CancelledError:
                if self.ws is not None:
                    await self.ws.stop()
                raise
            except Exception as exc:
                self.live.state, self.live.last_error = "error", f"{type(exc).__name__}: {exc}"
                self._error("live data", exc)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 120.0)

    async def _on_message(self, msg) -> None:
        now = time.time()
        self.frame_times.append(now)
        if msg.t_recv_ns:
            self.dispatch_us.append((time.monotonic_ns() - msg.t_recv_ns) / 1000.0)
        t, d = msg.type, msg.data
        if t in ("cfbenchmarks_value", "cfbenchmarks_value_5hz"):
            if self.cf_subscribers:
                self._publish_cf(d, now)
            m = d.get("msg", {})
            idx = m.get("index_id")
            try:
                v = float(m.get("value_usd") or m.get("value"))
            except (TypeError, ValueError):
                return
            src = m.get("source_ts_ms")
            src_s = float(src) / 1000.0 if src else None
            if src_s and src_s > 1e9:
                self.cf_lag_ms.append(max(0.0, (now - src_s) * 1000.0))
            self.ref_last[idx] = (now, v, src_s)
            buf = self.ref.setdefault(idx, deque(maxlen=7200))
            if not buf or now - buf[-1][0] >= 1.0:          # 1 point/s, 2 hours
                buf.append((now, v))
        elif t == "ticker":
            m = d.get("msg", {})
            tk = m.get("market_ticker")
            if tk in self.access:
                buf = self.ticks.setdefault(tk, deque(maxlen=1800))
                buf.append((now, dollars_to_p4(m.get("yes_bid_dollars")), dollars_to_p4(m.get("yes_ask_dollars")),
                            dollars_to_p4(m.get("price_dollars") or m.get("last_price_dollars"))))

    # ---------------------------------------------------------------- demo trading support
    async def _demo_loop(self) -> None:
        while True:
            try:
                if self.demo.exchange() is not None:
                    await self.demo.refresh_account()
                    await self.demo.reconcile()
                    await self.update_pnl_today()
            except Exception as exc:
                self._error("demo account", exc)
            busy = self.demo_ledger.orders(states=("SUBMITTING", "UNKNOWN", "RESTING", "PARTIAL", "CANCEL_PENDING"), limit=1)
            await asyncio.sleep(3 if busy else 10)

    ACCOUNTS = ("demo", "real")

    def acct(self, account: str = "demo"):
        """(trader, ledger) of the account the owner is looking at: 'demo' (default) or 'real'."""
        if account == "real":
            return self.real, self.real_ledger
        if account == "demo":
            return self.demo, self.demo_ledger
        raise ValueError("account must be demo or real")

    async def _real_loop(self) -> None:
        """Real account: balance, positions and order reconciliation (only once the owner has set up the key)."""
        while True:
            try:
                if self.real.exchange() is not None:
                    await self.real.refresh_account()
                    await self.real.reconcile()
                    await self.real.auto_cashout()
                    self.real.day_equity()
                    await self.update_pnl_today("real")
            except Exception as exc:
                self._error("real account", exc)
            busy = self.real_ledger.orders(states=("SUBMITTING", "UNKNOWN", "RESTING", "PARTIAL", "CANCEL_PENDING"), limit=1)
            await asyncio.sleep(3 if busy or (self.real.account or {}).get("positions") else 10)

    def real_status(self) -> Dict[str, Any]:
        r, b = self.real, self.real_bot
        acct = r.account or {}
        return {"state": r.state, "error": r.last_error, "bot_on": b.on, "stake_pct": b.settings.stake_pct, "kill": r.kill_on(),
                "cashout_pct": r.cashout_pct(),
                "balance": acct.get("balance"), "portfolio_value": acct.get("portfolio_value"),
                "open_positions": len(acct.get("positions", [])), "positions": acct.get("positions", []),
                "limits": r.limits_status(), "last_bot_error": b.last_error,
                "events": [{"t": e["t"], "kind": e["kind"], "message": e["message"].replace("demo cash", "cash").replace("Demo cash", "Cash")}
                           for e in self.real_ledger.events(limit=30)],
                "rules": "same as demo practice mode, judged on their results at real prices"}

    # ---- local read-only copy of the CF index feed (second consumer for the recorder) ----------
    CF_QUEUE_MAX = 2000

    @property
    def cf_subscribers(self) -> list:
        return self.__dict__.setdefault("_cf_subs", [])

    def cf_subscribe(self) -> "asyncio.Queue":
        q: asyncio.Queue = asyncio.Queue(maxsize=self.CF_QUEUE_MAX)
        self.cf_subscribers.append(q)
        return q

    def cf_unsubscribe(self, q) -> None:
        if q in self.cf_subscribers:
            self.cf_subscribers.remove(q)

    def _publish_cf(self, data: Dict[str, Any], t_recv: float) -> None:
        """Never waits: a subscriber that falls behind loses messages (and its dropped count says so)."""
        for q in list(self.cf_subscribers):
            try:
                q.put_nowait({"t_recv": t_recv, "data": data})
            except asyncio.QueueFull:
                self.cf_dropped = getattr(self, "cf_dropped", 0) + 1

    async def update_pnl_today(self, account: str = "demo") -> None:
        """Today's profit/loss = every position closed since local midnight (settled or cashed out), after
        fees, from our own position records. Kalshi's position list drops a market once it settles, so
        deriving the figure from that list (the old way) lost most settled results."""
        from decimal import Decimal as _D
        try:
            rows = await self.transactions(account)   # also resolves results of newly settled positions
        except Exception as exc:
            self._error("today's profit/loss", exc)
            return
        midnight = datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        today = [r for r in rows if r.get("closed") and datetime.fromisoformat(r["closed"]).timestamp() >= midnight]
        total = sum((_D(r["pnl"]) - _D(r["fees"]) for r in today), _D(0))
        val = {"value": f"{total:.2f}", "trades": len(today), "wins": sum(1 for r in today if _D(r["pnl"]) - _D(r["fees"]) > 0)}
        if not hasattr(self, "pnl_by"):
            self.pnl_by = {}
        self.pnl_by[account] = val
        if account == "demo":
            self.pnl_today = val
        self.acct(account)[0].account["realized_today"] = val["value"]          # also what the demo daily loss stop sees

    # MarketContext for DemoTrader
    def market_access(self, ticker: str):
        if self.reg is None or ticker not in self.reg.markets:
            return None
        m = self.reg.markets[ticker]
        a = classify(self.reg.decisions.get(ticker), m, self.reg.series.get(m.series_ticker), self.ks, self.now_fn())   # fresh, not cached
        return a

    async def market_shard(self, ticker: str):
        """Kalshi exchange shard (exchange_index) this market trades on; fetched fresh if unknown."""
        m = self.market(ticker)
        if m is None:
            return None
        if m.raw.get("exchange_index") is None:
            try:
                data = await self._rest().get_market(ticker)
                m.raw["exchange_index"] = market_payload(data).get("exchange_index")
            except Exception:
                return None
        v = m.raw.get("exchange_index")
        return int(v) if v is not None else None

    def market(self, ticker: str):
        return self.reg.markets.get(ticker) if self.reg else None

    def series_for(self, ticker: str):
        m = self.market(ticker)
        return self.reg.series.get(m.series_ticker) if m else None

    async def fresh_book(self, ticker: str) -> Dict[str, Any]:
        b = self.ws.books.books.get(ticker) if self.ws is not None else None
        if b is not None and b.valid:
            age = (time.monotonic_ns() - b.last_update_ns) / 1e9 if b.last_update_ns else 0.0
            # an untouched live book is still current: the stream would have sent deltas
            return {"valid": True, "source": "live", "age_s": 0.0 if self.live.state == "live" else age,
                    "best_yes_bid": b.best_yes_bid, "best_yes_ask": b.best_yes_ask}
        try:
            data = await self._rest().get_orderbook(ticker, depth=10)
        except Exception as exc:
            return {"valid": False, "error": type(exc).__name__}
        ob = data.get("orderbook_fp") or {}
        yb = [dollars_to_p4(x[0]) for x in ob.get("yes_dollars") or [] if x and fp_to_c2(x[1])]
        nb = [dollars_to_p4(x[0]) for x in ob.get("no_dollars") or [] if x and fp_to_c2(x[1])]
        return {"valid": True, "source": "rest", "age_s": 0.0, "best_yes_bid": max(yb) if yb else None,
                "best_yes_ask": (10000 - max(nb)) if nb else None}

    # ---------------------------------------------------------------- 15-minute focus view
    FOCUS_CLASSES = ("crypto", "metals", "energy")
    ASSET_ORDER = ["BTC", "ETH", "SOL", "XRP", "DOGE", "GOLD", "SILVER", "COPPER", "WTI"]

    def live15(self) -> List[Dict[str, Any]]:
        """One row per asset: its currently open 15-minute window (or the next one if none is open)."""
        if self.reg is None:
            return []
        now = self.now_fn()
        best: Dict[str, Any] = {}
        for t, a in self.access.items():
            d = self.reg.decisions[t]
            if d.duration.bucket.value != "15m" or d.asset_class not in self.FOCUS_CLASSES:
                continue
            m = self.reg.markets[t]
            if not m.close_time or m.close_time <= now or m.status not in (MarketStatus.ACTIVE, MarketStatus.INITIALIZED):
                continue
            is_open = m.status is MarketStatus.ACTIVE and (m.open_time is None or m.open_time <= now)
            key = (0 if is_open else 1, m.close_time)
            if d.asset not in best or key < best[d.asset][0]:
                best[d.asset] = (key, t, is_open)
        order = {a: i for i, a in enumerate(self.ASSET_ORDER)}
        out = []
        for asset, (_, t, is_open) in best.items():
            r = self.row(t, now)
            r["open_now"] = is_open
            out.append(r)
        out.sort(key=lambda r: (0 if r["asset_class"] == "crypto" else 1, order.get(r["asset"], 99), r["asset"]))
        return out

    async def refresh_15m(self, min_gap_s: float = 5.0) -> Dict[str, Any]:
        """Pull the currently open 15-minute windows from Kalshi's public API. One failing series
        never stops the others; the report says exactly what happened."""
        now = time.monotonic()
        if now - getattr(self, "_last_15m_refresh", 0.0) < min_gap_s and getattr(self, "last_refresh", None):
            return {**self.last_refresh, "skipped": True}
        self._last_15m_refresh = now
        series = sorted({s.ticker for s in self.reg.series.values()
                         if s.frequency in ("fifteen_min", "15 minutes") and is_financial_series(s, self.ks)})
        rep: Dict[str, Any] = {"t": time.time(), "series": len(series), "markets": 0, "failed": 0, "error": "", "skipped": False}
        rest = self._rest()
        before = len(getattr(rest, "mismatches", []))
        got: List[Dict[str, Any]] = []
        for st in series:
            try:
                got += await rest.list_markets(status="open", series_ticker=st, max_pages=1)
            except Exception as exc:
                rep["failed"] += 1
                rep["error"] = rep["error"] or f"{st}: {type(exc).__name__}: {str(exc)[:160]}"
        for i in range(0, len(got), 250):    # a few disk commits instead of one per market (that took ~1 minute),
            with self.reg.batch():           # in slices so the live feed keeps running in between
                for raw in got[i:i + 250]:
                    self.reg.upsert_market(raw)
                    rep["markets"] += 1
            await asyncio.sleep(0)
        rep["rejected_format"] = len(getattr(rest, "mismatches", [])) - before
        if rep["rejected_format"] and not rep["error"]:
            mm = rest.mismatches[-1]
            rep["error"] = f"format: {mm.get('context')}: {str(mm.get('problems'))[:160]}"
        await self.recompute_access_async()
        self.last_refresh = rep
        return rep

    async def _refresh_15m_loop(self) -> None:
        """New 15-minute windows open constantly; keep the registry current."""
        while True:
            try:
                await self.refresh_15m()
            except Exception as exc:
                self.last_refresh = {"t": time.time(), "series": 0, "markets": 0, "failed": 1, "error": f"{type(exc).__name__}: {exc}", "skipped": False}
            await asyncio.sleep(30)

    def _real_bids(self, t: str) -> Dict[str, Optional[str]]:
        """Best bids on the REAL exchange for a ticker, from the real-price lab's quotes."""
        q = self.real_lab.quotes.get(t) if self.real_lab else None
        if not q or time.monotonic() - q[0] > 30:
            return {}
        yb, ya = q[1], q[2]
        return {"yes_bid": f"{yb / 10000:.4f}" if yb else None, "no_bid": f"{(10000 - ya) / 10000:.4f}" if ya else None}

    def positions_view(self, account: str = "demo") -> List[Dict[str, Any]]:
        """Active positions of the chosen account with current price, value and unrealized P/L
        (real positions are valued at the real exchange's prices)."""
        from decimal import Decimal as _D
        trader, _ = self.acct(account)
        out = []
        for p in trader.account.get("positions", []):
            t = p["ticker"]
            m = self.reg.markets.get(t) if self.reg else None
            n, cost = _D(p["contracts"]), _D(p["exposure"]).copy_abs()
            q = (self._real_bids(t) if account == "real" else self.quote(m)) if m is not None else {}
            bid = q.get("yes_bid") if p["side"] == "yes" else q.get("no_bid")
            value = (_D(bid) * n) if bid else None
            ttc = (m.close_time - self.now_fn()).total_seconds() if (m and m.close_time) else None
            out.append({"ticker": t, "title": (m.yes_sub_title or m.title) if m else t, "side": p["side"], "contracts": str(n),
                        "avg_price": str((cost / n).quantize(_D("0.0001"))) if n else None, "cost": str(cost),
                        "price": bid, "value": None if value is None else f"{value:.2f}",
                        "pnl": None if value is None else f"{value - cost:.2f}",
                        "pnl_pct": None if (value is None or cost == 0) else round(float((value - cost) / cost * 100), 1),
                        "seconds_to_close": None if ttc is None else int(ttc), "visible": t in self.access})
        return out

    def _real_evidence(self) -> Dict[str, Tuple[int, Optional[float], Optional[float]]]:
        """Per rule: (settled trades, net per trade, t) at real-exchange prices. Cached for 15 s."""
        now = time.monotonic()
        hit = getattr(self, "_real_ev", None)
        if hit and now - hit[0] < 15:
            return hit[1]
        try:
            ev = {r["cid"]: (r["n"], r["net_per_trade"], r["t"]) for r in self.real_lab.store.scoreboard()}
        except Exception:
            ev = {}
        self._real_ev = (now, ev)
        return ev

    FAMILY_INFO = {
        "fair": ("Fair value", "Buys when its price model says a side is cheap"),
        "lock": ("Final-seconds lock-in", "Last seconds: buys the side the settlement average has nearly locked in"),
        "momentum": ("Price momentum", "Follows the coin's move over the last 3 minutes"),
        "kmomentum": ("Kalshi momentum", "Follows Kalshi's own price move over the last 2 minutes"),
        "favorite": ("Favourite", "Near the end, buys the side priced at 80-98% (the favourite)"),
        "imbalance": ("Order-book imbalance", "Follows the side with far more buyers waiting"),
        "favmid": ("Favourite, 2-7 min", "Your idea: buys the side priced at 70-90% with 2-7 minutes left (testing only until it shows a profit at real prices)"),
    }

    def _shadow_by_family(self) -> Dict[str, Tuple[int, float]]:
        """Recorder's production-price shadow: per family (filled trades, return on money paid) at 1 s latency."""
        import json as _json
        import sqlite3 as _sq
        p = self.ks.path("registry_db").parent / "shadow_real.sqlite"
        if not p.exists():
            return {}
        g: Dict[str, List[float]] = {}
        c = _sq.connect(f"file:{p}?mode=ro", uri=True, timeout=5)
        try:
            for fam, fills_js, net_js in c.execute("SELECT family, fills, net FROM proposals WHERE result IS NOT NULL"):
                net = _json.loads(net_js or "{}")
                f = ((_json.loads(fills_js or "{}").get("L1") or {}).get("one") or {})
                if "L1_one" in net and f.get("filled"):
                    g.setdefault(fam, []).append((net["L1_one"], f["cost"] + f["fee"]))
        finally:
            c.close()
        return {k: (len(v), sum(a for a, _ in v) / sum(b for _, b in v)) for k, v in g.items() if sum(b for _, b in v) > 0}

    def _lab_by_family(self, store) -> Dict[str, Tuple[int, float]]:
        with store._c() as c:
            rows = c.execute("SELECT c.family, COUNT(DISTINCT t.ticker || t.side), "
                             "SUM(CAST(t.pnl AS REAL)) / SUM(CAST(t.price AS REAL) + CAST(t.fee AS REAL)) FROM trades t JOIN candidates c USING(cid) "
                             "WHERE t.settled_at IS NOT NULL AND t.result IN ('yes','no') GROUP BY c.family").fetchall()
        return {r[0]: (r[1], r[2]) for r in rows}

    async def lab_families(self) -> List[Dict[str, Any]]:
        """One plain row per strategy family: demo-price result, real-price result and a verdict."""
        hit = getattr(self, "_fam_cache", None)
        if hit and time.monotonic() - hit[0] < 60:
            return hit[1]
        demo, real_lab, shadow = await asyncio.gather(asyncio.to_thread(self._lab_by_family, self.lab.store),
                                                      asyncio.to_thread(self._lab_by_family, self.real_lab.store),
                                                      asyncio.to_thread(self._shadow_by_family))
        out = []
        for fam, (name, desc) in self.FAMILY_INFO.items():
            dn, dm = demo.get(fam, (0, None))
            if shadow.get(fam, (0, 0))[0] >= 30:
                rn, rm = shadow[fam]
                real_src = "real prices, 1 s delay, limited depth"
            else:
                rn, rm = real_lab.get(fam, (0, None))
                real_src = "real displayed prices"
            if rn >= 100:                                   # real-price evidence decides once there is enough
                if rm < -0.01:                              # returns: below -1% / up to +2% / above
                    verdict, tone = "Loses at real prices", "bad"
                elif rm <= 0.02:
                    verdict, tone = "No clear edge", ""
                else:
                    verdict, tone = "Promising, needs more proof", "warn"
            elif dn >= 30 and (dm or 0) <= 0:
                verdict, tone = "Losing", "bad"
            else:
                verdict, tone = "Still testing", ""
            out.append({"family": fam, "name": name, "description": desc, "verdict": verdict, "tone": tone,
                        "demo_trades": dn, "demo_ret": round(100 * dm, 1) if dm is not None else None,
                        "real_trades": rn, "real_ret": round(100 * rm, 1) if rm is not None else None, "real_source": real_src})
        self._fam_cache = (time.monotonic(), out)
        return out

    async def bot_progress(self, window: int = 25, account: str = "demo") -> Dict[str, Any]:
        """Is the bot getting better? Its closed demo trades in order, with a rolling win rate
        (share of trades that made money after fees) and cumulative profit after fees."""
        from decimal import Decimal as _D
        rows = [r for r in await self.transactions(account) if r["by"] == "bot" and r["closed"]]
        rows.sort(key=lambda r: r["closed"])
        pts, days, cum, wins = [], {}, _D(0), []
        for r in rows:
            net = _D(r["pnl"]) - _D(r["fees"])
            cum += net
            wins.append(1 if net > 0 else 0)
            last = wins[-window:]
            t = datetime.fromisoformat(r["closed"]).timestamp()
            pts.append({"t": t, "rolling_win_pct": round(100 * sum(last) / len(last), 1), "cum_net": float(cum)})
            d = datetime.fromtimestamp(t).strftime("%Y-%m-%d")
            dd = days.setdefault(d, {"day": d, "trades": 0, "wins": 0, "net": _D(0), "fees": _D(0), "staked": _D(0)})
            dd["trades"] += 1
            dd["wins"] += 1 if net > 0 else 0
            dd["net"] += net
            dd["fees"] += _D(r["fees"])
            dd["staked"] += _D(r["cost"])
        table = [{**d, "win_pct": round(100 * d["wins"] / d["trades"], 1), "net": f"{d['net']:.2f}", "fees": f"{d['fees']:.2f}",
                  "staked": f"{d['staked']:.2f}"} for d in sorted(days.values(), key=lambda d: d["day"])]
        n = len(rows)
        return {"window": window, "points": pts, "days": table, "trades": n, "today": getattr(self, "pnl_by", {}).get(account),
                "recent_win_pct": pts[-1]["rolling_win_pct"] if pts else None,
                "win_pct": round(100 * sum(wins) / n, 1) if n else None, "net": f"{cum:.2f}"}

    async def transactions(self, account: str = "demo") -> List[Dict[str, Any]]:
        """Closed positions, newest first. Sold positions use Kalshi's own realized P/L; positions
        held to the end are scored from the market result. P/L is before fees; fees are listed."""
        from decimal import Decimal as _D
        L = self.acct(account)[1]
        for tr in L.tracks("gone"):                               # settled: needs the market result
            t = tr["ticker"]
            m = self.reg.markets.get(t) if self.reg else None
            result = (m.result or "").lower() if m else ""
            if result not in ("yes", "no"):
                try:
                    data = await self.cached("result", t, 20.0, lambda t=t: self._rest().get_market(t))
                    result = (market_payload(data).get("result") or "").lower()
                except Exception:
                    result = ""
            if result in ("yes", "no"):
                n, cost = _D(tr["contracts"] or "0"), _D(tr["cost"] or "0")
                L.track_put(t, state="closed", how="settled", result=result, pnl=str(_settled_pnl(tr["side"], result, n, cost, tr.get("realized"))))
        bot_tickers = {o["ticker"] for o in L.orders(limit=500) if o["origin"].startswith(("bot", "auto"))}
        out = []
        for tr in L.tracks("closed"):
            t = tr["ticker"]
            m = self.reg.markets.get(t) if self.reg else None
            n, cost, pnl = _D(tr["contracts"] or "0"), _D(tr["cost"] or "0"), _D(tr["pnl"] or "0")
            if tr["how"] == "settled" and tr["result"] in ("yes", "no"):   # recompute: older rows missed the netted part
                pnl = _settled_pnl(tr["side"], tr["result"], n, cost, tr.get("realized"))
            iso = lambda ts: datetime.fromtimestamp(ts, timezone.utc).isoformat() if ts else None  # noqa: E731
            out.append({"ticker": t, "title": (m.yes_sub_title or m.title) if m else t, "side": tr["side"], "contracts": str(n),
                        "avg_entry": str((cost / n).quantize(_D("0.0001"))) if n else None,
                        "avg_exit": str(((cost + pnl) / n).quantize(_D("0.0001"))) if (n and tr["how"] == "cashout") else None,
                        "how": tr["how"], "result": tr["result"], "won": (tr["side"] == tr["result"]) if tr["how"] == "settled" else None,
                        "cost": f"{cost:.2f}", "fees": f"{_D(tr['fees'] or '0'):.2f}", "pnl": f"{pnl:.2f}",
                        "pnl_pct": round(float(pnl / cost * 100), 1) if cost else None,
                        "opened": iso(tr["opened"]), "closed": iso(tr["closed"]), "by": "bot" if t in bot_tickers else "manual"})
        out.sort(key=lambda r: r["closed"] or "", reverse=True)
        return out

    def auto_context(self) -> Dict[str, Any]:
        """Inputs for automated strategies: only auto-eligible, open markets."""
        from decimal import Decimal as _D
        out = []
        now = self.now_fn()
        for t, a in self.access.items():
            if not a.auto:
                continue
            r = self.row(t, now)
            q = r["quote"]
            out.append({"ticker": t, "asset": r["asset"], "duration": r["duration"], "strike": r["strike"],
                        "seconds_to_close": r["seconds_to_close"],
                        "yes_bid": _D(q["yes_bid"]) if q["yes_bid"] else None, "yes_ask": _D(q["yes_ask"]) if q["yes_ask"] else None,
                        "quote_age_s": q["age_s"], "quote_source": q["source"]})
        ref = {ASSET_BY_CF_INDEX.get(i, i): v for i, (tw, v, _) in self.ref_last.items() if time.time() - tw < 10}
        return {"markets": out, "reference": ref}

    def _rest(self):
        if self.rest is None:
            if self.rest_factory is not None:
                self.rest = self.rest_factory()
            else:
                from ..kalshi.client import KalshiRestClient
                # UI calls must fail fast: short timeout, one retry
                self.rest = KalshiRestClient(self.env, signer=None, public=True, requests_per_second=5, timeout_s=4.0, max_retries=1)
        return self.rest

    async def cached(self, kind: str, key: str, ttl: float, fn, error_ttl: float = 10.0):
        """Short-lived cache; failures are cached too (error_ttl) so a dead endpoint isn't hammered."""
        hit = self._cache.get((kind, key))
        if hit:
            age = time.monotonic() - hit[0]
            if isinstance(hit[1], Exception):
                if age < error_ttl:
                    raise hit[1]
            elif age < ttl:
                return hit[1]
        try:
            val = await fn()
        except Exception as exc:
            self._cache[(kind, key)] = (time.monotonic(), exc)
            raise
        self._cache[(kind, key)] = (time.monotonic(), val)
        if len(self._cache) > 500:
            for k in sorted(self._cache, key=lambda k: self._cache[k][0])[:250]:
                self._cache.pop(k, None)
        return val

    def _error(self, where: str, exc: Exception) -> None:
        self.errors.append({"t": time.time(), "where": where, "error": f"{type(exc).__name__}: {exc}"})

    # ---------------------------------------------------------------- views
    def quote(self, m: MarketInfo) -> Dict[str, Any]:
        ls = self.reg.liquidity.get(m.ticker) if self.reg else None
        book = self.ws.books.books.get(m.ticker) if self.ws is not None else None
        if book is not None and book.valid:
            yb, ya = book.best_yes_bid, book.best_yes_ask
            src, ydep, ndep = "book", book.depth_c2("yes"), book.depth_c2("no")
            age = (time.monotonic_ns() - book.last_update_ns) / 1e9 if book.last_update_ns else None
        elif ls is not None and ls.last_update_mono:
            yb, ya = ls.yes_bid_p4, ls.yes_ask_p4
            src, ydep, ndep = "live", ls.bid_size_c2, ls.ask_size_c2
            age = time.monotonic() - ls.last_update_mono
        else:
            yb, ya = m.yes_bid_p4, m.yes_ask_p4
            src, ydep, ndep, age = "snapshot", m.yes_bid_size_c2 or 0, m.yes_ask_size_c2 or 0, None
        yb = yb or None
        ya = ya if ya and ya < 10000 else None
        nb = 10000 - ya if ya else None
        na = 10000 - yb if yb else None
        spread = (ya - yb) if (ya and yb) else None
        vol = ls.volume_24h_c2 if (ls and ls.volume_24h_c2) else m.volume_24h_c2
        oi = ls.open_interest_c2 if (ls and ls.open_interest_c2) else m.open_interest_c2
        return {"source": src, "age_s": None if age is None else round(age, 1), "yes_bid": p4_str(yb), "yes_ask": p4_str(ya),
                "no_bid": p4_str(nb), "no_ask": p4_str(na), "spread": p4_str(spread),
                "yes_depth": round(ydep / 100, 2), "no_depth": round(ndep / 100, 2),
                "volume_24h": round((vol or 0) / 100, 2), "open_interest": round((oi or 0) / 100, 2),
                "last": p4_str(m.last_price_p4)}

    @staticmethod
    def strike_text(m: MarketInfo) -> str:
        f = lambda d: f"{d:,.2f}".rstrip("0").rstrip(".") if d is not None else "?"  # noqa: E731
        st = m.strike_type.value if hasattr(m.strike_type, "value") else str(m.strike_type)
        if st in ("greater", "greater_or_equal"):
            return ("≥ " if st == "greater_or_equal" else "> ") + f(m.floor_strike) if m.floor_strike is not None else "target pending"
        if st in ("less", "less_or_equal"):
            return ("≤ " if st == "less_or_equal" else "< ") + f(m.cap_strike) if m.cap_strike is not None else "target pending"
        if st == "between":
            return f"{f(m.floor_strike)} – {f(m.cap_strike)}"
        return st or "—"

    def row(self, t: str, now: Optional[datetime] = None) -> Dict[str, Any]:
        reg = self.reg
        m = reg.markets[t]
        d = reg.decisions[t]
        a = self.access[t]
        now = now or self.now_fn()
        ttc = (m.close_time - now).total_seconds() if m.close_time else None
        return {"ticker": t, "series": m.series_ticker, "event": m.event_ticker, "title": m.title, "subtitle": m.yes_sub_title,
                "asset": d.asset, "asset_class": d.asset_class, "tab": a.tab, "duration": d.duration.bucket.value,
                "strike": self.strike_text(m), "strike_type": m.strike_type.value if hasattr(m.strike_type, "value") else str(m.strike_type),
                "status": m.status.value, "open_time": m.open_time.isoformat() if m.open_time else None,
                "close_time": m.close_time.isoformat() if m.close_time else None,
                "seconds_to_close": None if ttc is None else int(ttc), "tier": d.tier.value,
                "reasons": [r.value for r in d.reasons], "access": a.to_dict(),
                "reference": {"provider": d.reference.provider.value, "instrument": d.reference.instrument,
                              "status": d.reference.status.value},
                "quote": self.quote(m)}

    def query(self, *, tab: Optional[str] = None, q: str = "", duration: str = "", status: str = "open", access: str = "",
              sort: str = "close", limit: int = 200, offset: int = 0) -> Dict[str, Any]:
        reg = self.reg
        if reg is None:
            return {"total": 0, "rows": [], "loading": True}
        now = self.now_fn()
        ql = q.strip().lower()
        sel = []
        for t, a in self.access.items():
            if tab and a.tab != tab:
                continue
            m = reg.markets[t]
            if status == "open" and m.status is not MarketStatus.ACTIVE:
                continue
            if status == "upcoming" and m.status not in (MarketStatus.INITIALIZED, MarketStatus.INACTIVE):
                continue
            if status == "closed" and m.status in (MarketStatus.ACTIVE, MarketStatus.INITIALIZED, MarketStatus.INACTIVE):
                continue
            if duration and reg.decisions[t].duration.bucket.value != duration:
                continue
            if access == "manual" and not a.manual:
                continue
            if access == "auto" and not a.auto:
                continue
            if ql and ql not in t.lower() and ql not in (m.title or "").lower() and ql not in (m.yes_sub_title or "").lower():
                continue
            sel.append(t)
        far = datetime.max.replace(tzinfo=timezone.utc)
        if sort == "volume":
            sel.sort(key=lambda t: -(self.reg.liquidity.get(t).volume_24h_c2 if t in self.reg.liquidity else reg.markets[t].volume_24h_c2))
        elif sort == "ticker":
            sel.sort()
        else:
            sel.sort(key=lambda t: (reg.markets[t].close_time or far, t))
        rows = [self.row(t, now) for t in sel[offset:offset + limit]]
        return {"total": len(sel), "offset": offset, "rows": rows, "loading": False}

    # ---------------------------------------------------------------- status
    @staticmethod
    def _pct(xs, p):
        if not xs:
            return None
        s = sorted(xs)
        return round(s[min(len(s) - 1, int(p * len(s)))], 1)

    def feeds(self) -> List[Dict[str, Any]]:
        stale_after = float(self.ks.reference_feeds.staleness_seconds.get("cfbenchmarks", 3))
        now = time.time()
        out = []
        for idx, (tw, v, src) in sorted(self.ref_last.items()):
            age = now - tw
            fast = idx in ("BRTI", "ETHUSD_RTI", "SOLUSD_RTI", "XRPUSD_RTI", "DOGEUSD_RTI")
            out.append({"index": idx, "asset": ASSET_BY_CF_INDEX.get(idx, idx), "provider": "CF Benchmarks",
                        "value": round(v, 6), "age_s": round(age, 1), "rate": "5 Hz" if fast else "1 Hz",
                        "stale": age > (stale_after if fast else stale_after + 2),
                        "spark": [round(x[1], 6) for x in list(self.ref.get(idx, []))[-120:]]})
        pyth = self.ks.reference_feeds.pyth.enabled
        out.append({"index": "Pyth (metals, energy, indices)", "asset": "—", "provider": "Pyth", "value": None, "age_s": None,
                    "rate": "—", "stale": False, "disabled": not pyth,
                    "note": "Off by decision 2026-11-08 (no paid feeds). Metals/energy/index markets are visible but not auto-eligible."})
        return out

    def status(self) -> Dict[str, Any]:
        reg = self.reg
        now = time.time()
        ws = self.ws
        rate = sum(1 for x in self.frame_times if now - x <= 10) / 10.0
        tiers: Dict[str, int] = {}
        if reg is not None:
            for t in self.access:
                tv = reg.decisions[t].tier.value
                tiers[tv] = tiers.get(tv, 0) + 1
        live_books = []
        if ws is not None:
            for t, b in ws.books.books.items():
                live_books.append({"ticker": t, "valid": b.valid, "levels": len(b.yes_bids) + len(b.no_bids),
                                   "age_s": round((time.monotonic_ns() - b.last_update_ns) / 1e9, 1) if b.last_update_ns else None})
        wstats = ws.stats if ws is not None else None
        last_frame_age = (time.monotonic() - wstats.last_frame_mono) if (wstats and wstats.last_frame_mono) else None
        totals = {k: sum(s[k] for s in self.tab_stats.values()) for k in ("visible", "open", "manual", "auto")}
        return {
            "app": "aicrypto-lab", "time": now, "issues": self.issues(now),
            "load": self.load.__dict__,
            "mode": {"environment": self.env, "market_data": "read-only", "local_paper": "not active",
                     "kalshi_demo_orders": "enabled (demo host only)" if self.demo.state == "connected" else "not connected",
                     "production_orders": ("REAL-MONEY BOT ON" if self.real_bot.on else
                                           ("real account connected, bot off" if self.real.state == "connected" else "not set up")),
                     "automation": "running" if self.lab.bot.on else self.auto.state,
                     "bot": self.lab.bot.on},
            "connection": {"state": self.live.state, "detail": self.live.detail, "last_error": self.live.last_error,
                           "attempts": self.live.attempts, "msgs_per_s": round(rate, 1),
                           "last_frame_age_s": None if last_frame_age is None else round(last_frame_age, 1),
                           "connects": getattr(wstats, "connects", 0), "reconnects": getattr(wstats, "reconnects", 0),
                           "seq_gaps": getattr(wstats, "seq_gaps", 0), "schema_mismatches": getattr(wstats, "schema_mismatches", 0),
                           "uptime_s": round(now - self.live.started_at) if self.live.started_at else None},
            "books": {"live": len(self.sess.book_sub.market_tickers) if (self.sess and self.sess.book_sub) else 0,
                      "budget": self.ks.subscriptions.max_orderbooks, "valid": sum(1 for b in live_books if b["valid"]),
                      "items": sorted(live_books, key=lambda b: b["ticker"])},
            "registry": {"loaded": len(reg.markets) if reg else 0, **totals, "tiers": tiers,
                         "monitored_quotes": len(self.ticks)},
            "latency": {"dispatch_p50_us": self._pct(self.dispatch_us, 0.5), "dispatch_p99_us": self._pct(self.dispatch_us, 0.99),
                        "cf_lag_p50_ms": self._pct(self.cf_lag_ms, 0.5), "cf_lag_p99_ms": self._pct(self.cf_lag_ms, 0.99)},
            "accounts": {
                "local_paper": {"label": "Local paper simulation", "balance": f"{self.ks.capital.starting_balance:.2f}",
                                "active": False, "pnl_today": None, "open_positions": 0,
                                "note": "Engine arrives in Milestone C; nothing is simulated yet."},
                "kalshi_demo": {"label": "Kalshi demo account", "connected": self.demo.state == "connected",
                                "balance": self.demo.account.get("balance"), "portfolio_value": self.demo.account.get("portfolio_value"), "pnl_today": self.demo.account.get("realized_today"),
                                "open_positions": len(self.demo.account.get("positions", [])) if self.demo.account else None,
                                "budget": str(self.demo.budget()) if self.demo.budget() else None, "kill": self.demo.kill_on()},
                "kalshi_real": {"label": "Kalshi REAL account", "connected": self.real.state == "connected", "state": self.real.state,
                                "balance": self.real.account.get("balance"), "portfolio_value": self.real.account.get("portfolio_value"),
                                "pnl_today": self.real.account.get("realized_today"),
                                "open_positions": len(self.real.account.get("positions", [])) if self.real.account else None,
                                "kill": self.real.kill_on(), "bot_on": self.real_bot.on, "stake_pct": self.real_bot.settings.stake_pct},
            },
            "risk": {"per_position": self.ks.risk.max_loss_per_position, "aggregate": self.ks.risk.max_aggregate_planned_loss,
                     "daily_stop": self.ks.risk.daily_realized_loss_stop, "leverage": self.ks.risk.leverage},
            "errors": list(self.errors)[-20:] + ([{"t": now, "where": "live data", "error": e["msg"] if isinstance(e, dict) and "msg" in e else str(e)}
                                                   for e in (wstats.errors[-5:] if wstats else [])]),
        }

    # ---------------------------------------------------------------- plain-language problems for the UI
    def issues(self, now: Optional[float] = None) -> List[Dict[str, Any]]:
        """Problems the user should see (and can copy to report). Technical detail goes in
        `report` only. Ordered most serious first."""
        now = now or time.time()
        out: List[Dict[str, Any]] = []

        def add(code, level, title, message, detail=""):
            out.append({"id": code, "level": level, "title": title, "message": message,
                        "report": f"[{code}] {title} | {detail or message} | env={self.env} | "
                                  f"{datetime.fromtimestamp(now, timezone.utc).strftime('%Y-%m-%d %H:%M:%SZ')}"})

        L = self.load
        if L.phase == "error":
            if "discover" in L.error:
                add("NO-MARKETS", "error", "Market list is missing",
                    "No downloaded market list was found. Markets can't be shown until it exists.", L.error)
            else:
                add("MARKETS-LOAD", "error", "Market list couldn't load", "The saved market list could not be read.", L.error)
        lv = self.live
        if self.live_enabled and L.phase == "ready":
            if lv.state == "no_credentials":
                add("NO-KEY", "warning", "Live prices are off",
                    "The Kalshi demo API key wasn't found, so prices won't update.", lv.detail)
            elif lv.state in ("connecting", "error") and lv.not_live_since and now - lv.not_live_since > 30:
                add("KALSHI-OFFLINE", "error", "Not connected to Kalshi",
                    f"Live prices have been unavailable for {int((now - lv.not_live_since) // 60)} min "
                    f"{int((now - lv.not_live_since) % 60)} s. The app keeps retrying.", lv.last_error or "no connection")
            if lv.state == "live":
                stale = [ASSET_BY_CF_INDEX.get(i, i) for i, (tw, _, _) in self.ref_last.items() if now - tw > 30]
                if stale:
                    add("PRICES-STALE", "warning", "Some prices stopped updating",
                        f"No new prices for {', '.join(sorted(stale))} in the last 30 seconds.", f"stale={sorted(stale)}")
                ws = self.ws.stats if self.ws is not None else None
                if ws is not None and ws.schema_mismatches:
                    add("DATA-FORMAT", "warning", "Kalshi sent unexpected data",
                        "Some messages were ignored because their format changed.", f"schema_mismatches={ws.schema_mismatches}")
        for i in self.demo.issues():
            add(i["id"], i["level"], i["title"], i["message"], i.get("detail", ""))
        lr = getattr(self, "last_refresh", None)
        if lr and lr.get("series") and (lr.get("failed") or lr.get("rejected_format")) and not lr.get("markets"):
            add("MARKETS-REFRESH", "error", "Can't load the current 15-minute markets",
                "The app couldn't get the open windows from Kalshi, so market cards may be out of date.",
                f"series={lr['series']} failed={lr['failed']} format_rejected={lr.get('rejected_format')} first={lr['error']}")
        elif lr is not None and not lr.get("series"):
            add("NO-15M-SERIES", "error", "No 15-minute markets in the market list",
                "The downloaded market list has no 15-minute series. It needs to be downloaded again.", "run: aicrypto kalshi discover")
        recent = [e for e in self.errors if now - e["t"] < 300]
        if recent:
            e = recent[-1]
            add("BACKGROUND", "warning", "Something went wrong in the background",
                "The app recovered, but please report this.", f"{e['where']}: {e['error']}")
        return out

    def tabs(self) -> Dict[str, Any]:
        return {"tabs": [{"name": t, **self.tab_stats.get(t, {"visible": 0, "open": 0, "manual": 0, "auto": 0, "durations": {}})} for t in TABS]}
