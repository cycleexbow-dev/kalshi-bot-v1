"""Event-loop stall detector.

Everything in the backend (live WebSocket, labs, bot, web server) shares one asyncio loop. If any
piece of code runs for a long time without yielding, the WebSocket cannot answer Kalshi's pings and
the connection drops ("keepalive ping timeout"). This watchdog notices stalls from a helper thread
and logs where the loop was stuck, so the slow code can be found and fixed.
"""
from __future__ import annotations

import asyncio
import logging
import sys
import threading
import time
import traceback
from typing import Any, Dict, List, Optional

log = logging.getLogger("aicrypto.loopwatch")


class LoopWatch:
    def __init__(self, threshold_s: float = 1.5, beat_s: float = 0.25):
        self.threshold_s, self.beat_s = threshold_s, beat_s
        self.last_beat = time.monotonic()
        self.max_lag_s = 0.0
        self.stalls = 0
        self.recent: List[Dict[str, Any]] = []
        self._loop_thread: Optional[int] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    async def heartbeat(self) -> None:
        self._loop_thread = threading.get_ident()
        if self._thread is None:
            self._thread = threading.Thread(target=self._watch, name="loopwatch", daemon=True)
            self._thread.start()
        try:
            while True:
                self.last_beat = time.monotonic()
                await asyncio.sleep(self.beat_s)
        finally:
            self._stop.set()

    def _watch(self) -> None:
        reported = False
        while not self._stop.wait(0.2):
            lag = time.monotonic() - self.last_beat
            if lag > self.threshold_s and not reported:
                reported = True
                frame = sys._current_frames().get(self._loop_thread)
                where = "".join(traceback.format_stack(frame, limit=12)) if frame else "(no frame)"
                self.stalls += 1
                self.recent.append({"t": time.time(), "where": where})
                self.recent = self.recent[-20:]
                log.warning("event loop stalled > %.1fs; stuck in:\n%s", self.threshold_s, where)
            elif lag <= self.threshold_s and reported:
                reported = False
                self.max_lag_s = max(self.max_lag_s, lag)
            if lag > self.max_lag_s:
                self.max_lag_s = lag

    def status(self) -> Dict[str, Any]:
        return {"stalls": self.stalls, "max_lag_s": round(self.max_lag_s, 2),
                "last_stall": self.recent[-1] if self.recent else None}
