/* Minimal canvas charts (no external libraries; works offline inside the desktop window). */
(function () {
  const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  let tip;
  function tooltip(x, y, html) {
    if (!tip) { tip = document.createElement("div"); tip.className = "tooltip"; document.body.appendChild(tip); }
    if (html == null) { tip.style.display = "none"; return; }
    tip.innerHTML = html; tip.style.display = "block";
    tip.style.left = (x + 14) + "px"; tip.style.top = (y + 12) + "px";
  }
  function setup(canvas) {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h };
  }
  function niceTicks(lo, hi, n) {
    if (!(hi > lo)) { hi = lo + 1; }
    const span = hi - lo, step0 = span / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
    const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => span / s <= n) || 10 * mag;
    const out = []; for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  }
  const fmtTime = (t, long) => {
    const d = new Date(t * 1000);
    return long ? d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
                : d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  /* series: [{name, color, points:[[t, v]], step?:bool, dash?:[]}]  opts: {yFmt, yMin, yMax, empty} */
  function line(canvas, series, opts = {}) {
    const { ctx, w, h } = setup(canvas);
    const pad = { l: 10, r: 62, t: 12, b: 22 };
    const pts = series.flatMap((s) => s.points.filter((p) => p[1] != null && isFinite(p[1])));
    if (pts.length < 2) {
      ctx.fillStyle = css("--dim"); ctx.font = "12px " + css("--sans"); ctx.textAlign = "center";
      ctx.fillText(opts.empty || "No data yet", w / 2, h / 2); canvas.onmousemove = null; return;
    }
    let t0 = Math.min(...pts.map((p) => p[0])), t1 = Math.max(...pts.map((p) => p[0]));
    if (t1 === t0) t1 = t0 + 60;
    let lo = opts.yMin != null ? opts.yMin : Math.min(...pts.map((p) => p[1]));
    let hi = opts.yMax != null ? opts.yMax : Math.max(...pts.map((p) => p[1]));
    if (hi === lo) { hi += Math.abs(hi) * 0.001 || 1; lo -= Math.abs(lo) * 0.001 || 1; }
    const padY = (hi - lo) * 0.08; if (opts.yMin == null) lo -= padY; if (opts.yMax == null) hi += padY;
    const X = (t) => pad.l + (t - t0) / (t1 - t0) * (w - pad.l - pad.r);
    const Y = (v) => pad.t + (1 - (v - lo) / (hi - lo)) * (h - pad.t - pad.b);
    const yf = opts.yFmt || ((v) => v.toFixed(2));
    ctx.font = "10.5px " + css("--mono"); ctx.lineWidth = 1;
    niceTicks(lo, hi, 4).forEach((v) => {
      ctx.strokeStyle = "#1a2230"; ctx.beginPath(); ctx.moveTo(pad.l, Y(v)); ctx.lineTo(w - pad.r, Y(v)); ctx.stroke();
      ctx.fillStyle = css("--dim"); ctx.textAlign = "left"; ctx.fillText(yf(v), w - pad.r + 6, Y(v) + 3);
    });
    const long = (t1 - t0) > 86400;
    for (let i = 0; i <= 4; i++) {
      const t = t0 + (t1 - t0) * i / 4; ctx.fillStyle = css("--dim");
      ctx.textAlign = i === 0 ? "left" : i === 4 ? "right" : "center"; ctx.fillText(fmtTime(t, long), X(t), h - 6);
    }
    series.forEach((s) => {
      const p = s.points.filter((q) => q[1] != null && isFinite(q[1]));
      if (p.length < 1) return;
      ctx.strokeStyle = s.color; ctx.lineWidth = s.width || 1.6; ctx.setLineDash(s.dash || []);
      ctx.beginPath();
      p.forEach((q, i) => {
        const x = X(q[0]), y = Y(q[1]);
        if (i === 0) ctx.moveTo(x, y);
        else if (s.step) { ctx.lineTo(x, Y(p[i - 1][1])); ctx.lineTo(x, y); } else ctx.lineTo(x, y);
      });
      ctx.stroke(); ctx.setLineDash([]);
      if (s.fill) {
        ctx.lineTo(X(p[p.length - 1][0]), h - pad.b); ctx.lineTo(X(p[0][0]), h - pad.b); ctx.closePath();
        const g = ctx.createLinearGradient(0, pad.t, 0, h - pad.b); g.addColorStop(0, s.fill); g.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = g; ctx.fill();
      }
      const last = p[p.length - 1];
      ctx.fillStyle = s.color; ctx.beginPath(); ctx.arc(X(last[0]), Y(last[1]), 2.8, 0, 7); ctx.fill();
    });
    canvas.onmousemove = (ev) => {
      const r = canvas.getBoundingClientRect(); const mx = ev.clientX - r.left;
      const t = t0 + (mx - pad.l) / (w - pad.l - pad.r) * (t1 - t0);
      const rows = series.map((s) => {
        let best = null; s.points.forEach((q) => { if (q[1] != null && (!best || Math.abs(q[0] - t) < Math.abs(best[0] - t))) best = q; });
        return best ? `<span style="color:${s.color}">${s.name}</span> ${yf(best[1])}` : "";
      }).filter(Boolean);
      tooltip(ev.clientX, ev.clientY, `<div style="color:#7f8a9c">${fmtTime(t, true)}</div>` + rows.join("<br>"));
    };
    canvas.onmouseleave = () => tooltip(0, 0, null);
  }

  function spark(canvas, values, color) {
    const { ctx, w, h } = setup(canvas);
    const v = values.filter((x) => x != null);
    if (v.length < 2) return;
    const lo = Math.min(...v), hi = Math.max(...v), span = hi - lo || 1;
    ctx.strokeStyle = color; ctx.lineWidth = 1.3; ctx.beginPath();
    v.forEach((x, i) => { const X = i / (v.length - 1) * (w - 2) + 1, Y = h - 2 - (x - lo) / span * (h - 4); i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); });
    ctx.stroke();
  }
  window.Charts = { line, spark, css };
})();
