/* AI Crypto Lab terminal — single-page UI. Talks only to the local backend (127.0.0.1).
   Milestone A: read-only. The order ticket computes estimates; submission is disabled. */
(function () {
  "use strict";
  const $ = (s, el = document) => el.querySelector(s);
  const view = $("#view");
  const C = () => ({ yes: Charts.css("--yes"), no: Charts.css("--no"), accent: Charts.css("--accent"), blue: Charts.css("--blue"), warn: Charts.css("--warn"), muted: Charts.css("--muted") });
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const api = async (path) => {
    const r = await fetch(path, { cache: "no-store" });
    if (!r.ok) { const e = new Error("HTTP " + r.status); e.status = r.status; try { e.body = await r.json(); } catch (_) {} throw e; }
    return r.json();
  };
  const post = async (path, body) => {
    const r = await fetch(path, { method: "POST", cache: "no-store", headers: { "Content-Type": "application/json", "X-AICL-Client": "terminal" }, body: JSON.stringify(body || {}) });
    let j = {}; try { j = await r.json(); } catch (_) {}
    if (!r.ok || j.ok === false) { const e = new Error((j.errors || [j.detail || ("HTTP " + r.status)]).join(" ")); e.errors = j.errors || [String(j.detail || r.status)]; throw e; }
    return j;
  };
  /* ------------------------------------------------------------ account: Demo or Real (owner choice, remembered) */
  let ACCT = (() => { try { return localStorage.getItem("aicl.account") === "real" ? "real" : "demo"; } catch (_) { return "demo"; } })();
  const AQ = () => "account=" + ACCT;
  const ACC = (s) => s.accounts[ACCT === "real" ? "kalshi_real" : "kalshi_demo"];
  function drawSwitch() { document.querySelectorAll("#acct-sw button").forEach((b) => b.classList.toggle("on", b.dataset.a === ACCT)); }
  document.querySelectorAll("#acct-sw button").forEach((b) => b.onclick = () => {
    if (b.dataset.a === ACCT) return;
    ACCT = b.dataset.a; try { localStorage.setItem("aicl.account", ACCT); } catch (_) {}
    drawSwitch(); route();
  });
  drawSwitch();
  async function realToggle() {
    const st = await api("/api/real/status").catch(() => null); if (!st) return;
    if (st.bot_on) { try { await post("/api/real/bot/off"); toast("Real bot is OFF."); } catch (e) { toast(e.message, 6000); } return; }
    if (st.state !== "connected") { toast("The real account is not connected" + (st.error ? ": " + st.error : "."), 6000); return; }
    if (st.kill) {
      if (!confirm("The real emergency stop is on. Reset it?")) return;
      try { await post("/api/real/kill/reset"); } catch (e) { toast(e.message, 6000); return; }
    }
    const m = modal(`<h3 style="color:var(--no)">Turn on REAL-MONEY trading</h3>
      <p>The bot will place real orders with your real Kalshi money, on the same rules as demo practice mode. None of them is proven yet, and losses are possible.</p>
      <p>Limits: at least $1 per trade, at most ${st.limits.per_trade_pct}% of the account per trade, ${st.limits.per_day_pct == null ? "no daily spending limit" : st.limits.per_day_pct + "% of the account per day"}. No daily loss stop.
        Bet size now: ${st.stake_pct}% per trade.</p>
      <p>Type <b>REAL MONEY</b> to confirm:</p><input id="r-phrase" style="width:100%" autocomplete="off">
      <div style="display:flex;gap:10px;margin-top:12px;justify-content:flex-end"><button class="btn" id="r-cancel">Cancel</button><button class="btn" id="r-go" style="background:var(--no);color:#fff">Turn on real trading</button></div>`);
    $("#r-cancel", m.el).onclick = m.close;
    await new Promise((done) => {
      $("#r-cancel", m.el).onclick = () => { m.close(); done(); };
      $("#r-go", m.el).onclick = async () => {
        try { await post("/api/real/bot/on", { phrase: $("#r-phrase", m.el).value }); m.close(); toast("REAL-MONEY bot is ON.", 6000); done(); }
        catch (e) { toast(e.message, 8000); }
      };
    });
  }
  function modal(html) {
    const m = document.createElement("div"); m.className = "modal-bg";
    m.innerHTML = `<div class="modal">${html}</div>`; document.body.appendChild(m);
    const close = () => m.remove(); m.addEventListener("click", (e) => { if (e.target === m) close(); });
    return { el: m, close };
  }
  const centsNum = (s) => { const v = Number(s) * 100; return Math.abs(v - Math.round(v)) < 1e-6 ? String(Math.round(v)) : v.toFixed(1); };
  const pxt = (s) => (s == null || s === "") ? "—" : centsNum(s) + "%";
  const px = (s) => (s == null || s === "") ? '<span class="px na">—</span>' : `<span class="px">${centsNum(s)}%</span>`;
  const chance = (q) => { const b = q.yes_bid, a = q.yes_ask; if (b != null && a != null) return (Number(b) + Number(a)) / 2; return (q.last != null && Number(q.last) > 0) ? Number(q.last) : (b != null ? Number(b) : a != null ? Number(a) : null); };
  const pctP = (s) => (s == null || s === "") ? "—" : centsNum(s) + "%";
  const pctOf = (v) => v == null ? "—" : Math.round(v * 100) + "%";
  const signed = (v) => v == null ? "—" : (Number(v) >= 0 ? "+" : "−") + "$" + Math.abs(Number(v)).toFixed(2);
  const pnlCls = (v) => v == null ? "" : Number(v) > 0 ? "yes" : Number(v) < 0 ? "no" : "";
  const pnlCell = (v, p) => v == null ? '<span class="dim">—</span>' : `<span class="${pnlCls(v)}">${signed(v)}${p != null ? ` <span style="opacity:.8">(${p > 0 ? "+" : ""}${p}%)</span>` : ""}</span>`;
  const num = (v, d = 0) => v == null ? "—" : Number(v).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d });
  const usd = (v) => v == null ? "—" : "$" + Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const refFmt = (v) => v == null ? "—" : (v >= 1000 ? num(v, 2) : v >= 1 ? num(v, 4) : num(v, 6));
  function ttc(sec) {
    if (sec == null) return "—"; if (sec <= 0) return "closed";
    const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = Math.floor(sec % 60);
    if (d > 0) return `${d}d ${h}h`; if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`; return `${m}m ${String(s).padStart(2, "0")}s`;
  }
  const accessBadge = (a) => {
    const map = { auto: ["auto", "AUTO-ELIGIBLE"], manual: ["manual", "MANUAL DEMO"], view: ["view", "VIEW ONLY"] };
    const [cls, txt] = map[a.level] || ["view", a.level];
    const why = (a.level === "auto" ? [] : (a.level === "manual" ? a.auto_blockers : a.manual_blockers)).map((b) => b.text).join("; ");
    return `<span class="badge ${cls}" title="${esc(why)}">${txt}</span>`;
  };
  const refBadge = (r, short) => { const n = short ? ({ cf_benchmarks: "CF" }[r.provider] || provName(r.provider)) : provName(r.provider);
    return r.status === "validated" ? `<span class="badge ok" title="${esc(provName(r.provider))} ${esc(r.instrument)} — live feed">${esc(n)} ✓</span>`
      : `<span class="badge warn" title="${esc(provName(r.provider))} ${esc(r.instrument || "")} — no licensed feed">${esc(n)} · no feed</span>`; };
  const provName = (p) => ({ cf_benchmarks: "CF Benchmarks", pyth: "Pyth", ice: "ICE", us_treasury: "US Treasury", unspecified: "Unspecified" }[p] || p);
  function toast(msg, ms = 3500) { const t = $("#toast"); t.textContent = msg; t.classList.remove("hidden"); clearTimeout(t._h); t._h = setTimeout(() => t.classList.add("hidden"), ms); }
  const emptyState = (title, body) => `<div class="empty"><b>${esc(title)}</b>${esc(body || "")}</div>`;

  /* ------------------------------------------------------------ global status */
  let STATUS = null; const timers = []; let cleanupView = null;
  /* periodic task; an async task never overlaps itself (slow network calls don't pile up) */
  const every = (ms, fn) => {
    let busy = false;
    const run = async () => { if (busy) return; busy = true; try { await fn(); } catch (_) {} finally { busy = false; } };
    run(); const h = setInterval(run, ms); timers.push(h); return h;
  };
  function clearTimers() { while (timers.length) clearInterval(timers.pop()); }

  let FAILS = 0; const DISMISSED = {};
  async function pollStatus() {
    try { STATUS = await api("/api/terminal/status"); FAILS = 0; } catch (e) { STATUS = null; FAILS++; }
    const s = STATUS;
    const strip = $("#demo-strip");
    if (strip && s) {
      const R = s.accounts.kalshi_real || {};
      if (ACCT === "real") {
        strip.textContent = "REAL ACCOUNT — REAL MONEY" + (R.bot_on ? " · REAL BOT ON" : " · real bot off") + (R.connected ? "" : " · not connected");
        strip.style.background = "var(--no)"; strip.style.color = "#fff";
      } else {
        strip.textContent = "DEMO — SIMULATED FUNDS" + (R.bot_on ? " · note: the REAL-money bot is ON (switch to Real to see it)" : "");
        strip.style.background = R.bot_on ? "var(--no)" : ""; strip.style.color = R.bot_on ? "#fff" : "";
      }
    }
    const pill = $("#pill-conn"), dot = pill.querySelector(".dot"), lbl = pill.querySelector("span:last-child");
    const set = (cls, text) => { pill.className = "pill " + cls; dot.className = "dot " + cls; lbl.textContent = text; };
    let issues = s ? s.issues.slice() : [];
    if (!s) {
      set("bad", "Disconnected");
      if (FAILS >= 3) issues = [{ id: "BACKEND-DOWN", level: "error", title: "Can't reach the app's backend",
        message: "The background service stopped responding. Close and reopen AI Crypto Lab.",
        report: `[BACKEND-DOWN] backend not responding | ${new Date().toISOString()}` }];
    } else if (s.load.phase !== "ready" && s.load.phase !== "error") set("warn", "Loading…");
    else if (s.connection.state === "live") set("ok", "Connected");
    else if (s.connection.state === "connecting") set("warn", "Connecting…");
    else set("bad", "Not connected");
    renderNotes(issues);
    if (s) { const on = ACCT === "real" ? !!(s.accounts.kalshi_real || {}).bot_on : !!s.mode.bot; const b = $("#bot-toggle"); b.classList.toggle("on", on);
      $("#bot-lbl").textContent = (ACCT === "real" ? "Real bot " : "Bot ") + (on ? "ON" : "OFF"); b.title = ACCT === "real" ? "Real-money bot" : "Demo bot"; }
    const L = s && s.load, loading = $("#loading");
    if (L && L.phase !== "ready" && L.phase !== "error") {
      loading.classList.remove("hidden");
      $("#load-bar").style.width = Math.round((L.progress || 0) * 100) + "%";
      $("#load-msg").textContent = Math.round((L.progress || 0) * 100) + "%";
    } else loading.classList.add("hidden");
  }
  $("#bot-toggle").onclick = async () => {
    if (ACCT === "real") { await realToggle(); pollStatus(); return; }
    const on = STATUS && STATUS.mode.bot;
    if (!on && !confirm("Turn the bot ON?\n\nIt will place DEMO orders automatically with demo money. In practice mode it also trades rules it is still testing, so expect losing trades while it learns. It turns off when the app restarts or on emergency stop.")) return;
    try { const r = await post("/api/bot/toggle"); toast(r.on ? "Bot is ON (demo)." : "Bot is OFF."); pollStatus(); } catch (e) { toast(e.message, 6000); }
  };
  function renderNotes(issues) {
    const box = $("#notes");
    const show = issues.filter((i) => DISMISSED[i.id] !== i.title + i.message);
    box.innerHTML = show.map((i) => `<div class="note ${i.level === "error" ? "error" : ""}" data-id="${esc(i.id)}">
      <div class="t"><span>${i.level === "error" ? "⛔" : "⚠"} ${esc(i.title)}</span><button title="Dismiss">×</button></div>
      <div class="m">${esc(i.message)}</div>
      <button class="btn copy">Copy details for Claude</button></div>`).join("");
    box.querySelectorAll(".note").forEach((el) => {
      const i = show.find((x) => x.id === el.dataset.id);
      el.querySelector(".t button").onclick = () => { DISMISSED[i.id] = i.title + i.message; renderNotes(issues); };
      el.querySelector(".copy").onclick = async () => {
        try { await navigator.clipboard.writeText(i.report); toast("Copied — paste it to Claude."); }
        catch (_) { prompt("Copy this and send it to Claude:", i.report); }
      };
    });
  }
  function clock() {
    const d = new Date();
    $("#clock").textContent = d.toLocaleTimeString([], { hour12: false }) + "  ·  " + d.toISOString().slice(11, 19) + " UTC";
  }

  /* ------------------------------------------------------------ router */
  const routes = {};
  function route() {
    const h = location.hash.replace(/^#\/?/, "") || "dashboard";
    const [name, ...rest] = h.split("/");
    clearTimers(); if (cleanupView) { try { cleanupView(); } catch (_) {} cleanupView = null; }
    every(2000, pollStatus);
    document.querySelectorAll(".side a").forEach((a) => a.classList.toggle("on", a.dataset.nav === (name === "market" || name === "allmarkets" ? "markets" : name)));
    view.scrollTop = 0;
    (routes[name] || routes.dashboard)(rest.map(decodeURIComponent));
  }
  window.addEventListener("hashchange", route);
  const crumbs = (...parts) => { $("#crumbs").innerHTML = parts.map(esc).join('<span class="sep">/</span>'); };

  /* ------------------------------------------------------------ positions (shared) */
  async function cashOut(ticker) {
    let q; try { q = await post(`/api/demo/positions/${encodeURIComponent(ticker)}/cashout/quote`); } catch (e) { toast(e.message, 6000); return; }
    const est = Number(q.est_proceeds), cost = Number(q.cost), pl = est - cost;
    const m = modal(`<div class="demo-head">DEMO — SIMULATED FUNDS</div><div class="bd">
      <h3 style="margin:0 0 4px">Cash out position</h3><div class="muted mono" style="margin-bottom:12px">${esc(ticker)}</div>
      <div class="est" style="border:0;padding:0">
        <div><span class="muted">Selling</span><span class="${esc(q.side)}">${esc(q.count)} ${esc(q.side.toUpperCase())}</span></div>
        <div><span class="muted">Best price now</span><span>${pxt(q.bid)}</span></div>
        <div><span class="muted">You paid</span><span>$${cost.toFixed(2)}</span></div>
        <div><span class="muted">Estimated proceeds</span><span>$${est.toFixed(2)}</span></div>
        <div><span class="muted">Estimated profit / loss</span><span class="${pnlCls(pl)}">${signed(pl)}${cost ? ` (${(pl / cost * 100).toFixed(0)}%)` : ""}</span></div></div>
      <p class="dim" style="font-size:11.5px">Sells right away at the best available prices, never below ${pxt(q.floor)}. Fees apply. Anything that can't be sold stays in your position.</p>
      <div style="display:flex;gap:8px;margin-top:10px"><button class="btn big" id="c-no">Keep position</button><button class="btn big danger" id="c-yes">Cash out now</button></div>
      <div class="errs" id="c-err"></div></div>`);
    m.el.querySelector("#c-no").onclick = m.close;
    m.el.querySelector("#c-yes").onclick = async (ev) => {
      ev.target.disabled = true;
      try { const r = await post(`/api/demo/positions/${encodeURIComponent(ticker)}/cashout`); m.close();
        toast(r.state === "UNKNOWN" ? "Sent — checking with Kalshi whether it went through…" : r.sold >= r.count ? `Cashed out ${r.sold} contract(s).` : r.sold > 0 ? `Sold ${r.sold} of ${r.count}. The rest is still open.` : "Nothing could be sold at these prices. Position is still open.", 6000); }
      catch (e) { m.el.querySelector("#c-err").textContent = e.message; ev.target.disabled = false; }
    };
  }
  function renderPositions(el, rows) {
    if (!el) return;
    el.innerHTML = rows.length ? `<table><thead><tr><th>Market</th><th>Side</th><th class="r">Contracts</th><th class="r">Avg price</th><th class="r">Now</th><th class="r">Cost</th><th class="r">Value</th><th class="r">Profit / loss</th><th class="r">Closes in</th><th></th></tr></thead><tbody>${
      rows.map((p) => `<tr class="click" data-t="${esc(p.ticker)}" data-v="${p.visible ? 1 : 0}"><td><div style="max-width:340px;overflow:hidden;text-overflow:ellipsis">${esc(p.title)}</div><div class="dim mono" style="font-size:10.5px">${esc(p.ticker)}</div></td>
        <td class="${esc(p.side)}"><b>${esc(p.side.toUpperCase())}</b></td><td class="r num">${num(p.contracts)}</td><td class="r">${px(p.avg_price)}</td><td class="r">${px(p.price)}</td>
        <td class="r num">${usd(p.cost)}</td><td class="r num">${p.value != null ? usd(p.value) : "—"}</td><td class="r num">${pnlCell(p.pnl, p.pnl_pct)}</td>
        <td class="r ttc">${ttc(p.seconds_to_close)}</td><td>${ACCT === "real" ? "" : `<button class="btn danger" data-co="${esc(p.ticker)}">Cash out</button>`}</td></tr>`).join("")}</tbody></table>`
      : emptyState("No active positions", "Positions opened by you or the bot appear here.");
    el.querySelectorAll("button[data-co]").forEach((b) => b.onclick = (ev) => { ev.stopPropagation(); cashOut(b.dataset.co); });
    el.querySelectorAll("tr[data-t]").forEach((tr) => tr.onclick = () => { if (tr.dataset.v === "1") location.hash = "#/market/" + encodeURIComponent(tr.dataset.t); });
  }

  /* ------------------------------------------------------------ dashboard */
  routes.dashboard = function () {
    crumbs("Dashboard");
    view.innerHTML = `
      <div class="grid g-kpi" id="kpis"></div>
      <div class="card flush" style="margin-top:14px"><div class="hd"><h3>Active positions</h3><a href="#/trade">Portfolio →</a></div><div class="bd tbl-wrap" style="max-height:330px" id="d-pos">${emptyState("No active positions", "")}</div></div>
      <div class="grid g-2" style="margin-top:14px">
        <div class="card flush"><div class="hd"><h3>Prices</h3></div><div class="bd" id="feeds"></div></div>
        <div class="grid" style="align-content:start">
          <div class="card"><div class="hd"><h3>Bot &amp; strategies</h3><a href="#/strategy">Lab →</a></div><div class="bd">
            <div id="d-auto"></div>
            <p class="muted" style="margin:10px 0 0">${ACCT === "real" ? "The real-money bot trades the same rules as demo practice mode, at real prices, inside your limits. Switch it with <b>Real bot</b> at the top." : "In practice mode the bot trades rules it is still testing with demo money, and drops the ones that lose. Switch it with <b>Bot</b> at the top."}</p></div></div>
          <div class="card flush"><div class="hd"><h3>Recent trades</h3><a href="#/trade">All →</a></div><div class="bd tbl-wrap" style="max-height:300px" id="d-fills">${emptyState("No trades yet", "")}</div></div>
        </div>
      </div>`;
    every(3000, async () => {
      const s = STATUS; if (!s) return;
      const A = ACC(s), real = ACCT === "real";
      const auto = real ? (A.bot_on ? "Running" : "Off") : (s.mode.automation === "running" ? "Running" : s.mode.automation === "disarmed" ? "Off" : s.mode.automation[0].toUpperCase() + s.mode.automation.slice(1));
      $("#kpis").innerHTML = [
        kpi("Cash", A.connected ? usd(A.balance) : "Not linked", A.connected ? (real ? "Kalshi REAL money" : "Kalshi demo funds") : (real ? "Needs the real API key (docs/REAL_MONEY.md)" : "Needs the demo API key"), real ? "" : "demo"),
        kpi("Positions value", A.connected ? usd(A.portfolio_value) : "—", real ? "Real account" : "Demo account"),
        kpi("Today's profit / loss", A.connected && A.pnl_today != null ? signed(A.pnl_today) : "—", "Closed since midnight, after fees"),
        kpi("Open positions", A.open_positions != null ? String(A.open_positions) : "0", ""),
        kpi("Open markets", num(s.registry.open), "Crypto, metals, energy, indices"),
        kpi(real ? "Real-money bot" : "Automatic trading", auto, real ? `${A.stake_pct}% per trade` : ""),
      ].join("");
    });
    every(3000, async () => { const ps = await api("/api/demo/positions?" + AQ()).catch(() => null); if (ps) renderPositions($("#d-pos"), ps.positions); });
    every(4000, async () => {
      const sm = await api("/api/lab/summary").catch(() => null);
      const botOn = ACCT === "real" ? !!(STATUS && (STATUS.accounts.kalshi_real || {}).bot_on) : sm && sm.bot.on;
      if (sm) { const st = sm.stages || {}; $("#d-auto").innerHTML = `<div class="statline"><span class="muted">${ACCT === "real" ? "Real-money bot" : "Bot"}</span><span class="${botOn ? "ok" : "warn"}">${botOn ? "ON" : "OFF"}</span></div>
        <div class="statline"><span class="muted">Proven rules</span><span>${st.proven || 0}</span></div><div class="statline"><span class="muted">Shortlisted / exploring</span><span>${st.shortlisted || 0} / ${st.exploring || 0}</span></div>
        <div class="statline"><span class="muted">Paper trades settled</span><span>${num(sm.settled_trades)}</span></div>`; }
      const r = await api("/api/demo/orders?" + AQ()).catch(() => null);
      if (r && !r.fills.length) $("#d-fills").innerHTML = emptyState("No trades yet", "");
      if (r && r.fills.length) $("#d-fills").innerHTML = `<table><tbody>${r.fills.slice(0, 12).map((f) => `<tr><td class="mono">${f.created_time ? new Date(f.created_time).toLocaleTimeString() : ""}</td><td class="mono">${esc(f.ticker)}</td><td class="${f.side}">${esc((f.side || "").toUpperCase())}</td><td class="r">${px(f.price)}</td><td class="r num">${num(f.count, 0)}</td></tr>`).join("")}</tbody></table>`;
    });
    every(2000, async () => {
      const f = await api("/api/terminal/feeds").catch(() => null); if (!f) return;
      const live = f.feeds.filter((x) => !x.disabled);
      $("#feeds").innerHTML = live.length ? live.map((x, i) => `<div class="feed-row" style="grid-template-columns:90px 1fr 130px"><div><b>${esc(x.asset)}</b></div>
          <canvas id="sp${i}"></canvas><div class="num" style="text-align:right">${x.stale ? '<span class="dim">—</span>' : "$" + refFmt(x.value)}</div></div>`).join("")
        : emptyState("Prices will appear once connected", "");
      live.forEach((x, i) => { const c = document.getElementById("sp" + i); if (c) Charts.spark(c, x.spark, C().accent); });
    });
  };
  const kpi = (l, v, sub, cls = "") => `<div class="card kpi ${cls}"><div class="lbl">${esc(l)}</div><div class="val">${esc(v)}</div><div class="sub" title="${esc(sub)}">${esc(sub)}</div></div>`;

  /* ------------------------------------------------------------ market explorer */
  const MX = { tab: "BTC", q: "", duration: "", status: "open", access: "", sort: "close", offset: 0 };
  const ASSET_NAMES = { BTC: "Bitcoin", ETH: "Ethereum", SOL: "Solana", XRP: "XRP", DOGE: "Dogecoin", HYPE: "Hyperliquid", BNB: "BNB", NEAR: "NEAR", ZEC: "Zcash", ADA: "Cardano", DOT: "Polkadot", LTC: "Litecoin", SHIB: "Shiba Inu",
    GOLD: "Gold", SILVER: "Silver", COPPER: "Copper", WTI: "Oil (WTI)", BRENT: "Oil (Brent)", NATGAS: "Natural gas", PLATINUM: "Platinum", PALLADIUM: "Palladium" };
  const hiddenStore = { get() { try { return JSON.parse(localStorage.getItem("aicl.hiddenAssets") || "[]"); } catch (_) { return hiddenStore._m || []; } },
    set(v) { hiddenStore._m = v; try { localStorage.setItem("aicl.hiddenAssets", JSON.stringify(v)); } catch (_) {} } };
  routes.markets = function () {
    crumbs("Markets");
    let tab = "live", rows = [], hidden = hiddenStore.get(), last = {}, changedAt = {}, lastOk = 0;
    view.innerHTML = `<div class="filters" style="justify-content:space-between;margin-bottom:14px">
        <div style="display:flex;gap:6px" id="mtabs"></div>
        <div style="display:flex;gap:10px;align-items:center"><span class="muted" id="m-live" style="font-size:12px"></span><button class="btn" id="m-refresh">⟳ Refresh</button></div></div>
      <div class="mcards" id="mc"></div>
      <p style="margin-top:18px"><a href="#/allmarkets" class="muted">Browse all other markets →</a></p>`;
    const draw = () => {
      const vis = rows.filter((r) => !hidden.includes(r.asset)), hid = rows.filter((r) => hidden.includes(r.asset));
      const goneHidden = hidden.filter((a) => !rows.some((r) => r.asset === a));
      $("#mtabs").innerHTML = `<button class="chip ${tab === "live" ? "on" : ""}" data-k="live">15-minute markets<span class="n">${vis.length}</span></button>
        <button class="chip ${tab === "hidden" ? "on" : ""}" data-k="hidden">Hidden<span class="n">${hid.length + goneHidden.length}</span></button>`;
      $("#mtabs").querySelectorAll(".chip").forEach((b) => b.onclick = () => { tab = b.dataset.k; draw(); });
      const age = lastOk ? (Date.now() - lastOk) / 1000 : null;
      $("#m-live").innerHTML = age != null && age < 5 ? '<span class="dot ok" style="display:inline-block;margin-right:6px"></span>Live' : '<span class="dot warn" style="display:inline-block;margin-right:6px"></span>Updating…';
      const list = tab === "live" ? vis : hid;
      $("#mc").innerHTML = (list.length ? list.map((r) => { const q = r.quote, ch = chance(q), left = r.close_time ? (Date.parse(r.close_time) - Date.now()) / 1000 : null;
        const fl = changedAt[r.asset] && Date.now() - changedAt[r.asset] < 900 ? " flash" : "";
        return `<div class="mcard${fl}" data-t="${esc(r.ticker)}"><div class="mc-top"><div><div class="mc-name">${esc(ASSET_NAMES[r.asset] || r.asset)}</div><div class="muted">${r.open_now ? "Up in 15 min?" : "Waiting for next window"}</div></div>
          <div class="mc-ch">${r.open_now ? pctOf(ch) : "—"}<small>chance up</small></div></div>
          <div class="mc-mid"><span class="muted">Target</span><span class="mono">${r.strike.replace(/^[≥>] /, "$")}</span></div>
          <div class="mc-mid"><span class="muted">${r.open_now ? "Closes in" : "Opens soon"}</span><span class="mono ${left != null && left < 120 ? "warn" : ""}">${r.open_now ? ttc(left) : ""}</span></div>
          <div class="mc-btns"><span class="buy yes">Up ${pctP(q.yes_ask)}</span><span class="buy no">Down ${pctP(q.no_ask)}</span></div>
          <button class="mc-hide" data-a="${esc(r.asset)}" title="${tab === "live" ? "Hide this market" : "Show this market again"}">${tab === "live" ? "Hide" : "Show"}</button></div>`; }).join("")
        : (tab === "live" ? emptyState(rows.length ? "All markets are hidden" : "No 15-minute markets are open right now", rows.length ? "Open the Hidden tab to bring them back." : "They appear here as soon as Kalshi opens the next window.") : ""))
        + (tab === "hidden" ? goneHidden.map((a) => `<div class="mcard" style="cursor:default"><div class="mc-name">${esc(ASSET_NAMES[a] || a)}</div><div class="muted" style="margin:6px 0 12px">No window open right now</div><button class="mc-hide" data-a="${esc(a)}" style="position:static">Show</button></div>`).join("")
          + (!hid.length && !goneHidden.length ? emptyState("Nothing hidden", "Use Hide on a market card to move it here.") : "") : "");
      $("#mc").querySelectorAll(".mcard[data-t]").forEach((c) => c.onclick = () => location.hash = "#/market/" + encodeURIComponent(c.dataset.t));
      $("#mc").querySelectorAll(".mc-hide").forEach((b) => b.onclick = (ev) => { ev.stopPropagation(); const a = b.dataset.a;
        hidden = hidden.includes(a) ? hidden.filter((x) => x !== a) : hidden.concat(a); hiddenStore.set(hidden); draw(); });
    };
    const load = async (refresh) => {
      const r = await api("/api/terminal/live15" + (refresh ? "?refresh=1" : "")).catch(() => null); if (!r) return;
      r.markets.forEach((m) => { const sig = [m.ticker, m.quote.yes_bid, m.quote.yes_ask].join("|"); if (last[m.asset] && last[m.asset] !== sig) changedAt[m.asset] = Date.now(); last[m.asset] = sig; });
      rows = r.markets; lastOk = Date.now(); draw();
      return r.refresh;
    };
    $("#m-refresh").onclick = async (ev) => { ev.target.disabled = true; ev.target.textContent = "⟳ Refreshing…"; const rp = await load(true); ev.target.disabled = false; ev.target.textContent = "⟳ Refresh";
      if (!rp) toast("Refresh failed: the app's backend didn't answer.", 6000);
      else if (!rp.series) toast("Refresh found no 15-minute series in the market list.", 6000);
      else if (rp.markets) toast(`Refreshed: ${rp.markets} open 15-minute market(s) from Kalshi.${rp.failed ? ` (${rp.failed} of ${rp.series} lookups failed)` : ""}`);
      else { toast("Refresh got no markets from Kalshi. Details copied below — send them to Claude.", 8000); prompt("Copy this and send it to Claude:", `[MARKETS-REFRESH] series=${rp.series} failed=${rp.failed} format_rejected=${rp.rejected_format} first=${rp.error}`); } };
    every(1000, () => load(false));
  };

  routes.allmarkets = function (args) {
    if (args[0]) MX.tab = args[0];
    crumbs("Markets", MX.tab);
    view.innerHTML = `<div class="tabs" id="tabs"></div>
      <div class="filters">
        <input type="text" class="search" id="q" placeholder="Search ticker or title…" value="${esc(MX.q)}">
        <select id="status"><option value="open">Open</option><option value="upcoming">Upcoming</option><option value="closed">Closed / settled</option><option value="all">All statuses</option></select>
        <select id="access"><option value="">All access levels</option><option value="manual">Manual-demo ready</option><option value="auto">Auto-eligible</option></select>
        <select id="sort"><option value="close">Soonest close</option><option value="volume">Volume (24h)</option><option value="ticker">Ticker</option></select>
        <span id="durs" style="display:flex;gap:6px;flex-wrap:wrap"></span>
      </div>
      <div class="card flush"><div class="bd tbl-wrap" id="mtable"></div><div class="pager" id="pager"></div></div>
      <p class="dim" style="font-size:11.5px;margin-top:10px">Access levels — <span class="badge auto">AUTO-ELIGIBLE</span> validated settlement reference and live feed ·
        <span class="badge manual">MANUAL DEMO</span> verified terms, open, strike set (order book and your confirmation are checked again at order time) ·
        <span class="badge view">VIEW ONLY</span> visible but not tradeable. Hover a badge for the reason.</p>`;
    ["status", "access", "sort"].forEach((k) => { const el = $("#" + k); el.value = MX[k]; el.onchange = () => { MX[k] = el.value; MX.offset = 0; load(); }; });
    let qh; $("#q").oninput = (e) => { clearTimeout(qh); qh = setTimeout(() => { MX.q = e.target.value; MX.offset = 0; load(); }, 250); };
    let TABS = null;
    async function loadTabs() {
      try { TABS = (await api("/api/terminal/tabs")).tabs; } catch (e) { return; }
      $("#tabs").innerHTML = TABS.map((t) => `<div class="tab ${t.name === MX.tab ? "on" : ""}" data-tab="${esc(t.name)}">${esc(t.name)}<span class="n">${num(t.open)}</span></div>`).join("");
      $("#tabs").querySelectorAll(".tab").forEach((el) => el.onclick = () => { MX.tab = el.dataset.tab; MX.duration = ""; MX.offset = 0; history.replaceState(null, "", "#/allmarkets/" + encodeURIComponent(MX.tab)); crumbs("Markets", "All", MX.tab); loadTabs(); load(); });
      const cur = TABS.find((t) => t.name === MX.tab) || { durations: {} };
      const order = ["<=5m", "15m", "30m", "1h", "multi_hour", "daily", "weekly", "monthly", "quarterly", "longer", "unknown"];
      const ds = Object.keys(cur.durations).sort((a, b) => order.indexOf(a) - order.indexOf(b));
      $("#durs").innerHTML = `<button class="chip ${MX.duration ? "" : "on"}" data-d="">All durations</button>` +
        ds.map((d) => `<button class="chip ${MX.duration === d ? "on" : ""}" data-d="${esc(d)}">${esc(durName(d))}<span class="n">${num(cur.durations[d])}</span></button>`).join("");
      $("#durs").querySelectorAll(".chip").forEach((b) => b.onclick = () => { MX.duration = b.dataset.d; MX.offset = 0; loadTabs(); load(); });
    }
    async function load() {
      const p = new URLSearchParams({ tab: MX.tab, q: MX.q, duration: MX.duration, status: MX.status, access: MX.access, sort: MX.sort, limit: 150, offset: MX.offset });
      let r; try { r = await api("/api/terminal/markets?" + p); } catch (e) { if (e.status === 503) { $("#mtable").innerHTML = emptyState("Loading markets…", ""); } return; }
      const rows = r.rows;
      $("#mtable").innerHTML = rows.length ? `<table><thead><tr><th>Market</th><th class="r">Chance</th><th class="r">Yes</th><th class="r">No</th><th>Target</th><th>Duration</th><th class="r">Closes in</th>
        <th class="r">Volume</th><th>Access</th></tr></thead><tbody>${rows.map(rowHtml).join("")}</tbody></table>`
        : emptyState("No markets match", MX.tab === "Copper" || MX.tab === "Gold" || MX.tab === "Silver" ? "No open contracts in this tab right now on the demo exchange. Try “All statuses” or another duration." : "Try a different filter.");
      $("#mtable").querySelectorAll("tr[data-t]").forEach((tr) => tr.onclick = () => location.hash = "#/market/" + encodeURIComponent(tr.dataset.t));
      const end = Math.min(MX.offset + rows.length, r.total);
      $("#pager").innerHTML = `<span>${r.total ? `${num(MX.offset + 1)}–${num(end)} of ${num(r.total)}` : "0 markets"}</span>
        <button class="btn" id="prev" ${MX.offset ? "" : "disabled"}>Prev</button><button class="btn" id="next" ${end < r.total ? "" : "disabled"}>Next</button>`;
      $("#prev").onclick = () => { MX.offset = Math.max(0, MX.offset - 150); load(); };
      $("#next").onclick = () => { MX.offset += 150; load(); };
    }
    loadTabs(); every(3000, load); every(30000, loadTabs);
  };
  const durName = (d) => ({ "<=5m": "≤5 min", "15m": "15 min", "30m": "30 min", "1h": "Hourly", multi_hour: "Multi-hour", daily: "Daily", weekly: "Weekly", monthly: "Monthly", quarterly: "Quarterly", longer: "Long-dated", unknown: "Other" }[d] || d);
  function rowHtml(r) {
    const q = r.quote, soon = r.seconds_to_close != null && r.seconds_to_close < 900, ch = chance(q);
    return `<tr class="click" data-t="${esc(r.ticker)}">
      <td><div style="max-width:380px;overflow:hidden;text-overflow:ellipsis">${esc(r.subtitle || r.title)}</div><div class="dim mono" style="font-size:10.5px">${esc(r.ticker)}</div></td>
      <td class="r"><b class="num" style="font-size:14px">${pctOf(ch)}</b></td>
      <td class="r"><span class="buy yes">Yes ${pctP(q.yes_ask)}</span></td><td class="r"><span class="buy no">No ${pctP(q.no_ask)}</span></td>
      <td class="mono">${esc(r.strike)}</td><td>${esc(durName(r.duration))}</td>
      <td class="r ttc ${soon ? "soon" : ""}">${ttc(r.seconds_to_close)}</td><td class="r num">${num(q.volume_24h)}</td>
      <td>${accessBadge(r.access)}</td></tr>`;
  }

  /* ------------------------------------------------------------ market detail */
  routes.market = async function (args) {
    const t = args[0]; if (!t) { location.hash = "#/markets"; return; }
    crumbs("Markets", t);
    let d;
    try { d = await api("/api/terminal/market/" + encodeURIComponent(t)); }
    catch (e) { view.innerHTML = emptyState(e.status === 404 ? "Market not available" : "Could not load market", e.status === 404 ? "This market is not an approved financial-price contract, or it is no longer in the registry." : ""); return; }
    crumbs("Markets", d.tab, d.ticker);
    const ref = d.settlement, refOk = ref.status === "validated";
    const cf = d.reference_live && d.reference_live.index;
    view.innerHTML = `
      <div class="det-hd"><div>
        <h1>${esc(d.subtitle || d.title)}</h1>
        <div class="tk">${esc(d.ticker)} · ${esc(d.title)}</div>
        <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap">${accessBadge(d.access)}<span class="badge">${esc(d.tab)}</span><span class="badge">${esc(durName(d.duration))}</span><span class="badge ${d.status === "active" ? "ok" : ""}">${esc(d.status)}</span>${refBadge(ref)}</div>
      </div><div class="countdown" id="cd">—<small>until close</small></div></div>
      ${refOk ? "" : `<div class="banner warn"><b>⚠ No live ${esc(d.asset.toLowerCase())} price</b><span>This market settles on ${esc(provName(ref.provider))}, and the app has no licensed price source for it yet, so the ${esc(d.asset.toLowerCase())} price is not shown (never estimated). You can still view it; automatic trading can't use it.</span></div>`}
      ${d.access.manual ? "" : `<div class="banner info"><b>${d.access.manual_blockers.some((b) => b.code === "strike_pending") ? "Not open yet" : "View only"}</b><span>${d.access.manual_blockers.some((b) => b.code === "strike_pending") ? "This window hasn't opened yet, so it has no target price and can't be traded. Go back to Markets for the window that is live now." : d.access.manual_blockers.map((b) => esc(b.text)).join(" · ")}</span></div>`}
      <div class="grid g-detail"><div class="grid" style="align-content:start">
        <div class="quote-grid" id="quotes"></div>
        <div class="card"><div class="hd"><h3>Chance</h3><span class="muted" id="hist-sub"></span></div><div class="bd"><canvas class="chart" id="ch-contract"></canvas></div></div>
        <div class="card"><div class="hd"><h3>${esc(d.asset)} price</h3><span class="muted" id="ref-sub"></span></div><div class="bd">${cf && refOk
          ? '<canvas class="chart sm" id="ch-ref"></canvas>' : `<div class="empty"><b>No price available</b>${esc(refOk ? "" : "There is no licensed price source for this market yet.")}</div>`}</div></div>
        <div class="grid g-2e">
          <div class="card flush"><div class="hd"><h3>Order book</h3><span class="muted" id="book-sub"></span></div><div class="bd" id="book">${emptyState("Loading order book…", "")}</div></div>
          <div class="card flush"><div class="hd"><h3>Trade activity</h3></div><div class="bd tbl-wrap" style="max-height:320px" id="trades">${emptyState("Loading trades…", "")}</div></div>
        </div>
        <div class="card"><div class="hd"><h3>Rules & settlement</h3>${d.series_info.contract_url ? `<a href="${esc(d.series_info.contract_url)}" target="_blank" rel="noopener">Contract terms ↗</a>` : ""}</div><div class="bd">
          <dl class="kv">
            <dt>Settlement source</dt><dd>${esc(provName(ref.provider))} ${ref.instrument ? "· <span class='mono'>" + esc(ref.instrument) + "</span>" : ""} ${refBadge(ref)}</dd>
            <dt>Method</dt><dd>${esc(ref.method_text)}</dd>
            <dt>Strike</dt><dd class="mono">${esc(d.strike)}</dd>
            <dt>Opens / closes</dt><dd>${fmtDate(d.open_time)} → ${fmtDate(d.close_time)}</dd>
            <dt>Expected expiration</dt><dd>${fmtDate(d.expected_expiration_time)}</dd>
            <dt>Tick size</dt><dd class="mono">${pxt(d.tick)}</dd>
            <dt>Fees</dt><dd>${esc(d.series_info.fee_type)} × ${esc(d.series_info.fee_multiplier)}</dd>
            ${d.result ? `<dt>Result</dt><dd>${esc(d.result)} ${d.settlement_value ? "· " + pxt(d.settlement_value) : ""}</dd>` : ""}
          </dl>
          <div class="section-title">Rules</div><div class="rules">${esc(d.rules_primary)}${d.rules_secondary ? "\n\n" + esc(d.rules_secondary) : ""}</div>
        </div></div>
      </div>
      <div>${ticketHtml(d)}</div></div>`;
    const quoteCells = (yb, ya) => { const ch = chance({ yes_bid: yb, yes_ask: ya, last: d.quote.last });
      return [["Chance", pctOf(ch), ""], ["Buy Yes", pxt(ya), "yes"], ["Buy No", yb != null ? pxt(1 - Number(yb)) : "—", "no"], ["Sell Yes / No", `${pxt(yb)} / ${ya != null ? pxt(1 - Number(ya)) : "—"}`, ""]]
        .map(([l, v, c]) => `<div class="q"><div class="l">${l}</div><div class="v ${c}">${v}</div></div>`).join(""); };
    $("#quotes").innerHTML = quoteCells(d.quote.yes_bid, d.quote.yes_ask, "");
    window.__bestQuote = { best_yes_bid: d.quote.yes_bid, best_yes_ask: d.quote.yes_ask, fallback: true };
    const closeAt = d.close_time ? Date.parse(d.close_time) : null;
    every(1000, () => { if (closeAt) $("#cd").innerHTML = ttc((closeAt - Date.now()) / 1000) + "<small>until close</small>"; });
    setupTicket(d);
    let lastQuote = null;
    every(2000, async () => {
      const b = await api(`/api/terminal/market/${encodeURIComponent(t)}/book`).catch(() => null);
      if (!b) return;
      if (!b.available) { $("#book").innerHTML = emptyState("Order book not available right now", ""); $("#book-sub").textContent = ""; return; }
      lastQuote = b;
      $("#book-sub").textContent = "";
      $("#quotes").innerHTML = quoteCells(b.best_yes_bid, b.best_yes_ask, "");
      const maxQ = Math.max(1, ...b.yes_bids.map((x) => x[1]), ...b.no_bids.map((x) => x[1]));
      const lv = (rows, cls) => rows.length ? rows.slice(0, 12).map(([p, q]) => `<div class="lv ${cls}"><div class="fill" style="width:${(q / maxQ * 100).toFixed(1)}%"></div><span>${pxt(p)}</span><span>${num(q, q % 1 ? 2 : 0)}</span></div>`).join("") : '<div class="empty" style="padding:14px">No bids</div>';
      $("#book").innerHTML = `<div class="ladder"><div class="col"><h4 class="yes">YES bids</h4>${lv(b.yes_bids, "yes")}</div><div class="col"><h4 class="no">NO bids</h4>${lv(b.no_bids, "no")}</div></div>
        <div class="statline" style="padding:8px 12px;border-top:1px solid var(--line)"><span class="muted">Spread · depth YES / NO</span><span>${pxt(b.spread)} · ${num(b.yes_depth)} / ${num(b.no_depth)}</span></div>`;
      window.__bestQuote = b;
    });
    every(5000, async () => {
      const r = await api(`/api/terminal/market/${encodeURIComponent(t)}/trades`).catch(() => null); if (!r) return;
      $("#trades").innerHTML = r.trades.length ? `<table><thead><tr><th>Time</th><th>Taker</th><th class="r">Yes price</th><th class="r">Contracts</th></tr></thead><tbody>${
        r.trades.map((x) => `<tr><td class="mono">${x.time ? new Date(x.time).toLocaleTimeString() : "—"}</td><td class="${x.taker_side === "yes" ? "yes" : "no"}">${esc((x.taker_side || "").toUpperCase())}</td><td class="r">${px(x.yes_price)}</td><td class="r num">${num(x.count, 0)}</td></tr>`).join("")}</tbody></table>`
        : emptyState(r.available ? "No recent trades" : "Trades not available right now", "");
    });
    every(10000, async () => {
      const h = await api(`/api/terminal/market/${encodeURIComponent(t)}/history`).catch(() => null); if (!h) return;
      const c = C();
      const cand = h.candles.map((x) => ({ t: x[0], b: x[1] != null ? +x[1] : null, a: x[2] != null ? +x[2] : null, p: x[3] != null ? +x[3] : null }));
      const live = h.live.map((x) => ({ t: x[0], b: x[1] != null ? +x[1] : null, a: x[2] != null ? +x[2] : null, p: x[3] != null ? +x[3] : null }));
      const all = cand.concat(live.filter((x) => !cand.length || x.t > cand[cand.length - 1].t));
      $("#hist-sub").textContent = "";
      Charts.line($("#ch-contract"), [
        { name: "Yes ask", color: c.yes, points: all.map((x) => [x.t, x.a]), step: true, dash: [4, 3], width: 1.2 },
        { name: "Yes bid", color: c.yes, points: all.map((x) => [x.t, x.b]), step: true },
        { name: "Last trade", color: c.blue, points: all.map((x) => [x.t, x.p]), step: true },
      ], { yFmt: (v) => Math.round(v * 100) + "%", yMin: 0, yMax: 1, empty: "No price history yet for this market" });
    });
    if (cf && refOk) every(2000, async () => {
      const r = await api("/api/terminal/reference/" + encodeURIComponent(cf)).catch(() => null); if (!r) return;
      $("#ref-sub").textContent = r.last != null ? "$" + refFmt(r.last) : "";
      Charts.line($("#ch-ref"), [{ name: cf, color: C().accent, points: r.points, fill: "rgba(61,214,208,.18)" }],
        { yFmt: refFmt, empty: "Price appears once connected" });
    });
  };
  const fmtDate = (s) => s ? new Date(s).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

  /* ------------------------------------------------------------ order ticket (estimates only in Milestone A) */
  function ticketHtml(d) {
    return `<div class="card ticket"><div class="demo-head">DEMO — SIMULATED FUNDS</div><div class="bd">
      <div class="side-toggle"><button class="y on" data-side="yes">${d.duration === "15m" ? "Buy Up" : "Buy Yes"}</button><button class="n" data-side="no">${d.duration === "15m" ? "Buy Down" : "Buy No"}</button></div>
      <div class="field"><label>Amount to spend ($)</label><input type="number" id="tk-amt" min="1" step="1" value="5"></div>
      <div class="field"><label>Price (% chance) — follows the market until you change it</label><input type="number" id="tk-price" step="${Number(d.tick || 0.01) * 100}" min="1" max="99" value="50"></div>
      <div class="muted" id="tk-qtyline" style="font-size:12px;margin:-2px 0 8px"></div>
      <div class="est" id="tk-est"></div>
      <div class="errs" id="tk-err"></div>
      <button class="btn big primary" id="tk-review" disabled>Review Demo Order</button>
      <div class="lock" id="tk-lock"></div>
    </div></div>`;
  }
  function setupTicket(d) {
    let side = "yes"; let primed = false;
    document.querySelectorAll(".side-toggle button").forEach((b) => b.onclick = () => {
      side = b.dataset.side; document.querySelectorAll(".side-toggle button").forEach((x) => x.classList.toggle("on", x === b)); prime(true); upd();
    });
    let edited = false;
    function prime(force) {
      const q = window.__bestQuote; if (!q) return;
      if (edited && !force) return;
      if (primed && !force) return;          // primed = already set from a live book
      const ask = side === "yes" ? q.best_yes_ask : (q.best_yes_bid != null ? (1 - Number(q.best_yes_bid)).toFixed(4) : null);
      if (ask != null) { $("#tk-price").value = centsNum(ask); if (!q.fallback) primed = true; }
    }
    const tkPrice = () => (Number($("#tk-price").value) / 100).toFixed(4);
    const tkQty = () => { const pc = Number($("#tk-price").value), a = Number($("#tk-amt").value); return pc > 0 && a > 0 ? Math.floor(a * 100 / pc) : 0; };
    let h; const upd = () => { clearTimeout(h); h = setTimeout(async () => {
      prime(false);
      const n = tkQty();
      $("#tk-qtyline").textContent = n >= 1 ? `Buys ${n} contract${n > 1 ? "s" : ""} at ${$("#tk-price").value}% ($${(Number($("#tk-price").value) / 100).toFixed(2)} each, pays $1 if right)` : "Amount is too small for one contract at this price";
      const p = new URLSearchParams({ side, price: tkPrice(), count: String(Math.max(n, 1)) });
      const r = await api(`/api/terminal/market/${encodeURIComponent(d.ticker)}/preview?` + p).catch(() => null); if (!r) return;
      const ret = Number(r.max_loss) > 0 ? Math.round(Number(r.max_profit) / Number(r.max_loss) * 100) + "%" : "—";
      $("#tk-est").innerHTML = [["Cost", usd(r.cost)], ["Fee (estimate)", usd(r.fee_taker)], ["Payout if right", usd(n)],
        ["Profit if right", `${usd(r.max_profit)} (${ret})`], ["Most you can lose", usd(r.max_loss)]].map(([a, b]) => `<div><span class="muted">${a}</span><span>${b}</span></div>`).join("")
        + (() => { const S = STATUS, bd = S && S.accounts.kalshi_demo.budget; return `<div><span class="dim" style="font-size:11px">${bd ? `Most you can risk on one market: ${usd(bd * S.risk.per_position)} (${(S.risk.per_position * 100).toFixed(0)}% of your ${usd(bd)} risk budget, set in Settings)` : (S && S.accounts.kalshi_demo.balance != null ? `You can spend up to your demo cash: ${usd(S.accounts.kalshi_demo.balance)}` : "")}</span></div>`; })();
      $("#tk-err").textContent = r.errors.join(" · ");
    }, 200); };
    $("#tk-price").oninput = () => { edited = true; upd(); }; $("#tk-amt").oninput = upd;
    const lockState = () => {
      const s = STATUS, demo = s && s.accounts.kalshi_demo;
      const why = ACCT === "real" ? "Manual orders are demo-only; real trades are placed by the real-money bot. Switch to Demo at the top to place one."
        : !d.access.manual ? "This market is view only." : !demo || !demo.connected ? "Connect your Kalshi demo account to trade (demo API key)."
        : demo.kill ? "Emergency stop is on — reset it in Settings." : "";
      $("#tk-review").disabled = !!why;
      $("#tk-lock").innerHTML = why ? "🔒 " + esc(why) : "Orders go to Kalshi's <b>demo</b> exchange with simulated funds. You'll confirm before anything is sent.";
    };
    every(2000, lockState);
    $("#tk-review").onclick = async () => {
      const body = { ticker: d.ticker, side, price: tkPrice(), count: tkQty() };
      let r; try { r = await post("/api/demo/orders/prepare", body); } catch (e) { $("#tk-err").textContent = e.message; return; }
      if (!r.token) { $("#tk-err").textContent = r.errors.join(" "); return; }
      const m = modal(`<div class="demo-head">DEMO — SIMULATED FUNDS</div><div class="bd">
        <h3 style="margin:0 0 4px">Confirm demo order</h3><div class="muted" style="margin-bottom:12px">${esc(r.title)} · <span class="mono">${esc(r.ticker)}</span></div>
        <div class="est" style="border:0;padding:0">
          <div><span class="muted">Order</span><span class="${side}">Buy ${r.count} ${side.toUpperCase()} at ${pxt(r.price)} (limit)</span></div>
          <div><span class="muted">Estimated cost</span><span>$${esc(r.cost)}</span></div><div><span class="muted">Estimated fee</span><span>$${esc(r.fee)}</span></div>
          <div><span class="muted">Maximum loss</span><span>$${esc(r.max_loss)}</span></div><div><span class="muted">Maximum profit</span><span>$${esc(r.max_profit)}</span></div></div>
        <p class="dim" style="font-size:11.5px">Sent to Kalshi's demo exchange only. This confirmation expires in ${r.expires_in} s.</p>
        <div style="display:flex;gap:8px;margin-top:10px"><button class="btn big" id="m-cancel">Back</button><button class="btn big primary" id="m-ok">Confirm Demo Trade</button></div>
        <div class="errs" id="m-err"></div></div>`);
      m.el.querySelector("#m-cancel").onclick = m.close;
      m.el.querySelector("#m-ok").onclick = async (ev) => {
        ev.target.disabled = true;
        try { const res = await post("/api/demo/orders/confirm", { ...body, token: r.token }); m.close();
          toast(res.state === "UNKNOWN" ? "Sent — checking with Kalshi whether it went through…" : `Demo order ${res.state.toLowerCase()}.`); }
        catch (e) { m.el.querySelector("#m-err").textContent = e.message; }
      };
    };
    setTimeout(() => { prime(false); upd(); }, 900); upd();
  }

  /* ------------------------------------------------------------ demo trading terminal */
  routes.trade = function (args) {
    let tab = (args && args[0]) || "positions";
    crumbs("Portfolio");
    view.innerHTML = `<div class="grid g-kpi" id="dk"></div>
      <div class="filters" style="margin-top:14px;justify-content:space-between"><div style="display:flex;gap:6px" id="ptabs"></div>
        <button class="btn danger" id="k-on">Emergency stop</button></div>
      <div class="card flush"><div class="bd tbl-wrap" id="pbody"></div></div>`;
    const TABS = [["positions", "Positions"], ["orders", "Open orders"], ["transactions", "Transactions"], ["activity", "Activity"]];
    const drawTabs = (counts) => { $("#ptabs").innerHTML = TABS.map(([k, n]) => `<button class="chip ${k === tab ? "on" : ""}" data-k="${k}">${n}${counts[k] != null ? `<span class="n">${counts[k]}</span>` : ""}</button>`).join("");
      $("#ptabs").querySelectorAll(".chip").forEach((b) => b.onclick = () => { tab = b.dataset.k; history.replaceState(null, "", "#/trade/" + tab); $("#pbody").innerHTML = ""; load(); }); };
    const realView = ACCT === "real";
    $("#k-on").textContent = realView ? "STOP REAL TRADING" : "Emergency stop";
    $("#k-on").onclick = async () => {
      if (realView) { if (confirm("Stop real trading: turn the real-money bot off and cancel all open REAL orders?")) { const r = await post("/api/real/kill").catch((e) => toast(e.message)); if (r) toast(`Real trading stopped: ${r.canceled} order(s) canceled.`, 6000); } return; }
      if (confirm("Emergency stop: cancel all open demo orders and turn the bot off?")) { const r = await post("/api/demo/kill").catch((e) => toast(e.message)); if (r) toast(`Emergency stop: ${r.canceled} order(s) canceled. Reset it in Settings.`, 6000); } };
    const stateBadge = (st) => ({ RESTING: "live", PARTIAL: "live", FILLED: "ok", CANCELED: "", REJECTED: "bad", FAILED: "bad", UNKNOWN: "warn", SUBMITTING: "warn", CANCEL_PENDING: "warn" }[st] || "");
    const when = (t) => t ? new Date(t).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";
    const orderRow = (o, cancel) => `<tr><td class="mono">${when(o.created_at * 1000)}</td><td class="mono">${esc(o.ticker)}</td><td class="${o.side}">${esc((o.action || "buy").toUpperCase())} ${o.side.toUpperCase()}</td>
      <td class="r">${px(o.price)}</td><td class="r num">${num(o.filled, 0)} / ${num(o.count, 0)}</td><td><span class="badge ${stateBadge(o.state)}">${esc(o.state.replace("_", " ").toLowerCase())}</span></td>
      <td>${/^(auto|bot)/.test(o.origin) ? '<span class="badge">bot</span>' : o.origin.startsWith("cashout") ? "cash out" : "you"}</td><td class="muted" style="white-space:normal;max-width:260px">${esc(o.error || "")}</td>
      ${cancel ? `<td>${["RESTING", "PARTIAL"].includes(o.state) ? `<button class="btn" data-c="${esc(o.client_order_id)}">Cancel</button>` : ""}</td>` : ""}</tr>`;
    const orderHead = (c) => `<thead><tr><th>Time</th><th>Market</th><th>Order</th><th class="r">Price</th><th class="r">Filled</th><th>Status</th><th>By</th><th>Note</th>${c ? "<th></th>" : ""}</tr></thead>`;
    async function load() {
      const [ds, ps, os, tx] = await Promise.all([api("/api/demo/status?" + AQ()).catch(() => null), api("/api/demo/positions?" + AQ()).catch(() => null),
        api("/api/demo/orders?" + AQ()).catch(() => null), api("/api/demo/transactions?" + AQ()).catch(() => null)]);
      if (!ds) return;
      const acc = ds.account || {}, conn = ds.state === "connected", pos = ps ? ps.positions : [];
      const open = os ? os.orders.filter((o) => ["SUBMITTING", "UNKNOWN", "RESTING", "PARTIAL", "CANCEL_PENDING"].includes(o.state)) : [];
      const upl = pos.reduce((a, p) => a + (p.pnl != null ? Number(p.pnl) : 0), 0);
      $("#dk").innerHTML = [
        kpi("Cash", conn ? usd(acc.balance) : "Not connected", conn ? (realView ? "REAL money" : "Demo funds") : (realView ? "Needs the real API key" : "Needs the demo API key"), realView ? "" : "demo"),
        kpi("Positions value", conn ? usd(acc.portfolio_value) : "—", `${pos.length} open`),
        kpi("Open profit / loss", pos.length ? signed(upl) : "—", "If cashed out now"),
        kpi("Today's profit / loss", conn && acc.realized_today != null ? signed(acc.realized_today) : "—", "Closed since midnight, after fees"),
        kpi("All closed trades", tx && tx.count ? signed(tx.total_pnl) : "—", tx && tx.count ? `${tx.count} closed · ${(tx.wins / tx.count * 100).toFixed(0)}% won` : "None yet"),
        kpi(realView ? "Real stop" : "Emergency stop", ds.kill ? "ON" : "Off", ds.kill ? (realView ? "Reset when turning the real bot on" : "Reset in Settings") : ""),
      ].join("");
      drawTabs({ positions: pos.length, orders: open.length, transactions: tx ? tx.count : null });
      const el = $("#pbody");
      if (tab === "positions") renderPositions(el, pos);
      else if (tab === "orders") {
        el.innerHTML = open.length ? `<table>${orderHead(!realView)}<tbody>${open.map((o) => orderRow(o, !realView)).join("")}</tbody></table>` : emptyState("No open orders", "");
        el.querySelectorAll("button[data-c]").forEach((b) => b.onclick = async () => { b.disabled = true; try { const x = await post(`/api/demo/orders/${encodeURIComponent(b.dataset.c)}/cancel`); toast(`Order ${x.state.toLowerCase()}.`); load(); } catch (e) { toast(e.message); b.disabled = false; } });
      } else if (tab === "transactions") {
        const rows = tx ? tx.transactions : [];
        el.innerHTML = rows.length ? `<table><thead><tr><th>Closed</th><th>Market</th><th>Side</th><th class="r">Contracts</th><th class="r">Entry</th><th class="r">Exit</th><th>Result</th><th class="r">Cost</th><th class="r">Profit / loss</th><th class="r">Fees</th><th>By</th></tr></thead><tbody>${
          rows.map((r) => `<tr><td class="mono">${when(r.closed)}</td><td><div style="max-width:320px;overflow:hidden;text-overflow:ellipsis">${esc(r.title)}</div><div class="dim mono" style="font-size:10.5px">${esc(r.ticker)}</div></td>
            <td class="${esc(r.side || "")}"><b>${esc((r.side || "").toUpperCase())}</b></td><td class="r num">${num(r.contracts)}</td><td class="r">${px(r.avg_entry)}</td>
            <td class="r">${r.how === "settled" ? px(r.won ? "1" : "0") : px(r.avg_exit)}</td>
            <td>${r.how === "settled" ? (r.won ? '<span class="badge ok">Won</span>' : '<span class="badge bad">Lost</span>') : '<span class="badge">Cashed out</span>'}</td>
            <td class="r num">${usd(r.cost)}</td><td class="r num">${pnlCell(r.pnl, r.pnl_pct)}</td><td class="r num">${usd(r.fees)}</td><td>${r.by === "bot" ? '<span class="badge">bot</span>' : "you"}</td></tr>`).join("")}</tbody></table>`
          : emptyState("No closed positions yet", "A position shows here after it is cashed out or its market settles.");
      } else {
        const ev = await api("/api/demo/events?limit=120&" + AQ()).catch(() => ({ events: [] }));
        const hist = os ? os.orders : [];
        el.innerHTML = `<div class="section-title" style="margin:12px 14px 4px">All orders</div>${hist.length ? `<table>${orderHead(false)}<tbody>${hist.map((o) => orderRow(o, false)).join("")}</tbody></table>` : emptyState("No orders yet", "")}
          <div class="section-title" style="margin:16px 14px 4px">Log</div>${ev.events.length ? `<table><tbody>${ev.events.map((e) => `<tr><td class="mono">${when(e.t * 1000)}</td><td>${esc(e.kind)}</td><td style="white-space:normal">${esc(e.message)}</td></tr>`).join("")}</tbody></table>` : emptyState("No activity yet", "")}`;
      }
    }
    every(3000, load);
  };

  routes.strategy = async function () {
    crumbs("Bot & Strategies");
    view.innerHTML = `
      <div class="card" id="real-card" style="border:1px solid var(--no);margin-bottom:14px;${ACCT === "real" ? "" : "display:none"}">
        <div class="hd"><h3 style="color:var(--no)">REAL MONEY</h3><span class="muted" id="r-conn">checking…</span></div>
        <div class="bd" style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">
          <div><div class="muted" style="font-size:12px">Real bot</div><div id="r-state" style="font:600 22px/1.2 var(--mono)">—</div></div>
          <div id="r-line" style="flex:1;min-width:240px"></div>
          <label style="display:flex;gap:8px;align-items:center">Bet size <input id="r-stake" type="number" min="0.5" max="10" step="0.5" style="width:70px"> %</label>
          <button class="btn" id="r-stake-save">Save</button>
          <label style="display:flex;gap:8px;align-items:center" title="Sell a position automatically when its chance of winning drops to this % or lower (and under half of what was paid). 0 = off.">Cash out losers at <input id="r-cashout" type="number" min="0" max="50" step="1" style="width:60px"> %</label>
          <button class="btn" id="r-cashout-save">Save</button>
          <button class="btn" id="r-toggle">Turn on</button>
          <button class="btn" id="r-kill" style="background:var(--no);color:#fff">STOP REAL TRADING</button></div>
        <div class="bd" id="r-limits" style="border-top:1px solid var(--line2)"></div>
        <div class="banner warn" id="r-err" style="display:none;margin:0 14px 14px"></div>
        <details style="padding:0 14px 12px"><summary class="muted" style="cursor:pointer">Real-account activity</summary><div class="tbl-wrap" id="r-events" style="max-height:220px"></div></details></div>
      <div class="card" style="${ACCT === "real" ? "display:none" : ""}"><div class="bd" style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">
          <div><div class="muted" style="font-size:12px">Bot</div><div id="b-state" style="font:600 22px/1.2 var(--mono)">—</div></div>
          <div class="muted" id="b-line" style="flex:1;min-width:220px"></div>
          <button class="btn" id="b-set-toggle">Settings</button></div>
        <div class="bd" id="b-settings" style="display:none;border-top:1px solid var(--line2);gap:18px;align-items:center;flex-wrap:wrap">
          <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="bs-practice"> Practice mode (also trade rules still being tested)</label>
          <label style="display:flex;gap:8px;align-items:center">Bet size <input id="bs-stake" type="number" min="0.5" max="10" step="0.5" style="width:70px"> % of account</label>
          <button class="btn" id="bs-save">Save</button></div>
        <div class="banner warn" id="b-err" style="display:none;margin:0 14px 14px"></div></div>
      <div class="card" style="margin-top:14px"><div class="hd"><h3>How the bot is doing</h3><span class="muted">${ACCT === "real" ? "REAL money" : "demo money"}</span></div><div class="bd">
        <div class="grid g-kpi" id="bp-k"></div>
        <canvas class="chart" id="bp-cum" style="margin-top:12px"></canvas>
        <div class="tbl-wrap" id="bp-days" style="margin-top:10px"></div></div></div>
      <div class="card flush" style="margin-top:14px"><div class="hd"><h3>Strategies</h3><span class="muted">average return per trade, after fees</span></div>
        <div class="bd tbl-wrap" id="fam"></div>
        <p class="dim" style="font-size:11.5px;margin:0;padding:10px 14px">Return = profit after fees as a % of the money paid (+10% means a $10 bet made $1 on average).
          "Real prices" runs the same rule against the real exchange's prices as a simulation; real orders are placed only by the REAL MONEY bot above.
          Demo results usually look better because demo prices are often out of date.</p></div>
      <details class="card" style="margin-top:14px" id="more"><summary class="muted" style="padding:12px 14px;cursor:pointer">Show details: every rule version and lab activity</summary>
        <div class="bd tbl-wrap" style="max-height:460px" id="sb"></div><div class="bd tbl-wrap" style="max-height:220px" id="lev"></div></details>`;

    const pct = (v) => v == null ? "—" : `${v > 0 ? "+" : ""}${v.toFixed(1)}%`;
    const tone = (v) => v > 0 ? "yes" : v < 0 ? "no" : "";
    let bsLoaded = false;
    $("#b-set-toggle").onclick = () => { const s = $("#b-settings"); s.style.display = s.style.display === "none" ? "flex" : "none"; };
    $("#bs-save").onclick = async () => { try { const r = await post("/api/bot/settings", { practice: $("#bs-practice").checked, stake_pct: $("#bs-stake").value }); toast(`Saved: ${r.stake_pct}% per trade, practice ${r.practice ? "on" : "off"}.`); } catch (e) { toast(e.message, 6000); } };

    let rsLoaded = false;
    $("#r-cashout-save").onclick = async () => { try { const r = await post("/api/real/settings", { cashout_pct: $("#r-cashout").value }); toast(r.cashout_pct > 0 ? `Real positions are sold automatically when their chance drops to ${r.cashout_pct}% or less.` : "Automatic cash-out is off."); drawReal(); } catch (e) { toast(e.message, 6000); } };
    $("#r-stake-save").onclick = async () => { try { const r = await post("/api/real/settings", { stake_pct: $("#r-stake").value }); toast(`Real bet size: ${r.stake_pct}% of the real account per trade.`); drawReal(); } catch (e) { toast(e.message, 6000); } };
    $("#r-kill").onclick = async () => { try { const r = await post("/api/real/kill"); toast(`Real trading stopped: ${r.canceled} open orders canceled${r.failed ? `, ${r.failed} failed` : ""}.`, 6000); drawReal(); } catch (e) { toast(e.message, 6000); } };
    $("#r-toggle").onclick = async () => { await realToggle(); drawReal(); pollStatus(); };
    const drawReal = async () => {
      const st = await api("/api/real/status").catch(() => null); if (!st || !$("#r-state")) return;
      if (!rsLoaded) { rsLoaded = true; $("#r-stake").value = st.stake_pct; $("#r-cashout").value = st.cashout_pct; }
      const conn = { connected: "real account connected", no_credentials: "not set up: add the real API key file (see docs/REAL_MONEY.md)", error: "connection problem", off: "starting…" }[st.state] || st.state;
      $("#r-conn").textContent = conn + (st.balance != null ? ` · cash ${usd(st.balance)} · positions ${usd(st.portfolio_value)}` : "");
      $("#r-state").textContent = st.bot_on ? "ON" : (st.kill ? "STOPPED" : "OFF");
      $("#r-state").className = st.bot_on ? "no" : "";
      $("#r-toggle").textContent = st.bot_on ? "Turn off" : "Turn on";
      $("#r-toggle").disabled = st.state !== "connected" && !st.bot_on;
      $("#r-line").textContent = st.bot_on ? `Trading REAL money · ${st.stake_pct}% of the account per trade · ${st.open_positions} open positions` : "Off. Real trading starts only when you turn it on here.";
      const L = st.limits;
      $("#r-limits").innerHTML = `<div class="grid g-kpi">${[
        kpi("Spent today", usd(L.spent_today), L.daily_limit == null ? "no daily limit" : `of ${usd(L.daily_limit)} allowed (${L.per_day_pct}% per day)`),
        kpi("Left today", L.left_today == null ? "no limit" : usd(L.left_today), L.left_today == null ? "your choice" : "new trades stop at the limit"),
        kpi("Per trade", `$${Number(L.min_trade).toFixed(0)} – ${L.per_trade_pct}%`, "minimum $1, maximum 10% of the account"),
        kpi("Daily loss stop", "none", "your choice"),
        kpi("Cash out losers", st.cashout_pct > 0 ? `at ${st.cashout_pct}%` : "off", "sells a position whose chance falls this low")].join("")}</div>`;
      const errs = [st.error && st.state === "error" ? "Connection: " + st.error : "", st.last_bot_error ? "Last refused real order: " + st.last_bot_error : ""].filter(Boolean);
      const err = $("#r-err"); err.style.display = errs.length ? "flex" : "none"; err.textContent = errs.join(" · ");
      $("#r-events").innerHTML = st.events.length ? `<table><tbody>${st.events.map((e) => `<tr><td class="mono">${new Date(e.t * 1000).toLocaleTimeString()}</td><td>${esc(e.kind)}</td><td style="white-space:normal">${esc(e.message)}</td></tr>`).join("")}</tbody></table>` : '<span class="dim">No real-account activity yet.</span>';
    };

    const drawBot = async () => {
      const sm = await api("/api/lab/summary").catch(() => null); if (!sm || !$("#b-state")) return;
      const b = sm.bot;
      if (!bsLoaded) { bsLoaded = true; $("#bs-practice").checked = !!b.practice; $("#bs-stake").value = b.stake_pct; }
      $("#b-state").textContent = b.on ? "ON" : "OFF";
      $("#b-state").className = b.on ? "yes" : "";
      $("#b-line").textContent = b.on ? `Trading demo money · bets ${b.stake_pct}% of the account per trade${b.practice ? " · practice mode" : ""}`
        : "Off. Use the switch at the top to start it.";
      const err = $("#b-err"); err.style.display = b.last_error ? "flex" : "none"; err.textContent = b.last_error ? "Last refused order: " + b.last_error : "";
    };

    const drawProgress = async () => {
      const bp = await api("/api/bot/progress?" + AQ()).catch(() => null); if (!bp || !$("#bp-k")) return;
      const td = bp.today;
      $("#bp-k").innerHTML = [
        kpi("Today", td ? signed(td.value) : "—", td ? `${td.trades} trades${td.trades ? ` · ${Math.round(td.wins / td.trades * 100)}% won` : ""}` : "since midnight"),
        kpi("All time", bp.trades ? signed(bp.net) : "—", bp.trades ? `${num(bp.trades)} trades · ${bp.win_pct.toFixed(0)}% won` : "no trades yet"),
        kpi("Recent win rate", bp.recent_win_pct != null ? bp.recent_win_pct.toFixed(0) + "%" : "—", "last 25 trades")].join("");
      const Q = bp.points.map((p) => [p.t, p.cum_net]);
      const draw = () => { if ($("#bp-cum")) Charts.line($("#bp-cum"), [{ name: "Profit", color: C().accent, points: Q, fill: "rgba(61,214,208,.15)" }], { yFmt: (v) => "$" + v.toFixed(0) }); };
      requestAnimationFrame(draw);
      window.onresize = () => requestAnimationFrame(draw);
      $("#bp-days").innerHTML = bp.days.length ? `<table><thead><tr><th>Day</th><th class="r">Trades</th><th class="r">Won</th><th class="r">Profit</th></tr></thead><tbody>${
        bp.days.slice().reverse().map((d) => `<tr><td>${esc(new Date(d.day + "T12:00:00").toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }))}</td><td class="r num">${num(d.trades)}</td><td class="r num">${d.win_pct.toFixed(0)}%</td><td class="r num ${tone(+d.net)}">${signed(d.net)}</td></tr>`).join("")}</tbody></table>` : "";
    };

    const drawFamilies = async () => {
      const r = await api("/api/lab/families").catch(() => null); if (!r || !$("#fam")) return;
      $("#fam").innerHTML = `<table><thead><tr><th>Strategy</th><th>Verdict</th><th class="r">On demo</th><th class="r">At real prices</th></tr></thead><tbody>${
        r.families.map((f) => `<tr><td style="white-space:normal"><b>${esc(f.name)}</b><div class="dim" style="font-size:11.5px">${esc(f.description)}</div></td>
          <td><span class="badge ${f.tone}">${esc(f.verdict)}</span></td>
          <td class="r num ${tone(f.demo_ret)}">${pct(f.demo_ret)}<div class="dim" style="font-size:11px">${num(f.demo_trades)} trades</div></td>
          <td class="r num ${tone(f.real_ret)}" title="${esc(f.real_source)}">${pct(f.real_ret)}<div class="dim" style="font-size:11px">${num(f.real_trades)} trades</div></td></tr>`).join("")}</tbody></table>`;
    };

    const fam = { lock: "Lock-in", fair: "Fair value", momentum: "Momentum", favorite: "Favourite", imbalance: "Imbalance", kmomentum: "Kalshi momentum", favmid: "Favourite 2-7 min" };
    const stage = { proven: "Proven", shortlisted: "Shortlisted", exploring: "Testing", rejected: "Rejected", retired: "No edge", retired_live: "Stopped working" };
    const pstr = (p) => Object.entries(p).map(([k, v]) => `${k} ${Array.isArray(v) ? v.join("–") : v}`).join(", ");
    const drawDetails = async () => {
      if (!$("#more") || !$("#more").open) return;
      const r = await api("/api/lab/scoreboard").catch(() => null); if (!r) return;
      const rows = r.rows.filter((x) => x.n > 0).sort((a, b) => b.n - a.n).slice(0, 150);
      $("#sb").innerHTML = rows.length ? `<table><thead><tr><th>Rule</th><th>Settings</th><th class="r">Trades</th><th class="r">On demo</th><th class="r">At real prices</th><th>Stage</th></tr></thead><tbody>${
        rows.map((x) => `<tr><td>${esc(fam[x.family] || x.family)} <b>${esc(x.asset)}</b></td><td class="dim" style="white-space:normal;max-width:240px">${esc(pstr(x.params))}</td>
          <td class="r num">${num(x.n)}</td><td class="r num ${tone(x.return_pct)}">${pct(x.return_pct)}</td>
          <td class="r num ${x.real ? tone(x.real.return_pct) : ""}">${x.real ? pct(x.real.return_pct) : "—"}</td>
          <td class="dim">${esc(stage[x.stage] || x.stage)}</td></tr>`).join("")}</tbody></table>` : emptyState("No results yet", "");
      const said = { shortlisted: "was shortlisted (strong start on demo prices; now must prove itself on new trades)", proven: "passed every test and is now proven",
        rejected: "was rejected (failed on new trades)", retired: "was retired (no edge after many trades)", retired_live: "stopped working and was retired" };
      const ruleName = (cid) => { const [f, a, ...p] = (cid || "").split(":"); return `${fam[f] || f} ${a || ""}${p.length ? ` (${p.join(":").replace(/,/g, ", ").replace(/=/g, " ")})` : ""}`; };
      $("#lev").innerHTML = r.events.length ? `<table><tbody>${r.events.map((e) => { const st = (e.message || "").split(":")[0];
          return `<tr><td class="dim" style="white-space:nowrap">${new Date(e.t * 1000).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</td><td style="white-space:normal">${esc(ruleName(e.cid))} ${esc(said[st] || st)}</td></tr>`; }).join("")}</tbody></table>`
        : `<p class="dim" style="margin:0">No rule has been promoted or retired yet.</p>`;
    };
    $("#more").addEventListener("toggle", drawDetails);

    drawProgress(); drawFamilies();
    if (ACCT === "real") every(4000, drawReal); else every(5000, drawBot); every(30000, drawProgress); every(60000, drawFamilies); every(30000, drawDetails);
  };

  /* ------------------------------------------------------------ analytics */
  routes.analytics = async function () {
    crumbs("Analytics");
    view.innerHTML = `<div class="section-title" style="margin-top:0">Crypto spot paper — Freqtrade dry-run (existing lab)</div><div id="cp"></div>
      <div class="section-title">Kalshi local paper simulation</div><div class="card flush"><div class="bd" id="klp"></div></div>
      <div class="section-title">Kalshi demo exchange fills</div><div class="card flush"><div class="bd" id="kd"></div></div>
      <p class="dim" style="font-size:11.5px">These three are separate systems. Balances, orders and P/L are never combined.</p>`;
    const r = await api("/api/terminal/analytics").catch(() => null); if (!r) return;
    const p = r.crypto_paper;
    $("#cp").innerHTML = p.available ? `<div class="grid g-kpi">${kpi("Closed trades", num(p.closed_trades), "")}${kpi("Realized P/L", usd(p.realized_pnl), "simulated")}${kpi("Win rate", (p.win_rate * 100).toFixed(1) + "%", "")}${kpi("Max drawdown", (p.max_drawdown * 100).toFixed(1) + "%", "")}${kpi("Open positions", num(p.open_trades), "")}${kpi("Starting balance", usd(p.starting_balance), "simulated")}</div>
      <div class="card" style="margin-top:14px"><div class="hd"><h3>Equity curve</h3></div><div class="bd"><canvas class="chart" id="eq"></canvas></div></div>`
      : `<div class="card flush"><div class="bd">${emptyState("No crypto paper trades yet", p.note || p.error || "Start the Freqtrade dry-run bot to populate this.")}</div></div>`;
    if (p.available && p.equity_curve && p.equity_curve.length) Charts.line($("#eq"), [{ name: "Equity", color: C().accent, points: p.equity_curve.map((e) => [Date.parse(e.t) / 1000, e.equity]), fill: "rgba(61,214,208,.15)" }], { yFmt: (v) => "$" + v.toFixed(0) });
    $("#klp").innerHTML = emptyState("No simulated Kalshi trades", r.kalshi_local_paper.note);
    $("#kd").innerHTML = emptyState("No demo fills", r.kalshi_demo.note);
  };

  /* ------------------------------------------------------------ safety & system */
  routes.settings = function () {
    crumbs("Settings");
    const desk = !!window.pywebview;
    view.innerHTML = `<div class="grid g-3">
        <div class="card"><div class="hd"><h3>Mode</h3></div><div class="bd">
          <div class="statline"><span class="muted">Showing</span><span class="${ACCT === "real" ? "no" : "warn"}">${ACCT === "real" ? "Kalshi REAL account (real money)" : "Kalshi DEMO (simulated funds)"}</span></div>
          <div class="statline"><span class="muted">Real-money trading</span><span id="s-real">—</span></div>
          <div class="statline"><span class="muted">Automatic trading</span><span id="s-auto">Off</span></div></div></div>
        <div class="card"><div class="hd"><h3>Risk limits</h3></div><div class="bd"><div id="risk"></div><div id="budget" style="margin-top:12px"></div></div></div>
        <div class="card"><div class="hd"><h3>Emergency stop</h3></div><div class="bd">
          <div id="s-kill"></div></div></div>
      </div>
      <div class="card" style="margin-top:14px"><div class="hd"><h3>App</h3></div><div class="bd">${desk
        ? `<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="d-logs">Open log folder</button><button class="btn danger" id="d-quit">Quit AI Crypto Lab</button></div>`
        : '<span class="muted">Running in a browser.</span>'}</div></div>`;
    if (desk) {
      $("#d-logs").onclick = () => window.pywebview.api.open_logs();
      $("#d-quit").onclick = () => { if (confirm("Quit AI Crypto Lab?")) window.pywebview.api.shutdown(true); };
    }
    every(2000, async () => {
      const s = STATUS; if (!s) return; const R = s.accounts.kalshi_real || {};
      $("#s-real").textContent = !R.connected ? "Real account not connected" : R.bot_on ? "REAL BOT ON" : "Connected, bot off";
      if (ACCT === "real") {
        $("#s-auto").textContent = R.bot_on ? "Real bot running" : "Off";
        $("#s-kill").innerHTML = R.kill ? `<p class="warn" style="margin:0 0 10px">Real stop is ON. It resets when you turn the real bot on again.</p>`
          : `<button class="btn big danger" id="sk-real">STOP REAL TRADING</button><p class="muted" style="margin:10px 0 0">Turns the real-money bot off and cancels all open real orders.</p>`;
        if (!R.kill) $("#sk-real").onclick = async () => { if (confirm("Stop real trading: turn the real bot off and cancel all open REAL orders?")) { const r = await post("/api/real/kill").catch((e) => toast(e.message)); if (r) toast(`Real trading stopped: ${r.canceled} order(s) canceled.`); } };
        return;
      }
      const k = s.accounts.kalshi_demo.kill;
      $("#s-auto").textContent = s.mode.automation === "disarmed" ? "Off" : s.mode.automation;
      $("#s-kill").innerHTML = k ? `<p class="warn" style="margin:0 0 10px">Emergency stop is ON.</p><button class="btn" id="sk-r">Reset</button>`
        : `<button class="btn big danger" id="sk-on">EMERGENCY STOP</button><p class="muted" style="margin:10px 0 0">Cancels all open demo orders and turns automatic trading off.</p>`;
      if (k) $("#sk-r").onclick = async () => { if (confirm("Reset the emergency stop?")) await post("/api/demo/kill/reset").catch((e) => toast(e.message)); };
      else $("#sk-on").onclick = async () => { if (confirm("Emergency stop: cancel all open demo orders and stop automatic trading?")) { const r = await post("/api/demo/kill").catch((e) => toast(e.message)); if (r) toast(`Emergency stop: ${r.canceled} order(s) canceled.`); } };
    });
    let budgetDrawn = false;
    every(3000, async () => {
      if (ACCT === "real") {
        if (budgetDrawn) return; const st = await api("/api/real/status").catch(() => null); if (!st) return; budgetDrawn = true; const L = st.limits;
        $("#risk").innerHTML = [["Smallest trade", "$" + Number(L.min_trade).toFixed(0)], ["Largest trade", L.per_trade_pct + "% of the account"],
          ["Spent per day", L.per_day_pct == null ? "No limit" : L.per_day_pct + "% of the account"], ["Daily loss stop", "None"], ["Cash out losers", st.cashout_pct > 0 ? "at " + st.cashout_pct + "% chance" : "Off"], ["Bet size", st.stake_pct + "% (Bot & Strategies)"]]
          .map(([a, b]) => `<div class="statline"><span class="muted">${a}</span><span>${b}</span></div>`).join("");
        $("#budget").innerHTML = '<span class="dim" style="font-size:11.5px">Real-money limits are fixed in the app (docs/REAL_MONEY.md).</span>';
        return;
      }
      if (budgetDrawn) return; const ds = await api("/api/demo/status").catch(() => null); if (!ds) return; budgetDrawn = true;
      $("#budget").innerHTML = `<label class="muted" style="font-size:11.5px">Optional spending limit ($). Leave empty to use whatever is in the account.</label>
        <div style="display:flex;gap:8px;margin-top:4px"><input type="number" id="b-amt" min="1" step="1" placeholder="No limit" value="${ds.budget ? Number(ds.budget) : ""}" style="width:130px"><button class="btn" id="b-save">Save</button><button class="btn" id="b-clear">No limit</button></div>`;
      $("#b-save").onclick = async () => { try { const r = await post("/api/demo/budget", { amount: $("#b-amt").value }); toast(r.budget ? "Limit saved." : "No limit: using account cash."); } catch (e) { toast(e.message); } };
      $("#b-clear").onclick = async () => { try { await post("/api/demo/budget", { amount: "" }); $("#b-amt").value = ""; toast("No limit: using account cash."); } catch (e) { toast(e.message); } };
    });
    every(3000, async () => {
      if (ACCT === "real") return;
      const s = STATUS; if (!s) return; const r = s.risk;
      const bd = s.accounts.kalshi_demo.budget;
      if (!bd) { $("#risk").innerHTML = `<div class="statline"><span class="muted">Spending limit</span><span>None — account cash</span></div><div class="statline"><span class="muted">Bot size</span><span>Set on the Bot &amp; Strategies page</span></div>`; return; }
      $("#risk").innerHTML = [["Max loss per position", (r.per_position * 100).toFixed(0) + "%"], ["Max total open risk", (r.aggregate * 100).toFixed(0) + "%"], ["Daily loss stop", (r.daily_stop * 100).toFixed(0) + "%"]]
        .map(([a, b]) => `<div class="statline"><span class="muted">${a}</span><span>${b}</span></div>`).join("");
    });
  };
  routes.safety = routes.settings;

  /* ------------------------------------------------------------ boot */
  clock(); setInterval(clock, 1000); route();
})();
