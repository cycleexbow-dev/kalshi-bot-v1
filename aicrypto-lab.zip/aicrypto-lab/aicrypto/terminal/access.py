"""Financial-market allowlist and the three access levels shown in the terminal.

    visible   - a financial-price contract on an approved asset (crypto, metals, energy,
                indices, and the configured rates/FX instruments). Everything else (sports,
                politics, weather, entertainment, companies, unknown/undecided markets) is
                never returned by any terminal endpoint.
    manual    - may be offered for a MANUAL demo order (Milestone B): verified identity and
                contract terms, active status, strike stamped, not closing. A valid live order
                book and explicit user confirmation are checked again at order time.
    auto      - may be used by AUTOMATED research/trading: TRADEABLE tier only, i.e. the
                settlement reference is mapped and a validated reference feed is enabled.

A missing licensed reference feed blocks `auto` but not `visible`, and not `manual` on its own.
Markets without an eligibility decision (e.g. their series is absent from the API) are not
visible and can never be traded.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional

from ..kalshi.eligibility import Decision, Reason, Tier
from ..kalshi.models import MarketInfo, MarketStatus, SeriesInfo
from ..kalshi.settings import KalshiSettings

# Explorer tabs, in display order. Platinum/palladium, rates and FX go to "Other".
TABS: List[str] = ["BTC", "ETH", "SOL", "Other Crypto", "Gold", "Silver", "Copper", "Energy", "Indices", "Other"]

# Reasons that mean "not a financial-price contract on an approved asset" -> never shown.
HIDDEN_REASONS = {
    Reason.CATEGORY_DENIED, Reason.CATEGORY_NOT_ALLOWED, Reason.TAG_DENIED, Reason.ASSET_NOT_ALLOWED,
    Reason.ASSET_UNPARSEABLE, Reason.TEST_SERIES, Reason.MARKET_TYPE_NOT_ALLOWED,
}
# Reasons that still allow a manual demo order (the user reads the rules themselves).
MANUAL_OK_REASONS = {Reason.OK, Reason.REFERENCE_FEED_UNAVAILABLE}

FINANCIAL_CLASSES = ("crypto", "metals", "energy", "indices", "rates", "fx")

BLOCKER_TEXT: Dict[str, str] = {
    "not_visible": "Not an approved financial-price market",
    "status": "Market is not open for trading",
    "closing": "Market closes in under 60 seconds",
    "strike_pending": "Strike not yet set (window has not opened)",
    "terms_unverified": "Contract terms not verified",
    "reference_unavailable": "Licensed settlement-reference feed unavailable",
    "not_tradeable_tier": "Not validated for automated trading",
    "no_close_time": "Close time unknown",
}


def tab_for(asset: str, asset_class: str) -> Optional[str]:
    a = (asset or "").upper()
    if asset_class == "crypto":
        return a if a in ("BTC", "ETH", "SOL") else "Other Crypto"
    if asset_class == "metals":
        return {"GOLD": "Gold", "SILVER": "Silver", "COPPER": "Copper"}.get(a, "Other")
    if asset_class == "energy":
        return "Energy"
    if asset_class == "indices":
        return "Indices"
    if asset_class in ("rates", "fx"):
        return "Other"
    return None


@dataclass
class Access:
    visible: bool
    tab: Optional[str]
    manual: bool
    auto: bool
    manual_blockers: List[str] = field(default_factory=list)
    auto_blockers: List[str] = field(default_factory=list)

    @property
    def level(self) -> str:
        if not self.visible:
            return "hidden"
        if self.auto:
            return "auto"
        if self.manual:
            return "manual"
        return "view"

    def to_dict(self) -> dict:
        return {"visible": self.visible, "tab": self.tab, "level": self.level, "manual": self.manual, "auto": self.auto,
                "manual_blockers": [{"code": c, "text": BLOCKER_TEXT.get(c, c)} for c in self.manual_blockers],
                "auto_blockers": [{"code": c, "text": BLOCKER_TEXT.get(c, c)} for c in self.auto_blockers]}


HIDDEN = Access(False, None, False, False, ["not_visible"], ["not_visible"])


def is_financial_series(series: Optional[SeriesInfo], ks: KalshiSettings) -> bool:
    """Cheap pre-filter used before loading markets: category must be allowed and not denied."""
    if series is None:
        return False
    el = ks.eligibility
    cats = {series.category, *series.categories} - {""}
    if any(c in el.denied_categories for c in cats):
        return False
    return series.category in el.allowed_categories


def classify(decision: Optional[Decision], market: MarketInfo, series: Optional[SeriesInfo], ks: KalshiSettings,
             now: Optional[datetime] = None, series_ok: Optional[bool] = None) -> Access:
    """series_ok: the caller's cached is_financial_series(series) result (saves recomputing it per market)."""
    if decision is None or series is None or not (is_financial_series(series, ks) if series_ok is None else series_ok):
        return HIDDEN
    reasons = set(decision.reasons)
    if reasons & HIDDEN_REASONS:
        return HIDDEN
    el = ks.eligibility
    if decision.asset_class not in FINANCIAL_CLASSES or decision.asset not in el.allowed_assets.get(decision.asset_class, []):
        return HIDDEN
    tab = tab_for(decision.asset, decision.asset_class)
    if tab is None:
        return HIDDEN
    now = now or datetime.now(timezone.utc)

    manual_blockers: List[str] = []
    if market.status is not MarketStatus.ACTIVE:
        manual_blockers.append("status")
    if market.close_time is None:
        manual_blockers.append("no_close_time")
    elif (market.close_time - now).total_seconds() < 60:
        manual_blockers.append("closing")
    if Reason.STRIKE_PENDING in reasons:
        manual_blockers.append("strike_pending")
    if decision.tier is Tier.REJECTED or not reasons <= (MANUAL_OK_REASONS | {Reason.STATUS_NOT_TRADEABLE, Reason.CADENCE_DISAGREEMENT}):
        manual_blockers.append("terms_unverified")

    auto_blockers = list(manual_blockers)
    if decision.tier is not Tier.TRADEABLE:
        auto_blockers.append("reference_unavailable" if Reason.REFERENCE_FEED_UNAVAILABLE in reasons else "not_tradeable_tier")
    return Access(True, tab, not manual_blockers, not auto_blockers, manual_blockers, auto_blockers)
