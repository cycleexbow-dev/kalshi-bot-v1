"""Demo trading + automation endpoints. Every state-changing call requires:
  * header X-AICL-Client: terminal  (forces a CORS preflight that this server never approves, so
    other websites open in a browser cannot send these requests), and
  * no foreign Origin (only http://127.0.0.1:<port> / http://localhost:<port> or none).
Orders still need the single-use confirmation token from /prepare (manual) or an armed,
approved strategy (automation). All orders go to the Kalshi DEMO host only.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Optional
from urllib.parse import urlsplit

from fastapi import Body, Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from ..kalshi.demo_exec.trader import Intent, OrderRefused
from .fees import p4_str


class OrderIn(BaseModel):
    ticker: str = Field(max_length=80)
    side: str = Field(max_length=3)
    price: str = Field(max_length=12)
    count: int


class ConfirmIn(OrderIn):
    token: str = Field(max_length=100)


class BudgetIn(BaseModel):
    amount: str = Field(max_length=20)


class ArmIn(BaseModel):
    strategy: str = Field(max_length=80)
    version: str = Field(max_length=20)
    phrase: str = Field(max_length=40)
    max_positions: int = 3
    max_orders_per_min: int = 6


def _dec(s: str) -> Decimal:
    try:
        return Decimal(s)
    except (InvalidOperation, ValueError):
        raise HTTPException(400, {"errors": ["Price is not a number."]})


def add_demo_routes(app: FastAPI, service, port: Optional[int] = None) -> None:
    def guard(request: Request):
        if request.headers.get("x-aicl-client") != "terminal":
            raise HTTPException(403, "missing client header")
        origin = request.headers.get("origin")
        if origin:
            u = urlsplit(origin)
            if u.hostname not in ("127.0.0.1", "localhost") or (port and u.port not in (port, None)):
                raise HTTPException(403, "foreign origin")
        return True

    def refused(e: OrderRefused):
        return JSONResponse({"ok": False, "errors": e.errors}, status_code=422)

    def order_view(o: Dict[str, Any]) -> Dict[str, Any]:
        return {"client_order_id": o["client_order_id"], "order_id": o["order_id"], "ticker": o["ticker"], "side": o["side"],
                "price": p4_str(o["price_p4"]), "count": (o["count_c2"] or 0) / 100, "filled": (o["filled_c2"] or 0) / 100,
                "remaining": (o["remaining_c2"] or 0) / 100, "state": o["state"], "origin": o["origin"], "action": o["action"],
                "max_loss": o["max_loss"], "fees": o["fees"], "error": o["error"], "created_at": o["created_at"],
                "updated_at": o["updated_at"]}

    # ---------------------------------------------------------------- read
    def which(account: str) -> str:
        if account not in ("demo", "real"):
            raise HTTPException(400, "account must be demo or real")
        return account

    @app.get("/api/demo/status")
    async def demo_status(account: str = "demo"):
        if which(account) == "real":
            r = service.real
            return {"state": r.state, "error": r.last_error, "account": r.account, "budget": None, "kill": r.kill_on(),
                    "limits": r.limits_status(), "host": "real exchange", "real": True}
        d = service.demo
        return {"state": d.state, "error": d.last_error, "account": d.account, "budget": str(d.budget()) if d.budget() else None,
                "kill": d.kill_on(), "limits": {"per_position": service.ks.risk.max_loss_per_position,
                                                "aggregate": service.ks.risk.max_aggregate_planned_loss,
                                                "daily_stop": service.ks.risk.daily_realized_loss_stop},
                "host": "demo-api.kalshi.co"}

    @app.get("/api/demo/orders")
    async def demo_orders(scope: str = "all", limit: int = 200, account: str = "demo"):
        L = service.acct(which(account))[1]
        states = ("SUBMITTING", "UNKNOWN", "RESTING", "PARTIAL", "CANCEL_PENDING") if scope == "open" else None
        return {"orders": [order_view(o) for o in L.orders(states=states, limit=min(limit, 500))],
                "fills": [{**f, "price": p4_str(f["price_p4"]), "count": (f["count_c2"] or 0) / 100} for f in L.fills(100)]}

    @app.get("/api/demo/events")
    async def demo_events(limit: int = 100, auto_only: bool = False, account: str = "demo"):
        L = service.acct(which(account))[1]
        ev = L.events(limit=min(limit, 500), origin_prefix="auto" if auto_only else "")
        if account == "real":
            ev = [{**e, "message": (e.get("message") or "").replace("demo cash", "cash").replace("Demo cash", "Cash")} for e in ev]
        return {"events": ev}

    # ---------------------------------------------------------------- write (guarded)
    @app.post("/api/demo/budget")
    async def set_budget(body: BudgetIn, _=Depends(guard)):
        try:
            b = service.demo.set_budget(body.amount.strip())
            return {"ok": True, "budget": str(b) if b else None}
        except OrderRefused as e:
            return refused(e)

    @app.post("/api/demo/orders/prepare")
    async def prepare(body: OrderIn, _=Depends(guard)):
        if body.ticker not in service.access:
            return refused(OrderRefused(["This market is not available for trading."]))
        try:
            return {"ok": True, **(await service.demo.prepare(Intent(body.ticker, body.side, _dec(body.price), body.count)))}
        except OrderRefused as e:
            return refused(e)

    @app.post("/api/demo/orders/confirm")
    async def confirm(body: ConfirmIn, _=Depends(guard)):
        try:
            return {"ok": True, **(await service.demo.confirm(body.token, body.ticker, body.side, body.price, body.count))}
        except OrderRefused as e:
            return refused(e)

    @app.post("/api/demo/orders/{client_order_id}/cancel")
    async def cancel(client_order_id: str, _=Depends(guard)):
        try:
            return {"ok": True, **(await service.demo.cancel(client_order_id[:64]))}
        except OrderRefused as e:
            return refused(e)

    @app.get("/api/demo/positions")
    async def demo_positions(account: str = "demo"):
        return {"positions": service.positions_view(which(account))}

    @app.get("/api/demo/transactions")
    async def demo_transactions(account: str = "demo"):
        rows = await service.transactions(which(account))
        from decimal import Decimal as _D
        return {"transactions": rows[:500], "total_pnl": f"{sum((_D(r['pnl']) for r in rows), _D(0)):.2f}",
                "wins": sum(1 for r in rows if _D(r["pnl"]) > 0), "count": len(rows)}

    @app.post("/api/demo/positions/{ticker}/cashout/quote")
    async def cashout_quote(ticker: str, _=Depends(guard)):
        try:
            q = await service.demo.cashout_quote(ticker[:80])
        except OrderRefused as e:
            return refused(e)
        return {"ok": True, **{k: str(v) for k, v in q.items()}}

    @app.post("/api/demo/positions/{ticker}/cashout")
    async def cashout(ticker: str, _=Depends(guard)):
        try:
            return {"ok": True, **(await service.demo.cashout(ticker[:80]))}
        except OrderRefused as e:
            return refused(e)

    @app.post("/api/demo/kill")
    async def kill(_=Depends(guard)):
        r = await service.demo.kill("emergency stop pressed")
        real = None
        if service.real_bot.on or service.real.ex is not None:       # one emergency stop halts real money too
            real = await service.real.kill("emergency stop pressed (demo page)")
        return {"ok": True, **r, "real": real}

    # ---------------------------------------------------------------- REAL-MONEY trading (rule 21)
    @app.get("/api/real/status")
    async def real_status():
        return service.real_status()

    @app.post("/api/real/bot/on")
    async def real_bot_on(body: Dict[str, Any] = Body(default={}), _=Depends(guard)):
        from ..kalshi.demo_exec.trader import OrderRefused
        try:
            service.real_bot.turn_on(str(body.get("phrase") or ""))
        except OrderRefused as e:
            raise HTTPException(400, {"errors": e.errors})
        return {"ok": True, **service.real_status()}

    @app.post("/api/real/bot/off")
    async def real_bot_off(_=Depends(guard)):
        service.real_bot.turn_off("user")
        return {"ok": True, **service.real_status()}

    @app.post("/api/real/kill")
    async def real_kill(_=Depends(guard)):
        return {"ok": True, **(await service.real.kill("real emergency stop pressed"))}

    @app.post("/api/real/kill/reset")
    async def real_kill_reset(_=Depends(guard)):
        service.real.reset_kill()
        return {"ok": True}

    @app.post("/api/real/settings")
    async def real_settings(body: Dict[str, Any] = Body(default={}), _=Depends(guard)):
        if "stake_pct" not in body and "cashout_pct" not in body:
            raise HTTPException(400, {"errors": ["nothing to change"]})
        try:
            pct = float(body["stake_pct"]) if "stake_pct" in body else None
            co = float(body["cashout_pct"]) if "cashout_pct" in body else None
        except (TypeError, ValueError):
            raise HTTPException(400, {"errors": ["stake_pct must be 0.5-10 and cashout_pct 0-50"]})
        if pct is not None:
            service.real_bot.configure(stake_pct=pct)
        if co is not None:
            service.real.set_cashout_pct(co)
        return {"ok": True, **service.real_status()}

    @app.post("/api/demo/kill/reset")
    async def kill_reset(_=Depends(guard)):
        service.demo.reset_kill()
        return {"ok": True}

    # ---------------------------------------------------------------- live lab + Toggle bot
    @app.get("/api/lab/summary")
    async def lab_summary():
        return service.lab.summary()

    @app.get("/api/lab/scoreboard")
    async def lab_scoreboard():
        rows = service.lab.store.scoreboard()
        real = {r["cid"]: r for r in service.real_lab.store.scoreboard()}
        for r in rows:                      # same rule, scored at the real exchange's public prices
            x = real.get(r["cid"]) or {}
            r["real"] = {"n": x.get("n", 0), "wins": x.get("wins", 0), "net_per_trade": x.get("net_per_trade"), "t": x.get("t"),
                         "return_pct": x.get("return_pct"),
                         "stage": x.get("stage"), "open": x.get("open", 0)}
        order = {"proven": 0, "shortlisted": 1, "exploring": 2, "retired_live": 3, "rejected": 4, "retired": 5}
        rows.sort(key=lambda r: (order.get(r["stage"], 9), -(r["t"] or -99), -r["n"]))
        return {"rows": rows[:400], "events": service.lab.store.events(60)}

    @app.get("/api/lab/families")
    async def lab_families():
        return {"families": await service.lab_families()}

    @app.get("/api/lab/real/summary")
    async def lab_real_summary():
        return service.real_lab.summary()

    @app.get("/api/bot/progress")
    async def bot_progress(account: str = "demo"):
        return await service.bot_progress(account=which(account))

    @app.post("/api/bot/toggle")
    async def bot_toggle(_=Depends(guard)):
        b = service.lab.bot
        try:
            if b.on:
                b.turn_off("user")
            else:
                b.turn_on()
        except OrderRefused as e:
            return refused(e)
        return {"ok": True, "on": b.on}

    @app.post("/api/bot/settings")
    async def bot_settings(body: Dict[str, Any] = Body(default={}), _=Depends(guard)):
        try:
            pct = float(body["stake_pct"]) if body.get("stake_pct") not in (None, "") else None
        except (TypeError, ValueError):
            return refused(OrderRefused(["Stake must be a number between 0.5 and 10 (percent of the account)."]))
        if pct is not None and not (0.5 <= pct <= 10):
            return refused(OrderRefused(["Stake must be between 0.5% and 10% of the account per trade."]))
        service.lab.bot.configure(practice=body.get("practice"), stake_pct=pct)
        return {"ok": True, **service.lab.bot.settings.__dict__}

    # ---------------------------------------------------------------- automation
    @app.get("/api/auto/status")
    async def auto_status():
        return service.auto.status()

    @app.post("/api/auto/arm")
    async def auto_arm(body: ArmIn, _=Depends(guard)):
        try:
            return {"ok": True, **service.auto.arm(body.strategy, body.version, body.phrase, body.max_positions, body.max_orders_per_min)}
        except OrderRefused as e:
            return refused(e)

    @app.post("/api/auto/{action}")
    async def auto_action(action: str, _=Depends(guard)):
        a = service.auto
        try:
            if action == "start":
                return {"ok": True, **a.start()}
            if action == "pause":
                return {"ok": True, **a.pause()}
            if action == "stop":
                return {"ok": True, **(await a.stop())}
            if action == "emergency":
                return {"ok": True, **(await a.emergency())}
        except OrderRefused as e:
            return refused(e)
        raise HTTPException(404, "unknown action")
