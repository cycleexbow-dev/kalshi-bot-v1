"""Typed settings loaded from config/research.yaml."""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Literal

import yaml
from pydantic import BaseModel, Field, field_validator

PROJECT_ROOT = Path(os.environ.get("AICRYPTO_ROOT", Path(__file__).resolve().parent.parent))
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "research.yaml"


class Capital(BaseModel):
    starting_balance: float = 1000.0
    stake_currency: str = "USDT"
    risk_per_trade: float = 0.02
    max_alloc_per_trade: float = 0.95
    max_open_trades: int = 3

    @field_validator("risk_per_trade")
    @classmethod
    def _risk_bounds(cls, v: float) -> float:
        if not 0 < v <= 0.05:
            raise ValueError("risk_per_trade must be in (0, 0.05]")
        return v

    @field_validator("max_alloc_per_trade")
    @classmethod
    def _alloc_bounds(cls, v: float) -> float:
        # Spot only: can never allocate more than 100% of equity (no leverage).
        if not 0 < v <= 1.0:
            raise ValueError("max_alloc_per_trade must be in (0, 1]; leverage is not supported")
        return v


class Markets(BaseModel):
    exchange: str = "binance"
    pairs: List[str] = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
    timeframes: List[str] = ["15m", "1h", "4h"]
    history_days: int = 1095


class Costs(BaseModel):
    fee_pct: float = 0.001
    slippage_bps: float = 5.0
    spread_bps: float = 0.0

    @property
    def slip_frac(self) -> float:
        return (self.slippage_bps + self.spread_bps) / 10_000.0


class WalkForward(BaseModel):
    scheme: Literal["rolling", "anchored"] = "rolling"
    train_bars: int = 4000
    test_bars: int = 1000
    step_bars: int = 1000
    max_folds: int = 8
    optimizer_samples: int = 24
    seed: int = 42


class Gates(BaseModel):
    min_trades: int = 60
    min_folds: int = 4
    min_positive_fold_fraction: float = 0.6
    min_oos_sharpe: float = 0.5
    min_oos_is_ratio: float = 0.4
    max_drawdown: float = 0.25
    max_lookahead_diffs: int = 0
    max_recursive_drift: float = 0.01
    min_neighbour_retention: float = 0.5
    freqtrade_trade_count_tolerance: float = 0.30
    # Freqtrade second-opinion tolerances (see freqtrade_bridge/compare.py for rationale)
    ft_min_entry_match: float = 0.70          # fraction of our entries with an FT entry on the same pair within ±1 bar
    ft_min_exit_match: float = 0.60           # of matched entries, fraction exiting within ±1 bar
    ft_stake_tolerance: float = 0.25          # |median(ft_stake / our_notional) - 1|
    ft_pnl_tolerance_of_capital: float = 0.15 # |ft_pnl - our_pnl| / starting_balance
    ft_fee_tolerance: float = 0.50            # |ft_fees / our_fees - 1|
    ft_drawdown_tolerance: float = 0.10       # |ft_max_dd - our_max_dd| absolute


class Budget(BaseModel):
    max_candidates: int = 40
    max_minutes: float = 30.0
    workers: int = Field(default=1, ge=1, le=2)
    soft_memory_gb: float = 4.0


class Paths(BaseModel):
    user_data: str = "user_data"
    experiments: str = "experiments"
    reports: str = "reports"


class Settings(BaseModel):
    capital: Capital = Capital()
    markets: Markets = Markets()
    costs: Costs = Costs()
    walk_forward: WalkForward = WalkForward()
    gates: Gates = Gates()
    budget: Budget = Budget()
    paths: Paths = Paths()
    root: Path = PROJECT_ROOT

    def path(self, name: str) -> Path:
        return (self.root / getattr(self.paths, name)).resolve()


def load_settings(path: Path | str | None = None, root: Path | None = None) -> Settings:
    p = Path(path) if path else DEFAULT_CONFIG
    data = {}
    if p.exists():
        with open(p, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    s = Settings(**data)
    if root is not None:
        s.root = Path(root)
    return s
