"""Local read-only dashboard (FastAPI). Binds to 127.0.0.1 by default.

Reads: experiments/tracker.sqlite, experiments/runs/*/oos_equity.csv,
user_data/tradesv3.dryrun.sqlite, user_data/config*.json, reports/latest.md.
Never writes anything and has no control endpoints.
"""
from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from .. import safety
from ..experiments import Tracker
from ..reporting import read_paper_trades
from ..reporting.daily import data_health
from ..settings import Settings

HTML_PATH = Path(__file__).with_name("index.html")


def create_app(settings: Settings) -> FastAPI:
    app = FastAPI(title="aicrypto-lab dashboard (paper only)", docs_url=None, redoc_url=None)
    tracker = Tracker(settings.path("experiments"))

    @app.get("/", response_class=HTMLResponse)
    def index():
        return HTML_PATH.read_text(encoding="utf-8")

    @app.get("/api/status")
    def status() -> Dict[str, Any]:
        reps = safety.scan_configs(settings.path("user_data"))
        compose = settings.root / "docker-compose.yml"
        return {
            "paper_only": True,
            "configs": [r.__dict__ for r in reps],
            "all_configs_safe": all(r.ok for r in reps),
            "compose_dry_run": compose.exists() and safety.compose_is_dry_run(compose.read_text()),
            "capital": settings.capital.model_dump(),
            "markets": settings.markets.model_dump(),
            "costs": settings.costs.model_dump(),
            "budget": settings.budget.model_dump(),
            "tracker": tracker.summary(),
            "disclaimer": "Simulated results on past data. Not a forecast. Not a claim of profitability.",
        }

    @app.get("/api/runs")
    def runs(limit: int = 100):
        return tracker.list_runs(limit=limit)

    @app.get("/api/runs/{run_id}")
    def run_detail(run_id: str):
        try:
            d = tracker.load_run(run_id)
        except FileNotFoundError:
            raise HTTPException(404, "run not found")
        eq_path = tracker.runs_dir / run_id / "oos_equity.csv"
        if eq_path.exists():
            with open(eq_path, newline="") as fh:
                d["oos_equity"] = [{"t": r["date"], "equity": float(r["equity"])} for r in csv.DictReader(fh)]
        return JSONResponse(d)

    @app.get("/api/lifecycle")
    def lifecycle():
        return {s: tracker.by_status(s) for s in ("PAPER", "VALIDATED", "CANDIDATE", "RETIRED")}

    @app.get("/api/paper")
    def paper():
        return read_paper_trades(settings).__dict__

    @app.get("/api/data")
    def data():
        return data_health(settings)

    @app.get("/api/report", response_class=PlainTextResponse)
    def report():
        p = settings.path("reports") / "latest.md"
        return p.read_text(encoding="utf-8") if p.exists() else "No report yet. Run: aicrypto report"

    return app
