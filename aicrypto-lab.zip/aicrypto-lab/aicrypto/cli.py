"""aicrypto command line.

  audit          print environment + safety summary
  safety-check   fail if any config under user_data could trade real money
  init-config    write a paper-only user_data/config_dryrun.json (placeholder strategy)
  data-check     validate downloaded candles
  synth-data     write synthetic candles (offline demo / tests)
  backtest       whole-sample backtest of a spec file
  research       bounded autonomous research session
  promote        move gate-passing specs to PAPER after the Freqtrade second opinion (exit 0/3/4)
  activate       HUMAN ONLY (--confirm): switch the active paper strategy
  verify-ft      run Freqtrade backtest / lookahead / recursive on an exported strategy
  report         write the daily Markdown report
  dashboard      serve the local dashboard (legacy)
  ui             desktop terminal backend (Windows launcher)
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import List

from . import __version__, safety
from .settings import Settings, load_settings


def _settings(args) -> Settings:
    root = Path(args.root).resolve() if args.root else None
    return load_settings(args.config, root=root)


def cmd_audit(args):
    import platform
    s = _settings(args)
    print(f"aicrypto-lab {__version__} · python {platform.python_version()} · {platform.platform()}")
    print(f"root: {s.root}")
    for name, mod in [("pandas", "pandas"), ("numpy", "numpy"), ("pyarrow", "pyarrow"), ("fastapi", "fastapi"), ("freqtrade", "freqtrade")]:
        try:
            m = __import__(mod)
            print(f"  {name:10s} {getattr(m, '__version__', 'ok')}")
        except Exception:
            print(f"  {name:10s} missing")
    import shutil
    print(f"  docker     {'present' if shutil.which('docker') else 'missing'}")
    try:
        import resource
        soft, _ = resource.getrlimit(resource.RLIMIT_AS)
        print(f"  RLIMIT_AS  {'unlimited' if soft == resource.RLIM_INFINITY else soft // 1024**3} GB")
    except Exception:
        pass
    print(f"capital ${s.capital.starting_balance:.0f} · risk {s.capital.risk_per_trade:.0%} · pairs {s.markets.pairs} · tfs {s.markets.timeframes}")
    return cmd_safety_check(args)


def cmd_safety_check(args):
    s = _settings(args)
    reps = safety.scan_configs(s.path("user_data")) + safety.scan_kalshi(s.root)
    compose = s.root / "docker-compose.yml"
    ok = True
    for r in reps:
        print(("OK   " if r.ok else "FAIL ") + r.path + ("" if r.ok else ": " + "; ".join(r.problems)))
        ok &= r.ok
    if compose.exists():
        c_ok = safety.compose_is_dry_run(compose.read_text())
        print(("OK   " if c_ok else "FAIL ") + f"{compose} carries --dry-run")
        ok &= c_ok
    print("paper-only: " + ("yes" if ok else "NO"))
    return 0 if ok else 2


def cmd_init_config(args):
    from .freqtrade_bridge import write_config
    s = _settings(args)
    p = write_config(s, args.strategy or "SampleStrategy", args.timeframe)
    print(f"wrote {p} (dry_run=true, no keys)")
    return 0


def cmd_data_check(args):
    from .reporting.daily import data_health
    s = _settings(args)
    rows = data_health(s)
    bad = 0
    for r in rows:
        print(f"{'OK  ' if r['ok'] else 'FAIL'} {r['pair']:9s} {r['tf']:4s} rows={r['rows']:<7} last={r['last']} {r['note']}")
        bad += not r["ok"]
    return 0 if bad == 0 else 2


def cmd_synth_data(args):
    from .data import save_ohlcv, synthetic_ohlcv
    s = _settings(args)
    d = s.path("user_data") / "data" / s.markets.exchange
    seeds = {"BTC/USDT": (1, 30000.0), "ETH/USDT": (2, 2000.0), "SOL/USDT": (3, 100.0)}
    for tf in (args.timeframes or s.markets.timeframes):
        for pair in s.markets.pairs:
            seed, s0 = seeds.get(pair, (hash(pair) % 1000, 100.0))
            p = save_ohlcv(synthetic_ohlcv(args.bars, tf, seed=seed, s0=s0), d, pair, tf)
            print("wrote", p)
    print("NOTE: synthetic data — for pipeline demos only, says nothing about real markets")
    return 0


def _load_data(s: Settings, timeframe: str):
    from .agent.researcher import load_market_data
    return load_market_data(s, timeframe)


def cmd_backtest(args):
    from .research import backtest, compute_metrics
    from .strategies import StrategySpec
    s = _settings(args)
    spec = StrategySpec.from_dict(json.loads(Path(args.spec).read_text()))
    data = _load_data(s, spec.timeframe)
    m = compute_metrics(backtest(data, spec, s.capital, s.costs))
    print(json.dumps({"spec": spec.to_dict(), "metrics": m,
                      "note": "whole-sample, in-sample figure under modelled costs; not a forecast"}, indent=2))
    return 0


def cmd_research(args):
    from .agent import ResearchSession
    from .agent.researcher import load_spec_files
    from .experiments import Tracker
    s = _settings(args)
    data = _load_data(s, args.timeframe)
    tracker = Tracker(s.path("experiments"))
    explicit = load_spec_files([Path(p) for p in args.spec]) if args.spec else None
    log = s.path("experiments") / "research.log"
    sess = ResearchSession(s, tracker, data, args.timeframe, seed=args.seed, max_candidates=args.max_candidates,
                           max_minutes=args.max_minutes, families=args.family or None, explicit_specs=explicit, log=log)
    reps = sess.run()
    passed = [r for r in reps if r.passed]
    print(f"\n{len(reps)} candidates evaluated; {len(passed)} passed all gates (not a profitability claim).")
    for r in passed:
        print(f"  VALIDATED {r.spec.name}  oos_sharpe={r.oos_metrics['sharpe']:.2f} trades={r.oos_metrics["trades"]}")
    return 0


class PromoteStatus:
    """Explicit outcomes with process exit codes. daily.sh treats 0 and 3 as normal, aborts on 2/4."""
    PROMOTED = ("PROMOTED", 0)                       # at least one spec exported and marked PAPER
    NOTHING_TO_PROMOTE = ("NOTHING_TO_PROMOTE", 3)   # expected: no VALIDATED specs
    REJECTED_BY_VERIFICATION = ("REJECTED_BY_VERIFICATION", 3)  # expected: candidates failed the second opinion
    VERIFICATION_ERROR = ("VERIFICATION_ERROR", 4)   # unexpected: tooling failed -> fail closed
    SAFETY_BLOCKED = ("SAFETY_BLOCKED", 2)


class VerificationError(RuntimeError):
    """Freqtrade second opinion could not be *run* (as opposed to running and disagreeing)."""


def cmd_promote(args):
    """Promote VALIDATED specs to PAPER after the Freqtrade second opinion. Never replaces the
    active paper strategy: a new candidate config is written alongside; `aicrypto activate`
    (human, --confirm) is the only way to switch."""
    from .experiments import Tracker
    from .freqtrade_bridge import write_config, write_strategy
    from .strategies import StrategySpec
    s = _settings(args)
    tracker = Tracker(s.path("experiments"))
    out_path = s.path("experiments") / "last_promote.json"

    def finish(status, detail: dict):
        name, code = status
        payload = {"status": name, "exit_code": code, "time": time.time(), **detail}
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2, default=str))
        print(f"status: {name}")
        return code

    if cmd_safety_check(args) != 0:
        return finish(PromoteStatus.SAFETY_BLOCKED, {"reason": "safety-check failed"})

    validated = tracker.by_status("VALIDATED")
    if args.spec_hash:
        validated = [v for v in validated if v["spec_hash"] in args.spec_hash]
    if not validated:
        print("nothing to promote (no VALIDATED specs). Run `aicrypto research` first.")
        return finish(PromoteStatus.NOTHING_TO_PROMOTE, {"candidates": 0})
    validated = sorted(validated, key=lambda v: -tracker.load_run(v["run_id"])["oos_metrics"].get("sharpe", 0))[: args.max]

    exported: List[StrategySpec] = []
    rejected: List[dict] = []
    for v in validated:
        spec = StrategySpec.from_dict(json.loads(v["spec_json"]))
        p = write_strategy(spec, s)
        if not args.skip_ft_verify:
            try:
                ok, why, report = _ft_second_opinion(s, spec, v["run_id"], tracker, offline=args.offline)
            except VerificationError as exc:
                p.unlink(missing_ok=True)
                print(f"ERROR  {spec.class_name}: {exc}")
                return finish(PromoteStatus.VERIFICATION_ERROR, {"spec": spec.class_name, "error": str(exc)[-500:]})
            if not ok:
                print(f"REJECT {spec.class_name}: Freqtrade second opinion disagreed ({why}); stays VALIDATED")
                p.unlink(missing_ok=True)
                rejected.append({"spec": spec.class_name, "why": why, "report": report})
                continue
        tracker.set_status(spec, "PAPER", v["run_id"], "promoted to paper trading (freqtrade agreement checked)")
        exported.append(spec)
        print(f"PAPER  {spec.class_name}  -> {p}")

    if not exported:
        return finish(PromoteStatus.REJECTED_BY_VERIFICATION, {"rejected": rejected})

    activation_note = ""
    if args.dry_run_config:
        best = exported[0]
        active = s.path("user_data") / "config_dryrun.json"
        if active.exists():
            cand = write_config(s, best.class_name, best.timeframe, path=s.path("user_data") / "config_dryrun.candidate.json")
            activation_note = (f"active paper strategy left unchanged ({_active_strategy(s)}). Candidate config written to {cand}. "
                               f"To switch: aicrypto activate {best.class_name} --confirm")
        else:
            cp = write_config(s, best.class_name, best.timeframe)
            _record_activation(tracker, best.class_name, "initial activation via promote (no active strategy existed)")
            activation_note = f"wrote {cp} (strategy={best.class_name}, dry_run=true). Start with scripts/start_dryrun.sh"
        print(activation_note)
    print("Promotion means 'not rejected by the gates on past data'. It is not a profitability claim.")
    return finish(PromoteStatus.PROMOTED, {"promoted": [e.class_name for e in exported], "rejected": rejected, "note": activation_note})


def _active_strategy(s: Settings) -> str:
    p = s.path("user_data") / "config_dryrun.json"
    try:
        return json.loads(p.read_text()).get("strategy", "?")
    except Exception:
        return "none"


def _record_activation(tracker, class_name: str, reason: str, previous: str = "none") -> None:
    with tracker._conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS activations (ts REAL, strategy TEXT, previous TEXT, reason TEXT)")
        c.execute("INSERT INTO activations VALUES (?,?,?,?)", (time.time(), class_name, previous, reason))


def cmd_activate(args):
    """Human-only switch of the active paper strategy. Requires --confirm and a PAPER-status
    strategy file on disk. Refuses silently-automated use (no --confirm => exit 2)."""
    from .experiments import Tracker
    from .freqtrade_bridge import write_config
    from .strategies import StrategySpec
    s = _settings(args)
    if not args.confirm:
        print("refusing: activation requires an explicit --confirm (this switches the running paper strategy)")
        return 2
    tracker = Tracker(s.path("experiments"))
    match = None
    for v in tracker.by_status("PAPER"):
        spec = StrategySpec.from_dict(json.loads(v["spec_json"]))
        if spec.class_name == args.strategy:
            match = spec
    if match is None:
        print(f"refusing: {args.strategy} is not a PAPER-status strategy in the tracker")
        return 3
    if not (s.path("user_data") / "strategies" / f"{match.class_name}.py").exists():
        print("refusing: strategy file missing; run promote again")
        return 3
    previous = _active_strategy(s)
    cp = write_config(s, match.class_name, match.timeframe)
    (s.path("user_data") / "config_dryrun.candidate.json").unlink(missing_ok=True)
    _record_activation(tracker, match.class_name, f"manual activation ({args.reason or 'no reason given'})", previous)
    if cmd_safety_check(args) != 0:
        return 2
    print(f"ACTIVE {match.class_name} (previous: {previous}) -> {cp}. Restart the bot: docker compose restart freqtrade")
    return 0


def _ft_second_opinion(s: Settings, spec, run_id: str, tracker, offline: bool = False):
    """Promotion gate: Freqtrade's own backtester must agree with ours on trade count, entry/exit
    timing, position size, net P/L, fees and drawdown within documented tolerances, and its
    lookahead-analysis must report no bias. Returns (ok, reason, report_dict).
    Raises VerificationError when the check could not be executed (fail closed upstream)."""
    from .freqtrade_bridge import freqtrade_backtest, freqtrade_lookahead, write_config
    from .freqtrade_bridge.compare import compare
    from .freqtrade_bridge.runner import FreqtradeUnavailable, _read_backtest_zip
    from .research import backtest
    from .data.ohlcv import timeframe_to_minutes
    cfg_path = s.path("user_data") / "config_verify.json"
    try:
        data = _load_data(s, spec.timeframe)
        ours = backtest(data, spec, s.capital, s.costs)
        write_config(s, spec.class_name, spec.timeframe, path=cfg_path)
        rel = str(cfg_path.relative_to(s.root))
        first = min(df["date"].iloc[0] for df in data.values()); last = max(df["date"].iloc[-1] for df in data.values())
        tr = f"{first.strftime('%Y%m%d')}-{last.strftime('%Y%m%d')}"
        pairs = s.markets.pairs if offline else None
        bt = freqtrade_backtest(s.root, rel, spec.class_name, timerange=tr, fee=s.costs.fee_pct, offline_pairs=pairs)
        stats = _read_backtest_zip(Path(bt.raw_path))["strategy"][spec.class_name]
        la = freqtrade_lookahead(s.root, rel, spec.class_name, timerange=tr, offline_pairs=pairs)
    except FreqtradeUnavailable as exc:
        raise VerificationError(f"freqtrade unavailable: {exc}")
    except Exception as exc:
        raise VerificationError(f"verification could not run: {str(exc)[-300:]}")
    finally:
        cfg_path.unlink(missing_ok=True)
    if la.has_bias is None:
        raise VerificationError("lookahead-analysis produced no verdict")
    rep = compare(ours, stats, s.gates, timeframe_to_minutes(spec.timeframe), s.capital.starting_balance)
    ok_bias = la.has_bias is False
    report = {**rep.to_dict(), "lookahead_has_bias": la.has_bias}
    try:
        d = tracker.load_run(run_id)
        d.setdefault("gates", {}).setdefault("gates", []).append(
            {"name": "freqtrade_agreement", "passed": rep.passed and ok_bias, "value": rep.theirs.get("trades", 0),
             "threshold": s.gates.freqtrade_trade_count_tolerance, "note": f"failed={rep.failed} has_bias={la.has_bias}"})
        d["freqtrade_comparison"] = report
        (tracker.runs_dir / run_id / "run.json").write_text(json.dumps(d, indent=2, default=str))
    except Exception:
        pass
    if not rep.passed:
        return False, f"disagreement on {rep.failed}", report
    if not ok_bias:
        return False, "lookahead-analysis has_bias=True", report
    return True, "ok", report


def cmd_verify_ft(args):
    from .freqtrade_bridge import freqtrade_backtest, freqtrade_lookahead
    from .freqtrade_bridge.runner import freqtrade_recursive
    s = _settings(args)
    offline = s.markets.pairs if args.offline else None
    cfg = args.config_rel
    bt = freqtrade_backtest(s.root, cfg, args.strategy, timerange=args.timerange, fee=s.costs.fee_pct, offline_pairs=offline)
    print("backtest :", bt)
    la = freqtrade_lookahead(s.root, cfg, args.strategy, timerange=args.timerange, offline_pairs=offline)
    print("lookahead: has_bias =", la.has_bias, "| biased entries", la.biased_entry_signals, "exits", la.biased_exit_signals)
    rc = freqtrade_recursive(s.root, cfg, args.strategy, timerange=args.timerange, offline_pairs=offline)
    print("recursive: rc =", rc["returncode"])
    print(rc["output"][-1500:])
    return 0 if (la.has_bias is False and rc["returncode"] == "0") else 2


def cmd_kalshi(args):
    """Kalshi engine tooling. Phase 2: offline evaluate/summary/reevaluate. Phase 3: auth-check,
    limits, discover, stream — demo environment by default, read-only, no order paths exist."""
    from .kalshi.eligibility import evaluate
    from .kalshi.models import MarketInfo, SeriesInfo
    from .kalshi.registry import MarketRegistry
    from .kalshi.settings import load_kalshi_settings
    s = _settings(args)
    ks = load_kalshi_settings(args.kalshi_config, root=s.root)
    if args.kcmd == "evaluate":
        series = SeriesInfo.from_api(json.loads(Path(args.series).read_text()))
        for mp in args.market:
            m = MarketInfo.from_api(json.loads(Path(mp).read_text()))
            print(json.dumps(evaluate(series, m, ks).to_dict(), indent=2, default=str))
        return 0
    if args.kcmd == "summary":
        reg = MarketRegistry(ks); reg.reevaluate_all()
        print(json.dumps(reg.summary(), indent=2)); return 0
    if args.kcmd == "reevaluate":
        reg = MarketRegistry(ks)
        print(json.dumps(reg.reevaluate_all(), indent=2)); return 0

    # ---- Phase 3: network (demo by default). Safety check first, always. ----
    if cmd_safety_check(args) != 0:
        return 2
    from .kalshi.auth import Credentials, CredentialError, KalshiSigner
    from .kalshi.client import KalshiRestClient
    from .kalshi.transport import run_sync
    env = ks.environment
    if env != "demo" and not args.allow_production:
        print("refusing: config environment is not 'demo' and --allow-production (read-only market data) was not given")
        return 2

    def signer_or_none(required: bool):
        try:
            creds = Credentials.from_env(env, repo_root=s.root)
            return KalshiSigner.from_credentials(creds)
        except CredentialError as exc:
            if required:
                print(f"credentials unavailable: {exc}\nSee docs/KALSHI_DEMO_KEY.md"); return None
            return None

    if args.kcmd == "auth-check":
        sg = signer_or_none(True)
        if sg is None:
            return 2
        h = sg.headers("GET", "/trade-api/ws/v2", timestamp_ms=1)
        ok = sg.verify("1GET/trade-api/ws/v2", h["KALSHI-ACCESS-SIGNATURE"])
        print(f"key type: {sg.key_type} · self-verify: {'ok' if ok else 'FAILED'} · env: {env} · (key id and signature not shown)")
        return 0 if ok else 2

    if args.kcmd == "limits":
        sg = signer_or_none(True)
        if sg is None:
            return 2
        async def go():
            async with KalshiRestClient(env, signer=sg, public=False, requests_per_second=2) as c:
                return await c.account_limits()
        print(json.dumps(run_sync(go()), indent=2)); return 0

    if args.kcmd == "discover":
        from .kalshi.discovery import discover
        reg = MarketRegistry(ks)
        t0 = time.time()
        def progress(msg):
            print(f"[{time.time() - t0:6.1f}s] {msg}", flush=True)
        async def go():
            async with KalshiRestClient(env, signer=None, public=True, requests_per_second=args.rps) as c:
                return await discover(c, reg, statuses=tuple(args.status), max_series=args.max_series, progress=progress)
        progress(f"connecting to Kalshi {env} (public market data, read-only)")
        rep = run_sync(go())
        out = s.path("experiments") / "kalshi_discovery_last.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(rep.to_dict(), indent=2, default=str))
        print(json.dumps({k: v for k, v in rep.to_dict().items() if k != "durations"}, indent=2, default=str))
        print(f"durations by asset: {json.dumps(rep.durations)}")
        print(f"report -> {out}")
        return 0 if rep.markets_upserted > 0 else 3

    if args.kcmd == "stream":
        from .kalshi.stream import StreamSession
        from .kalshi.websocket import KalshiWebSocket
        sg = signer_or_none(True)
        if sg is None:
            return 2
        t0 = time.time()
        print("loading market registry…", flush=True)
        reg = MarketRegistry(ks)
        if not reg.markets:
            print("registry empty; run `aicrypto kalshi discover` first"); return 3
        print(f"  {len(reg.markets):,} markets loaded in {time.time() - t0:.0f}s; checking eligibility…", flush=True)
        counts = reg.reevaluate_all()
        print(f"  eligibility {counts} ({time.time() - t0:.0f}s); connecting to {env} WebSocket for {args.seconds:.0f}s…", flush=True)
        rest = KalshiRestClient(env, signer=None, public=True, requests_per_second=2)
        ws = KalshiWebSocket(sg, env)
        sess = StreamSession(ks, reg, ws, rest=rest, record_dir=s.root / ks.recorder.dir)
        async def go():
            try:
                await sess.run(seconds=args.seconds, progress=lambda m: print("  " + m, flush=True))
            finally:
                await rest.aclose()
        run_sync(go())
        summ = sess.summary()
        out = s.path("experiments") / "kalshi_stream_last.json"
        out.write_text(json.dumps(summ, indent=2, default=str))
        print(json.dumps({k: summ[k] for k in ("stream", "ws", "ws_errors", "live_book_subscriptions", "book_budget", "books_valid", "seq_gaps")}, indent=2, default=str))
        print(f"books: {len(summ['books'])} (valid {summ['books_valid']}) · registry markets {summ['registry']['markets']} · report -> {out}")
        return 0
    return 2


def cmd_report(args):
    from .experiments import Tracker
    from .reporting import write_daily_report
    s = _settings(args)
    p = write_daily_report(s, Tracker(s.path("experiments")), args.day)
    print(f"wrote {p}")
    if args.print:
        print(p.read_text())
    return 0


def cmd_dashboard(args):
    import uvicorn
    from .dashboard import create_app
    s = _settings(args)
    app = create_app(s)
    print(f"dashboard on http://{args.host}:{args.port}  (read-only, paper only)")
    uvicorn.run(app, host=args.host, port=args.port, log_level="warning")
    return 0


def cmd_ui(args):
    """Desktop terminal backend (127.0.0.1 only). Read-only market data; no order capability."""
    import os
    import socket
    import uvicorn
    from .dashboard import create_app
    from .kalshi.settings import load_kalshi_settings
    from .terminal.app import create_terminal_app
    from .terminal.service import TerminalService
    if args.host not in ("127.0.0.1", "localhost"):
        print("refusing: the terminal binds to 127.0.0.1 only"); return 2
    if cmd_safety_check(args) != 0:
        return 2
    s = _settings(args)
    ks = load_kalshi_settings(getattr(args, "kalshi_config", None), root=s.root)
    if ks.environment != "demo":
        print("refusing: the terminal runs against the Kalshi demo environment only"); return 2
    # single instance: refuse if the port is already taken (the launcher checks /api/health first)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        if probe.connect_ex(("127.0.0.1", args.port)) == 0:
            print(f"port {args.port} is already in use (another AI Crypto Lab backend or another program)"); return 3
    run_dir = s.root / "run"
    run_dir.mkdir(exist_ok=True)
    pid_file = run_dir / "ui.pid"
    pid_file.write_text(str(os.getpid()))

    def signer_factory():
        from .kalshi.auth import Credentials, CredentialError, KalshiSigner
        try:
            return KalshiSigner.from_credentials(Credentials.from_env(ks.environment, repo_root=s.root))
        except CredentialError:
            return None

    def demo_exchange_factory():
        from .kalshi.auth import Credentials, CredentialError
        from .kalshi.demo_exec.exchange import DemoExchange
        try:
            creds = Credentials.from_env("demo", repo_root=s.root)     # refuses KALSHI_ENV=production
        except CredentialError:
            return None
        return DemoExchange.from_credentials(creds)

    from .kalshi.real_exec.trader import real_exchange_factory
    service = TerminalService(ks, env=ks.environment, live=not args.no_live, signer_factory=signer_factory,
                              demo_exchange_factory=demo_exchange_factory, real_exchange_factory=real_exchange_factory(s.root))
    app = create_terminal_app(service, settings=s, legacy_app=create_app(s), pid_info={"port": args.port})
    print(f"AI Crypto Lab terminal on http://127.0.0.1:{args.port}  (demo environment · read-only market data · no orders)", flush=True)
    try:
        uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")
    finally:
        try:
            if pid_file.read_text().strip() == str(os.getpid()):
                pid_file.unlink()
        except OSError:
            pass
    return 0


def cmd_demo(args):
    """Strategy approval for demo automation (human-only) and status."""
    from .kalshi.demo_exec.automation import STRATEGIES, approve, revoke, strategy_status
    from .kalshi.demo_exec.ledger import DemoLedger
    from .kalshi.settings import load_kalshi_settings
    s = _settings(args)
    ks = load_kalshi_settings(None, root=s.root)
    L = DemoLedger(ks.path("registry_db").parent / "demo_ledger.sqlite")
    if args.dcmd == "strategies":
        for n, c in STRATEGIES.items():
            st = strategy_status(L, s.root, n, c.version)
            print(f"{n} {c.version}: {st['status']} - {st['why']}")
        return 0
    if args.dcmd == "approve":
        if not args.i_approve:
            print("refusing: add --i-approve to confirm you (a human) approve this strategy for demo automation"); return 2
        if not sys.stdin.isatty():
            print("refusing: approval must be typed by a person in an interactive terminal"); return 2
        try:
            st = approve(L, s.root, args.name, args.version, who="owner-cli")
        except ValueError as e:
            print(str(e)); return 3
        print(f"approved: {st['name']} {st['version']} ({st['code_hash']})"); return 0
    if args.dcmd == "revoke":
        revoke(L, args.name, args.version); print("revoked"); return 0
    return 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aicrypto", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", default=None, help="path to research.yaml")
    p.add_argument("--root", default=None, help="project root (default: package parent)")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("audit").set_defaults(fn=cmd_audit)
    sub.add_parser("safety-check").set_defaults(fn=cmd_safety_check)
    q = sub.add_parser("init-config"); q.add_argument("--strategy", default=None); q.add_argument("--timeframe", default="1h"); q.set_defaults(fn=cmd_init_config)
    sub.add_parser("data-check").set_defaults(fn=cmd_data_check)
    q = sub.add_parser("synth-data"); q.add_argument("--bars", type=int, default=8000); q.add_argument("--timeframes", nargs="*"); q.set_defaults(fn=cmd_synth_data)
    q = sub.add_parser("backtest"); q.add_argument("spec"); q.set_defaults(fn=cmd_backtest)
    q = sub.add_parser("research")
    q.add_argument("--timeframe", default="1h"); q.add_argument("--seed", type=int, default=0)
    q.add_argument("--max-candidates", type=int, default=None); q.add_argument("--max-minutes", type=float, default=None)
    q.add_argument("--family", action="append"); q.add_argument("--spec", action="append", help="explicit spec JSON file(s) to evaluate first")
    q.set_defaults(fn=cmd_research)
    q = sub.add_parser("promote"); q.add_argument("--spec-hash", action="append"); q.add_argument("--max", type=int, default=1)
    q.add_argument("--dry-run-config", action="store_true", help="also write user_data/config_dryrun.json for the best spec")
    q.add_argument("--offline", action="store_true", help="stub exchange markets for the Freqtrade check (no network)")
    q.add_argument("--skip-ft-verify", action="store_true", help="UNSAFE for promotion: skip the Freqtrade second-opinion gate")
    q.set_defaults(fn=cmd_promote)
    q = sub.add_parser("activate", help="HUMAN ONLY: switch the active paper strategy"); q.add_argument("strategy"); q.add_argument("--confirm", action="store_true"); q.add_argument("--reason", default=""); q.set_defaults(fn=cmd_activate)
    q = sub.add_parser("verify-ft"); q.add_argument("strategy"); q.add_argument("--config-rel", default="user_data/config_dryrun.json")
    q.add_argument("--timerange", default=None); q.add_argument("--offline", action="store_true", help="stub exchange markets (no network)"); q.set_defaults(fn=cmd_verify_ft)
    q = sub.add_parser("kalshi", help="Kalshi engine (paper only)")
    q.add_argument("--kalshi-config", default=None)
    kq = q.add_subparsers(dest="kcmd", required=True)
    e = kq.add_parser("evaluate", help="offline eligibility decision for series+market JSON files"); e.add_argument("--series", required=True); e.add_argument("--market", action="append", required=True)
    kq.add_parser("summary", help="registry summary: universe, tiers, durations, rejection reasons")
    kq.add_parser("reevaluate", help="re-run eligibility for all known markets under current config")
    q.add_argument("--allow-production", action="store_true", help="permit read-only market data against production hosts (never orders)")
    kq.add_parser("auth-check", help="load key from env, sign + self-verify; prints key type only")
    kq.add_parser("limits", help="GET /account/limits (authenticated, read-only)")
    d = kq.add_parser("discover", help="public REST discovery -> registry (no auth)"); d.add_argument("--status", nargs="*", default=["open", "unopened"]); d.add_argument("--max-series", type=int, default=None); d.add_argument("--rps", type=float, default=4.0)
    st = kq.add_parser("stream", help="authenticated read-only WebSocket session"); st.add_argument("--seconds", type=float, default=60)
    q.set_defaults(fn=cmd_kalshi)
    q = sub.add_parser("report"); q.add_argument("--day", default=None); q.add_argument("--print", action="store_true"); q.set_defaults(fn=cmd_report)
    dm = sub.add_parser("demo", help="demo automation: list strategies, human approval")
    dsub = dm.add_subparsers(dest="dcmd", required=True)
    dsub.add_parser("strategies")
    ap = dsub.add_parser("approve"); ap.add_argument("name"); ap.add_argument("version"); ap.add_argument("--i-approve", action="store_true")
    rv = dsub.add_parser("revoke"); rv.add_argument("name"); rv.add_argument("version")
    dm.set_defaults(fn=cmd_demo)
    u = sub.add_parser("ui", help="desktop terminal backend (used by the Windows launcher)")
    u.add_argument("--host", default="127.0.0.1"); u.add_argument("--port", type=int, default=8765)
    u.add_argument("--no-live", action="store_true", help="do not connect the read-only live market-data stream")
    u.add_argument("--kalshi-config", dest="kalshi_config", default=None)
    u.set_defaults(fn=cmd_ui)
    q = sub.add_parser("dashboard"); q.add_argument("--host", default="127.0.0.1"); q.add_argument("--port", type=int, default=8080); q.set_defaults(fn=cmd_dashboard)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.fn(args) or 0)


if __name__ == "__main__":
    sys.exit(main())
