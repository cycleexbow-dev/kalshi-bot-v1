"""Bounded autonomous research loop.

    sample/mutate spec -> quick backtest triage -> walk-forward -> leakage probes
    -> neighbour stability -> gates -> tracker (+ lifecycle VALIDATED/CANDIDATE)

Budgets: max candidates, max wall-clock minutes, soft address-space limit.
Everything is seeded; the same session seed on the same data yields the same
sequence of candidates and results.

Candidate sources, in priority order:
  1. explicit specs passed in (e.g. JSON files proposed by Claude Code),
  2. mutations of previously VALIDATED / best-scoring specs (exploitation),
  3. random specs per family (exploration).
"""
from __future__ import annotations

import json
import random
import resource
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from ..data import DatasetInfo, fingerprint, load_ohlcv
from ..experiments import Tracker, RunRecord, code_version
from ..experiments.tracker import make_run_id
from ..promotion import evaluate_gates
from ..promotion.gates import neighbour_retention
from ..research import backtest, compute_metrics
from ..research.leakage import lookahead_probe, recursive_probe
from ..research.walkforward import walk_forward
from ..settings import Settings
from ..strategies import FAMILIES, StrategySpec, mutate_spec, neighbours, random_spec


@dataclass
class CandidateReport:
    run_id: str
    spec: StrategySpec
    passed: bool
    gates: dict
    oos_metrics: Dict[str, float]
    is_metrics: Dict[str, float]
    n_folds: int
    positive_fold_fraction: float
    oos_is_ratio: float
    lookahead_ok: bool
    recursive_ok: bool
    neighbour_retention: Optional[float]
    seconds: float
    skipped_reason: str = ""


def set_soft_memory_limit(gb: float) -> None:
    """Fail fast instead of swapping the desktop. No-op where unsupported."""
    try:
        limit = int(gb * 1024 ** 3)
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        if hard != resource.RLIM_INFINITY and limit > hard:
            limit = hard
        resource.setrlimit(resource.RLIMIT_AS, (limit, hard))
    except (ValueError, OSError):
        pass


def load_market_data(settings: Settings, timeframe: str, pairs: Optional[List[str]] = None,
                     data_dir: Optional[Path] = None) -> Dict[str, pd.DataFrame]:
    data_dir = data_dir or settings.path("user_data") / "data" / settings.markets.exchange
    minutes = {"m": 1, "h": 60, "d": 1440}[timeframe[-1]] * int(timeframe[:-1])
    max_rows = int(settings.markets.history_days * 1440 / minutes)
    return {p: load_ohlcv(data_dir, p, timeframe, max_rows=max_rows) for p in (pairs or settings.markets.pairs)}


def evaluate_candidate(
    spec: StrategySpec,
    data: Dict[str, pd.DataFrame],
    settings: Settings,
    tracker: Tracker,
    datasets: Optional[List[DatasetInfo]] = None,
    code: Optional[str] = None,
    check_neighbours: bool = True,
    triage: bool = True,
) -> CandidateReport:
    """Full evaluation of one spec. Idempotent: an existing run_id is returned from the tracker."""
    t0 = time.time()
    datasets = datasets or [fingerprint(df, p, spec.timeframe) for p, df in data.items()]
    code = code or code_version(settings.root)
    cfg_blob = {
        "capital": settings.capital.model_dump(), "costs": settings.costs.model_dump(),
        "walk_forward": settings.walk_forward.model_dump(), "gates": settings.gates.model_dump(),
    }
    run_id = make_run_id(spec, datasets, cfg_blob, code)
    if tracker.has_run(run_id):
        r = tracker.load_run(run_id)
        return CandidateReport(run_id, spec, bool(r["gates_passed"]), r.get("gates", {}), r.get("oos_metrics", {}),
                               r.get("is_metrics", {}), r["n_folds"], r["positive_fold_fraction"],
                               r.get("oos_is_ratio", 0.0), bool(r["lookahead_ok"]), bool(r["recursive_ok"]),
                               r.get("neighbour_retention"), 0.0, "cached")

    cap, costs, wf_cfg, gates = settings.capital, settings.costs, settings.walk_forward, settings.gates

    # --- cheap triage: whole-sample backtest must at least trade ----------------
    if triage:
        quick = compute_metrics(backtest(data, spec, cap, costs))
        if quick["trades"] < max(10, gates.min_trades // 4):
            rep = CandidateReport(run_id, spec, False, {"passed": False, "gates": [
                {"name": "triage_min_trades", "passed": False, "value": quick["trades"], "threshold": gates.min_trades // 4}]},
                quick, {}, 0, 0.0, 0.0, True, True, None, time.time() - t0, "triage: too few trades")
            _record(tracker, rep, datasets, code, wf_equity=None)
            return rep

    # --- walk-forward --------------------------------------------------------
    wf = walk_forward(data, spec, cap, costs, wf_cfg)

    # --- leakage probes on the pair with most data ---------------------------
    probe_pair = max(data, key=lambda p: len(data[p]))
    look = lookahead_probe(data[probe_pair], spec)
    rec = recursive_probe(data[probe_pair], spec)

    # --- neighbour stability (OOS, no re-optimisation; bounded to 8 neighbours) ---
    retention = None
    if check_neighbours and wf.oos_metrics["total_return"] > 0:
        rng = random.Random(wf_cfg.seed)
        nbs = neighbours(spec)
        rng.shuffle(nbs)
        rets = []
        for nb in nbs[:8]:
            try:
                r = walk_forward(data, nb, cap, costs, wf_cfg, optimise=False)
                rets.append(r.oos_metrics["total_return"])
            except ValueError:
                rets.append(-1.0)
        retention = neighbour_retention(wf.oos_metrics["total_return"], rets)

    outcome = evaluate_gates(wf, look, rec, gates, neighbour_retention=retention)
    rep = CandidateReport(run_id, spec, outcome.passed, outcome.to_dict(), wf.oos_metrics, wf.is_metrics_mean,
                          wf.n_folds, wf.positive_fold_fraction, wf.oos_is_ratio, look.ok, rec.ok, retention,
                          time.time() - t0)
    _record(tracker, rep, datasets, code, wf_equity=wf.oos_equity,
            folds=[{"index": f.index, "chosen": f.chosen.to_dict(), "is": f.is_metrics, "oos": f.oos_metrics}
                   for f in wf.folds],
            lookahead=look.__dict__, recursive=rec.__dict__)
    return rep


def _record(tracker: Tracker, rep: CandidateReport, datasets: List[DatasetInfo], code: str,
            wf_equity: Optional[pd.Series], **extra) -> None:
    spec = rep.spec
    status = "VALIDATED" if rep.passed else "CANDIDATE"
    prev = tracker.status_of(spec.spec_hash)
    if prev in ("PAPER", "RETIRED"):
        status = prev  # don't demote a paper strategy from a re-run; promotion is explicit
    rec = RunRecord(
        rep.run_id, time.time(), spec.spec_hash, spec.family, spec.timeframe,
        ",".join(d.pair for d in datasets), code, 0, status, rep.passed,
        rep.is_metrics.get("sharpe", 0.0), rep.oos_metrics.get("sharpe", 0.0),
        rep.oos_metrics.get("total_return", 0.0), rep.oos_metrics.get("max_drawdown", 0.0),
        int(rep.oos_metrics.get("trades", 0)), rep.n_folds, rep.positive_fold_fraction,
        rep.lookahead_ok, rep.recursive_ok, spec.to_json(), rep.skipped_reason,
    )
    artefacts = {
        "spec": spec.to_dict(), "datasets": [asdict(d) for d in datasets], "gates": rep.gates,
        "oos_metrics": rep.oos_metrics, "is_metrics": rep.is_metrics, "oos_is_ratio": rep.oos_is_ratio,
        "neighbour_retention": rep.neighbour_retention, "seconds": rep.seconds,
        "disclaimer": "Simulated past performance under modelled costs. Not a forecast. Not a claim of profitability.",
        **extra,
    }
    tracker.record(rec, artefacts, equity=wf_equity)
    tracker.set_status(spec, status, rep.run_id, "gates passed" if rep.passed else "gates failed")


class ResearchSession:
    def __init__(self, settings: Settings, tracker: Tracker, data: Dict[str, pd.DataFrame], timeframe: str,
                 seed: int = 0, max_candidates: Optional[int] = None, max_minutes: Optional[float] = None,
                 families: Optional[List[str]] = None, explicit_specs: Optional[List[StrategySpec]] = None,
                 log: Optional[Path] = None):
        self.s = settings
        self.tracker = tracker
        self.data = data
        self.timeframe = timeframe
        self.rng = random.Random(seed)
        self.seed = seed
        self.max_candidates = max_candidates or settings.budget.max_candidates
        self.max_minutes = max_minutes if max_minutes is not None else settings.budget.max_minutes
        self.families = families or sorted(FAMILIES)
        self.queue: List[StrategySpec] = list(explicit_specs or [])
        self.reports: List[CandidateReport] = []
        self.session_id = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        self.log = log
        self.datasets = [fingerprint(df, p, timeframe) for p, df in data.items()]
        self.code = code_version(settings.root)

    def _log(self, msg: str) -> None:
        line = f"[{time.strftime('%H:%M:%S')}] {msg}"
        print(line, flush=True)
        if self.log:
            with open(self.log, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")

    def _next_spec(self) -> StrategySpec:
        if self.queue:
            return self.queue.pop(0)
        # exploit: mutate a validated or top-scoring spec 40% of the time
        pool = [r.spec for r in self.reports if r.passed] or sorted(
            (r for r in self.reports if r.oos_metrics), key=lambda r: -r.oos_metrics.get("sharpe", -9))[:3]
        pool = [p if isinstance(p, StrategySpec) else p.spec for p in pool]
        if pool and self.rng.random() < 0.4:
            return mutate_spec(self.rng.choice(pool), self.rng, n_changes=self.rng.choice([1, 2]))
        return random_spec(self.rng, self.rng.choice(self.families), timeframe=self.timeframe)

    def run(self) -> List[CandidateReport]:
        set_soft_memory_limit(self.s.budget.soft_memory_gb)
        budget = {"max_candidates": self.max_candidates, "max_minutes": self.max_minutes, "seed": self.seed,
                  "timeframe": self.timeframe, "pairs": sorted(self.data)}
        self.tracker.start_session(self.session_id, budget)
        self._log(f"session {self.session_id} start: {budget}")
        t0 = time.time()
        seen = set()
        while len(self.reports) < self.max_candidates:
            if (time.time() - t0) / 60.0 >= self.max_minutes:
                self._log("time budget exhausted")
                break
            spec = self._next_spec()
            if spec.spec_hash in seen:
                continue
            seen.add(spec.spec_hash)
            try:
                rep = evaluate_candidate(spec, self.data, self.s, self.tracker, self.datasets, self.code)
            except MemoryError:
                self._log("memory limit hit; stopping session")
                break
            except ValueError as exc:
                self._log(f"skip {spec.name}: {exc}")
                continue
            self.reports.append(rep)
            m = rep.oos_metrics
            self._log(
                f"{len(self.reports):>3}/{self.max_candidates} {spec.name} "
                f"{'PASS' if rep.passed else 'fail'} oos_sharpe={m.get('sharpe', 0):+.2f} "
                f"ret={m.get('total_return', 0):+.1%} dd={m.get('max_drawdown', 0):.1%} "
                f"trades={m.get('trades', 0)} folds={rep.n_folds} {rep.skipped_reason} ({rep.seconds:.1f}s)"
            )
        passed = sum(r.passed for r in self.reports)
        self.tracker.finish_session(self.session_id, len(self.reports), passed)
        self._log(f"session done: {len(self.reports)} candidates, {passed} passed gates (not a profitability claim)")
        return self.reports


def load_spec_files(paths: List[Path]) -> List[StrategySpec]:
    specs = []
    for p in paths:
        d = json.loads(Path(p).read_text())
        specs.append(StrategySpec.from_dict(d))
    return specs
