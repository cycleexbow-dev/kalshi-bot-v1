"""aicrypto-lab: bounded crypto strategy research and paper trading.

This package never places real orders. See aicrypto.safety.
"""

__version__ = "0.1.0"
