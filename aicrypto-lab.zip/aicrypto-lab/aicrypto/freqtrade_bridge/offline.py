"""Run Freqtrade subcommands in-process with a stubbed exchange market list.

Only for tests and offline demos (no network). Freqtrade's backtesting,
lookahead-analysis and recursive-analysis never place orders, but they do load the
exchange's market list at start-up; this shim supplies a static spot market list
for the configured pairs so those commands work without network access.

Never used by `trade`. Never used when network is available.
"""
from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path
from typing import Dict, Iterable, List
from unittest import mock


def _market(pair: str) -> Dict:
    base, quote = pair.split("/")
    return {
        "id": f"{base}{quote}", "symbol": pair, "base": base, "quote": quote, "settle": None,
        "baseId": base, "quoteId": quote, "settleId": None, "type": "spot", "spot": True, "margin": False,
        "swap": False, "future": False, "option": False, "active": True, "contract": False,
        "linear": None, "inverse": None, "taker": 0.001, "maker": 0.001, "contractSize": None,
        "expiry": None, "expiryDatetime": None, "strike": None, "optionType": None,
        "precision": {"amount": 1e-5, "price": 0.01, "cost": None, "base": 1e-8, "quote": 1e-8},
        "limits": {"leverage": {"min": None, "max": None}, "amount": {"min": 1e-5, "max": 9e6},
                   "price": {"min": 0.01, "max": 1e6}, "cost": {"min": 5.0, "max": 9e6}},
        "info": {}, "created": None,
    }


@contextlib.contextmanager
def offline_exchange(pairs: Iterable[str]):
    from freqtrade.exchange import exchange as ex

    markets = {p: _market(p) for p in pairs}

    def _load_async_markets(self, reload: bool = False) -> None:  # noqa: ARG001
        self._api_async.set_markets(markets)

    with mock.patch.object(ex.Exchange, "_load_async_markets", _load_async_markets), \
         mock.patch.object(ex.Exchange, "fetch_trading_fees", lambda self: {}):
        yield


def run_offline(argv: List[str], pairs: Iterable[str], cwd: Path) -> str:
    """Run `freqtrade <argv>` in-process with the stubbed exchange; returns captured output."""
    from freqtrade.main import main as ft_main

    buf = io.StringIO()
    old_cwd = Path.cwd()
    try:
        import os
        os.chdir(cwd)
        with offline_exchange(pairs), contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            try:
                ft_main(argv)
            except SystemExit as exc:
                if exc.code not in (0, None):
                    raise RuntimeError(f"freqtrade exited {exc.code}:\n{buf.getvalue()[-3000:]}")
    finally:
        import os
        os.chdir(old_cwd)
    return buf.getvalue()
