"""Run Freqtrade commands (backtesting, lookahead-analysis, recursive-analysis) as a
second opinion on exported strategies.

Two execution modes, chosen automatically:
  * `local`  — a `freqtrade` executable is on PATH (dev machines, CI).
  * `docker` — `docker compose run --rm freqtrade ...` from the project root
               (the WSL desktop). The compose file mounts ./user_data.

Every invocation is read-only with respect to money: these subcommands never
place orders. `trade` is deliberately not exposed from this module; it is only
started via scripts/start_dryrun.sh which re-checks safety and passes --dry-run.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

FORBIDDEN_SUBCOMMANDS = {"trade", "create-userdir", "new-config"}


class FreqtradeUnavailable(RuntimeError):
    pass


@dataclass
class FtBacktestSummary:
    strategy: str
    trades: int
    profit_total_pct: float
    max_drawdown_pct: float
    wins: int
    losses: int
    raw_path: Optional[str] = None


def _mode(project_root: Path) -> str:
    if shutil.which("freqtrade"):
        return "local"
    if shutil.which("docker") and (project_root / "docker-compose.yml").exists():
        return "docker"
    raise FreqtradeUnavailable("neither a local `freqtrade` nor docker compose is available")


def _base_cmd(project_root: Path, subcommand: str) -> List[str]:
    if subcommand in FORBIDDEN_SUBCOMMANDS:
        raise PermissionError(f"subcommand {subcommand!r} is not permitted through the runner")
    mode = _mode(project_root)
    if mode == "local":
        return ["freqtrade", subcommand]
    return ["docker", "compose", "-f", str(project_root / "docker-compose.yml"), "run", "--rm", "--no-deps",
            "freqtrade", subcommand]


def run_freqtrade(project_root: Path, subcommand: str, args: List[str], timeout: int = 1800,
                  offline_pairs: Optional[List[str]] = None) -> subprocess.CompletedProcess:
    """Run a read-only Freqtrade subcommand. With `offline_pairs`, run in-process with a
    stubbed market list (tests / no-network environments only)."""
    if subcommand in FORBIDDEN_SUBCOMMANDS:
        raise PermissionError(f"subcommand {subcommand!r} is not permitted through the runner")
    if offline_pairs is not None:
        from .offline import run_offline
        try:
            out = run_offline([subcommand] + args, offline_pairs, project_root)
            return subprocess.CompletedProcess([subcommand] + args, 0, out, "")
        except RuntimeError as exc:
            return subprocess.CompletedProcess([subcommand] + args, 1, "", str(exc))
    cmd = _base_cmd(project_root, subcommand) + args
    return subprocess.run(cmd, cwd=project_root, capture_output=True, text=True, timeout=timeout)


def _read_backtest_zip(path: Path) -> dict:
    """Freqtrade >=2024 writes <name>.zip containing <name>.json with the stats."""
    if path.suffix == ".zip" or zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.endswith(".json") and "config" not in n and "_signals" not in n and "_exited" not in n and "_rejected" not in n]
            names.sort(key=len)
            return json.loads(z.read(names[0]))
    return json.loads(path.read_text())


def freqtrade_backtest(project_root: Path, config_rel: str, strategy: str, timerange: Optional[str] = None,
                       fee: Optional[float] = None, timeout: int = 1800,
                       offline_pairs: Optional[List[str]] = None) -> FtBacktestSummary:
    user_data = project_root / "user_data"
    out_dir = user_data / "backtest_results"
    out_dir.mkdir(parents=True, exist_ok=True)
    args = ["--config", config_rel, "--userdir", "user_data", "--strategy", strategy,
            "--export", "trades", "--cache", "none"]
    if timerange:
        args += ["--timerange", timerange]
    if fee is not None:
        args += ["--fee", str(fee)]
    proc = run_freqtrade(project_root, "backtesting", args, timeout, offline_pairs)
    if proc.returncode != 0:
        raise RuntimeError(f"freqtrade backtesting failed:\n{proc.stdout[-2000:]}\n{proc.stderr[-2000:]}")
    last = out_dir / ".last_result.json"
    if not last.exists():
        raise RuntimeError("no backtest export found (.last_result.json missing)")
    latest = out_dir / json.loads(last.read_text())["latest_backtest"]
    stats = _read_backtest_zip(latest)
    s = stats["strategy"][strategy]
    return FtBacktestSummary(
        strategy=strategy, trades=int(s["total_trades"]), profit_total_pct=float(s.get("profit_total", 0.0)) * 100,
        max_drawdown_pct=float(s.get("max_drawdown_account", s.get("max_drawdown", 0.0))) * 100,
        wins=int(s.get("wins", 0)), losses=int(s.get("losses", 0)), raw_path=str(latest),
    )


@dataclass
class FtLookaheadSummary:
    strategy: str
    has_bias: Optional[bool]
    biased_entry_signals: int
    biased_exit_signals: int
    raw_output: str


def freqtrade_lookahead(project_root: Path, config_rel: str, strategy: str, timerange: Optional[str] = None,
                        timeout: int = 1800, offline_pairs: Optional[List[str]] = None) -> FtLookaheadSummary:
    export = project_root / "user_data" / "backtest_results" / f"lookahead_{strategy}.csv"
    args = ["--config", config_rel, "--userdir", "user_data", "--strategy", strategy,
            "--lookahead-analysis-exportfilename", str(export.relative_to(project_root))]
    if timerange:
        args += ["--timerange", timerange]
    proc = run_freqtrade(project_root, "lookahead-analysis", args, timeout, offline_pairs)
    out = proc.stdout + proc.stderr
    has_bias: Optional[bool] = None
    entries = exits = 0
    if export.exists():
        import csv
        with open(export, newline="") as fh:
            rows = [r for r in csv.DictReader(fh) if r.get("strategy") == strategy]
        if rows:
            r = rows[-1]
            has_bias = str(r.get("has_bias", "")).strip().lower() == "true"
            entries = int(float(r.get("biased_entry_signals", 0) or 0))
            exits = int(float(r.get("biased_exit_signals", 0) or 0))
    if has_bias is None:
        m = re.search(r"has_bias\W+(True|False)", out)
        if m:
            has_bias = m.group(1) == "True"
    return FtLookaheadSummary(strategy, has_bias, entries, exits, out[-3000:])


def freqtrade_recursive(project_root: Path, config_rel: str, strategy: str, timerange: Optional[str] = None,
                        startup_candles: Optional[List[int]] = None, timeout: int = 1800,
                        offline_pairs: Optional[List[str]] = None) -> Dict[str, str]:
    args = ["--config", config_rel, "--userdir", "user_data", "--strategy", strategy]
    if timerange:
        args += ["--timerange", timerange]
    if startup_candles:
        args += ["--startup-candle"] + [str(c) for c in startup_candles]
    proc = run_freqtrade(project_root, "recursive-analysis", args, timeout, offline_pairs)
    return {"returncode": str(proc.returncode), "output": (proc.stdout + proc.stderr)[-4000:]}
