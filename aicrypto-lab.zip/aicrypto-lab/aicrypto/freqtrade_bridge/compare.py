"""Engine-agreement comparison: our research backtester vs Freqtrade's backtester on the
same data, strategy and fee. Trade count alone is a weak check; this compares P/L, fees,
drawdown, entry/exit timing and position sizes against documented tolerances.

Why differences are expected (and bounded):
  * Our engine applies slippage to the fill price; Freqtrade (dry backtest) does not.
  * Freqtrade can stop out on the entry candle; ours checks stops from the next bar.
  * Freqtrade sizes from `get_total_stake_amount()` (wallet incl. open positions'
    stake); ours sizes from mark-to-market equity at the previous close.
  * Trailing-stop intrabar assumptions differ.
Tolerances (config/research.yaml `gates.ft_*`) are set to catch *disagreement about
what the strategy does* (signals, direction, sizing logic), not these known model
differences.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from ..research.backtest import BacktestResult
from ..settings import Gates


@dataclass
class Check:
    name: str
    passed: bool
    value: float
    tolerance: float
    note: str = ""


@dataclass
class ComparisonReport:
    checks: List[Check] = field(default_factory=list)
    ours: Dict[str, float] = field(default_factory=dict)
    theirs: Dict[str, float] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return all(c.passed for c in self.checks)

    @property
    def failed(self) -> List[str]:
        return [c.name for c in self.checks if not c.passed]

    def to_dict(self) -> dict:
        return {"passed": self.passed, "checks": [c.__dict__ for c in self.checks], "ours": self.ours, "theirs": self.theirs}


def _ft_trades_df(ft_strategy_stats: Dict[str, Any]) -> pd.DataFrame:
    rows = ft_strategy_stats.get("trades", [])
    if not rows:
        return pd.DataFrame(columns=["pair", "open", "close", "stake", "pnl", "fees", "exit_reason"])
    df = pd.DataFrame(rows)
    out = pd.DataFrame({
        "pair": df["pair"],
        "open": pd.to_datetime(df["open_timestamp"], unit="ms", utc=True),
        "close": pd.to_datetime(df["close_timestamp"], unit="ms", utc=True),
        "stake": df["stake_amount"].astype(float),
        "pnl": df["profit_abs"].astype(float),
        "exit_reason": df.get("exit_reason", ""),
    })
    fees = []
    for orders, fo, fc in zip(df["orders"], df["fee_open"], df["fee_close"]):
        f = 0.0
        for o in orders or []:
            f += float(o.get("cost", 0.0)) * float(fo if o.get("ft_is_entry") else fc)
        fees.append(f)
    out["fees"] = fees
    return out


def compare(ours: BacktestResult, ft_strategy_stats: Dict[str, Any], gates: Gates, bar_minutes: int,
            starting_balance: float) -> ComparisonReport:
    rep = ComparisonReport()
    our = ours.trades_df
    ft = _ft_trades_df(ft_strategy_stats)
    bar = pd.Timedelta(minutes=bar_minutes)

    n_ours, n_ft = len(our), len(ft)
    ratio = (n_ft / n_ours) if n_ours else (0.0 if n_ft == 0 else float("inf"))
    rep.checks.append(Check("trade_count", n_ours > 0 and abs(ratio - 1.0) <= gates.freqtrade_trade_count_tolerance, ratio,
                            gates.freqtrade_trade_count_tolerance, f"ours={n_ours} ft={n_ft}"))

    # ---- timing: match our entries to FT entries on the same pair within ±1 bar ------------
    matched_entries = 0
    matched_exits = 0
    stake_ratios: List[float] = []
    if n_ours and n_ft:
        ft_by_pair = {p: g.sort_values("open") for p, g in ft.groupby("pair")}
        for _, t in our.iterrows():
            g = ft_by_pair.get(t["pair"])
            if g is None or g.empty:
                continue
            dt = (g["open"] - pd.Timestamp(t["entry_time"])).abs()
            j = int(dt.values.argmin())
            if dt.iloc[j] <= bar:
                matched_entries += 1
                if abs(g["close"].iloc[j] - pd.Timestamp(t["exit_time"])) <= bar:
                    matched_exits += 1
                our_notional = float(t["qty"] * t["entry_price"])
                if our_notional > 0:
                    stake_ratios.append(float(g["stake"].iloc[j]) / our_notional)
    entry_frac = matched_entries / n_ours if n_ours else 0.0
    exit_frac = matched_exits / matched_entries if matched_entries else 0.0
    rep.checks.append(Check("entry_timing", entry_frac >= gates.ft_min_entry_match, entry_frac, gates.ft_min_entry_match,
                            f"{matched_entries}/{n_ours} entries matched within 1 bar"))
    rep.checks.append(Check("exit_timing", exit_frac >= gates.ft_min_exit_match, exit_frac, gates.ft_min_exit_match,
                            f"{matched_exits}/{matched_entries} matched entries exit within 1 bar"))
    med_stake = float(np.median(stake_ratios)) if stake_ratios else 0.0
    rep.checks.append(Check("position_size", bool(stake_ratios) and abs(med_stake - 1.0) <= gates.ft_stake_tolerance, med_stake,
                            gates.ft_stake_tolerance, "median ft_stake / our_notional"))

    # ---- money -----------------------------------------------------------------------------
    our_pnl = float(our["pnl"].sum()) if n_ours else 0.0
    ft_pnl = float(ft_strategy_stats.get("profit_total_abs", ft["pnl"].sum() if n_ft else 0.0))
    pnl_diff = abs(ft_pnl - our_pnl) / starting_balance
    rep.checks.append(Check("net_pnl", pnl_diff <= gates.ft_pnl_tolerance_of_capital, pnl_diff, gates.ft_pnl_tolerance_of_capital,
                            f"ours={our_pnl:.2f} ft={ft_pnl:.2f} (diff as fraction of capital)"))
    our_fees = float(our["fees"].sum()) if n_ours else 0.0
    ft_fees = float(ft["fees"].sum()) if n_ft else 0.0
    fee_ratio = (ft_fees / our_fees) if our_fees > 0 else (1.0 if ft_fees == 0 else float("inf"))
    rep.checks.append(Check("fees", abs(fee_ratio - 1.0) <= gates.ft_fee_tolerance, fee_ratio, gates.ft_fee_tolerance,
                            f"ours={our_fees:.2f} ft={ft_fees:.2f}"))
    our_dd = float(_max_dd(ours.equity))
    ft_dd = float(ft_strategy_stats.get("max_drawdown_account", 0.0))
    dd_diff = abs(ft_dd - our_dd)
    rep.checks.append(Check("max_drawdown", dd_diff <= gates.ft_drawdown_tolerance, dd_diff, gates.ft_drawdown_tolerance,
                            f"ours={our_dd:.3f} ft={ft_dd:.3f} (absolute difference)"))

    rep.ours = {"trades": n_ours, "pnl": our_pnl, "fees": our_fees, "max_drawdown": our_dd}
    rep.theirs = {"trades": n_ft, "pnl": ft_pnl, "fees": ft_fees, "max_drawdown": ft_dd}
    return rep


def _max_dd(eq: pd.Series) -> float:
    peak = eq.cummax()
    return float(-(eq / peak - 1.0).min()) if len(eq) else 0.0
