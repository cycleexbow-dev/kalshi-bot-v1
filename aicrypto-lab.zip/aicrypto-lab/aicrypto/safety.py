"""Paper-only safety guard.

This module is the single point of truth for "no real money". Every component that
renders or launches a Freqtrade configuration must call `assert_paper_only` and the
CLI `safety-check` command scans all configs on disk.

DO NOT MODIFY without a human reviewing the diff. CLAUDE.md forbids automated edits.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List

FORBIDDEN_TRADING_MODES = {"futures", "margin"}


class LiveTradingBlocked(RuntimeError):
    """Raised whenever a configuration could place real orders."""


@dataclass
class SafetyReport:
    path: str
    ok: bool
    problems: List[str] = field(default_factory=list)


def _nonempty(v: Any) -> bool:
    return isinstance(v, str) and v.strip() != ""


_CREDENTIAL_KEYS = {"key", "secret", "password", "uid", "walletaddress", "privatekey", "apikey", "api_key", "token",
                    "passphrase", "login", "private_key", "access_token"}


def _find_credentials(obj: Any, path: str = "") -> List[str]:
    """Recursively find non-empty credential-like values anywhere in a config (ccxt_config,
    ccxt_async_config, nested dicts, lists). Case-insensitive key match."""
    hits: List[str] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            kp = f"{path}.{k}" if path else str(k)
            if str(k).lower().replace("-", "_") in _CREDENTIAL_KEYS and (_nonempty(v) or (isinstance(v, (int, float)) and v)):
                hits.append(kp)
            hits += _find_credentials(v, kp)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            hits += _find_credentials(v, f"{path}[{i}]")
    return hits


def inspect_config(cfg: Dict[str, Any], path: str = "<memory>") -> SafetyReport:
    problems: List[str] = []
    if cfg.get("dry_run") is not True:
        problems.append("dry_run must be exactly true")
    ex = cfg.get("exchange", {}) or {}
    if not isinstance(ex, dict):
        problems.append("exchange section must be an object")
        ex = {}
    for hit in _find_credentials({"exchange": ex}):
        problems.append(f"{hit} must be empty in a paper-only config")
    # credentials smuggled outside the exchange block (e.g. top-level or in 'internals')
    for hit in _find_credentials({k: v for k, v in cfg.items() if k not in ("exchange", "api_server", "telegram")}):
        problems.append(f"unexpected credential-like value at {hit}")
    if str(cfg.get("trading_mode", "spot")).strip().lower() != "spot":
        problems.append("trading_mode must be 'spot'")
    if str(cfg.get("margin_mode") or "").strip().lower() not in ("", "none"):
        problems.append("margin_mode must not be set (no leverage)")
    if ex.get("sandbox") not in (None, False):
        problems.append("exchange.sandbox must not be used to disguise live endpoints")
    if any(str(k).lower().startswith("liquidation") for k in cfg):
        problems.append("futures-only settings present")
    api = cfg.get("api_server", {}) or {}
    if api.get("enabled") and api.get("listen_ip_address") not in ("127.0.0.1", "localhost", None):
        problems.append("api_server must listen on 127.0.0.1 only")
    try:
        if cfg.get("dry_run_wallet") is not None and float(cfg["dry_run_wallet"]) <= 0:
            problems.append("dry_run_wallet must be positive")
    except (TypeError, ValueError):
        problems.append("dry_run_wallet must be numeric")
    return SafetyReport(path=path, ok=not problems, problems=problems)


def assert_paper_only(cfg: Dict[str, Any], path: str = "<memory>") -> None:
    rep = inspect_config(cfg, path)
    if not rep.ok:
        raise LiveTradingBlocked(f"{path}: " + "; ".join(rep.problems))


def scan_configs(user_data: Path) -> List[SafetyReport]:
    """Inspect every config*.json under user_data. Missing dir => empty list."""
    reports: List[SafetyReport] = []
    if not user_data.exists():
        return reports
    for p in sorted(user_data.rglob("config*.json")):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                cfg = json.load(fh)
        except Exception as exc:  # unreadable config is a problem too
            reports.append(SafetyReport(str(p), False, [f"unreadable: {exc}"]))
            continue
        reports.append(inspect_config(cfg, str(p)))
    return reports


def compose_is_dry_run(compose_text: str) -> bool:
    """The Freqtrade service command line must carry --dry-run explicitly."""
    return "--dry-run" in compose_text and "trade" in compose_text


# ---- Kalshi engine checks --------------------------------------------------------------
_KEY_FILE_PATTERNS = ("*.pem", "*.key", "*.p8", "id_ed25519", "id_rsa")
_KEY_CONTENT_MARKERS = ("-----BEGIN PRIVATE KEY-----", "-----BEGIN RSA PRIVATE KEY-----", "-----BEGIN OPENSSH PRIVATE KEY-----",
                        "KALSHI-ACCESS-SIGNATURE:")


def scan_kalshi(root: Path) -> List[SafetyReport]:
    """Paper-only attestation for the Kalshi engine:
    - config/kalshi.yaml must validate (paper_only: true, leverage 1.0, demo/production only)
    - no private-key files or PEM content anywhere in the repo tree (keys live outside the repo)
    - .gitignore must cover key files and .env
    """
    reports: List[SafetyReport] = []
    cfg = root / "config" / "kalshi.yaml"
    if cfg.exists():
        try:
            from .kalshi.settings import load_kalshi_settings
            ks = load_kalshi_settings(cfg, root=root)
            probs = []
            if ks.paper_only is not True:
                probs.append("paper_only must be true")
            if ks.reference_feeds.pyth.enabled:
                probs.append("pyth feed enabled: requires explicit decision + validated licence (decision 2026-11-08: OFF)")
            reports.append(SafetyReport(str(cfg), not probs, probs))
        except Exception as exc:
            reports.append(SafetyReport(str(cfg), False, [f"invalid kalshi config: {str(exc)[:200]}"]))
    probs: List[str] = []
    skip = {".git", ".venv", "node_modules", "__pycache__", ".pytest_cache"}
    for p in root.rglob("*"):
        if any(part in skip for part in p.parts):
            continue
        if p.is_file():
            if any(p.match(pat) for pat in _KEY_FILE_PATTERNS):
                probs.append(f"private key file in repo tree: {p.relative_to(root)}")
            elif p.suffix in (".py", ".yaml", ".yml", ".json", ".env", ".txt", ".md", ".toml", ".sh", "") and p.stat().st_size < 2_000_000:
                try:
                    txt = p.read_text(errors="ignore")
                except Exception:
                    continue
                if any(mark in txt for mark in _KEY_CONTENT_MARKERS) and "safety.py" not in p.name and "test_" not in p.name:
                    probs.append(f"private-key or signature material in {p.relative_to(root)}")
    gi = root / ".gitignore"
    gi_text = gi.read_text() if gi.exists() else ""
    for needed in ("*.pem", ".env"):
        if needed not in gi_text:
            probs.append(f".gitignore must contain {needed}")
    reports.append(SafetyReport(f"{root}/<kalshi credentials>", not probs, probs))
    return reports
