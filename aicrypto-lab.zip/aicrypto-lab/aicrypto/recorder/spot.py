"""Coinbase and Kraken public spot feeds (WebSocket, no account, read-only).

Coinbase Exchange `ticker` channel: one message per match with best bid/ask, trade_id and exchange time.
Kraken v2 `trade` + `ticker` channels. Gaps in trade ids, reconnects and stale feeds are recorded.
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

COINBASE_WS = "wss://ws-feed.exchange.coinbase.com"
KRAKEN_WS = "wss://ws.kraken.com/v2"
COINBASE = {"BTC": "BTC-USD", "ETH": "ETH-USD", "SOL": "SOL-USD", "XRP": "XRP-USD", "DOGE": "DOGE-USD"}
KRAKEN = {"BTC": "BTC/USD", "ETH": "ETH/USD", "SOL": "SOL/USD", "XRP": "XRP/USD", "DOGE": "DOGE/USD"}


def _iso(s: Optional[str]) -> Optional[float]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


class SpotFeed:
    def __init__(self, store, venue: str, assets: List[str], clock=time.time):
        assert venue in ("coinbase", "kraken")
        self.store, self.venue, self.clock = store, venue, clock
        self.map = COINBASE if venue == "coinbase" else KRAKEN
        self.assets = [a for a in assets if a in self.map]
        self.last_trade_id: Dict[str, int] = {}
        self.last: Dict[str, Dict[str, Any]] = {}
        self.stats = {"messages": 0, "gaps": 0, "reconnects": 0, "errors": 0, "state": "starting", "last_msg": 0.0}

    def _check_gap(self, sym: str, tid: Any) -> None:
        try:
            tid = int(tid)
        except (TypeError, ValueError):
            return
        prev = self.last_trade_id.get(sym)
        if prev is not None and tid > prev + 1:
            self.stats["gaps"] += 1
            self.store.write(self.venue, "gap", symbol=sym, after=prev, next=tid, missing=tid - prev - 1)
        if prev is None or tid > prev:
            self.last_trade_id[sym] = tid

    def on_message(self, raw: str, t_recv: float) -> None:
        try:
            m = json.loads(raw)
        except json.JSONDecodeError:
            self.store.write(self.venue, "invalid", raw=raw[:300])
            return
        self.stats["last_msg"] = t_recv
        if self.venue == "coinbase":
            if m.get("type") != "ticker":
                if m.get("type") == "error":
                    self.store.write(self.venue, "error", raw=m)
                return
            sym, ex = m.get("product_id"), _iso(m.get("time"))
            self._check_gap(sym, m.get("trade_id"))
            rec = {"symbol": sym, "price": m.get("price"), "bid": m.get("best_bid"), "ask": m.get("best_ask"),
                   "bid_size": m.get("best_bid_size"), "ask_size": m.get("best_ask_size"), "size": m.get("last_size"),
                   "side": m.get("side"), "trade_id": m.get("trade_id"), "ex_ts": ex,
                   "lat_ms": round((t_recv - ex) * 1000, 1) if ex else None}
            self.last[sym] = rec
            self.stats["messages"] += 1
            self.store.write(self.venue, "ticker", t=t_recv, **rec)
            return
        ch = m.get("channel")
        if ch == "trade":
            for tr in m.get("data", []):
                sym, ex = tr.get("symbol"), _iso(tr.get("timestamp"))
                self._check_gap(sym, tr.get("trade_id"))
                self.stats["messages"] += 1
                self.store.write(self.venue, "trade", t=t_recv, symbol=sym, price=tr.get("price"), qty=tr.get("qty"),
                                 side=tr.get("side"), trade_id=tr.get("trade_id"), ex_ts=ex,
                                 lat_ms=round((t_recv - ex) * 1000, 1) if ex else None)
        elif ch == "ticker":
            for tk in m.get("data", []):
                rec = {"symbol": tk.get("symbol"), "bid": tk.get("bid"), "ask": tk.get("ask"), "bid_size": tk.get("bid_qty"),
                       "ask_size": tk.get("ask_qty"), "price": tk.get("last")}
                self.last[rec["symbol"]] = rec
                self.stats["messages"] += 1
                self.store.write(self.venue, "ticker", t=t_recv, **rec)
        elif m.get("method") == "subscribe" and not m.get("success", True):
            self.store.write(self.venue, "error", raw=m)

    def _subscribe_msgs(self) -> List[Dict[str, Any]]:
        syms = [self.map[a] for a in self.assets]
        if self.venue == "coinbase":
            return [{"type": "subscribe", "product_ids": syms, "channels": ["ticker"]}]
        return [{"method": "subscribe", "params": {"channel": "trade", "symbol": syms, "snapshot": False}},
                {"method": "subscribe", "params": {"channel": "ticker", "symbol": syms}}]

    async def run(self, stop: asyncio.Event) -> None:
        import websockets
        url = COINBASE_WS if self.venue == "coinbase" else KRAKEN_WS
        backoff, first = 2.0, True
        while not stop.is_set():
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2 ** 22) as ws:
                    if not first:
                        self.stats["reconnects"] += 1
                        self.store.write(self.venue, "reconnect")
                    first = False
                    self.last_trade_id.clear()       # ids after a reconnect are not a gap we can measure
                    for msg in self._subscribe_msgs():
                        await ws.send(json.dumps(msg))
                    self.stats["state"] = "live"
                    backoff = 2.0
                    while not stop.is_set():
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=30)
                        except asyncio.TimeoutError:
                            self.store.write(self.venue, "stale", seconds=30)
                            break
                        self.on_message(raw, self.clock())
            except Exception as e:
                self.stats["errors"] += 1
                self.stats["state"] = "reconnecting"
                self.store.write(self.venue, "error", error=f"{type(e).__name__}: {str(e)[:200]}")
            try:
                await asyncio.wait_for(stop.wait(), timeout=backoff)
            except asyncio.TimeoutError:
                pass
            backoff = min(60.0, backoff * 2)
