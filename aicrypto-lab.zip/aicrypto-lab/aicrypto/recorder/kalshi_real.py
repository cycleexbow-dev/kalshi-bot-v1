"""Kalshi REAL-exchange recorder: public, unsigned, GET-only (through the guarded KalshiRestClient).

Polls the 15-minute crypto and commodity series. Records:
  series_meta  fee type/multiplier and settlement sources (hourly)
  market_meta  ticker, strike, open/close/expiration, status, rules text (on first sight and on change)
  quote        best bid/ask, sizes, last price, volume (when changed)
  book         order-book depth: top BOOK_LEVELS each side every poll, full depth every FULL_DEPTH_S
  trade        each public trade in a recorded market (deduplicated by trade_id)
  settled      result and settlement value once the window is determined
  poll / error request round-trip latency, failures (recorded, never papered over)
"""
from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Deque, Dict, List, Optional, Tuple

CRYPTO = ["BTC", "ETH", "SOL", "XRP", "DOGE", "BNB", "HYPE", "NEAR", "ZEC"]
COMMODITY = ["GOLD", "SILVER", "COPPER", "WTI", "BRENT", "NATGAS", "PLATINUM", "PALLADIUM"]
CORE = {"BTC", "ETH", "SOL", "XRP", "DOGE"}          # order books every poll; others every OTHER_BOOK_S
BOOK_LEVELS = 10
FULL_DEPTH_S = 30.0
OTHER_BOOK_S = 5.0
SRC = "kalshi_real"


def series_for(asset: str) -> str:
    return f"KX{asset}15M"


def _ts(iso: Optional[str]) -> Optional[float]:
    if not iso:
        return None
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _levels(rows: Any) -> List[Tuple[float, float]]:
    """[[price_dollars, size], ...] -> [(price, size)] sorted best (highest bid) first; invalid rows dropped."""
    out = []
    for r in rows or []:
        try:
            p, s = float(r[0]), float(r[1])
        except (TypeError, ValueError, IndexError):
            continue
        if 0 < p < 1 and s > 0:
            out.append((p, s))
    out.sort(key=lambda x: -x[0])
    return out


@dataclass
class Book:
    t: float                                  # local receive time
    yes_bids: List[Tuple[float, float]]       # best first
    no_bids: List[Tuple[float, float]]        # best first; YES ask = 1 - NO bid

    def asks(self, side: str) -> List[Tuple[float, float]]:
        """Executable asks to BUY `side`, best (cheapest) first: buying YES lifts NO bids and vice versa."""
        src = self.no_bids if side == "yes" else self.yes_bids
        return [(round(1 - p, 4), s) for p, s in src]

    def best_bid(self) -> Optional[Tuple[float, float]]:
        return self.yes_bids[0] if self.yes_bids else None

    def best_ask(self) -> Optional[Tuple[float, float]]:
        a = self.asks("yes")
        return a[0] if a else None


@dataclass
class MarketState:
    ticker: str
    asset: str
    asset_class: str
    meta: Dict[str, Any] = field(default_factory=dict)
    quote: Dict[str, Any] = field(default_factory=dict)
    book: Optional[Book] = None
    books: Deque[Book] = field(default_factory=lambda: deque(maxlen=120))
    trade_ids: Deque[str] = field(default_factory=lambda: deque(maxlen=2000))
    last_trade_ts: int = 0
    last_full: float = 0.0
    last_book_poll: float = 0.0
    result: Optional[str] = None

    @property
    def open_ts(self) -> Optional[float]:
        return self.meta.get("open_ts")

    @property
    def close_ts(self) -> Optional[float]:
        return self.meta.get("close_ts")

    @property
    def strike(self) -> Optional[float]:
        return self.meta.get("strike")


class RealKalshi:
    def __init__(self, store, client=None, clock=time.time, assets: Optional[List[str]] = None):
        self.store, self.clock = store, clock
        self._client = client
        self.assets = assets or (CRYPTO + COMMODITY)
        self.markets: Dict[str, MarketState] = {}
        self.series_meta: Dict[str, Dict[str, Any]] = {}
        self.stats = {"polls": 0, "errors": 0, "quotes": 0, "books": 0, "trades": 0, "settled": 0, "last_ok": 0.0,
                      "rtt_ms": deque(maxlen=200)}

    def client(self):
        if self._client is None:
            from ..kalshi.client import KalshiRestClient
            self._client = KalshiRestClient("production", signer=None, public=True, requests_per_second=6.0, priority="high",
                                            timeout_s=5.0, max_retries=1)
        return self._client

    async def _get(self, path: str, params: Dict[str, Any], what: str) -> Optional[Dict[str, Any]]:
        t0 = time.monotonic()
        try:
            data = await self.client().transport.request("GET", path, params)
        except Exception as e:  # a failed poll is a recorded gap, never a guess
            self.stats["errors"] += 1
            self.store.write(SRC, "error", what=what, error=f"{type(e).__name__}: {str(e)[:200]}")
            return None
        rtt = (time.monotonic() - t0) * 1000
        self.stats["rtt_ms"].append(rtt)
        self.stats["polls"] += 1
        self.stats["last_ok"] = self.clock()
        return data

    # ------------------------------------------------------------------ discovery & metadata
    async def refresh_series(self) -> None:
        for a in self.assets:
            s = series_for(a)
            d = await self._get(f"/series/{s}", {}, f"series {s}")
            if d is None:
                continue
            ser = d.get("series") or d
            meta = {"series": s, "fee_type": ser.get("fee_type"), "fee_multiplier": ser.get("fee_multiplier"),
                    "settlement_sources": ser.get("settlement_sources"), "frequency": ser.get("frequency")}
            self.series_meta[s] = meta
            self.store.write(SRC, "series_meta", **meta)

    async def discover(self) -> int:
        """Open windows of each series; records market_meta for new or changed markets."""
        n = 0
        for a in self.assets:
            s = series_for(a)
            d = await self._get("/markets", {"series_ticker": s, "status": "open", "limit": 20}, f"discover {s}")
            for m in (d or {}).get("markets", []):
                self._meta(m, a)
                n += 1
        return n

    def _meta(self, m: Dict[str, Any], asset: str) -> MarketState:
        t = m["ticker"]
        st = self.markets.get(t)
        if st is None:
            st = self.markets[t] = MarketState(t, asset, "crypto" if asset in CRYPTO else "commodity")
        strike = m.get("floor_strike")
        meta = {"ticker": t, "series": series_for(asset), "asset": asset, "status": m.get("status"),
                "strike": float(strike) if strike is not None else None,
                "open_ts": _ts(m.get("open_time")), "close_ts": _ts(m.get("close_time")),
                "expiration_ts": _ts(m.get("expected_expiration_time") or m.get("expiration_time")),
                "strike_type": m.get("strike_type"), "rules_primary": m.get("rules_primary")}
        key = ("status", "strike", "open_ts", "close_ts", "expiration_ts")
        if any(st.meta.get(k) != meta[k] for k in key):
            st.meta = meta
            self.store.write(SRC, "market_meta", **meta)
        return st

    def live(self, now: Optional[float] = None) -> List[MarketState]:
        now = self.clock() if now is None else now
        return [s for s in self.markets.values()
                if s.open_ts and s.close_ts and s.open_ts <= now < s.close_ts and s.meta.get("status") in ("active", "open")]

    # ------------------------------------------------------------------ quotes, books, trades
    async def poll_quotes(self) -> int:
        live = self.live()
        if not live:
            return 0
        d = await self._get("/markets", {"tickers": ",".join(s.ticker for s in live), "limit": len(live)}, "quotes")
        n = 0
        for m in (d or {}).get("markets", []):
            st = self.markets.get(m.get("ticker"))
            if st is None:
                continue
            self._meta(m, st.asset)
            q = {"yes_bid": m.get("yes_bid_dollars"), "yes_ask": m.get("yes_ask_dollars"), "bid_size": m.get("yes_bid_size_fp"),
                 "ask_size": m.get("yes_ask_size_fp"), "last": m.get("last_price_dollars"), "volume": m.get("volume_fp"),
                 "updated": m.get("updated_time")}
            if q != st.quote:
                st.quote = q
                self.store.write(SRC, "quote", ticker=st.ticker, **q)
                self.stats["quotes"] += 1
                n += 1
        return n

    async def poll_books(self) -> int:
        now = self.clock()
        want = [s for s in self.live(now) if s.asset in CORE or now - s.last_book_poll >= OTHER_BOOK_S]
        if not want:
            return 0
        d = await self._get("/markets/orderbooks", {"tickers": [s.ticker for s in want]}, "books")
        if d is None:
            return 0
        t_recv = self.clock()
        n = 0
        for ob in d.get("orderbooks", []):
            st = self.markets.get(ob.get("ticker"))
            if st is None:
                continue
            st.last_book_poll = t_recv
            fp = ob.get("orderbook_fp") or {}
            book = Book(t_recv, _levels(fp.get("yes_dollars")), _levels(fp.get("no_dollars")))
            full = t_recv - st.last_full >= FULL_DEPTH_S
            top = (book.yes_bids[:BOOK_LEVELS], book.no_bids[:BOOK_LEVELS])
            changed = st.book is None or (st.book.yes_bids[:BOOK_LEVELS], st.book.no_bids[:BOOK_LEVELS]) != top
            if not book.yes_bids and not book.no_bids:
                self.store.write(SRC, "book_empty", ticker=st.ticker)
            elif changed or full:
                lv = None if full else BOOK_LEVELS
                self.store.write(SRC, "book_full" if full else "book", ticker=st.ticker,
                                 yes_bids=book.yes_bids[:lv], no_bids=book.no_bids[:lv])
                if full:
                    st.last_full = t_recv
                self.stats["books"] += 1
            st.book = book
            st.books.append(book)
            n += 1
        return n

    async def poll_trades(self, ticker: str) -> int:
        st = self.markets.get(ticker)
        if st is None:
            return 0
        params: Dict[str, Any] = {"ticker": ticker, "limit": 200}
        if st.last_trade_ts:
            params["min_ts"] = st.last_trade_ts - 1
        d = await self._get("/markets/trades", params, f"trades {ticker}")
        n = 0
        for tr in reversed((d or {}).get("trades", [])):
            tid = tr.get("trade_id")
            if not tid or tid in st.trade_ids:
                continue
            st.trade_ids.append(tid)
            ts = _ts(tr.get("created_time"))
            if ts:
                st.last_trade_ts = max(st.last_trade_ts, int(ts))
            self.store.write(SRC, "trade", ticker=ticker, trade_id=tid, created=tr.get("created_time"),
                             count=tr.get("count_fp"), yes_price=tr.get("yes_price_dollars"), no_price=tr.get("no_price_dollars"),
                             taker_side=tr.get("taker_side"))
            self.stats["trades"] += 1
            n += 1
        return n

    async def poll_settlements(self) -> int:
        now = self.clock()
        due = [s for s in self.markets.values() if s.result is None and s.close_ts and now >= s.close_ts + 5]
        if not due:
            return 0
        d = await self._get("/markets", {"tickers": ",".join(s.ticker for s in due[:50]), "limit": 50}, "settlements")
        n = 0
        for m in (d or {}).get("markets", []):
            st = self.markets.get(m.get("ticker"))
            r = (m.get("result") or "").lower()
            if st is None or r not in ("yes", "no"):
                continue
            st.result = r
            self.store.write(SRC, "settled", ticker=st.ticker, result=r, settle_value=m.get("expiration_value"),
                             status=m.get("status"), strike=st.strike, close_ts=st.close_ts)
            self.stats["settled"] += 1
            n += 1
        # forget windows settled long ago
        for t in [t for t, s in self.markets.items() if s.result and s.close_ts and now - s.close_ts > 3600]:
            self.markets.pop(t, None)
        return n

    async def run(self, stop: asyncio.Event) -> None:
        await self.refresh_series()
        last = {"series": self.clock(), "discover": 0.0, "settle": 0.0}
        trade_cycle = 0
        while not stop.is_set():
            now = self.clock()
            if now - last["discover"] >= 60:
                last["discover"] = now
                await self.discover()
            if now - last["series"] >= 3600:
                last["series"] = now
                await self.refresh_series()
            await self.poll_quotes()
            await self.poll_books()
            live = self.live()
            if live:                            # one market's trades per cycle, round robin
                await self.poll_trades(live[trade_cycle % len(live)].ticker)
                trade_cycle += 1
            if now - last["settle"] >= 15:
                last["settle"] = now
                await self.poll_settlements()
            try:
                await asyncio.wait_for(stop.wait(), timeout=max(0.05, 1.0 - (self.clock() - now)))
            except asyncio.TimeoutError:
                pass
