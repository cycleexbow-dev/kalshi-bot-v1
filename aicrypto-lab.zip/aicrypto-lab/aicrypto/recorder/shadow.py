"""Production-price SHADOW trading: every lab rule evaluated on real-exchange prices, fills simulated
conservatively. Nothing is ever sent anywhere; every row is a hypothetical, never an execution.

Fill model (fixed in advance, deliberately conservative):
* Only marketable (taker) orders are simulated: all six rule families are takers. Resting/passive
  orders are NOT simulated, because a displayed price touching a limit does not prove a fill.
* Latency: the order is assumed to reach the book LATENCIES_S after the signal. It fills against the
  first recorded order book at or after that moment (books are polled about once a second).
* Depth: only DEPTH_SHARE of each displayed level is assumed available (others race for it too).
* Price limit: the order will not pay more than SLIPPAGE_LIMIT above the ask seen at the signal.
  Anything not available inside the limit is simply not filled (partial or no fill is recorded).
* Fees: Kalshi taker fee 0.07 x C x P x (1 - P) per price level, summed and rounded up to the cent.
* Sizes: 1 contract, and STAKE_USD worth of contracts at the signal price.
* Held to settlement; P/L uses the official result recorded from the real exchange.
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
from collections import deque
from decimal import Decimal
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple

from ..kalshi.lab.candidates import WindowView, build
from ..kalshi.lab.engine import LAB_VERSION
from ..kalshi.lab.features import move_pct, prob_up_avg_settle, realized_sigma

LATENCIES_S = (1.0, 3.0)
DEPTH_SHARE = 0.5
SLIPPAGE_LIMIT = 0.02
STAKE_USD = 10.0
BOOK_MAX_AGE_S = 3.0
REF_MAX_AGE_S = 5.0
FILL_WAIT_MAX_S = 15.0

_SCHEMA = """
CREATE TABLE IF NOT EXISTS proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, cid TEXT, family TEXT, asset TEXT, version TEXT, duration TEXT,
  ticker TEXT, strike REAL, close_ts REAL, signal_ts REAL, t_left REAL, side TEXT,
  signal_ask REAL, signal_bid REAL, depth TEXT, book_age_s REAL, p_up REAL, ref_age_s REAL, spread REAL,
  order_type TEXT, fills TEXT, result TEXT, settled_ts REAL, net TEXT, UNIQUE(cid, ticker));
CREATE INDEX IF NOT EXISTS idx_prop_open ON proposals(result);
"""


def fee_total(levels: List[Tuple[float, float]]) -> float:
    raw = sum(0.07 * q * p * (1 - p) for p, q in levels)
    return math.ceil(raw * 100 - 1e-9) / 100 if raw > 0 else 0.0


def simulate_fill(asks: List[Tuple[float, float]], want: float, limit: float, depth_share: float = DEPTH_SHARE) -> Dict[str, Any]:
    """Walk the asks (cheapest first) up to `limit`, taking `depth_share` of each displayed size."""
    got: List[Tuple[float, float]] = []
    left = want
    for p, s in asks:
        if p > limit + 1e-9 or left <= 0:
            break
        q = min(left, math.floor(s * depth_share))
        if q > 0:
            got.append((p, q))
            left -= q
    filled = sum(q for _, q in got)
    if filled <= 0:
        return {"filled": 0, "wanted": want}
    cost = sum(p * q for p, q in got)
    fee = fee_total(got)
    return {"filled": filled, "wanted": want, "vwap": round(cost / filled, 4), "cost": round(cost, 4), "fee": fee,
            "max_loss": round(cost + fee, 4), "levels": got}


class ShadowEngine:
    def __init__(self, db_path: Path, kalshi, cf, clock=time.time):
        self.kalshi, self.cf, self.clock = kalshi, cf, clock
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._c() as c:
            c.executescript(_SCHEMA)
            self.entered = {(r[0], r[1]) for r in c.execute("SELECT cid, ticker FROM proposals WHERE signal_ts > ?", (time.time() - 3 * 3600,))}
        from .kalshi_real import COMMODITY, CRYPTO
        self.cands = build({"crypto": [a for a in CRYPTO if a in kalshi.assets], "commodity": [a for a in COMMODITY if a in kalshi.assets]})
        self.by_asset: Dict[str, list] = {}
        for k in self.cands:
            self.by_asset.setdefault(k.asset, []).append(k)
        self.mids: Dict[str, Deque[Tuple[float, float]]] = {}
        self.version = f"lab{LAB_VERSION}"
        self.stats = {"proposals": 0, "fills_done": 0, "settled": 0, "skipped_no_ref": 0}

    def _c(self):
        c = sqlite3.connect(self.db_path, timeout=30)
        c.execute("PRAGMA journal_mode=WAL")
        return c

    # ------------------------------------------------------------------ live view
    def _ref(self, asset: str, now: float):
        idx = self.cf.asset_index(asset)
        if not idx:
            return None
        last = self.cf.last.get(idx)
        if not last or now - last[0] > REF_MAX_AGE_S:
            return None
        per_s: Dict[int, float] = {}
        for t, v in self.cf.series(idx, now - 900):
            per_s[int(t)] = v                         # one print per second (the settlement uses 1-s prints)
        pts = sorted(per_s.items())
        return idx, last, [(float(t), v) for t, v in pts]

    def window(self, st, now: float) -> Optional[WindowView]:
        b = st.book
        if b is None or now - b.t > BOOK_MAX_AGE_S or st.strike is None or not st.close_ts:
            return None
        bb, ba = b.best_bid(), b.best_ask()
        yes_bid = Decimal(str(bb[0])) if bb else None
        yes_ask = Decimal(str(ba[0])) if ba else None
        mid = float((yes_bid + yes_ask) / 2) if (yes_bid is not None and yes_ask is not None) else None
        hist = self.mids.setdefault(st.ticker, deque(maxlen=400))
        if mid is not None and (not hist or now - hist[-1][0] >= 1.0):
            hist.append((now, mid))
        past = [v for t, v in hist if t <= now - 120]
        w = WindowView(st.ticker, st.asset, st.asset_class, now, st.close_ts, st.open_ts, yes_bid, yes_ask,
                       bb[1] if bb else 0.0, ba[1] if ba else 0.0,
                       mid_change_120s=(mid - past[-1]) if (mid is not None and past) else None)
        if st.asset_class == "crypto":
            ref = self._ref(st.asset, now)
            if ref:
                _, last, prints = ref
                if len(prints) > 60:
                    sigma = realized_sigma(prints, now=now)
                    if sigma:
                        win = [v for t, v in prints if st.close_ts - 60 <= t <= now]
                        w.p_up = prob_up_avg_settle(now=now, close_ts=st.close_ts, target=float(st.strike), spot=last[1],
                                                    sigma=sigma, window_prints=win)
                    w.move_3m_pct = move_pct(prints, now, 180)
        return w

    # ------------------------------------------------------------------ signals
    def tick(self) -> int:
        now = self.clock()
        n = 0
        rows = []
        for st in self.kalshi.live(now):
            w = self.window(st, now)
            if w is None:
                continue
            for c in self.by_asset.get(st.asset, []):
                if (c.cid, st.ticker) in self.entered:
                    continue
                if c.needs_reference and w.p_up is None and w.move_3m_pct is None:
                    continue
                side = c.signal(w)
                if not side:
                    continue
                self.entered.add((c.cid, st.ticker))
                asks = st.book.asks(side)
                bid_side = st.book.asks("no" if side == "yes" else "yes")
                rows.append((c.cid, c.family, c.asset, self.version, "15m", st.ticker, st.strike, st.close_ts, now, w.t_left, side,
                             float(w.ask(side)), round(1 - bid_side[0][0], 4) if bid_side else None, json.dumps(asks[:5]),
                             round(now - st.book.t, 3), w.p_up, None,
                             float(w.yes_ask - w.yes_bid) if (w.yes_ask is not None and w.yes_bid is not None) else None,
                             "marketable_limit", json.dumps({})))
                n += 1
        if rows:
            with self._c() as c:
                c.executemany("INSERT OR IGNORE INTO proposals (cid, family, asset, version, duration, ticker, strike, close_ts, signal_ts, "
                              "t_left, side, signal_ask, signal_bid, depth, book_age_s, p_up, ref_age_s, spread, order_type, fills) "
                              "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            self.stats["proposals"] += n
        return n

    # ------------------------------------------------------------------ fills and settlement
    def resolve_fills(self) -> int:
        now = self.clock()
        done = 0
        with self._c() as c:
            rows = c.execute("SELECT id, ticker, side, signal_ts, signal_ask, fills FROM proposals WHERE result IS NULL AND signal_ts > ?",
                             (now - 3600,)).fetchall()
            for pid, ticker, side, ts, ask, fills_js in rows:
                fills = json.loads(fills_js or "{}")
                if all(f"L{L:g}" in fills for L in LATENCIES_S):
                    continue
                st = self.kalshi.markets.get(ticker)
                changed = False
                for L in LATENCIES_S:
                    key = f"L{L:g}"
                    if key in fills:
                        continue
                    book = next((b for b in (st.books if st else ()) if b.t >= ts + L), None)
                    if book is None:
                        if now - ts > L + FILL_WAIT_MAX_S:
                            fills[key] = {"status": "no_book_data"}       # a gap, recorded as such
                            changed = True
                        continue
                    asks = book.asks(side)
                    n_stake = max(1, math.floor(STAKE_USD / ask)) if ask > 0 else 1
                    fills[key] = {"book_t": book.t, "delay_s": round(book.t - ts, 3),
                                  "one": simulate_fill(asks, 1, ask + SLIPPAGE_LIMIT),
                                  "stake": simulate_fill(asks, n_stake, ask + SLIPPAGE_LIMIT),
                                  "best_ask_then": asks[0][0] if asks else None}
                    changed = True
                if changed:
                    c.execute("UPDATE proposals SET fills=? WHERE id=?", (json.dumps(fills), pid))
                    done += 1
        self.stats["fills_done"] += done
        return done

    def settle(self) -> int:
        now = self.clock()
        n = 0
        with self._c() as c:
            rows = c.execute("SELECT id, ticker, side, fills FROM proposals WHERE result IS NULL").fetchall()
            for pid, ticker, side, fills_js in rows:
                st = self.kalshi.markets.get(ticker)
                if st is None or st.result is None:
                    continue
                win = 1.0 if st.result == side else 0.0
                fills = json.loads(fills_js or "{}")
                net = {}
                for L, f in fills.items():
                    for size in ("one", "stake"):
                        x = (f or {}).get(size)
                        if x and x.get("filled"):
                            net[f"{L}_{size}"] = round(x["filled"] * win - x["cost"] - x["fee"], 4)
                c.execute("UPDATE proposals SET result=?, settled_ts=?, net=? WHERE id=?", (st.result, now, json.dumps(net), pid))
                n += 1
        self.stats["settled"] += n
        return n
