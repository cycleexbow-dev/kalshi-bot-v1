"""Run the recorder + shadow engine:  python -m aicrypto.recorder   (or bash scripts/start_recorder.sh)"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import time
from collections import deque
from pathlib import Path

from .cfindex import CFIndex
from .kalshi_real import COMMODITY, CRYPTO, RealKalshi
from .longer import LongerDurations
from .shadow import ShadowEngine
from .spot import SpotFeed
from .store import Store

log = logging.getLogger("aicrypto.recorder")
ROOT = Path(__file__).resolve().parents[2]


def demo_signer_factory():
    """Demo key only (for the CF index channel). A non-demo environment is refused."""
    from ..kalshi.auth import CredentialError, Credentials, KalshiSigner
    try:
        creds = Credentials.from_env("demo", repo_root=ROOT)
    except CredentialError:
        return None
    if getattr(creds, "env", "demo") != "demo":
        return None
    return KalshiSigner.from_credentials(creds)


def status(parts) -> dict:
    kal, cf, cb, kr, sh, store, longer = parts
    now = time.time()
    rtt = list(kal.stats["rtt_ms"])
    return {"t": now, "pid": os.getpid(),
            "kalshi_real": {k: v for k, v in kal.stats.items() if k != "rtt_ms"} | {
                "live_markets": len(kal.live()), "rtt_ms_median": sorted(rtt)[len(rtt) // 2] if rtt else None,
                "last_ok_age_s": round(now - kal.stats["last_ok"], 1) if kal.stats["last_ok"] else None},
            "cfindex": cf.stats | {"indices": {k: round(now - v[0], 1) for k, v in cf.last.items()}},
            "coinbase": cb.stats | {"last_age_s": round(now - cb.stats["last_msg"], 1) if cb.stats["last_msg"] else None},
            "kraken": kr.stats | {"last_age_s": round(now - kr.stats["last_msg"], 1) if kr.stats["last_msg"] else None},
            "shadow": sh.stats, "hourly_daily": longer.stats, "lines": store.lines}


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    for noisy in ("httpx", "websockets", "aicrypto.kalshi.transport"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    (ROOT / "run").mkdir(exist_ok=True)
    (ROOT / "run" / "recorder.pid").write_text(str(os.getpid()))
    store = Store(ROOT)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set)
    kal = RealKalshi(store)
    longer = LongerDurations(store, root=ROOT)
    cf = CFIndex(store, demo_signer_factory, CRYPTO)
    cb = SpotFeed(store, "coinbase", CRYPTO)
    kr = SpotFeed(store, "kraken", CRYPTO)
    sh = ShadowEngine(ROOT / "user_data" / "kalshi" / "shadow_real.sqlite", kal, cf)
    store.write("recorder", "start", assets=CRYPTO + COMMODITY)

    async def shadow_loop():
        last_slow = 0.0
        while not stop.is_set():
            try:
                sh.tick()
                if time.time() - last_slow > 5:
                    last_slow = time.time()
                    sh.resolve_fills()
                    sh.settle()
            except Exception as e:
                log.exception("shadow")
                store.write("recorder", "error", where="shadow", error=f"{type(e).__name__}: {e}")
            try:
                await asyncio.wait_for(stop.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                pass

    async def status_loop():
        while not stop.is_set():
            st = status((kal, cf, cb, kr, sh, store, longer))
            (ROOT / "run" / "recorder_status.json").write_text(json.dumps(st, default=str))
            store.write("recorder", "health", **{k: v for k, v in st.items() if k not in ("t", "lines")})
            store.flush()
            try:
                await asyncio.wait_for(stop.wait(), timeout=10.0)
            except asyncio.TimeoutError:
                pass

    tasks = [asyncio.create_task(x) for x in (kal.run(stop), cf.run(stop), cf.run_app_feed(stop), cb.run(stop), kr.run(stop), longer.run(stop),
                                              shadow_loop(), status_loop())]
    await stop.wait()
    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)
    store.write("recorder", "stop")
    store.close()
    (ROOT / "run" / "recorder.pid").unlink(missing_ok=True)


if __name__ == "__main__":
    asyncio.run(main())
