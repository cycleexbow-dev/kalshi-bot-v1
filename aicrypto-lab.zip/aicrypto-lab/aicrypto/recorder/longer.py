"""Low-frequency recorder for the real exchange's hourly and daily financial-price markets (owner request 2026-11-11).

Public, unsigned, GET-only (the guarded KalshiRestClient). Separate stream ("kalshi_real_long") so the
15-minute recording and the research experiment (15-minute only) are unaffected.

Every QUOTE_EVERY_S: one request per series for its open markets; market terms are recorded on first sight
or change, prices only when they change (top of book and sizes come with the market list; no depth).
Every SETTLE_EVERY_S: each series' recently settled markets with their result and settlement value.
Failed requests are recorded as errors; nothing is estimated.

Series list (Phase B, 2026-11-12): the fixed list below PLUS every non-15-minute series the multi-timeframe registry
(python -m aicrypto.timeframes discover) found eligible for the priority assets, so new weekly, monthly and yearly
series are picked up without code changes. The registry file is re-read every RELOAD_S; no restart needed.
Hourly and daily series are polled every QUOTE_EVERY_S, weekly and longer every SLOW_EVERY_S.
Path-dependent or composite series (e.g. "BTC max daily", "gold vs silver") never qualify, as in the app's
eligibility rules.

Each quote cycle writes one "cycle" line (how many series were polled, which failed), so missing minutes can be
detected later instead of guessed (aicrypto.timeframes.quality).
"""
from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

SRC = "kalshi_real_long"
SERIES = {
    # hourly ladders (an hourly event plus the 5 pm daily event)
    "KXBTCD": "BTC", "KXBTC": "BTC", "KXETHD": "ETH", "KXETH": "ETH", "KXSOLD": "SOL", "KXSOLE": "SOL", "KXSOL": "SOL",
    "KXXRPD": "XRP", "KXXRP": "XRP", "KXDOGED": "DOGE", "KXDOGE": "DOGE",
    "KXGOLDH": "GOLD", "KXSILVERH": "SILVER", "KXWTIH": "WTI",
    # daily
    "BTCD": "BTC", "BTC": "BTC", "ETHD": "ETH", "ETH": "ETH",
    "KXGOLDD": "GOLD", "KXSILVERD": "SILVER", "KXCOPPERD": "COPPER", "KXWTI": "WTI",
}
QUOTE_EVERY_S = 60.0
SLOW_EVERY_S = 300.0
SETTLE_EVERY_S = 300.0
RELOAD_S = 1800.0
PRIORITY_ASSETS = ("BTC", "ETH", "SOL", "XRP", "DOGE", "GOLD", "SILVER", "COPPER", "WTI")
FAST_BUCKETS = ("1h", "multi_hour", "daily")
FIXED_BUCKET = {s: ("daily" if s in ("BTCD", "BTC", "ETHD", "ETH", "KXGOLDD", "KXSILVERD", "KXCOPPERD", "KXWTI") else "1h")
                for s in SERIES}


def series_plan(root: Optional[Path]) -> Dict[str, Dict[str, str]]:
    """{series: {"asset", "bucket"}}: the fixed list plus the registry's eligible non-15-minute priority series."""
    plan = {s: {"asset": a, "bucket": FIXED_BUCKET[s]} for s, a in SERIES.items()}
    if root is None:
        return plan
    try:
        reg = json.loads((Path(root) / "user_data" / "kalshi" / "timeframes" / "registry.json").read_text())
    except (OSError, ValueError):
        return plan
    for r in reg.get("rows", []):
        if r.get("asset") in PRIORITY_ASSETS and r.get("bucket") not in ("15m", "<=5m", "unknown") and r.get("series"):
            plan.setdefault(r["series"], {"asset": r["asset"], "bucket": r["bucket"]})
    return plan


def interval_for(bucket: str) -> float:
    return QUOTE_EVERY_S if bucket in FAST_BUCKETS else SLOW_EVERY_S


def _ts(iso: Optional[str]) -> Optional[float]:
    from datetime import datetime
    if not iso:
        return None
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


class LongerDurations:
    def __init__(self, store, client=None, clock=time.time, series: Optional[Dict[str, str]] = None,
                 root: Optional[Path] = None):
        self.store, self.clock, self.root = store, clock, root
        self._client = client
        self.fixed = series is not None
        self.buckets: Dict[str, str] = {}
        self.series: Dict[str, str] = {}
        self.last_poll: Dict[str, float] = {}
        self._loaded = 0.0
        self.stats = {"polls": 0, "errors": 0, "markets": 0, "quotes": 0, "settled": 0, "series": 0,
                      "cycles": 0, "series_failed_last": 0}
        if series is not None:
            self.series = dict(series)
            self.buckets = {s: FIXED_BUCKET.get(s, "1h") for s in self.series}
            self.stats["series"] = len(self.series)
        else:
            self.reload_series()
        self.meta: Dict[str, tuple] = {}
        self.quotes: Dict[str, tuple] = {}
        self.settled_seen: set = set()

    def reload_series(self) -> None:
        plan = series_plan(self.root)
        new = {s: p["asset"] for s, p in plan.items()}
        self._loaded = self.clock()
        if new != self.series:
            self.series, self.buckets = new, {s: p["bucket"] for s, p in plan.items()}
            self.stats["series"] = len(self.series)
            self.store.write(SRC, "series_set", series={s: [self.series[s], self.buckets[s]] for s in sorted(self.series)})

    def client(self):
        if self._client is None:
            from ..kalshi.client import KalshiRestClient
            # 3 retries with exponential back-off and jitter (transport): a rate-limited poll is recovered, not lost
            self._client = KalshiRestClient("production", signer=None, public=True, requests_per_second=1.0, priority="high",
                                            timeout_s=10.0, max_retries=3)
        return self._client

    async def _list(self, params: Dict[str, Any], what: str) -> Optional[List[Dict[str, Any]]]:
        out: List[Dict[str, Any]] = []
        cursor = None
        for _ in range(5):                                # at most 5 pages (5,000 markets) per series
            p = dict(params, limit=1000, cursor=cursor) if cursor else dict(params, limit=1000)
            try:
                d = await self.client().transport.request("GET", "/markets", p)
            except Exception as e:
                self.stats["errors"] += 1
                self.store.write(SRC, "error", what=what, error=f"{type(e).__name__}: {str(e)[:200]}")
                return None
            self.stats["polls"] += 1
            out += [m for m in (d or {}).get("markets", []) if isinstance(m, dict)]
            cursor = (d or {}).get("cursor")
            if not cursor:
                break
        return out

    async def poll_quotes(self, due_only: bool = False) -> int:
        n, polled, failed = 0, 0, []
        now = self.clock()
        for s, asset in list(self.series.items()):
            if due_only and now - self.last_poll.get(s, 0.0) < interval_for(self.buckets.get(s, "1h")) - 1.0:
                continue
            self.last_poll[s] = now
            polled += 1
            ms = await self._list({"series_ticker": s, "status": "open"}, f"open {s}")
            if ms is None:
                failed.append(s)
            for m in ms or []:
                t = m.get("ticker")
                if not t:
                    continue
                meta = (m.get("status"), m.get("strike_type"), m.get("floor_strike"), m.get("cap_strike"), m.get("close_time"))
                if self.meta.get(t) != meta:
                    self.meta[t] = meta
                    self.store.write(SRC, "market_meta", ticker=t, series=s, asset=asset, event=m.get("event_ticker"),
                                     status=meta[0], strike_type=meta[1], floor_strike=meta[2], cap_strike=meta[3],
                                     open_ts=_ts(m.get("open_time")), close_ts=_ts(m.get("close_time")),
                                     title=m.get("title"), subtitle=m.get("yes_sub_title"))
                    self.stats["markets"] += 1
                q = (m.get("yes_bid_dollars"), m.get("yes_ask_dollars"), m.get("yes_bid_size_fp"), m.get("yes_ask_size_fp"),
                     m.get("last_price_dollars"), m.get("volume_fp"))
                if self.quotes.get(t) != q:
                    self.quotes[t] = q
                    self.store.write(SRC, "quote", ticker=t, yes_bid=q[0], yes_ask=q[1], bid_size=q[2], ask_size=q[3], last=q[4], volume=q[5])
                    self.stats["quotes"] += 1
                    n += 1
        self.stats["cycles"] += 1
        self.stats["series_failed_last"] = len(failed)
        self.store.write(SRC, "cycle", polled=polled, failed=failed)
        return n

    async def poll_settled(self) -> int:
        n = 0
        since = int(self.clock() - 6 * 3600)
        for s, asset in self.series.items():
            ms = await self._list({"series_ticker": s, "status": "settled", "min_close_ts": since}, f"settled {s}")
            for m in ms or []:
                t = m.get("ticker")
                r = (m.get("result") or "").lower()
                if not t or t in self.settled_seen or r not in ("yes", "no"):
                    continue
                self.settled_seen.add(t)
                self.store.write(SRC, "settled", ticker=t, series=s, asset=asset, result=r, settle_value=m.get("expiration_value"),
                                 floor_strike=m.get("floor_strike"), cap_strike=m.get("cap_strike"), close_ts=_ts(m.get("close_time")))
                self.quotes.pop(t, None)
                self.meta.pop(t, None)
                self.stats["settled"] += 1
                n += 1
        return n

    async def run(self, stop: asyncio.Event) -> None:
        last_settle = 0.0
        while not stop.is_set():
            t0 = self.clock()
            if not self.fixed and t0 - self._loaded >= RELOAD_S:
                try:
                    self.reload_series()
                except Exception as e:                    # keep the current list; never stop recording over this
                    self.store.write(SRC, "error", what="reload series", error=f"{type(e).__name__}: {str(e)[:200]}")
            await self.poll_quotes(due_only=True)
            if t0 - last_settle >= SETTLE_EVERY_S:
                last_settle = t0
                await self.poll_settled()
            try:
                await asyncio.wait_for(stop.wait(), timeout=max(1.0, QUOTE_EVERY_S - (self.clock() - t0)))
            except asyncio.TimeoutError:
                pass
