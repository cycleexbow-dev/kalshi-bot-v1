"""CF Benchmarks settlement-index recorder (Kalshi WebSocket, read-only market-data channels).

Kalshi distributes the CF Benchmarks real-time indices that its 15-minute crypto markets settle on
(the simple average of the 60 one-second prints before the close). Production WebSocket access needs
an account key, which is forbidden, so the index is read from the DEMO WebSocket with the demo key:
it is the same index. Every message is recorded with the local receive time and the publisher's
timestamp (latency), and the socket's sequence gaps and reconnects are recorded too.
"""
from __future__ import annotations

import asyncio
import json
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional, Tuple

from ..kalshi.settlement_map import CF_5HZ_ASSETS, CF_INDEX_BY_ASSET

SRC = "cfindex"
GAP_S = 1.5          # 5 Hz channel publishes every 0.2 s, the 1 Hz channel every 1 s: longer silence is a gap


class CFIndex:
    def __init__(self, store, signer_factory, assets: List[str], clock=time.time):
        self.store, self.signer_factory, self.clock = store, signer_factory, clock
        self.assets = [a for a in assets if a in CF_INDEX_BY_ASSET]
        # index_id -> deque of (local receive time, value, publisher time)
        self.prints: Dict[str, Deque[Tuple[float, float, Optional[float]]]] = {}
        self.last: Dict[str, Tuple[float, float, Optional[float]]] = {}
        self.stats = {"messages": 0, "invalid": 0, "reconnects": 0, "seq_gaps": 0, "state": "starting"}
        self._seen: Dict[str, Tuple[set, Deque[float]]] = {}
        self.ws = None

    def asset_index(self, asset: str) -> Optional[str]:
        return CF_INDEX_BY_ASSET.get(asset)

    def on_value(self, data: Dict[str, Any], t_recv: float, via: str = "own") -> None:
        """One index message from our own connection ("own") or the app's copy ("app"). The same print
        arriving from both is recorded once; a print only one source received fills the other's gap."""
        m = data.get("msg") or {}
        idx = m.get("index_id")
        inner: Dict[str, Any] = {}
        if isinstance(m.get("data"), str):           # 1 Hz channel: the print is a JSON string inside "data"
            try:
                inner = json.loads(m["data"])
            except json.JSONDecodeError:
                inner = {}
        try:
            raw_v = m.get("value_usd") if m.get("value_usd") is not None else (m.get("value") if m.get("value") is not None else inner.get("value"))
            v = float(raw_v)
        except (TypeError, ValueError):
            self.stats["invalid"] += 1
            self.store.write(SRC, "invalid", raw=m)
            return
        src = m.get("source_ts_ms") or inner.get("time")
        src_s = float(src) / 1000.0 if src else None
        if src_s is not None:
            seen, order = self._seen.setdefault(idx, (set(), deque()))
            key = round(src_s, 3)
            if key in seen:
                self.stats["duplicates"] = self.stats.get("duplicates", 0) + 1
                return
            seen.add(key)
            order.append(key)
            if len(order) > 5000:
                seen.discard(order.popleft())
        avg = m.get("avg_60s_data")
        if isinstance(avg, dict):                     # Kalshi's running 60-second average (the settlement statistic)
            self.store.write(SRC, "avg60", t=t_recv, index=idx, value=avg.get("value"), window_size=avg.get("window_size"),
                             start_ms=avg.get("window_start_ts_ms"), end_ms=avg.get("window_end_ts_exclusive"))
        self.stats["messages"] += 1
        self.stats[f"via_{via}"] = self.stats.get(f"via_{via}", 0) + 1
        prev = self.last.get(idx)
        newer = prev is None or not prev[2] or not src_s or src_s >= prev[2]
        if newer:
            if prev is not None and prev[2] and src_s and src_s - prev[2] > GAP_S:
                self.stats["gaps"] = self.stats.get("gaps", 0) + 1     # recorded, never estimated
                self.store.write(SRC, "gap", t=t_recv, index=idx, from_ts=prev[2], to_ts=src_s, seconds=round(src_s - prev[2], 3))
            self.last[idx] = (t_recv, v, src_s)
        else:
            self.stats["late_fill"] = self.stats.get("late_fill", 0) + 1  # a real print the other source missed
        self.prints.setdefault(idx, deque(maxlen=20000)).append((t_recv, v, src_s))
        self.store.write(SRC, "value", t=t_recv, index=idx, value=v, src_ts=src_s, ch=data.get("type"), via=via,
                         lat_ms=round((t_recv - src_s) * 1000, 1) if src_s else None, seq=data.get("seq"))

    def series(self, idx: str, since: float) -> List[Tuple[float, float]]:
        """(publisher time if known else receive time, value) for prints since `since`, in time order."""
        return sorted(((s or r), v) for r, v, s in self.prints.get(idx, ()) if (s or r) >= since)

    async def run_app_feed(self, stop: asyncio.Event, url: str = "http://127.0.0.1:8765/api/terminal/cf_stream") -> None:
        """Second, independent source: the desktop app's own copy of the same index feed (local, read-only).
        Used whenever the app is running; when it is not, the recorder's own connection carries on alone."""
        import httpx
        while not stop.is_set():
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(10.0, read=60.0)) as http:
                    async with http.stream("GET", url) as r:
                        if r.status_code != 200:
                            raise RuntimeError(f"HTTP {r.status_code}")
                        self.stats["app_feed"] = "live"
                        self.store.write(SRC, "app_feed", state="connected")
                        async for line in r.aiter_lines():
                            if stop.is_set():
                                break
                            if line.startswith("data: "):
                                item = json.loads(line[6:])
                                self.on_value(item["data"], float(item["t_recv"]), via="app")
            except Exception as e:
                if self.stats.get("app_feed") == "live":
                    self.store.write(SRC, "app_feed", state="disconnected", error=type(e).__name__)
                self.stats["app_feed"] = "app not running"
            try:
                await asyncio.wait_for(stop.wait(), timeout=10.0)
            except asyncio.TimeoutError:
                pass

    async def run(self, stop: asyncio.Event) -> None:
        from ..kalshi.websocket import KalshiWebSocket
        signer = self.signer_factory()
        if signer is None:
            self.stats["state"] = "no_demo_key"
            self.store.write(SRC, "error", error="demo key not configured: CF index NOT recorded")
            await stop.wait()
            return
        ws = self.ws = KalshiWebSocket(signer, "demo")

        async def handler(msg):
            if msg.type in ("cfbenchmarks_value", "cfbenchmarks_value_5hz"):
                self.on_value(msg.data, msg.t_recv_ns / 1e9 - time.monotonic() + self.clock() if msg.t_recv_ns else self.clock())
        ws.handlers.append(handler)
        fast = sorted(CF_INDEX_BY_ASSET[a] for a in self.assets if a in CF_5HZ_ASSETS)
        slow = sorted(CF_INDEX_BY_ASSET[a] for a in self.assets if a not in CF_5HZ_ASSETS)
        if fast:
            await ws.subscribe(["cfbenchmarks_value_5hz"], index_ids=fast)
        if slow:
            await ws.subscribe(["cfbenchmarks_value"], index_ids=slow)
        task = asyncio.create_task(ws.run())
        last = {"connects": 0, "seq_gaps": 0}
        try:
            while not stop.is_set():
                st = ws.stats
                self.stats["state"] = "live" if ws.is_connected else "connecting"
                if st.connects > last["connects"]:
                    if last["connects"]:
                        self.stats["reconnects"] += 1
                        self.store.write(SRC, "reconnect", connects=st.connects, last_close=getattr(st, "last_close", None))
                    last["connects"] = st.connects
                if st.seq_gaps > last["seq_gaps"]:
                    self.store.write(SRC, "seq_gap", total=st.seq_gaps, new=st.seq_gaps - last["seq_gaps"])
                    self.stats["seq_gaps"] = last["seq_gaps"] = st.seq_gaps
                try:
                    await asyncio.wait_for(stop.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    pass
        finally:
            await ws.stop()
            task.cancel()
