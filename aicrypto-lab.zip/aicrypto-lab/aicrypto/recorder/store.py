"""Append-only, hourly-rotated gzip JSONL files, one stream per source.

Layout: <root>/user_data/kalshi/recordings/real/<YYYY-MM-DD>/<source>-<HH>.jsonl.gz (UTC).
Every line: {"t": local wall-clock receive time (s), "m": monotonic (s), "k": kind, ...fields}.
Files are flushed every couple of seconds (gzip sync flush), so a crash loses at most that much and
every file stays readable while it is being written.
"""
from __future__ import annotations

import gzip
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, Optional, Tuple


def recordings_dir(root: Path) -> Path:
    d = Path(root) / "user_data" / "kalshi" / "recordings" / "real"
    d.mkdir(parents=True, exist_ok=True)
    return d


class Store:
    def __init__(self, root: Path, flush_s: float = 2.0, clock=time.time):
        self.base = recordings_dir(root)
        self.flush_s = flush_s
        self.clock = clock
        self._files: Dict[str, Tuple[str, Any]] = {}
        self._last_flush = 0.0
        self.lines: Dict[str, int] = {}

    def _file(self, src: str, t: float):
        dt = datetime.fromtimestamp(t, timezone.utc)
        key = dt.strftime("%Y-%m-%d/%H")
        cur = self._files.get(src)
        if cur and cur[0] == key:
            return cur[1]
        if cur:
            cur[1].close()
        d = self.base / dt.strftime("%Y-%m-%d")
        d.mkdir(parents=True, exist_ok=True)
        f = gzip.open(d / f"{src}-{dt.strftime('%H')}.jsonl.gz", "at", compresslevel=6)
        self._files[src] = (key, f)
        return f

    def write(self, src: str, kind: str, t: Optional[float] = None, **fields: Any) -> None:
        t = self.clock() if t is None else t
        rec = {"t": round(t, 4), "m": round(time.monotonic(), 4), "k": kind, **fields}
        self._file(src, t).write(json.dumps(rec, separators=(",", ":"), default=str) + "\n")
        self.lines[src] = self.lines.get(src, 0) + 1
        if t - self._last_flush >= self.flush_s:
            self.flush()
            self._last_flush = t

    def flush(self) -> None:
        for _, f in self._files.values():
            try:
                f.flush()
            except Exception:
                pass

    def close(self) -> None:
        for _, f in self._files.values():
            try:
                f.close()
            except Exception:
                pass
        self._files.clear()


def read(path: Path) -> Iterator[Dict[str, Any]]:
    """Read one recording file; tolerates a truncated last line from a crash."""
    try:
        with gzip.open(path, "rt") as f:
            for line in f:
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    continue
    except (EOFError, OSError):
        return


def read_source(root: Path, src: str, day: Optional[str] = None) -> Iterator[Dict[str, Any]]:
    base = recordings_dir(root)
    days = [base / day] if day else sorted(p for p in base.iterdir() if p.is_dir())
    for d in days:
        for p in sorted(d.glob(f"{src}-*.jsonl.gz")):
            yield from read(p)
