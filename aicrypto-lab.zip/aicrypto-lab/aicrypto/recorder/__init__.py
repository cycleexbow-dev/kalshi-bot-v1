"""Continuous, read-only market-data recorder and production-price shadow engine (owner request 2026-11-11).

Runs as its own process (`python -m aicrypto.recorder`, scripts/start_recorder.sh) so it can never slow
the desktop app or the demo bot. It records, with local reception timestamps:

* Kalshi REAL exchange (production) public data through the guarded GET-only KalshiRestClient, unsigned:
  market metadata, quotes, order-book depth, trades, settlements. No account, no keys, no orders.
* CF Benchmarks settlement-index values from Kalshi's demo WebSocket (read-only market-data channel,
  demo key), the same index the real 15-minute crypto markets settle on.
* Coinbase and Kraken public spot feeds.

Missing or invalid data is recorded as such (gap / error events); nothing is estimated or filled in.
The shadow engine evaluates the lab's candidate rules on these real prices and simulates fills
conservatively. It has no order code: nothing in this package can place an order anywhere.
"""
