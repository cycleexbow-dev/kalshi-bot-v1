"""Promotion gates. Reject-by-default.

Passing every gate means "not rejected by these checks on this data"; it is not a
claim about future returns, and the wording in reports reflects that.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..research.leakage import LookaheadReport, RecursiveReport
from ..research.walkforward import WalkForwardResult
from ..settings import Gates


@dataclass
class GateResult:
    name: str
    passed: bool
    value: float
    threshold: float
    note: str = ""


@dataclass
class GateOutcome:
    results: List[GateResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(r.passed for r in self.results)

    @property
    def failed_names(self) -> List[str]:
        return [r.name for r in self.results if not r.passed]

    def to_dict(self) -> dict:
        return {"passed": self.passed, "gates": [r.__dict__ for r in self.results]}


def evaluate_gates(
    wf: WalkForwardResult,
    look: LookaheadReport,
    rec: RecursiveReport,
    gates: Gates,
    neighbour_retention: Optional[float] = None,
    freqtrade_trade_ratio: Optional[float] = None,
) -> GateOutcome:
    g = gates
    m = wf.oos_metrics
    out = GateOutcome()
    add = out.results.append

    add(GateResult("min_trades", wf.oos_trades >= g.min_trades, wf.oos_trades, g.min_trades))
    add(GateResult("min_folds", wf.n_folds >= g.min_folds, wf.n_folds, g.min_folds))
    add(GateResult("positive_fold_fraction", wf.positive_fold_fraction >= g.min_positive_fold_fraction,
                   wf.positive_fold_fraction, g.min_positive_fold_fraction))
    add(GateResult("oos_sharpe", m["sharpe"] >= g.min_oos_sharpe, m["sharpe"], g.min_oos_sharpe))
    add(GateResult("oos_is_ratio", wf.oos_is_ratio >= g.min_oos_is_ratio, wf.oos_is_ratio, g.min_oos_is_ratio,
                   "IS->OOS decay"))
    add(GateResult("max_drawdown", m["max_drawdown"] <= g.max_drawdown, m["max_drawdown"], g.max_drawdown))
    add(GateResult("lookahead", look.total_diffs <= g.max_lookahead_diffs, look.total_diffs, g.max_lookahead_diffs,
                   look.detail))
    add(GateResult("recursive", rec.ok and rec.max_rel_drift <= g.max_recursive_drift,
                   rec.max_rel_drift if rec.ok else float(rec.signal_flips), g.max_recursive_drift, rec.detail))
    if neighbour_retention is not None:
        add(GateResult("parameter_stability", neighbour_retention >= g.min_neighbour_retention,
                       neighbour_retention, g.min_neighbour_retention, "median neighbour OOS return / own"))
    if freqtrade_trade_ratio is not None:
        ok = abs(freqtrade_trade_ratio - 1.0) <= g.freqtrade_trade_count_tolerance
        add(GateResult("freqtrade_agreement", ok, freqtrade_trade_ratio, g.freqtrade_trade_count_tolerance,
                       "freqtrade trades / our trades"))
    return out


def neighbour_retention(own_return: float, neighbour_returns: List[float]) -> float:
    """Median neighbour OOS return relative to own. 1.0 = neighbours do as well.

    If own return is <= 0 the stability question is moot (it will fail other
    gates); return 0 so the gate fails loudly rather than dividing by zero.
    """
    if own_return <= 0 or not neighbour_returns:
        return 0.0
    s = sorted(neighbour_returns)
    med = s[len(s) // 2] if len(s) % 2 else 0.5 * (s[len(s) // 2 - 1] + s[len(s) // 2])
    return max(0.0, med / own_return)
