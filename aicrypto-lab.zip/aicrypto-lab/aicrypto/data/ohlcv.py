"""OHLCV loading/saving compatible with Freqtrade's feather data layout.

Files live at `<user_data>/data/<exchange>/<PAIR>-<tf>.feather` with columns
date, open, high, low, close, volume (date in ms, UTC).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

COLUMNS = ["date", "open", "high", "low", "close", "volume"]

_TF_UNITS = {"m": 1, "h": 60, "d": 1440, "w": 10080}


class DataIntegrityError(ValueError):
    pass


def timeframe_to_minutes(tf: str) -> int:
    unit = tf[-1]
    if unit not in _TF_UNITS:
        raise ValueError(f"unsupported timeframe {tf}")
    return int(tf[:-1]) * _TF_UNITS[unit]


def pair_filename(data_dir: Path, pair: str, timeframe: str) -> Path:
    return Path(data_dir) / f"{pair.replace('/', '_').replace(':', '_')}-{timeframe}.feather"


@dataclass(frozen=True)
class DatasetInfo:
    pair: str
    timeframe: str
    rows: int
    start: str
    end: str
    fingerprint: str


def fingerprint(df: pd.DataFrame, pair: str, timeframe: str) -> DatasetInfo:
    """Stable identity for a dataset so experiments record exactly what they saw."""
    h = hashlib.sha256()
    h.update(f"{pair}|{timeframe}|{len(df)}".encode())
    if len(df):
        h.update(str(int(df["date"].iloc[0].timestamp())).encode())
        h.update(str(int(df["date"].iloc[-1].timestamp())).encode())
        # round to avoid float32/float64 noise between writers
        h.update(np.round(df["close"].to_numpy(dtype=np.float64), 6).tobytes())
    start = df["date"].iloc[0].isoformat() if len(df) else ""
    end = df["date"].iloc[-1].isoformat() if len(df) else ""
    return DatasetInfo(pair, timeframe, len(df), start, end, h.hexdigest()[:16])


def validate_ohlcv(df: pd.DataFrame, timeframe: str, max_gap_fraction: float = 0.02) -> None:
    """Raise DataIntegrityError on structural problems; tolerate small gap fractions."""
    missing = [c for c in COLUMNS if c not in df.columns]
    if missing:
        raise DataIntegrityError(f"missing columns {missing}")
    if len(df) < 2:
        raise DataIntegrityError("need at least 2 rows")
    d = df["date"]
    if not d.is_monotonic_increasing:
        raise DataIntegrityError("date not monotonic increasing")
    if d.duplicated().any():
        raise DataIntegrityError("duplicate timestamps")
    if df[["open", "high", "low", "close"]].isna().any().any():
        raise DataIntegrityError("NaN in OHLC")
    bad = (df["high"] < df[["open", "close", "low"]].max(axis=1)) | (df["low"] > df[["open", "close"]].min(axis=1))
    if bad.any():
        raise DataIntegrityError(f"{int(bad.sum())} rows with high/low inconsistent with open/close")
    if (df[["open", "high", "low", "close"]] <= 0).any().any():
        raise DataIntegrityError("non-positive prices")
    step = pd.Timedelta(minutes=timeframe_to_minutes(timeframe))
    diffs = d.diff().dropna()
    gaps = (diffs != step).sum()
    if gaps / max(len(diffs), 1) > max_gap_fraction:
        raise DataIntegrityError(f"{gaps} irregular intervals ({gaps/len(diffs):.1%}) exceeds tolerance")


def _normalise(df: pd.DataFrame) -> pd.DataFrame:
    df = df.loc[:, COLUMNS].copy()
    if not pd.api.types.is_datetime64_any_dtype(df["date"]):
        df["date"] = pd.to_datetime(df["date"], unit="ms", utc=True)
    elif df["date"].dt.tz is None:
        df["date"] = df["date"].dt.tz_localize("UTC")
    else:
        df["date"] = df["date"].dt.tz_convert("UTC")
    for c in ("open", "high", "low", "close", "volume"):
        df[c] = df[c].astype("float64")
    return df.reset_index(drop=True)


def save_ohlcv(df: pd.DataFrame, data_dir: Path, pair: str, timeframe: str) -> Path:
    path = pair_filename(data_dir, pair, timeframe)
    path.parent.mkdir(parents=True, exist_ok=True)
    out = _normalise(df)
    # Freqtrade stores ms-precision UTC timestamps.
    out["date"] = out["date"].dt.as_unit("ms")
    out.to_feather(path)
    return path


def load_ohlcv(
    data_dir: Path,
    pair: str,
    timeframe: str,
    max_rows: Optional[int] = None,
    validate: bool = True,
) -> pd.DataFrame:
    """Load candles. `max_rows` keeps only the most recent rows (memory bound)."""
    path = pair_filename(data_dir, pair, timeframe)
    if not path.exists():
        raise FileNotFoundError(f"no data for {pair} {timeframe} at {path}; run scripts/download_data.sh")
    df = pd.read_feather(path)
    df = _normalise(df)
    if max_rows is not None and len(df) > max_rows:
        df = df.iloc[-max_rows:].reset_index(drop=True)
    if validate:
        validate_ohlcv(df, timeframe)
    return df
