"""Synthetic OHLCV generator for tests and offline demos.

Regime-switching geometric random walk with volatility clustering. Deterministic
under a seed. Synthetic results say nothing about real markets; they exist so the
pipeline can be exercised without network access.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .ohlcv import timeframe_to_minutes


def synthetic_ohlcv(
    n: int = 5000,
    timeframe: str = "1h",
    seed: int = 0,
    start: str = "2023-01-01",
    s0: float = 30_000.0,
    base_vol: float = 0.01,
    regime_len: int = 400,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    step = pd.Timedelta(minutes=timeframe_to_minutes(timeframe))
    dates = pd.date_range(start=start, periods=n, freq=step, tz="UTC")

    # regimes: drift and vol multipliers switch every ~regime_len bars
    n_reg = n // regime_len + 1
    drifts = rng.choice([-0.0004, 0.0, 0.0004], size=n_reg)
    vols = rng.choice([0.6, 1.0, 1.8], size=n_reg)
    drift = np.repeat(drifts, regime_len)[:n]
    vol = np.repeat(vols, regime_len)[:n] * base_vol

    # GARCH-ish clustering
    eps = rng.standard_normal(n)
    sigma = np.empty(n)
    sigma[0] = vol[0]
    for i in range(1, n):
        sigma[i] = np.sqrt(0.05 * vol[i] ** 2 + 0.85 * sigma[i - 1] ** 2 + 0.10 * (sigma[i - 1] * eps[i - 1]) ** 2)
    rets = drift + sigma * eps
    close = s0 * np.exp(np.cumsum(rets))
    open_ = np.concatenate([[s0], close[:-1]])
    intrabar = np.abs(rng.standard_normal(n)) * sigma * close
    high = np.maximum(open_, close) + intrabar
    low = np.minimum(open_, close) - np.abs(rng.standard_normal(n)) * sigma * close
    low = np.maximum(low, 1e-6)
    volume = rng.lognormal(mean=np.log(100.0), sigma=0.5, size=n) * (1 + 5 * np.abs(rets) / base_vol)

    return pd.DataFrame(
        {"date": dates, "open": open_, "high": high, "low": low, "close": close, "volume": volume}
    )
