# aicrypto-lab

A bounded, reproducible crypto strategy research lab with Freqtrade **paper trading**.
Simulated capital $1,000 · BTC/USDT, ETH/USDT, SOL/USDT · spot only, no leverage ·
2% of equity at risk per trade.

**There is no real-money execution in this system.** `dry_run=true` is hard-coded,
exchange keys are written empty, `docker-compose.yml` passes `--dry-run` on the
command line, `aicrypto safety-check` scans every config before the bot starts,
and the lifecycle has no live state. See `ARCHITECTURE.md` §3.

**Nothing here claims profitability.** Backtests and walk-forward runs describe
simulated behaviour on past data under modelled costs (0.10% fee + 5 bps slippage
per side). Promotion gates reject candidates; they do not certify them.

## What it does

| Stage | Module | Notes |
|---|---|---|
| Data | `aicrypto/data` | Freqtrade feather format, integrity checks, dataset fingerprints, synthetic generator for offline runs |
| Strategy generation | `aicrypto/strategies` | Declarative `StrategySpec` (4 families: EMA cross, RSI reversion, Donchian breakout, Bollinger reversion), seeded sampling & mutation, ±1-step neighbours |
| Backtest | `aicrypto/research/backtest.py` | Portfolio, long-only, **next-bar-open fills**, fees, slippage, 2%-risk sizing capped at 95% equity, stop / trailing / time / signal exits |
| Walk-forward | `aicrypto/research/walkforward.py` | Rolling or anchored, bounded in-sample random search, untouched OOS windows, per-fold reporting |
| Leakage | `aicrypto/research/leakage.py` | Lookahead probe (truncate + scramble future), recursive/warm-up probe |
| Tracking | `aicrypto/experiments` | SQLite + JSON artefacts; `run_id = hash(spec, data, costs, config, code, seed)` |
| Gates | `aicrypto/promotion` | min trades, folds, positive-fold fraction, OOS Sharpe, IS→OOS decay, max DD, lookahead, recursive, parameter stability, Freqtrade agreement |
| Autonomous loop | `aicrypto/agent` | Budgeted by candidates / minutes / memory; explicit specs → mutations → random |
| Freqtrade | `aicrypto/freqtrade_bridge` | Renders standalone `IStrategy` files, paper-only config, runs Freqtrade's own backtesting / lookahead-analysis / recursive-analysis as a second opinion |
| Observability | `aicrypto/dashboard`, `aicrypto/reporting` | Read-only FastAPI dashboard on 127.0.0.1:8080; daily Markdown report |

## Quick start (WSL Ubuntu)

See `docs/WSL_SETUP.md` for the full walkthrough (incl. `.wslconfig` memory cap).

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest -q                      # 55 tests
aicrypto audit
scripts/download_data.sh 1095 15m 1h 4h  # Freqtrade download-data via Docker (public API, no keys)
aicrypto research --timeframe 1h         # bounded session (defaults: 40 candidates / 30 min)
aicrypto promote --dry-run-config        # VALIDATED -> PAPER, export strategy + config
aicrypto verify-ft <ClassName> --timerange 20250101-
scripts/start_dryrun.sh                  # freqtrade --dry-run + dashboard
aicrypto report --print
```

Offline demo without network or Docker: `make demo` (synthetic candles; results are
meaningless for real markets and exist only to exercise the pipeline).

## Claude Code

`CLAUDE.md` defines what Claude Code may do here (propose specs and families,
run research, write the lab notebook) and what it must never do (anything that
could place a real order, touch the safety module, loosen budgets, or claim
profitability).

## Layout

```
aicrypto/           package (see table above)
config/research.yaml  capital, markets, costs, walk-forward, gates, budgets
user_data/          Freqtrade dir: data/, strategies/, config_dryrun.json, dry-run sqlite
experiments/        tracker.sqlite, runs/<run_id>/, research.log
reports/            daily-YYYY-MM-DD.md, latest.md
specs/              hand-written StrategySpec JSON proposals
scripts/            wsl_audit.sh, download_data.sh, start_dryrun.sh, daily.sh
docs/               ENV_AUDIT.md, WSL_SETUP.md, RESEARCH_LOG.md
```
