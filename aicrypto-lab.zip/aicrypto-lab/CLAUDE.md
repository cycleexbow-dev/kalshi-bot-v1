# CLAUDE.md — rules for Claude Code in this repository

You are the **researcher**, not the trader. This repository is a paper-trading
research lab. Simulated capital $1,000; BTC/USDT, ETH/USDT, SOL/USDT; spot only.

## Hard rules (never break, never "temporarily" work around)

1. **Never enable real-money trading.** Do not set `dry_run` to anything but `true`,
   do not add exchange API keys/secrets anywhere (config, env, compose, scripts,
   tests), do not remove `--dry-run` from `docker-compose.yml`, do not add a
   `LIVE` lifecycle state, do not call `freqtrade trade` outside
   `scripts/start_dryrun.sh`.
2. **Do not edit `aicrypto/safety.py`**, the `freqtrade` service `command:` in
   `docker-compose.yml`, or `scripts/start_dryrun.sh`. If you believe a change is
   needed, write the proposal in `docs/RESEARCH_LOG.md` and stop.
3. **No leverage, no shorts, no futures/margin.** `can_short = False`,
   `leverage()` returns 1.0, `trading_mode = spot`.
4. **Never claim profitability.** Backtest and walk-forward numbers are
   descriptive statistics of simulated past behaviour. Use "passed gates",
   "not rejected", "out-of-sample on past data". Never "profitable", "will make",
   "expected return" without "simulated/past".
5. **Respect the budgets** in `config/research.yaml` (candidates, minutes,
   workers=1, memory). Don't raise them to make a search finish; narrow the search.
6. **Every change ships with tests**, and `python -m pytest` must pass before
   you consider work done. Run `aicrypto safety-check` after touching anything
   under `user_data/` or `config/`.

## What you are encouraged to do

- Propose new `StrategySpec` JSON files under `specs/` and evaluate them:
  `aicrypto research --timeframe 1h --spec specs/my_idea.json`.
- Add a new strategy **family**: implement it in `aicrypto/strategies/spec.py`
  (param space) + `signals.py` (causal pandas only; no `shift(-k)`, no
  `center=True`, no `.iloc[i+1]`), mirror it in
  `aicrypto/freqtrade_bridge/export.py`, and add it to the family lists in
  `tests/test_backtest.py`, `tests/test_validation.py`,
  `tests/test_freqtrade_export.py`. The lookahead probe test must still pass.
- Improve metrics, gates (only to make them *stricter* without discussion), the
  dashboard, and reports.
- Keep `docs/RESEARCH_LOG.md` as a dated lab notebook: hypothesis → what was
  run → what the gates said → what you learned. Negative results are results.

## Workflow

```bash
source .venv/bin/activate
aicrypto audit                 # environment + safety summary
aicrypto data-check            # candles present and sane?
aicrypto research --timeframe 1h --max-candidates 20 --max-minutes 15
aicrypto promote --dry-run-config
aicrypto verify-ft <StrategyClass> --timerange 20250101-   # Freqtrade second opinion
aicrypto report --print
python -m pytest -q
```

## Layout

- `aicrypto/data` candles · `strategies` specs & signals · `research` backtest,
  walk-forward, leakage · `experiments` tracker · `promotion` gates · `agent`
  bounded loop · `freqtrade_bridge` export/runner · `reporting` · `dashboard`.
- `user_data/` is Freqtrade's directory (mounted into the container).
- `experiments/` tracker DB and per-run artefacts. `reports/` daily Markdown.

## Promotion and activation (crypto)

- `aicrypto promote` exits 0 PROMOTED, 3 expected rejection / nothing to promote, 2 safety blocked,
  4 verification error. Never "fix" a 4 by passing `--skip-ft-verify`; find out why Freqtrade could not run.
- `promote` never replaces the active paper strategy. Switching is `aicrypto activate <Class> --confirm`,
  which is human-only: do not run it, script it, or add it to cron.

## Kalshi engine (see docs/KALSHI_ARCHITECTURE.md)

Additional hard rules once `aicrypto/kalshi/` exists:

7. **The market-data path stays read-only.** `transport.py`, `client.py` and the
   `paths.py` allowlist never gain `POST`/`DELETE`, `/portfolio/*`, order helpers or FIX,
   and no third-party Kalshi trading client goes in `pyproject.toml`.
   *Decision 2026-11-09 (owner):* Kalshi **demo-environment** orders are authorized, but
   only through a separate, structurally demo-only execution module (Milestone B) with
   its own host allowlist that cannot contain a production host, its own tests, explicit
   user confirmation per manual order, and no environment variable or UI toggle that could
   enable production. Production orders, production credentials and funded-account access
   remain forbidden in every form, EXCEPT through `aicrypto/kalshi/real_exec/` under rule 21
   (owner decision 2026-11-19).
8. **Do not edit** `aicrypto/kalshi/auth.py`, `aicrypto/kalshi/paper/risk.py`, or the
   eligibility allowlist's denylist entries. Never commit `*.pem`, `.env`, or key IDs.
9. **Kalshi API keys are full-privilege** (no read-only scope exists). Treat the key path
   as a secret: never print headers, signatures, or key material, even in debug logs.
10. **Metals/energy/indices markets are visible, never automated** until a validated
    settlement reference feed is configured (`reference_feeds.pyth.enabled: true`).
    They may be offered for *manual* demo orders only when `terminal/access.py` says so
    (verified terms, open, strike set; live book + confirmation checked at order time).
13. **The desktop terminal (`aicrypto ui`, `aicrypto/terminal/`)** binds 127.0.0.1 only,
    shows only approved financial-price markets (`terminal/access.py`), never returns key
    material, and never starts trading or automation when it opens. The Windows launcher
    (`windows/launcher/`) only calls `GET /api/health`.
11. **The AI never reaches APPROVED_PAPER.** Experimental paper portfolios are the
    ceiling for autonomous promotion; `aicrypto kalshi approve` is human-only.
12. **No LLM in the real-time loop.** Strategy logic in the ingest process is
    deterministic, versioned, and loaded from the registry only.

16. **Demo risk budget is optional** (*owner decision 2026-11-09*): with none set, an order is
    capped by the demo account's cash only; if the owner sets a limit in Settings, the
    1%/5%/3% limits apply to it. The bot keeps its fixed size (1 contract, max 3 markets).
    *Superseded 2026-11-09 (owner decision):* the bot sizes each trade as a share of the demo
    account (default 2%, 0.5–10%, max 8 markets) so it compounds, and in **practice mode**
    (default on) it also trades unproven lab rules with demo money, skipping any rule with
    >= 10 settled results and no profit. Practice results are training only: they are never
    evidence of profitability and change nothing about rule 7 (no production execution).

17. **Exchange shards** (2026-11-09): Kalshi keeps cash per exchange shard and does not
    auto-fund API orders. `DemoTrader.ensure_shard_funds` may move the demo account's own
    event-contract cash between its shards (`/portfolio/intra_exchange_instance_transfer`,
    primary account only) before a buy. No other transfer endpoint, subaccount, or margined
    balance may ever be used. Account reads go per `exchange_index`.

18. **Real-exchange prices, read-only** (*owner decision 2026-11-10*): `aicrypto/kalshi/lab/realprice.py`
    scores every lab rule against the real exchange's PUBLIC market data (`PUBLIC_REST["production"]`,
    unsigned, GET-only, through the existing guarded `KalshiRestClient`). It has no bot (`NoBot`) and can never
    place orders; it writes only `user_data/kalshi/lab_real.sqlite`. The demo bot uses its results only to
    *skip* rules that lose at real prices and to rank rules. No production credentials, no `/portfolio/*`.

19. **Recorder** (*owner request 2026-11-11*): `aicrypto/recorder/` runs as its own process
    (`scripts/start_recorder.sh`). It reads real-exchange PUBLIC data only through
    `KalshiRestClient("production", signer=None, public=True)`, the CF index from the DEMO WebSocket (demo key),
    and Coinbase/Kraken public feeds. It has no order code; `tests/test_recorder.py` enforces that. Its shadow
    engine's fills are hypothetical and must never be reported as executions. It does not activate any strategy.

20. **Research agent** (*owner request 2026-11-11*): `aicrypto/research_agent/` is offline research only. The AI
    researcher writes hypotheses in `research/hypotheses/` and sandboxed code in `research/sandbox/` only. It must not
    edit `config/research_agent.yaml` or the protected harness files (`config.PROTECTED`), must not weaken
    `tests/test_research_agent.py`, and nothing it produces may be wired into the demo bot or any order path.
    Passing its gates means "candidate for forward shadow testing", never a trading decision.

21. **Real-money trading** (*owner decision 2026-11-19*): the owner chose to trade their real Kalshi account.
    It exists only in `aicrypto/kalshi/real_exec/` (exchange pinned to `HOSTS["production"]["rest"]`, the same
    endpoint allowlist as demo, no withdrawals/deposits/transfers to anyone, no API-key or subaccount endpoints).
    - Owner limits, module constants in `real_exec/trader.py`: at least $1 per trade, at most 10% of the account
      value per trade; no daily spending limit (the owner removed the 30% one on 2026-11-19); no daily loss stop. Only a human may change them; the bot, the lab and the research agent never.
    - The real bot trades the same rules as demo practice mode (owner choice 2026-11-19), priced and checked
      against the REAL exchange's quotes, never the demo book. No manual real orders.
    - The real bot is OFF at every start and after any emergency stop; turning it on needs the owner to type
      `REAL MONEY` in the app. The demo page's emergency stop also stops real trading. Claude must never turn it on,
      place, script or schedule real orders, or test against the real account with live orders.
    - The real key lives outside the repo (`~/.config/aicrypto/kalshi_real.env` + PEM, both mode 0600), set up
      by the owner. Claude never reads, prints, copies or moves it. Demo keys and env vars stay separate.
    - The market-data transport stays read-only (rule 7) and the recorder, research agent and timeframe tools
      never import `real_exec`.

