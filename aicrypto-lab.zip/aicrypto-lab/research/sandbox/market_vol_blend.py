"""Mostly trust the market; nudge toward the volatility model (70% market, 30% model, on the log-odds scale)."""
import math


def _logit(p):
    p = min(max(p, 1e-4), 1 - 1e-4)
    return math.log(p / (1 - p))


def probability(ctx):
    vol = ctx["vol_15m"]
    if not vol or vol <= 0:
        return None
    tau = max(1e-6, (ctx["t_left_s"] / 60.0 - 1.0) + 1.0 / 3.0)
    z = math.log(ctx["spot"] / ctx["strike"]) / (vol * math.sqrt(tau))
    model = 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))
    x = 0.7 * _logit(ctx["mid"]) + 0.3 * _logit(model)
    return 1 / (1 + math.exp(-x))
