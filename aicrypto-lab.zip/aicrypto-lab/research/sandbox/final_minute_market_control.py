"""Control on the final-minute data: the real market's own mid price as the probability (must never pass)."""


def probability(ctx):
    return ctx["mid"]
