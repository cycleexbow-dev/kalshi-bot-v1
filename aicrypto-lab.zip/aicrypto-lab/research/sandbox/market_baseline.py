"""Control: use the market's own mid price as the probability. It should never pass (it has no edge by construction)."""


def probability(ctx):
    return ctx["mid"]
