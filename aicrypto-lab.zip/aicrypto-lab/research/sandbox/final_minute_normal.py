"""Final-minute settlement-average model, normal tails.

The window settles on the average of the 60 one-second index prints before the close. Prints already
inside that minute are fixed; the remaining n follow a driftless random walk from the latest value with
per-second volatility sigma (EWMA of recent 1-second returns, half-life 120 s):
    mean = (sum(known) + n * S) / 60,  sd = S * sigma * sqrt(n(n+1)(2n+1)/6) / 60.
"""
import math


def _sigma(rets):
    lam = math.log(2) / 120.0
    num = den = 0.0
    k = len(rets)
    for i, r in enumerate(rets):
        w = math.exp(-lam * (k - 1 - i))
        num += w * r * r
        den += w
    return math.sqrt(num / den) if den > 0 else None


def probability(ctx):
    sigma = _sigma(ctx["ret_1s"])
    if not sigma:
        return None
    known, S, K = ctx["known_prints"], ctx["last_value"], ctx["strike"]
    n = max(0, 60 - len(known))              # prints still to come, each one random step further
    mean = (sum(known) + (60 - len(known)) * S) / 60.0
    if n == 0:
        return 1.0 if mean >= K else 0.0
    sd = S * sigma * math.sqrt(n * (n + 1) * (2 * n + 1) / 6.0) / 60.0
    if sd <= 0:
        return 1.0 if mean >= K else 0.0
    return 0.5 * (1.0 + math.erf((mean - K) / sd / math.sqrt(2.0)))
