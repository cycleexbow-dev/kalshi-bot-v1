"""Settlement-aware volatility model (the fair-value idea, rebuilt on the harness inputs).

P(60-second settlement average >= target) for a driftless lognormal: distance from the target in units of
recent 1-minute volatility, with the averaging minute counting as one third of its length.
"""
import math


def probability(ctx):
    vol = ctx["vol_15m"]
    if not vol or vol <= 0:
        return None
    t_left_min = ctx["t_left_s"] / 60.0
    tau = max(1e-6, (t_left_min - 1.0) + 1.0 / 3.0)
    z = math.log(ctx["spot"] / ctx["strike"]) / (vol * math.sqrt(tau))
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))
