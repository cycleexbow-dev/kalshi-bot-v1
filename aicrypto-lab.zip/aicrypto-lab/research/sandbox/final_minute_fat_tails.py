"""Final-minute settlement-average model with fat tails (Student-t, 4 degrees of freedom, unit variance).

Same average logic as final_minute_normal; crypto returns jump more often than a normal curve allows,
which matters most when the model would otherwise say 99%+.
"""
import math

NU = 4.0


def _sigma(rets):
    lam = math.log(2) / 120.0
    num = den = 0.0
    k = len(rets)
    for i, r in enumerate(rets):
        w = math.exp(-lam * (k - 1 - i))
        num += w * r * r
        den += w
    return math.sqrt(num / den) if den > 0 else None


def _betacf(a, b, x):
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
    h = d
    for m in range(1, 200):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1.0 + aa / c if abs(c) > 1e-30 else 1e-30
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1.0 + aa / c if abs(c) > 1e-30 else 1e-30
        de = d * c
        h *= de
        if abs(de - 1.0) < 1e-12:
            break
    return h


def _t_cdf(x):
    z = x * math.sqrt(NU / (NU - 2.0))       # unit-variance scaling
    if z == 0:
        return 0.5
    a, b = NU / 2.0, 0.5
    xx = NU / (NU + z * z)
    lbeta = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    ib = math.exp(a * math.log(xx) + b * math.log(1.0 - xx) - lbeta) * _betacf(a, b, xx) / a
    return 1.0 - 0.5 * ib if z > 0 else 0.5 * ib


def probability(ctx):
    sigma = _sigma(ctx["ret_1s"])
    if not sigma:
        return None
    known, S, K = ctx["known_prints"], ctx["last_value"], ctx["strike"]
    n = max(0, 60 - len(known))
    mean = (sum(known) + (60 - len(known)) * S) / 60.0
    if n == 0:
        return 1.0 if mean >= K else 0.0
    sd = S * sigma * math.sqrt(n * (n + 1) * (2 * n + 1) / 6.0) / 60.0
    if sd <= 0:
        return 1.0 if mean >= K else 0.0
    return min(1.0, max(0.0, _t_cdf((mean - K) / sd)))
