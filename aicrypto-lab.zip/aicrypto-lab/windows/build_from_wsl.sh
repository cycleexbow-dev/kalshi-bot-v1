#!/usr/bin/env bash
# Build the Windows .exe from inside Ubuntu (WSL) with ONE command:
#     bash windows/build_from_wsl.sh            (add --install-python to let winget install Python 3.12)
# Copies the launcher sources to %LOCALAPPDATA%\AICryptoLab\src on Windows (PyInstaller cannot
# build from a \\wsl$ network path) and runs build.ps1 with native Windows PowerShell + Python.
set -euo pipefail
cd "$(dirname "$0")"
command -v powershell.exe >/dev/null || { echo "powershell.exe not reachable from WSL (Windows interop disabled?)"; exit 1; }
LAD_WIN="$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')"
[[ -n "$LAD_WIN" && "$LAD_WIN" != "%LOCALAPPDATA%" ]] || { echo "could not read %LOCALAPPDATA% from Windows"; exit 1; }
LAD="$(wslpath -u "$LAD_WIN")"
DEST="$LAD/AICryptoLab/src"
mkdir -p "$DEST/launcher"
cp -f build.ps1 requirements-launcher.txt "$DEST/"
cp -f launcher/aicl_core.py launcher/aicl_launcher.py launcher/startup.html launcher/aicl.ico "$DEST/launcher/"
ARGS=()
[[ "${1:-}" == "--install-python" ]] && ARGS+=(-InstallPython)
echo "Building on Windows from $LAD_WIN\\AICryptoLab\\src ..."
cd "$DEST"   # powershell.exe needs a Windows-side working directory
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$(wslpath -w "$DEST/build.ps1")" "${ARGS[@]}"
