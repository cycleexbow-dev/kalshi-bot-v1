"""AI Crypto Lab — Windows desktop launcher (pywebview + WebView2).

Double-click -> startup window -> WSL/project checks -> start or attach to the backend ->
wait for /api/health -> show the trading terminal in this native window.
Closing the window stops the backend if this launcher started it.
It never starts trading or automation.
"""
from __future__ import annotations

import ctypes
import logging
import logging.handlers
import os
import subprocess
import sys
import threading
import traceback
from pathlib import Path

import webview  # pywebview

from aicl_core import LaunchError, Launcher, app_data_dir, load_config

APP_TITLE = "AI Crypto Lab"
VERSION = "0.2.0"

LOG_DIR = app_data_dir() / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
log = logging.getLogger("aicl")
log.setLevel(logging.INFO)
_h = logging.handlers.RotatingFileHandler(LOG_DIR / "launcher.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
_h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
log.addHandler(_h)


def resource(name: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    return base / name


def single_instance() -> bool:
    if os.name != "nt":
        return True
    kernel32 = ctypes.windll.kernel32
    single_instance.handle = kernel32.CreateMutexW(None, False, "Local\\AICryptoLabLauncher")
    return kernel32.GetLastError() != 183          # ERROR_ALREADY_EXISTS


def message_box(text: str, title: str = APP_TITLE) -> None:
    if os.name == "nt":
        ctypes.windll.user32.MessageBoxW(None, text, title, 0x40)


class Api:
    """Exposed to the startup page and to the terminal UI as window.pywebview.api."""

    def __init__(self, app: "App"):
        self._app = app

    def retry(self):
        self._app.start_async()

    def open_logs(self):
        os.startfile(str(LOG_DIR))                          # noqa: S606 (fixed local folder)

    def open_backend_log(self):
        p = self._app.launcher.backend_log_unc() if self._app.launcher else ""
        if p:
            try:
                os.startfile(p)
                return
            except OSError:
                pass
        self.open_logs()

    def shutdown(self, stop_backend: bool = True):
        self._app.quit(stop_backend=stop_backend)

    def version(self):
        return VERSION


class App:
    def __init__(self):
        self.cfg = load_config()
        self.launcher: Launcher | None = None
        self.window = None
        self._busy = threading.Lock()
        self._closing = False

    # ---- startup page bridge
    def js(self, code: str):
        try:
            self.window.evaluate_js(code)
        except Exception:
            pass

    def progress(self, step, state, msg):
        log.info("[%s] %s %s", step, state, msg)
        import json
        self.js(f"window.setStep && setStep({json.dumps(step)}, {json.dumps(state)}, {json.dumps(msg)})")

    def start_async(self):
        threading.Thread(target=self._start, daemon=True).start()

    def _start(self):
        if not self._busy.acquire(blocking=False):
            return
        import json
        try:
            try:
                self.window.events.loaded.wait(10)      # let the startup page finish loading
            except Exception:
                pass
            self.js("window.resetSteps && resetSteps()")
            self.launcher = Launcher(self.cfg, progress=self.progress, log=log.info)
            url = self.launcher.launch()
            log.info("opening %s (%s)", url, "attached" if self.launcher.attached else "started")
            self.window.load_url(url)
        except LaunchError as e:
            log.error("launch failed: %s | %s", e, e.log_tail[-2000:])
            self.js(f"window.showError && showError({json.dumps(e.title)}, {json.dumps(e.detail)}, {json.dumps(e.hint)}, {json.dumps(e.log_tail)})")
        except Exception as e:  # never leave the user with a blank window
            log.error("unexpected: %s", traceback.format_exc())
            self.js(f"window.showError && showError('Unexpected error', {json.dumps(str(e))}, 'Open the logs and send them for troubleshooting.', '')")
        finally:
            self._busy.release()

    def on_closing(self):
        if self._closing:
            return True
        self._closing = True
        self._stop_backend()
        return True

    def _stop_backend(self):
        if self.launcher and self.cfg.stop_backend_on_exit and self.launcher.started_backend:
            log.info("stopping backend started by this launcher")
            try:
                self.launcher.shutdown()
            except Exception:
                log.error("shutdown error: %s", traceback.format_exc())

    def quit(self, stop_backend: bool = True):
        self._closing = True
        if stop_backend and self.launcher:
            log.info("user requested shutdown")
            self.launcher.shutdown(force=True)
        threading.Timer(0.2, lambda: self.window.destroy()).start()

    def run(self):
        splash = resource("startup.html").read_text(encoding="utf-8").replace("{{VERSION}}", VERSION)
        self.window = webview.create_window(APP_TITLE, html=splash, js_api=Api(self), width=1440, height=900,
                                            min_size=(1100, 700), background_color="#0a0d13", text_select=True)
        self.window.events.closing += self.on_closing
        storage = app_data_dir() / "webview"
        webview.start(self.start_async, gui="edgechromium", private_mode=False, storage_path=str(storage),
                      icon=str(resource("aicl.ico")))


def selftest() -> int:
    """Used by build.ps1 to test the built .exe without opening a window: checks bundled files,
    pywebview import, WSL discovery and the health probe. Writes selftest.json next to the logs."""
    import json
    from aicl_core import Runner, probe_health
    res = {"version": VERSION, "frozen": bool(getattr(sys, "frozen", False))}
    res["startup_html"] = resource("startup.html").exists()
    res["icon"] = resource("aicl.ico").exists()
    res["webview"] = getattr(webview, "__version__", "imported")
    r = Runner()
    res["wsl_exe"] = r.wsl or ""
    try:
        if r.wsl:
            rc, out, err = r.run(["-l", "-q"], timeout=60)
            res["wsl_list_rc"] = rc
            res["distros"] = [x.strip() for x in out.splitlines() if x.strip()]
    except Exception as e:
        res["wsl_error"] = repr(e)
    cfg = load_config()
    res["port"] = cfg.port
    res["health_now"] = probe_health(cfg.health_url).state
    ok = res["startup_html"] and res["icon"] and bool(res["wsl_exe"])
    res["ok"] = bool(ok)
    (LOG_DIR / "selftest.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(json.dumps(res, indent=2))
    return 0 if ok else 1


def main():
    if "--selftest" in sys.argv:
        return selftest()
    log.info("launcher %s starting (pid %s)", VERSION, os.getpid())
    if not single_instance():
        message_box("AI Crypto Lab is already open.")
        return 0
    try:
        App().run()
    except Exception:
        log.error("fatal: %s", traceback.format_exc())
        message_box("AI Crypto Lab could not start the window.\n\nWebView2 runtime may be missing — install "
                    "'Microsoft Edge WebView2 Runtime' and try again.\n\nLog: " + str(LOG_DIR / "launcher.log"))
        return 1
    log.info("launcher exited")
    return 0


if __name__ == "__main__":
    sys.exit(main())
