"""AI Crypto Lab Windows launcher — platform logic (no GUI), unit-tested on Linux with fakes.

Flow: find WSL -> pick the Ubuntu distro -> check the project + Python env -> if a healthy
AI Crypto Lab backend already answers on the port, attach to it; if something else holds the
port, stop with a clear message; otherwise start scripts/start_ui.sh inside WSL and wait for
a real /api/health answer. Shutdown stops only a backend this launcher started.

The launcher only ever calls GET /api/health. It cannot start trading or automation.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Tuple

APP_ID = "aicrypto-lab"
CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200


# ------------------------------------------------------------------ config
@dataclass
class LauncherConfig:
    distro: str = ""                 # "" = auto (prefer "Ubuntu")
    project_dir: str = "aicrypto-lab"  # relative to the WSL user's home
    port: int = 8765
    start_timeout_s: float = 120.0
    stop_backend_on_exit: bool = True

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    @property
    def health_url(self) -> str:
        return f"http://127.0.0.1:{self.port}/api/health"


def app_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    d = Path(base) / "AICryptoLab"
    d.mkdir(parents=True, exist_ok=True)
    return d


def load_config(path: Optional[Path] = None) -> LauncherConfig:
    path = path or app_data_dir() / "launcher.json"
    cfg = LauncherConfig()
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            for k, v in data.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, type(getattr(cfg, k))(v))
        except (ValueError, TypeError):
            pass
    else:
        try:
            path.write_text(json.dumps(asdict(cfg), indent=2), encoding="utf-8")
        except OSError:
            pass
    if not (1024 < int(cfg.port) < 65536):
        cfg.port = 8765
    if any(c in cfg.project_dir for c in "\"'`$;&|<>\\") or cfg.project_dir.startswith(("/", "..")):
        cfg.project_dir = "aicrypto-lab"          # never interpolate odd strings into a shell command
    return cfg


# ------------------------------------------------------------------ errors
@dataclass
class LaunchError(Exception):
    code: str
    title: str
    detail: str
    hint: str = ""
    log_tail: str = ""

    def __str__(self) -> str:
        return f"{self.title}: {self.detail}"


def friendly(code: str, detail: str = "", log_tail: str = "") -> LaunchError:
    table = {
        "no_wsl": ("WSL is not installed or not enabled",
                   "AI Crypto Lab's backend runs inside WSL Ubuntu.",
                   "Open PowerShell as administrator and run:  wsl --install  then restart Windows."),
        "no_distro": ("No Ubuntu distribution found in WSL",
                      "WSL is installed but no Ubuntu distribution is registered.",
                      "Install Ubuntu from the Microsoft Store, or run:  wsl --install -d Ubuntu"),
        "no_project": ("AI Crypto Lab is not installed in WSL",
                       "The project folder was not found in your WSL home folder.",
                       "In Ubuntu, unzip aicrypto-lab.zip into your home folder (~/aicrypto-lab)."),
        "no_venv": ("Python environment missing",
                    "The project's Python environment (~/aicrypto-lab/.venv) is not set up.",
                    "In Ubuntu run:  cd ~/aicrypto-lab && bash scripts/kalshi_demo_setup.sh"),
        "port_busy": ("Port is used by another program",
                      "Something that is not AI Crypto Lab is answering on the backend port.",
                      "Close that program, or change \"port\" in %LOCALAPPDATA%\\AICryptoLab\\launcher.json."),
        "backend_crashed": ("The backend stopped while starting",
                            "The AI Crypto Lab backend exited before it became ready.",
                            "See the backend log below or open it from the button."),
        "timeout": ("The backend did not answer in time",
                    "WSL started but the backend did not respond to its health check.",
                    "Try again. If it keeps happening, open the logs. If WSL localhost forwarding is "
                    "disabled in .wslconfig, enable it."),
        "wsl_error": ("WSL returned an error", "", "Try again, or run  wsl --shutdown  in PowerShell and retry."),
    }
    title, base, hint = table.get(code, ("Unexpected error", "", ""))
    return LaunchError(code, title, detail or base, hint, log_tail)


# ------------------------------------------------------------------ helpers
def decode_wsl(b: bytes) -> str:
    """wsl.exe's own messages are UTF-16LE (unless WSL_UTF8=1); Linux programs print UTF-8."""
    if not b:
        return ""
    if b.startswith(b"\xff\xfe") or (len(b) > 1 and b[1:2] == b"\x00" and b.count(b"\x00") >= len(b) // 3):
        try:
            return b.decode("utf-16-le").lstrip("\ufeff")
        except UnicodeDecodeError:
            pass
    return b.decode("utf-8", errors="replace").replace("\x00", "")


def pick_distro(names: Sequence[str], preferred: str = "") -> Optional[str]:
    clean = [n.strip().lstrip("\ufeff") for n in names if n and n.strip()]
    clean = [n for n in clean if not n.lower().startswith("docker-desktop")]
    if preferred:
        return preferred if preferred in clean else None
    for n in clean:
        if n.lower() == "ubuntu":
            return n
    for n in clean:
        if n.lower().startswith("ubuntu"):
            return n
    return None


@dataclass
class Health:
    state: str                  # ours | foreign | down
    data: dict = field(default_factory=dict)
    error: str = ""


def probe_health(url: str, timeout: float = 2.0, opener: Callable = urllib.request.urlopen) -> Health:
    try:
        with opener(url, timeout=timeout) as r:
            body = r.read(65536)
        try:
            data = json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return Health("foreign", error="non-JSON response")
        if isinstance(data, dict) and data.get("app") == APP_ID and data.get("component") == "terminal":
            return Health("ours", data)
        return Health("foreign", data if isinstance(data, dict) else {}, "unexpected service")
    except urllib.error.HTTPError as e:
        return Health("foreign", error=f"HTTP {e.code}")
    except (urllib.error.URLError, ConnectionError, OSError) as e:
        return Health("down", error=str(e))


# ------------------------------------------------------------------ runner (real or fake)
class Runner:
    """Thin wrapper around subprocess so tests can substitute it."""

    def __init__(self, wsl_path: Optional[str] = None):
        self.wsl = wsl_path or self.find_wsl()

    @staticmethod
    def find_wsl() -> Optional[str]:
        root = os.environ.get("SystemRoot", r"C:\Windows")
        for cand in (os.path.join(root, "System32", "wsl.exe"), os.path.join(root, "Sysnative", "wsl.exe")):
            if os.path.exists(cand):
                return cand
        return shutil.which("wsl.exe") or shutil.which("wsl")

    def _env(self):
        e = dict(os.environ)
        e["WSL_UTF8"] = "1"
        return e

    def run(self, args: List[str], timeout: float = 60.0) -> Tuple[int, str, str]:
        p = subprocess.run([self.wsl, *args], capture_output=True, timeout=timeout, env=self._env(),
                           creationflags=CREATE_NO_WINDOW if os.name == "nt" else 0)
        return p.returncode, decode_wsl(p.stdout), decode_wsl(p.stderr)

    def spawn(self, args: List[str]):
        flags = (CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP) if os.name == "nt" else 0
        return subprocess.Popen([self.wsl, *args], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, env=self._env(), creationflags=flags)


# ------------------------------------------------------------------ launcher
Progress = Callable[[str, str, str], None]     # (step, state: run|ok|fail|skip, message)


class Launcher:
    STEPS = ("wsl", "project", "backend", "health")

    def __init__(self, cfg: LauncherConfig, runner: Optional[Runner] = None, progress: Optional[Progress] = None,
                 health: Callable[[str], Health] = probe_health, sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic, log: Callable[[str], None] = lambda m: None):
        self.cfg = cfg
        self.runner = runner if runner is not None else Runner()
        self.progress = progress or (lambda *a: None)
        self.health = health
        self.sleep = sleep
        self.clock = clock
        self.log = log
        self.distro: Optional[str] = None
        self.wsl_home: str = ""
        self.proc = None
        self.started_backend = False
        self.attached = False

    # -- paths shown to the user
    def backend_log_unc(self) -> str:
        if not (self.distro and self.wsl_home):
            return ""
        home = self.wsl_home.strip("/").replace("/", "\\")
        return f"\\\\wsl.localhost\\{self.distro}\\{home}\\{self.cfg.project_dir}\\logs\\ui.log"

    def _wsl(self, script: str, timeout: float = 60.0) -> Tuple[int, str, str]:
        # fixed scripts only; project_dir is validated in load_config
        return self.runner.run(["-d", self.distro, "--cd", "~", "--", "bash", "-c", script], timeout=timeout)

    # -- steps
    def check_wsl(self) -> None:
        self.progress("wsl", "run", "Looking for WSL")
        if not getattr(self.runner, "wsl", None):
            raise friendly("no_wsl")
        try:
            rc, out, err = self.runner.run(["-l", "-q"], timeout=60)
        except (OSError, subprocess.TimeoutExpired) as e:
            raise friendly("no_wsl", f"wsl.exe could not be run ({type(e).__name__}).")
        if rc != 0:
            raise friendly("no_wsl", (err or out).strip()[:400] or "wsl.exe reported an error.")
        self.distro = pick_distro(out.splitlines(), self.cfg.distro)
        if not self.distro:
            raise friendly("no_distro", f"Distributions found: {', '.join(n.strip() for n in out.splitlines() if n.strip()) or 'none'}.")
        self.progress("wsl", "ok", f"WSL · {self.distro}")

    def check_project(self) -> None:
        self.progress("project", "run", "Checking the AI Crypto Lab installation (WSL may take a few seconds to wake)")
        d = self.cfg.project_dir
        script = (f'echo "HOME=$HOME"; if [ ! -f "./{d}/scripts/start_ui.sh" ]; then echo NOPROJECT; '
                  f'elif [ ! -x "./{d}/.venv/bin/aicrypto" ]; then echo NOVENV; else echo OK; fi')
        try:
            rc, out, err = self._wsl(script, timeout=90)
        except subprocess.TimeoutExpired:
            raise friendly("wsl_error", "WSL did not respond within 90 seconds.")
        for line in out.splitlines():
            if line.startswith("HOME="):
                self.wsl_home = line[5:].strip()
        if "NOPROJECT" in out:
            raise friendly("no_project", f"Expected ~/{d} with scripts/start_ui.sh inside {self.distro}.")
        if "NOVENV" in out:
            raise friendly("no_venv")
        if rc != 0 or "OK" not in out:
            raise friendly("wsl_error", (err or out).strip()[:400])
        self.progress("project", "ok", f"Project found · ~/{d}")

    def ensure_backend(self) -> str:
        """Return 'attached' if a healthy backend was already running, else 'started'."""
        self.progress("backend", "run", "Checking for a running backend")
        h = self.health(self.cfg.health_url)
        if h.state == "ours":
            self.attached = True
            self.progress("backend", "ok", f"Using the backend that is already running (pid {h.data.get('pid', '?')})")
            return "attached"
        if h.state == "foreign":
            raise friendly("port_busy", f"Port {self.cfg.port}: {h.error or 'another service'}.")
        self.progress("backend", "run", "Starting the backend in WSL")
        self.proc = self.runner.spawn(["-d", self.distro, "--cd", "~", "--", "bash", "-c",
                                       f'exec bash "./{self.cfg.project_dir}/scripts/start_ui.sh" {int(self.cfg.port)}'])
        self.started_backend = True
        self.log(f"spawned backend via wsl (pid {getattr(self.proc, 'pid', '?')})")
        self.progress("backend", "ok", f"Backend started in WSL on port {self.cfg.port}")
        return "started"

    def wait_healthy(self) -> dict:
        self.progress("health", "run", "Waiting for the backend to answer")
        t_end = self.clock() + self.cfg.start_timeout_s
        while self.clock() < t_end:
            h = self.health(self.cfg.health_url)
            if h.state == "ours":
                self.progress("health", "ok", "Backend is answering")
                return h.data
            if h.state == "foreign":
                raise friendly("port_busy", f"Port {self.cfg.port}: {h.error or 'another service'}.")
            if self.proc is not None and self.proc.poll() is not None:
                rc = self.proc.returncode
                tail = self.backend_log_tail()
                if rc == 20 or "Python environment missing" in tail:
                    raise friendly("no_venv", log_tail=tail)
                if rc == 3 or "already in use" in tail:
                    raise friendly("port_busy", f"Port {self.cfg.port} is already in use.", log_tail=tail)
                raise friendly("backend_crashed", f"Exit code {rc}.", log_tail=tail)
            self.sleep(0.5)
        raise friendly("timeout", f"No answer from {self.cfg.health_url} within {int(self.cfg.start_timeout_s)} s.",
                       log_tail=self.backend_log_tail())

    def backend_log_tail(self, n: int = 40) -> str:
        try:
            rc, out, _ = self._wsl(f'tail -n {int(n)} "./{self.cfg.project_dir}/logs/ui.log" 2>/dev/null', timeout=20)
            return out[-6000:]
        except Exception:
            return ""

    def launch(self) -> str:
        self.check_wsl()
        self.check_project()
        self.ensure_backend()
        self.wait_healthy()
        return self.cfg.url

    def shutdown(self, force: bool = False) -> bool:
        """Stop the backend if this launcher started it (or if force). Returns True if stopped."""
        if not (self.started_backend or force) or not self.distro:
            return False
        try:
            self._wsl(f'bash "./{self.cfg.project_dir}/scripts/stop_ui.sh"', timeout=30)
        except Exception as e:
            self.log(f"stop_ui failed: {e}")
        if self.proc is not None and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except OSError:
                pass
        self.started_backend = False
        return True
