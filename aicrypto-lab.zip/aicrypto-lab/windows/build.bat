@echo off
rem Double-click to build AI Crypto Lab.exe (when this folder is on a normal Windows drive).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1" %*
pause
