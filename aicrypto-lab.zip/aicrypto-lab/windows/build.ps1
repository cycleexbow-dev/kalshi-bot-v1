<#
  Build the AI Crypto Lab Windows launcher (.exe) with native Windows Python + PyInstaller.

  Usage (normally started for you by:  bash windows/build_from_wsl.sh  inside Ubuntu):
      powershell -ExecutionPolicy Bypass -File build.ps1 [-NoShortcut] [-InstallPython]

  Output:   %LOCALAPPDATA%\Programs\AICryptoLab\AI Crypto Lab.exe   (+ its support files)
  Shortcut: Desktop\AI Crypto Lab.lnk
  Build venv and work files: %LOCALAPPDATA%\AICryptoLab\build  (safe to delete)
#>
param(
  [switch]$NoShortcut,
  [switch]$InstallPython,
  [string]$PythonVersion = "3.12"
)
$ErrorActionPreference = "Stop"
$Here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Src     = Join-Path $Here "launcher"
$Base    = Join-Path $env:LOCALAPPDATA "AICryptoLab"
$Work    = Join-Path $Base "build"
$Venv    = Join-Path $Work "venv"
$Dist    = Join-Path $Work "dist"
$Install = Join-Path $env:LOCALAPPDATA "Programs\AICryptoLab"
$ExeName = "AI Crypto Lab"

function Step($m) { Write-Host ""; Write-Host "==> $m" -ForegroundColor Cyan }
function Fail($m) { Write-Host ""; Write-Host "BUILD FAILED: $m" -ForegroundColor Red; exit 1 }

Step "Checking Windows Python $PythonVersion"
$py = $null
try { & py "-$PythonVersion" -c "import sys; print(sys.version)" 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { $py = @("py", "-$PythonVersion") } } catch {}
if (-not $py) {
  if ($InstallPython) {
    Step "Installing Python $PythonVersion for the current user with winget"
    winget install -e --id "Python.Python.$PythonVersion" --scope user --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { Fail "winget could not install Python $PythonVersion" }
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" + $env:Path
    & py "-$PythonVersion" -c "import sys" 2>$null; if ($LASTEXITCODE -eq 0) { $py = @("py", "-$PythonVersion") }
  }
  if (-not $py) {
    Fail ("Windows Python $PythonVersion was not found. Install it from https://www.python.org/downloads/windows/ " +
          "(tick 'py launcher'), or rerun with -InstallPython to install it with winget.")
  }
}
& $py[0] $py[1] -c "import sys; print('   using', sys.executable, sys.version.split()[0])"

Step "Creating build environment"
New-Item -ItemType Directory -Force -Path $Work | Out-Null
if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) { & $py[0] $py[1] -m venv $Venv; if ($LASTEXITCODE -ne 0) { Fail "venv creation failed" } }
$VPy = Join-Path $Venv "Scripts\python.exe"
& $VPy -m pip install --disable-pip-version-check -q --upgrade pip
& $VPy -m pip install --disable-pip-version-check -q -r (Join-Path $Here "requirements-launcher.txt")
if ($LASTEXITCODE -ne 0) { Fail "pip install failed (network?)" }

Step "Unit-testing launcher logic"
& $VPy -c "import sys; sys.path.insert(0, r'$Src'); import aicl_core as c; assert c.pick_distro(['docker-desktop','Ubuntu-24.04'])=='Ubuntu-24.04'; assert c.decode_wsl('Ubuntu\r\n'.encode('utf-16-le'))=='Ubuntu\r\n'; print('   core ok')"
if ($LASTEXITCODE -ne 0) { Fail "launcher core self-check failed" }

Step "Building the executable with PyInstaller"
Push-Location $Src
try {
  & $VPy -m PyInstaller --noconfirm --clean --windowed --name $ExeName `
      --icon (Join-Path $Src "aicl.ico") --add-data "$(Join-Path $Src 'startup.html');." --add-data "$(Join-Path $Src 'aicl.ico');." `
      --distpath $Dist --workpath (Join-Path $Work "pyi") --specpath $Work `
      --hidden-import clr --collect-all webview (Join-Path $Src "aicl_launcher.py")
  if ($LASTEXITCODE -ne 0) { Fail "PyInstaller failed" }
} finally { Pop-Location }
$Built = Join-Path $Dist $ExeName
$Exe = Join-Path $Built "$ExeName.exe"
if (-not (Test-Path $Exe)) { Fail "expected $Exe was not produced" }

Step "Self-test of the built .exe (no window)"
$st = Join-Path $Base "logs\selftest.json"
if (Test-Path $st) { Remove-Item $st -Force }
$p = Start-Process -FilePath $Exe -ArgumentList "--selftest" -Wait -PassThru
if (-not (Test-Path $st)) { Fail "self-test produced no report (exit $($p.ExitCode))" }
Get-Content $st | Write-Host
$res = Get-Content $st -Raw | ConvertFrom-Json
if (-not $res.ok) { Fail "self-test reported a problem (see above)" }
# PE header check: a real Windows executable starts with 'MZ'
$hdr = [System.IO.File]::ReadAllBytes($Exe)[0..1]
if (-not ($hdr[0] -eq 0x4D -and $hdr[1] -eq 0x5A)) { Fail "output is not a Windows PE executable" }

Step "Installing to $Install"
$running = Get-Process -Name $ExeName -ErrorAction SilentlyContinue
if ($running) { Fail "AI Crypto Lab is running. Close it and run the build again." }
New-Item -ItemType Directory -Force -Path $Install | Out-Null
robocopy $Built $Install /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Fail "copy to $Install failed (robocopy $LASTEXITCODE)" }
$InstalledExe = Join-Path $Install "$ExeName.exe"

if (-not $NoShortcut) {
  Step "Creating desktop shortcut"
  $desk = [Environment]::GetFolderPath("Desktop")
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut((Join-Path $desk "$ExeName.lnk"))
  $lnk.TargetPath = $InstalledExe
  $lnk.WorkingDirectory = $Install
  $lnk.IconLocation = "$InstalledExe,0"
  $lnk.Description = "AI Crypto Lab - Kalshi demo terminal"
  $lnk.Save()
  Write-Host "   $desk\$ExeName.lnk"
}

$size = "{0:N1} MB" -f ((Get-ChildItem $Install -Recurse | Measure-Object Length -Sum).Sum / 1MB)
Write-Host ""
Write-Host "BUILD OK" -ForegroundColor Green
Write-Host "   Executable: $InstalledExe ($size installed)"
Write-Host "   Logs:       $Base\logs"
Write-Host "   Settings:   $Base\launcher.json"
Write-Host "Double-click 'AI Crypto Lab' on your desktop to start."
