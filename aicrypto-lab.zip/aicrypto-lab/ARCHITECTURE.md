# AI Crypto Research & Paper-Trading Lab — Architecture

**Status:** paper trading only. Simulated capital $1,000. Markets BTC/USDT, ETH/USDT,
SOL/USDT. Spot, no leverage, no shorts. Risk per trade 2% of equity.
**Real-money execution is not implemented and is actively blocked** (see §3).

> Backtest and walk-forward results in this system are *estimates of past behaviour
> under modelled costs*. They are not forecasts and no part of this system claims a
> strategy is profitable. The promotion gates exist to reject candidates, not to
> certify them.

---

## 1. Layered design

```
┌──────────────────────────────────────────────────────────────────────┐
│  Claude Code (operator / researcher)                                  │
│  reads CLAUDE.md, runs `aicrypto` CLI, proposes strategy specs,       │
│  reads reports. Never edits the safety module or config.              │
└──────────────────────────────┬───────────────────────────────────────┘
                               │ CLI / JSON spec files
┌──────────────────────────────▼───────────────────────────────────────┐
│  RESEARCH LAYER (pure Python, host venv, bounded resources)           │
│                                                                      │
│  data/        load Freqtrade feather candles · synthetic generator    │
│               · integrity checks (gaps, dupes, monotonic time)        │
│  strategies/  declarative StrategySpec (family + params) · indicator  │
│               library (pandas only, causal) · spec mutation/sampling  │
│  research/    vectorised next-bar backtester (fees, slippage, 2% risk │
│               sizing, stop/trail/time exits) · metrics · walk-forward │
│               · lookahead probe · recursive/startup-stability probe   │
│  experiments/ SQLite tracker: run id = sha256(spec, data fingerprint, │
│               cost model, code version, seed) · artefacts on disk     │
│  promotion/   gates: CANDIDATE → VALIDATED → PAPER (dry-run) → RETIRED│
│  agent/       bounded autonomous loop: sample → backtest → WFO →      │
│               leakage → gates → record; budget by count/time/memory   │
└──────────────────────────────┬───────────────────────────────────────┘
                               │ renders IStrategy .py + dry-run config
┌──────────────────────────────▼───────────────────────────────────────┐
│  EXECUTION LAYER (Docker, Freqtrade 2026.x, dry_run=true, forced)    │
│  freqtrade trade --dry-run · REST API on localhost only ·            │
│  Freqtrade's own backtesting / lookahead-analysis / recursive-analysis│
│  used as an independent second opinion on exported strategies.        │
└──────────────────────────────┬───────────────────────────────────────┘
                               │ sqlite (tradesv3.dryrun.sqlite) + REST
┌──────────────────────────────▼───────────────────────────────────────┐
│  OBSERVABILITY                                                        │
│  dashboard/  FastAPI on 127.0.0.1:8080 — experiments, gates, paper    │
│              equity, open dry-run trades, safety status               │
│  reporting/  daily Markdown report (research activity, promotions,    │
│              paper P&L, data health, safety attestation)              │
└──────────────────────────────────────────────────────────────────────┘
```

The research layer deliberately does **not** depend on Freqtrade at import time.
Freqtrade is the execution/second-opinion engine; a bug or version change in it
cannot take down research, and research can run on the host without Docker.

## 2. Data flow

1. **Ingest** — `scripts/download_data.sh` runs `freqtrade download-data` inside
   Docker (Binance public API, no keys) into `user_data/data/binance/*.feather`.
   The research layer reads those files directly (`aicrypto.data.load_ohlcv`).
   Each dataset gets a **fingerprint** (sha256 of pair, timeframe, first/last
   timestamp, row count, sum of closes) stored with every experiment.
2. **Specify** — a strategy is a JSON `StrategySpec`: family (`ema_cross`,
   `rsi_reversion`, `donchian_breakout`, `bollinger_reversion`), parameters,
   exit rules (stop %, trailing %, max holding bars). Specs are data, so they are
   hashable, diffable and renderable to Freqtrade code.
3. **Backtest** — signals are computed on bar *t* and filled at the **open of
   bar t+1** with slippage; this is the structural defence against lookahead.
   Costs: taker fee 0.10% per side (configurable), slippage 5 bps per side.
   Position size = `min(equity × 2% / stop_distance, equity × max_alloc)`;
   one position per pair; spot only (quantity ≥ 0 always).
4. **Validate** — anchored or rolling walk-forward: optimise on train window
   (bounded random search, seeded), evaluate untouched test window, roll
   forward. Report per-fold OOS metrics and the **fraction of folds positive**,
   not just the stitched equity curve.
5. **Leakage probes**
   - *Lookahead*: recompute signals on a truncated series and compare with the
     full-series signals over the overlap. Any difference = future data leaked.
   - *Recursive*: compute indicators with different warm-up lengths; if the
     most recent values change, the indicator is path-dependent and live values
     will differ from backtest values (Freqtrade's "recursive analysis").
   - Exported strategies are additionally run through Freqtrade's own
     `lookahead-analysis` and `recursive-analysis` commands.
6. **Track** — every run writes a row to `experiments/tracker.sqlite` and a
   JSON artefact in `experiments/runs/<run_id>/`. Re-running the same spec on
   the same data with the same seed yields the same `run_id` and metrics.
7. **Promote** — `aicrypto promote` evaluates gates (§4). A spec that passes is
   exported to `user_data/strategies/<Name>.py` and added to the dry-run config.
8. **Paper trade** — `docker compose up freqtrade` runs the bot in dry-run.
   Trades land in `user_data/tradesv3.dryrun.sqlite`.
9. **Observe** — dashboard + `aicrypto report` daily Markdown in `reports/`.

## 3. Safety model (defence in depth)

| Layer | Control |
|---|---|
| Config generation | `dry_run` is hard-coded `true`; `exchange.key`/`secret` are written as empty strings; `aicrypto.safety.assert_paper_only()` refuses to render otherwise. |
| Config validation | `aicrypto safety-check` parses every `config*.json` under `user_data/` and fails if `dry_run != true`, any key/secret is non-empty, `trading_mode != spot`, or `margin_mode` is set. Runs in CI/tests and before every `docker compose up` via `scripts/start_dryrun.sh`. |
| Container | Compose passes `--dry-run` on the command line (CLI flag beats config). No `.env` with keys is mounted. API server bound to `127.0.0.1` only, with generated random password. |
| Code review | `CLAUDE.md` forbids Claude Code from editing `aicrypto/safety.py`, the compose command line, or introducing exchange credentials. Tests assert the compose command still contains `--dry-run`. |
| Language | Lifecycle states are `CANDIDATE / VALIDATED / PAPER / RETIRED`. There is no `LIVE` state anywhere in the codebase. |

### 3.1 Known modelling limitations of the crypto backtester (not fixed; documented)

- **Fills**: next-bar open ± fixed slippage with unlimited liquidity; no partial fills, no volume-participation cap. Suitable for liquid BTC/ETH/SOL spot at sub-$1k size; not suitable for order-book strategies.
- **Stops**: a stop is filled at the stop price when the bar's low crosses it, or at the open when the bar opens through it. Intrabar path is unknown; this ignores the possibility of worse fills inside the bar.
- **Trailing stops**: the trail level is raised with a bar's high only *after* that bar's stop check, so a same-bar new-high-then-reversal is never credited. Conservative, but the true intrabar ordering is unknown. Freqtrade's backtester makes a different intrabar assumption; that is one reason trade counts agree between engines while P&L differs.
- **Risk per trade (2%)** is a *planned* loss at the stop, not a guaranteed cap; gaps can exceed it.
- **Second-opinion gate** (`freqtrade_agreement`) runs via `aicrypto verify-ft`, which `promote` now requires (see KALSHI_ARCHITECTURE.md §A.2 for the audit that found it unwired).

## 4. Promotion gates (reject-by-default)

A candidate must pass **all** gates. Thresholds live in `config/research.yaml`.

| Gate | Default threshold | Why |
|---|---|---|
| Minimum trades (OOS, all folds) | ≥ 60 | Fewer trades → metrics are noise. |
| Walk-forward folds | ≥ 4 folds, ≥ 60% with positive OOS return | Robustness across regimes. |
| OOS Sharpe (annualised, after costs) | ≥ 0.5 | Modest bar; high bars reward overfitting. |
| OOS / IS performance ratio | ≥ 0.4 | Large IS→OOS decay signals overfitting. |
| Max drawdown (OOS, stitched) | ≤ 25% | Capital preservation. |
| Lookahead probe | 0 differing signals | Any leak is disqualifying. |
| Recursive probe | 0 signal flips and score drift ≤ 1% of its scale across warm-up lengths | Backtest values must equal live values. |
| Parameter stability | neighbouring params (±1 step) keep ≥ 50% of OOS return | Reject knife-edge optima. |
| Freqtrade second opinion | Freqtrade backtest trade count within ±30% of ours; lookahead-analysis reports 0 bias | Independent engine agreement. |

Passing gates means "not rejected", never "profitable". The report wording
enforces this.

## 5. Resource bounds (16 GB desktop, Windows + WSL)

- WSL memory cap 8 GB (`.wslconfig`), Freqtrade container 2 GB, research
  process soft address-space limit 4 GB.
- Single research worker by default; walk-forward holds one pair/timeframe in
  memory at a time; indicator frames are dropped after signal extraction.
- Research session budget: `max_candidates=40`, `max_minutes=30`,
  `max_folds=8`, timeframes limited to `15m, 1h, 4h`, history ≤ 3 years.
- Dashboard polls SQLite, never holds candle data.

## 6. Incremental delivery plan

| Phase | Deliverable | Verification |
|---|---|---|
| 1 | package, settings, safety module | unit tests; `safety-check` CLI |
| 2 | data loader, synthetic generator, fingerprinting, integrity | tests on synthetic + feather round-trip |
| 3 | specs, indicators, backtester, metrics | tests: no-lookahead by construction, cost accounting, sizing cap, deterministic |
| 4 | walk-forward, lookahead and recursive probes | tests with a deliberately leaky strategy that must be caught |
| 5 | tracker, gates | reproducibility test (same inputs → same run_id/metrics) |
| 6 | autonomous bounded loop | budget tests (count/time), determinism under seed |
| 7 | Freqtrade export, Docker compose, scripts | render + `freqtrade backtesting` + `lookahead-analysis` on synthetic feather data |
| 8 | dashboard, daily report | HTTP tests, report content tests |
| 9 | e2e demo on synthetic data; packaging | full pytest run; `make demo` |

## 7. What Claude Code does in this system

Claude Code is the *researcher*, not the trader. Its sanctioned actions
(see `CLAUDE.md`): propose new `StrategySpec` JSON files or new strategy
families with tests, run `aicrypto research`, read `reports/`, write hypotheses
to `docs/RESEARCH_LOG.md`. Everything it proposes still goes through the same
gates. It must not touch `aicrypto/safety.py`, Docker command lines, or add
credentials. Research hypotheses are cheap to generate; the pipeline's job is
to kill them cheaply too.
