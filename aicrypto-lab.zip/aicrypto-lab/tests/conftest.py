import random

import pytest

from aicrypto.data import synthetic_ohlcv
from aicrypto.settings import Capital, Costs
from aicrypto.strategies import StrategySpec


@pytest.fixture
def capital():
    return Capital()


@pytest.fixture
def costs():
    return Costs()


@pytest.fixture
def ema_spec():
    return StrategySpec(
        family="ema_cross",
        params={"fast": 10, "slow": 30, "trend_filter": 0},
        exits={"stop_pct": 0.03, "trail_pct": 0.0, "max_bars": 0},
        timeframe="1h",
    )


@pytest.fixture
def data3():
    return {
        "BTC/USDT": synthetic_ohlcv(3000, "1h", seed=1, s0=30000),
        "ETH/USDT": synthetic_ohlcv(3000, "1h", seed=2, s0=2000),
        "SOL/USDT": synthetic_ohlcv(3000, "1h", seed=3, s0=100),
    }


@pytest.fixture
def rng():
    return random.Random(123)


@pytest.fixture(autouse=True)
def _isolated_public_budget(tmp_path, monkeypatch):
    """Tests never touch the machine-wide request budget the live recorder relies on."""
    import aicrypto.kalshi.ratebudget as rb
    monkeypatch.setenv("AICRYPTO_RUN_DIR", str(tmp_path / "run"))
    monkeypatch.setattr(rb, "_shared", None)
    yield
