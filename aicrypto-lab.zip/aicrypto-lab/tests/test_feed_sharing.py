"""The recorder can use the app's copy of the CF index feed as a second source; per-asset research reporting."""
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))

from aicrypto.recorder import store as St  # noqa: E402
from aicrypto.recorder.cfindex import CFIndex  # noqa: E402
from aicrypto.research_agent import harness as H  # noqa: E402
from test_terminal import ks, reg  # noqa: E402,F401
from aicrypto.terminal.service import TerminalService  # noqa: E402


def _msg(ts, v):
    return {"type": "cfbenchmarks_value_5hz", "msg": {"index_id": "BRTI", "value_usd": str(v), "source_ts_ms": int(ts * 1000)}}


def test_two_sources_merge_without_duplicates_and_fill_gaps(tmp_path):
    store = St.Store(tmp_path, clock=lambda: 1_800_000_100.0)
    cf = CFIndex(store, lambda: None, ["BTC"])
    t0 = 1_800_000_000.0
    for k in range(5):                                                 # own connection: 0.0 .. 0.8 s
        cf.on_value(_msg(t0 + 0.2 * k, 100 + k), t0 + 0.2 * k + 0.1, via="own")
    for k in range(5):                                                 # the app saw the same prints: all duplicates
        cf.on_value(_msg(t0 + 0.2 * k, 100 + k), t0 + 0.2 * k + 0.15, via="app")
    cf.on_value(_msg(t0 + 3.0, 110), t0 + 3.1, via="own")              # own connection dropped 2.2 s -> gap event
    cf.on_value(_msg(t0 + 1.0, 105), t0 + 3.2, via="app")              # the app had prints inside that gap
    cf.on_value(_msg(t0 + 1.2, 106), t0 + 3.2, via="app")
    store.close()
    assert cf.stats["duplicates"] == 5 and cf.stats["late_fill"] == 2 and cf.stats["gaps"] == 1
    vals = [v for _, v in cf.series("BRTI", t0 - 1)]
    assert vals == [100, 101, 102, 103, 104, 105, 106, 110]            # time order, each print once
    recs = [r for r in St.read_source(tmp_path, "cfindex") if r["k"] == "value"]
    assert len(recs) == 8 and {r["via"] for r in recs} == {"own", "app"}


def test_app_copies_index_messages_without_ever_waiting(ks, reg):
    svc = TerminalService(ks, live=False, registry=reg)
    svc.CF_QUEUE_MAX = 3

    async def go():
        q = svc.cf_subscribe()
        for i in range(10):
            svc._publish_cf(_msg(1_800_000_000 + i, 100 + i), 1_800_000_000.0 + i)   # nobody reading: never blocks
        got = [q.get_nowait() for _ in range(q.qsize())]
        svc.cf_unsubscribe(q)
        svc._publish_cf(_msg(1, 1), 1.0)                                              # no subscribers: no-op
        return got
    got = asyncio.run(go())
    assert len(got) == 3 and svc.cf_dropped == 7 and got[0]["data"]["msg"]["index_id"] == "BRTI"
    assert set(got[0]) == {"t_recv", "data"} and "KALSHI" not in json.dumps(got)


def test_cf_stream_endpoint_is_read_only():
    import inspect
    from aicrypto.terminal import app as A
    src = inspect.getsource(A)
    i = src.index('"/api/terminal/cf_stream"')
    assert src[i - 30:i].strip().endswith("@app.get(")                                 # GET only


def test_per_asset_and_correlation_reporting():
    tr = []
    for k in range(10):
        for a, win in (("BTC", k % 2), ("SOL", k % 2)):                                # perfectly correlated results
            paid = 0.52 + H.fee1(0.52)
            tr.append({"asset": a, "close_ts": 1000.0 + 900 * k, "day": f"d{k // 3}", "win": float(win), "ask": 0.5,
                       "pnl_cons": win - paid, "paid_cons": paid, "pnl_opt": win - 0.5, "paid_opt": 0.5})
    c = H.correlation(tr)
    assert c["trades"] == 20 and c["independent_settlement_times"] == 10 and c["avg_correlation"] > 0.99
    ctxs = [{"asset": t["asset"], "mid": 0.5} for t in tr]
    labels = [{"y": int(t["win"])} for t in tr]
    pa = H.per_asset(tr, ctxs, labels, [0.6] * len(tr))
    assert set(pa) == {"BTC", "SOL"} and pa["BTC"]["trades"] == 10 and pa["BTC"]["win_rate"] == 0.5
    assert pa["BTC"]["fees"] == 0.2 and pa["BTC"]["net_expectancy_return"] < 0
