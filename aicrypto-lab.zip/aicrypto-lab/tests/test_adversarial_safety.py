"""Adversarial tests: configs and command paths that try to look paper-only while enabling
real trading, and promote/activate flows that must never silently switch the active strategy."""
import json
import subprocess
import sys
from pathlib import Path

import pytest

from aicrypto import safety

ROOT = Path(__file__).resolve().parents[1]


def good():
    return {"dry_run": True, "trading_mode": "spot", "exchange": {"name": "binance", "key": "", "secret": "", "ccxt_config": {},
                                                                  "ccxt_async_config": {}},
            "api_server": {"enabled": True, "listen_ip_address": "127.0.0.1"}, "dry_run_wallet": 1000}


@pytest.mark.parametrize("mutate,expect", [
    (lambda c: c["exchange"]["ccxt_config"].update(apiKey="abc"), "ccxt_config.apiKey"),
    (lambda c: c["exchange"]["ccxt_async_config"].update(secret="abc"), "ccxt_async_config.secret"),
    (lambda c: c["exchange"].update(Key="abc"), "exchange.Key"),
    (lambda c: c["exchange"].update(passphrase="abc"), "passphrase"),
    (lambda c: c["exchange"].update(key="   x"), "exchange.key"),
    (lambda c: c.update(internals={"api_key": "zzz"}), "internals.api_key"),
    (lambda c: c.update(trading_mode=" Futures "), "trading_mode"),
    (lambda c: c.update(margin_mode="CROSS"), "margin_mode"),
    (lambda c: c.update(dry_run=1), "dry_run"),
    (lambda c: c.update(dry_run="yes"), "dry_run"),
    (lambda c: c.update(dry_run_wallet="lots"), "numeric"),
    (lambda c: c["exchange"].update(sandbox=True), "sandbox"),
    (lambda c: c["api_server"].update(listen_ip_address="192.168.1.5"), "127.0.0.1"),
    (lambda c: c.update(exchange="binance"), "object"),
])
def test_disguised_live_configs_are_caught(mutate, expect):
    c = good(); mutate(c)
    rep = safety.inspect_config(c)
    assert not rep.ok and any(expect.lower() in p.lower() for p in rep.problems), rep.problems


def test_whitespace_and_case_do_not_bypass():
    c = good(); c["exchange"]["secret"] = "\t\n"   # whitespace-only counts as empty
    assert safety.inspect_config(c).ok
    c = good(); c["exchange"]["SECRET"] = "real"
    assert not safety.inspect_config(c).ok


def test_candidate_config_is_scanned_too(tmp_path):
    ud = tmp_path / "user_data"; ud.mkdir()
    (ud / "config_dryrun.json").write_text(json.dumps(good()))
    bad = good(); bad["dry_run"] = False
    (ud / "config_dryrun.candidate.json").write_text(json.dumps(bad))
    reps = safety.scan_configs(ud)
    assert len(reps) == 2 and not all(r.ok for r in reps)


def _cli(args, root, cfg=None):
    cmd = [sys.executable, "-m", "aicrypto.cli", "--root", str(root)] + (["--config", str(cfg)] if cfg else []) + args
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)


@pytest.fixture(scope="module")
def promoted_root(tmp_path_factory):
    """Synthetic data, loose gates (test-only), one research session -> VALIDATED specs."""
    root = tmp_path_factory.mktemp("lab")
    import shutil
    shutil.copy(ROOT / "docker-compose.yml", root / "docker-compose.yml")
    shutil.copy(ROOT / ".gitignore", root / ".gitignore")
    (root / "config").mkdir(); shutil.copy(ROOT / "config" / "research.yaml", root / "config" / "research.yaml")
    cfg = root / "loose.yaml"
    cfg.write_text("gates: {min_trades: 10, min_folds: 2, min_positive_fold_fraction: 0.0, min_oos_sharpe: -99, min_oos_is_ratio: -99, max_drawdown: 1.0, min_neighbour_retention: 0.0}\n"
                   "walk_forward: {train_bars: 4000, test_bars: 1000, step_bars: 1000, max_folds: 8, optimizer_samples: 4, seed: 42}\n")
    assert _cli(["synth-data", "--bars", "8000", "--timeframes", "1h"], root).returncode == 0
    r = _cli(["research", "--timeframe", "1h", "--max-candidates", "3", "--seed", "1", "--family", "ema_cross"], root, cfg)
    assert r.returncode == 0, r.stdout + r.stderr
    return root, cfg


def _freqtrade_available() -> bool:
    from aicrypto.freqtrade_bridge.runner import FreqtradeUnavailable, _mode
    try:
        _mode(ROOT)
        return True
    except FreqtradeUnavailable:
        return False


@pytest.mark.slow
@pytest.mark.skipif(not _freqtrade_available(),
                    reason="Freqtrade is not installed on this machine (no local `freqtrade`, no docker): promote's "
                           "verification step cannot run, so this end-to-end test cannot either. Unrelated to Kalshi.")
def test_promote_statuses_and_activation_guard(promoted_root):
    root, cfg = promoted_root
    # 1) first promote: no active strategy -> PROMOTED, writes active config, records activation
    r = _cli(["promote", "--dry-run-config", "--offline"], root, cfg)
    status = json.loads((root / "experiments" / "last_promote.json").read_text())
    assert r.returncode in (0, 3), r.stdout[-2000:] + r.stderr[-2000:]
    if r.returncode == 3:
        pytest.skip("no candidate passed the richer Freqtrade comparison on this synthetic set: " + json.dumps(status)[:300])
    assert status["status"] == "PROMOTED" and (root / "user_data" / "config_dryrun.json").exists()
    active = json.loads((root / "user_data" / "config_dryrun.json").read_text())["strategy"]
    # comparison report recorded on the run with all checks
    from aicrypto.experiments import Tracker
    tr = Tracker(root / "experiments")
    run = tr.by_status("PAPER")[0]
    comp = tr.load_run(run["run_id"])["freqtrade_comparison"]
    assert {c["name"] for c in comp["checks"]} == {"trade_count", "entry_timing", "exit_timing", "position_size", "net_pnl", "fees", "max_drawdown"}
    assert comp["passed"] and comp["lookahead_has_bias"] is False

    # 2) second promote must NOT replace the active strategy
    r2 = _cli(["promote", "--dry-run-config", "--offline", "--max", "2"], root, cfg)
    assert r2.returncode in (0, 3)
    assert json.loads((root / "user_data" / "config_dryrun.json").read_text())["strategy"] == active
    st2 = json.loads((root / "experiments" / "last_promote.json").read_text())
    if st2["status"] == "PROMOTED":
        assert "left unchanged" in st2["note"] and (root / "user_data" / "config_dryrun.candidate.json").exists()

    # 3) activate without --confirm refuses; with --confirm on a non-PAPER name refuses
    assert _cli(["activate", active], root, cfg).returncode == 2
    assert _cli(["activate", "ACNotAStrategy", "--confirm"], root, cfg).returncode == 3
    # with --confirm on the PAPER strategy succeeds and logs the activation
    r3 = _cli(["activate", active, "--confirm", "--reason", "test"], root, cfg)
    assert r3.returncode == 0, r3.stdout + r3.stderr
    with tr._conn() as c:
        rows = c.execute("SELECT strategy, previous, reason FROM activations ORDER BY ts").fetchall()
    assert len(rows) >= 2 and rows[-1]["reason"].startswith("manual activation")

    # 4) a config left behind by promote is still paper-only
    assert _cli(["safety-check"], root, cfg).returncode == 0


def test_promote_nothing_to_promote_exit_code(tmp_path):
    import shutil
    shutil.copy(ROOT / "docker-compose.yml", tmp_path / "docker-compose.yml")
    shutil.copy(ROOT / ".gitignore", tmp_path / ".gitignore")
    r = _cli(["promote"], tmp_path)
    assert r.returncode == 3 and "NOTHING_TO_PROMOTE" in r.stdout


def test_verification_error_fails_closed(promoted_root, monkeypatch):
    """If Freqtrade cannot run at all, promote must return 4, not promote anything."""
    root, cfg = promoted_root
    import os
    env = {**os.environ, "PATH": "/nonexistent"}   # no `freqtrade`, no docker on PATH; and offline flag omitted
    cmd = [sys.executable, "-m", "aicrypto.cli", "--root", str(root), "--config", str(cfg), "promote", "--max", "1"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, env=env)
    st = json.loads((root / "experiments" / "last_promote.json").read_text())
    assert r.returncode in (3, 4)
    if r.returncode == 4:
        assert st["status"] == "VERIFICATION_ERROR"


def test_kalshi_scan_catches_keys_and_pyth(tmp_path):
    import shutil
    (tmp_path / "config").mkdir()
    shutil.copy(ROOT / "config" / "kalshi.yaml", tmp_path / "config" / "kalshi.yaml")
    (tmp_path / ".gitignore").write_text("*.pem\n.env\n")
    assert all(r.ok for r in safety.scan_kalshi(tmp_path))
    # a PEM file in the tree
    (tmp_path / "secrets.pem").write_text("-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----\n")
    reps = safety.scan_kalshi(tmp_path)
    assert any("private key file" in p for r in reps for p in r.problems)
    (tmp_path / "secrets.pem").unlink()
    # key material pasted into a config
    (tmp_path / "notes.yaml").write_text("x: '-----BEGIN RSA PRIVATE KEY-----'")
    assert any("private-key" in p for r in safety.scan_kalshi(tmp_path) for p in r.problems)
    (tmp_path / "notes.yaml").unlink()
    # pyth switched on without a decision
    txt = (tmp_path / "config" / "kalshi.yaml").read_text().replace("    enabled: false               # OFF", "    enabled: true               # OFF")
    (tmp_path / "config" / "kalshi.yaml").write_text(txt)
    assert any("pyth" in p for r in safety.scan_kalshi(tmp_path) for p in r.problems)
    # paper_only tampered
    (tmp_path / "config" / "kalshi.yaml").write_text(txt.replace("paper_only: true", "paper_only: false"))
    assert any("invalid kalshi config" in p for r in safety.scan_kalshi(tmp_path) for p in r.problems)
    # .gitignore missing key patterns
    (tmp_path / ".gitignore").write_text("")
    assert any(".gitignore" in p for r in safety.scan_kalshi(tmp_path) for p in r.problems)
