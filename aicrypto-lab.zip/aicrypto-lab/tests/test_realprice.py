"""Rules scored at the REAL exchange's public prices: read-only, never trades; the bot learns from it."""
import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))
from test_lab import BTC, GOLD, lab_env  # noqa: E402,F401

from aicrypto.kalshi.lab import engine as E  # noqa: E402
from aicrypto.kalshi.lab.realprice import NoBot, RealPriceLab  # noqa: E402


class FakeRealTransport:
    def __init__(self):
        self.markets = {}
        self.calls = []

    async def request(self, method, path, params=None):
        self.calls.append((method, path, dict(params or {})))
        assert method == "GET" and path == "/markets"
        want = (params or {}).get("tickers", "").split(",")
        return {"markets": [self.markets[t] for t in want if t in self.markets]}


class FakeRealClient:
    def __init__(self):
        self.transport = FakeRealTransport()


def _market(t, bid, ask, strike=None, status="active", result=""):
    return {"ticker": t, "status": status, "yes_bid_dollars": bid, "yes_ask_dollars": ask, "yes_bid_size_fp": "500.00",
            "yes_ask_size_fp": "500.00", "floor_strike": strike, "result": result}


def _real_lab(svc, clk, tmp_path):
    fake = FakeRealClient()
    lab = RealPriceLab(svc, tmp_path / "lab_real.sqlite", clock=clk, client_factory=lambda: fake)
    lab.setup()
    return lab, fake


def test_real_lab_cannot_trade_and_uses_public_unsigned_real_host(lab_env, tmp_path):
    svc, *_ = lab_env
    lab = svc.real_lab
    # On its own the real-price lab has no bot and can never trade.
    bare = RealPriceLab(svc, tmp_path / "bare.sqlite")
    assert isinstance(bare.bot, NoBot) and bare.bot.on is False and bare.bot.may_trade("proven", 999, 1.0) is False
    with pytest.raises(RuntimeError):
        bare.bot.turn_on()
    with pytest.raises(RuntimeError):
        asyncio.run(bare.bot.submit())
    # In the app it carries the REAL-money bot (owner decision 2026-11-19, rule 21): off at start, and with no
    # real key set up it cannot be turned on at all.
    assert lab.bot is svc.real_bot and lab.bot.on is False and svc.real.state in ("off", "no_credentials")
    with pytest.raises(Exception):
        lab.bot.turn_on("REAL MONEY")
    assert lab.bot.on is False
    c = RealPriceLab(svc, tmp_path / "x.sqlite").client()        # default client: built, never called here
    assert c.transport.signer is None and c.transport.base_url == "https://external-api.kalshi.com/trade-api/v2"
    assert "demo" not in c.transport.base_url and "/portfolio" not in c.transport.base_url


def test_real_lab_scores_rules_at_real_prices_and_settles_from_real_results(lab_env, tmp_path):
    svc, _, _, clk = lab_env
    lab, fake = _real_lab(svc, clk, tmp_path)
    strike = float(svc.reg.markets[BTC].floor_strike)
    fake.transport.markets[BTC] = _market(BTC, "0.9300", "0.9400", strike)
    assert asyncio.run(lab.poll()) >= 1
    n = asyncio.run(lab.tick())
    assert n > 0
    rows = lab.store.open_trades()
    assert rows and all(r["ticker"] == BTC for r in rows)
    assert {r["price"] for r in rows if r["side"] == "yes"} <= {"0.94", "0.9400"}     # paid the REAL ask, not demo's 0.91
    fake.transport.markets[BTC] = _market(BTC, "0", "0", strike, status="finalized", result="yes")
    clk.t = E_CLOSE(svc) + 30
    assert asyncio.run(lab.settle()) == len(rows)


def E_CLOSE(svc):
    return svc.reg.markets[BTC].close_time.timestamp()


def test_real_lab_skips_window_when_targets_differ(lab_env, tmp_path):
    svc, _, _, clk = lab_env
    lab, fake = _real_lab(svc, clk, tmp_path)
    fake.transport.markets[BTC] = _market(BTC, "0.9300", "0.9400", float(svc.reg.markets[BTC].floor_strike) + 5)
    asyncio.run(lab.poll())
    assert lab.window_view(BTC, clk.t) is None


def test_bot_stops_rules_losing_at_real_prices_and_prefers_strong_evidence(lab_env):
    svc, *_ = lab_env
    b = svc.lab.bot
    assert b.may_trade("exploring", 0, None, (E.REAL_MIN_N, -0.01)) is False      # losing at real prices: skipped
    assert b.may_trade("exploring", 0, None, (E.REAL_MIN_N - 1, -0.5)) is True     # too little real data yet
    assert b.may_trade("exploring", 30, 0.05, (E.REAL_MIN_N, 0.02)) is True
    assert b.may_trade("exploring", 30, -0.01, None) is False                      # losing on demo practice
    lab = svc.lab
    lab.stats, lab.tstats = {"a": (40, 0.1), "b": (40, 0.1)}, {"a": 3.0, "b": 1.0}
    assert lab.evidence_score("a", {}) > lab.evidence_score("b", {})
    assert lab.evidence_score("a", {"a": (E.REAL_MIN_N, -0.02, -2.0)}) == -2.0     # real-price record wins once there is enough
    assert lab.evidence_score("new", {}) == 0.0


def test_bot_progress_rolls_win_rate_and_profit(lab_env):
    svc, *_ = lab_env

    async def fake_tx(account="demo"):
        out = []
        for i, (pnl, fee) in enumerate([("-0.50", "0.02"), ("0.40", "0.02"), ("0.60", "0.02"), ("0.01", "0.02")]):
            out.append({"by": "bot", "closed": f"2026-11-10T0{i}:00:00+00:00", "pnl": pnl, "fees": fee, "cost": "0.50"})
        out.append({"by": "manual", "closed": "2026-11-10T05:00:00+00:00", "pnl": "9", "fees": "0", "cost": "1"})
        return out
    svc.transactions = fake_tx
    r = asyncio.run(svc.bot_progress(window=2))
    assert r["trades"] == 4 and r["win_pct"] == 50.0                               # 0.01 - 0.02 fee is a loss
    assert [p["rolling_win_pct"] for p in r["points"]] == [0.0, 50.0, 100.0, 50.0]
    assert r["net"] == "0.43" and abs(r["points"][-1]["cum_net"] - 0.43) < 1e-9
