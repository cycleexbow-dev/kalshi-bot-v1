"""Milestone B/D: demo-only execution, reconciliation, risk, confirmation, automation.

All exchange traffic goes to a mocked Kalshi DEMO API (httpx.MockTransport). No network."""
import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import httpx
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.auth import HOSTS, Credentials, KalshiSigner  # noqa: E402
from aicrypto.kalshi.demo_exec import automation as auto_mod  # noqa: E402
from aicrypto.kalshi.demo_exec.automation import ARM_PHRASE, Strategy, approve, code_hash  # noqa: E402
from aicrypto.kalshi.demo_exec.exchange import (DEMO_BASE, DemoExchange, DemoOnlyViolation,  # noqa: E402
                                                UncertainOutcome, check_demo_request)
from aicrypto.kalshi.demo_exec.trader import Intent, OrderRefused, risk_errors  # noqa: E402
from aicrypto.kalshi.registry import MarketRegistry  # noqa: E402
from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402
from aicrypto.terminal.app import create_terminal_app  # noqa: E402
from aicrypto.terminal.service import TerminalService  # noqa: E402

NOW = datetime(2026, 11, 9, 13, 50, tzinfo=timezone.utc)
ETH = "KXETHD-26NOV1017-T2000"          # tradeable (auto-eligible) crypto market
GOLD = "KXGOLDD-26NOV0917-T4100"         # visible, manual only (no licensed reference feed)


def signer():
    k = ed25519.Ed25519PrivateKey.generate()
    pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    return KalshiSigner.from_pem_bytes("kid", pem)


# ---------------------------------------------------------------- fake Kalshi demo exchange
class FakeDemo:
    def __init__(self):
        self.orders = {}            # order_id -> order
        self.posts = []             # bodies received
        self.requests = []          # (method, host, path)
        self.mode = "ok"            # ok | timeout_after_accept | timeout_before | http500 | http400
        self.shards = {0: Decimal("500.00"), 2: Decimal("0.00")}      # cash starts on shard 0; crypto/commodities trade on shard 2
        self.transfers = []
        self.fills = []
        self.positions = []
        self.n = 0

    @property
    def balance_cents(self):
        return int(sum(self.shards.values()) * 100)

    @balance_cents.setter
    def balance_cents(self, v):
        self.shards = {0: Decimal(v) / 100, 2: Decimal(0)}

    def order_json(self, o):
        return {"order": o}

    def handler(self, req: httpx.Request) -> httpx.Response:
        self.requests.append((req.method, req.url.host, req.url.path))
        assert req.url.host == "demo-api.kalshi.co"
        assert "KALSHI-ACCESS-SIGNATURE" in req.headers
        p = req.url.path.replace("/trade-api/v2", "")
        if req.method == "GET" and p == "/portfolio/balance":
            return httpx.Response(200, json={"balance": self.balance_cents, "portfolio_value": 1234, "balance_breakdown": [
                {"exchange_index": k, "balance": f"{v:.4f}"} for k, v in sorted(self.shards.items())]})
        if req.method == "POST" and p == "/portfolio/intra_exchange_instance_transfer":
            b = json.loads(req.content)
            assert b["source"] == b["destination"] == "event_contract" and "source_subaccount" not in b
            amt = Decimal(b["amount"]) / 10000
            if amt > self.shards[b["source_exchange_shard"]]:
                return httpx.Response(400, json={"error": {"message": "insufficient balance"}})
            self.shards[b["source_exchange_shard"]] -= amt
            self.shards[b["destination_exchange_shard"]] = self.shards.get(b["destination_exchange_shard"], Decimal(0)) + amt
            self.transfers.append(b)
            return httpx.Response(200, json={"transfer_id": "t1"})
        if req.method == "GET" and p == "/portfolio/positions":
            return httpx.Response(200, json={"market_positions": self.positions, "event_positions": []})
        if req.method == "GET" and p == "/portfolio/fills":
            return httpx.Response(200, json={"fills": self.fills})
        if req.method == "GET" and p == "/portfolio/orders":
            t, st = req.url.params.get("ticker"), req.url.params.get("status")
            return httpx.Response(200, json={"orders": [o for o in self.orders.values() if (not t or o["ticker"] == t) and (not st or o["status"] == st)]})
        if req.method == "GET" and p.startswith("/portfolio/orders/"):
            o = self.orders.get(p.rsplit("/", 1)[1])
            return httpx.Response(200, json={"order": o}) if o else httpx.Response(404, json={"error": {"message": "not found"}})
        if p in ("/portfolio/orders",) and req.method == "POST" or (req.method == "DELETE" and p.startswith("/portfolio/orders/")):
            return httpx.Response(410, json={"error": {"code": "deprecated_v1_order_endpoint", "message": "Please switch to the V2 endpoints"}})
        if req.method == "POST" and p == "/portfolio/events/orders":
            body = json.loads(req.content)
            self.posts.append(body)
            assert body["side"] in ("bid", "ask") and isinstance(body["count"], str) and isinstance(body["price"], str)
            assert body["time_in_force"] and body["self_trade_prevention_type"]
            if self.mode == "timeout_before":
                raise httpx.ReadTimeout("timed out", request=req)
            if self.mode == "http500":
                return httpx.Response(503, text="unavailable")
            if self.mode == "http400":
                return httpx.Response(400, json={"error": {"code": "invalid_price", "message": "price out of range"}})
            cost = Decimal(body["count"]) * (Decimal(body["price"]) if body["side"] == "bid" else 1 - Decimal(body["price"]))
            if not body.get("reduce_only") and self.shards.get(2, 0) < cost:
                return httpx.Response(404, json={"error": {"code": "insufficient_shard_balance", "message": "insufficient shard balance"}})
            if any(o["client_order_id"] == body["client_order_id"] for o in self.orders.values()):
                return httpx.Response(409, json={"error": {"message": "duplicate client_order_id"}})
            self.n += 1
            oid = f"ord-{self.n}"
            cnt = body["count"]
            yes = body["side"] == "bid"
            o = {"order_id": oid, "client_order_id": body["client_order_id"], "ticker": body["ticker"], "side": "yes" if yes else "no",
                 "action": "buy", "type": "limit", "status": "resting", "fill_count_fp": "0.00", "remaining_count_fp": cnt,
                 "initial_count_fp": cnt, "yes_price_dollars": body["price"], "no_price_dollars": f"{1 - float(body['price']):.4f}"}
            self.orders[oid] = o
            if self.mode == "timeout_after_accept":
                raise httpx.ReadTimeout("timed out", request=req)
            return httpx.Response(201, json={"order_id": oid, "client_order_id": body["client_order_id"], "fill_count": "0.00",
                                             "remaining_count": cnt, "ts_ms": 1})
        if req.method == "DELETE" and p.startswith("/portfolio/events/orders/"):
            o = self.orders.get(p.rsplit("/", 1)[1])
            if not o:
                return httpx.Response(404, json={"error": {"message": "not found"}})
            red = o["remaining_count_fp"]
            o.update(status="canceled", remaining_count_fp="0.00")
            return httpx.Response(200, json={"order_id": o["order_id"], "reduced_by": red})
        return httpx.Response(404, json={"error": {"message": "no route"}})

    def fill(self, oid, n):
        o = self.orders[oid]
        f = Decimal(o["fill_count_fp"]) + n
        rem = Decimal(o["initial_count_fp"]) - f
        o.update(fill_count_fp=f"{f:.2f}", remaining_count_fp=f"{rem:.2f}", status="executed" if rem == 0 else "resting",
                 taker_fees_dollars="0.02")
        self.fills.append({"fill_id": f"fill-{oid}-{f}", "order_id": oid, "ticker": o["ticker"], "side": o["side"], "action": "buy",
                           "count_fp": f"{n:.2f}", "yes_price_dollars": o.get("yes_price_dollars") or "0.5000",
                           "no_price_dollars": o.get("no_price_dollars") or "0.5000", "is_taker": False, "created_time": "2026-11-09T13:51:00Z"})


class FakeRest:
    def __init__(self):
        self.results = {}
        self.book = {"orderbook_fp": {"yes_dollars": [["0.4800", "100.00"], ["0.4900", "50.00"]], "no_dollars": [["0.4900", "80.00"]]}}

    async def get_orderbook(self, ticker, depth=None):
        return self.book

    async def get_market(self, ticker):
        return {"ticker": ticker, "exchange_index": 2, "result": self.results.get(ticker, "")}   # bare market, like KalshiRestClient

    async def aclose(self):
        pass


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


@pytest.fixture
def env(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "registry.sqlite")
    for s in fx.SERIES.values():
        reg.upsert_series(s)
    for m in fx.MARKETS.values():
        reg.upsert_market(m)
    reg.reevaluate_all()
    fake, rest = FakeDemo(), FakeRest()
    sg = signer()
    svc = TerminalService(ks, live=False, registry=reg, rest_factory=lambda: rest,
                          demo_exchange_factory=lambda: DemoExchange(sg, http_transport=httpx.MockTransport(fake.handler)),
                          demo_ledger_path=tmp_path / "demo.sqlite")
    svc.now_fn = lambda: NOW
    svc.recompute_access()
    clk = Clock()
    svc.demo.clock = clk
    svc.auto.clock = clk
    return svc, fake, rest, clk


def run(coro):
    return asyncio.get_event_loop().run_until_complete(coro) if False else asyncio.run(coro)


async def ready(svc, budget="700"):
    svc.demo.set_budget(budget)
    await svc.demo.refresh_account()
    assert svc.demo.state == "connected"


# ---------------------------------------------------------------- demo-only enforcement
def test_demo_base_is_the_demo_host_and_matches_auth_table():
    assert DEMO_BASE == HOSTS["demo"]["rest"] == "https://demo-api.kalshi.co/trade-api/v2"


def test_production_credentials_and_hosts_refused(tmp_path):
    key = tmp_path / "k.pem"
    key.write_text("x")
    with pytest.raises(DemoOnlyViolation):
        DemoExchange.from_credentials(Credentials("kid", key, "production"))
    with pytest.raises(DemoOnlyViolation):
        DemoExchange(signer(), _credentials_env="production")
    with pytest.raises(TypeError):
        DemoExchange(signer(), base_url="https://api.elections.kalshi.com/trade-api/v2")      # no such parameter exists
    src = Path(auto_mod.__file__).with_name("exchange.py").read_text()
    assert "os.environ" not in src and "getenv" not in src                                    # nothing configurable


def test_kalshi_env_production_is_refused_for_demo_credentials(tmp_path, monkeypatch):
    key = tmp_path / "k.pem"
    key.write_text("x")
    key.chmod(0o600)
    from aicrypto.kalshi.auth import CredentialError
    with pytest.raises(CredentialError):
        Credentials.from_env("demo", environ={"KALSHI_ENV": "production", "KALSHI_API_KEY_ID": "a", "KALSHI_PRIVATE_KEY_PATH": str(key)})


@pytest.mark.parametrize("method,path", [
    ("POST", "/portfolio/orders/batched"), ("DELETE", "/portfolio/orders/batched"), ("POST", "/portfolio/orders/ord-1/amend"),
    ("POST", "/portfolio/orders/ord-1/decrease"), ("PUT", "/portfolio/orders/ord-1"), ("POST", "/portfolio/order_groups/create"),
    ("GET", "/api_keys"), ("POST", "/portfolio/orders"), ("DELETE", "/portfolio/orders/ord-1"),
    ("POST", "/portfolio/events/orders/batched"), ("DELETE", "/portfolio/events/orders/batched"),
    ("POST", "/portfolio/events/orders/ord-1/amend"), ("POST", "/portfolio/events/orders/ord-1/decrease"), ("DELETE", "/portfolio/events/orders"), ("GET", "//external-api.kalshi.com/portfolio/balance"),
    ("GET", "https://api.elections.kalshi.com/trade-api/v2/portfolio/balance"), ("GET", "/portfolio/../api_keys"),
    ("GET", "/portfolio/balance?x=1"), ("POST", "/portfolio/transfer"), ("GET", "/markets"),
])
def test_demo_allowlist_rejects_everything_else(method, path):
    with pytest.raises(DemoOnlyViolation):
        check_demo_request(method, path)


def test_read_only_market_transport_still_refuses_orders():
    from aicrypto.kalshi.paths import RequestAllowlist, RequestNotAllowed
    al = RequestAllowlist()
    for m, p in (("POST", "/portfolio/orders"), ("DELETE", "/portfolio/orders/x"), ("GET", "/portfolio/balance")):
        with pytest.raises(RequestNotAllowed):
            al.check_rest(m, p)


def test_all_requests_go_to_demo_host_only(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        tok = (await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 2)))["token"]
        await svc.demo.confirm(tok, ETH, "yes", "0.50", 2)
        await svc.demo.reconcile()
    run(go())
    assert fake.requests and {h for _, h, _ in fake.requests} == {"demo-api.kalshi.co"}


# ---------------------------------------------------------------- validation + confirmation
def test_manual_order_requires_confirmation_token(env):
    svc, fake, _, clk = env

    async def go():
        await ready(svc)
        with pytest.raises(OrderRefused):                                  # no token
            await svc.demo.confirm("", ETH, "yes", "0.50", 1)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        assert p["token"] and not p["errors"] and p["max_loss"] == "0.52"
        with pytest.raises(OrderRefused, match="changed"):                 # params changed after review
            await svc.demo.confirm(p["token"], ETH, "yes", "0.51", 1)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        clk.t += 61
        with pytest.raises(OrderRefused, match="expired"):
            await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1)
        assert r["state"] == "RESTING"
        with pytest.raises(OrderRefused, match="already used"):           # duplicate submission of the same confirmation
            await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1)
    run(go())
    assert len(fake.posts) == 1
    b = fake.posts[0]
    assert b == {"ticker": ETH, "side": "bid", "count": "1.00", "price": "0.5000", "time_in_force": "good_till_canceled",
                 "self_trade_prevention_type": "taker_at_cross", "client_order_id": b["client_order_id"]}        # Kalshi V2 shape
    assert ("POST", "demo-api.kalshi.co", "/trade-api/v2/portfolio/events/orders") in fake.requests


@pytest.mark.parametrize("side,price,count,msg", [
    ("yes", "1.20", 1, "between"), ("yes", "0.00", 1, "between"), ("yes", "0.505", 1, "multiple"),
    ("yes", "0.50", 0, "whole number"), ("yes", "0.50", 501, "limited"), ("maybe", "0.50", 1, "Side"),
    ("yes", "0.75", 1, "above the best offer"),       # best YES ask is 0.51 -> fat finger
])
def test_invalid_orders_refused(env, side, price, count, msg):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, side, Decimal(price), count))
        assert p["token"] is None and any(msg in e for e in p["errors"]), p["errors"]
    run(go())
    assert fake.posts == []


def test_market_eligibility_enforced(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        with pytest.raises(OrderRefused):
            await svc.demo.prepare(Intent("KXPRES-28-DEM", "yes", Decimal("0.50"), 1))    # politics: not even visible
        g = await svc.demo.prepare(Intent(GOLD, "yes", Decimal("0.50"), 1))
        assert g["token"]                                                               # gold: manual OK
        with pytest.raises(OrderRefused, match="automated"):
            await svc.demo.place(Intent(GOLD, "yes", Decimal("0.50"), 1, origin="auto:x"), automated=True)
    run(go())


def test_invalid_order_book_blocks(env):
    svc, fake, rest, _ = env

    async def boom(*a, **k):
        raise RuntimeError("down")
    rest.get_orderbook = boom

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        assert any("order book" in e for e in p["errors"])
    run(go())


# ---------------------------------------------------------------- risk
def test_risk_limits():
    b = Decimal(700)
    base = dict(budget=b, per_position=0.01, aggregate=0.05, daily_stop=0.03, exposure=Decimal(0), resting=Decimal(0),
                realized_today=Decimal(0), available=Decimal(100), kill=False)
    assert risk_errors(max_loss=Decimal("7.00"), **base) == []
    assert any("per-position" in e for e in risk_errors(max_loss=Decimal("7.01"), **base))
    assert any("Total open risk" in e for e in risk_errors(max_loss=Decimal("5"), **{**base, "exposure": Decimal("31")}))
    assert any("Daily loss stop" in e for e in risk_errors(max_loss=Decimal("1"), **{**base, "realized_today": Decimal("-21")}))
    assert any("Not enough" in e for e in risk_errors(max_loss=Decimal("5"), **{**base, "available": Decimal("4")}))
    assert any("Emergency stop" in e for e in risk_errors(max_loss=Decimal("1"), **{**base, "kill": True}))
    assert risk_errors(max_loss=Decimal("99"), **{**base, "budget": None}) == []                 # no budget: cash is the only cap
    assert any("Not enough" in e for e in risk_errors(max_loss=Decimal("101"), **{**base, "budget": None}))
    assert any("Emergency stop" in e for e in risk_errors(max_loss=Decimal("1"), **{**base, "budget": None, "kill": True}))


def test_budget_required_and_per_position_enforced(env):
    svc, fake, _, _ = env

    async def go():
        await svc.demo.refresh_account()
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 100))    # $50 + fee, no budget set: allowed (cash $500)
        assert p["token"] and not p["errors"]
        svc.demo.set_budget("700")                       # optional limit: 1% -> $7.00 max loss per position
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 14))   # cost 7.00 + fee > 7.00
        assert any("per-position" in e for e in p["errors"])
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 13))
        assert p["token"]
        assert svc.demo.set_budget("") is None and svc.demo.budget() is None     # limit removed again
        fake.balance_cents = 300
        await svc.demo.refresh_account()
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 100))
        assert any("Not enough demo cash" in e for e in p["errors"])
    run(go())


# ---------------------------------------------------------------- uncertain outcomes, duplicates, reconciliation
def test_timeout_after_accept_is_reconciled_not_resubmitted(env):
    svc, fake, _, clk = env
    fake.mode = "timeout_after_accept"

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1)
        assert r["state"] == "UNKNOWN"
        assert any(i["id"] == "ORDER-UNCERTAIN" for i in svc.demo.issues())
        fake.mode = "ok"
        clk.t += 5
        st = await svc.demo.reconcile()
        assert st["adopted"] == 1
        o = svc.demo_ledger.order(r["client_order_id"])
        assert o["state"] == "RESTING" and o["order_id"] == "ord-1"
    run(go())
    assert len(fake.posts) == 1                     # never auto-retried


def test_timeout_before_accept_marked_not_placed_after_checks(env):
    svc, fake, _, clk = env
    fake.mode = "timeout_before"

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1)
        assert r["state"] == "UNKNOWN"
        fake.mode = "ok"
        for _ in range(3):
            clk.t += 6
            await svc.demo.reconcile()
        o = svc.demo_ledger.order(r["client_order_id"])
        assert o["state"] == "FAILED" and "not placed" in o["error"]
    run(go())
    assert len(fake.posts) == 1


def test_server_error_on_create_is_uncertain_and_4xx_is_rejected(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        fake.mode = "http500"
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 1))
        assert (await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 1))["state"] == "UNKNOWN"
        fake.mode = "http400"
        p = await svc.demo.prepare(Intent(ETH, "no", Decimal("0.50"), 1))
        with pytest.raises(OrderRefused, match="price out of range"):
            await svc.demo.confirm(p["token"], ETH, "no", "0.50", 1)
        rej = [o for o in svc.demo_ledger.orders() if o["state"] == "REJECTED"]
        assert len(rej) == 1 and rej[0]["side"] == "no"
    run(go())


def test_unique_client_order_ids(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        for _ in range(3):
            p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.45"), 1))
            await svc.demo.confirm(p["token"], ETH, "yes", "0.45", 1)
    run(go())
    ids = [b["client_order_id"] for b in fake.posts]
    assert len(ids) == 3 and len(set(ids)) == 3


# ---------------------------------------------------------------- fills, partial fills, cancel
def test_partial_fill_then_cancel_remaining(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 5))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 5)
        cid = r["client_order_id"]
        fake.fill("ord-1", Decimal(2))
        await svc.demo.reconcile()
        o = svc.demo_ledger.order(cid)
        assert o["state"] == "PARTIAL" and o["filled_c2"] == 200 and o["remaining_c2"] == 300
        assert len(svc.demo_ledger.fills()) == 1
        await svc.demo.reconcile()
        assert len(svc.demo_ledger.fills()) == 1          # fills are de-duplicated
        c = await svc.demo.cancel(cid)
        assert c["state"] == "CANCELED" and fake.orders["ord-1"]["status"] == "canceled"
        with pytest.raises(OrderRefused):
            await svc.demo.cancel(cid)
        kinds = [e["kind"] for e in svc.demo_ledger.events(100)]
        for k in ("submit", "ack", "fill", "cancel"):
            assert k in kinds
    run(go())


def test_full_fill(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "no", Decimal("0.50"), 2))
        r = await svc.demo.confirm(p["token"], ETH, "no", "0.50", 2)
        fake.fill("ord-1", Decimal(2))
        await svc.demo.reconcile()
        assert svc.demo_ledger.order(r["client_order_id"])["state"] == "FILLED"
    run(go())
    assert fake.posts[0]["side"] == "ask" and fake.posts[0]["price"] == "0.5000"      # buy NO at 50c = ask YES at 50c


# ---------------------------------------------------------------- kill switch
def test_kill_switch_cancels_everything_and_blocks(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        for px in ("0.45", "0.46"):
            p = await svc.demo.prepare(Intent(ETH, "yes", Decimal(px), 1))
            await svc.demo.confirm(p["token"], ETH, "yes", px, 1)
        fake.orders["ord-x"] = {"order_id": "ord-x", "client_order_id": "foreign", "ticker": ETH, "status": "resting",
                                "remaining_count_fp": "1.00", "fill_count_fp": "0.00"}     # resting order unknown locally
        r = await svc.demo.kill()
        assert r["canceled"] == 3 and r["failed"] == 0
        assert all(o["status"] == "canceled" for o in fake.orders.values())
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.45"), 1))
        assert p["token"] is None and any("Emergency stop" in e for e in p["errors"])
        svc.demo.reset_kill()
        assert (await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.45"), 1)))["token"]
    run(go())


# ---------------------------------------------------------------- automation
class AlwaysBid(Strategy):
    name = "test_always_bid"
    version = "1"
    interval_s = 0.01

    def decide(self, ctx):
        return [Intent(m["ticker"], "yes", Decimal("0.45"), 1, reason="test") for m in ctx.markets[:5]]


def _validate(root, cls, ok=True, h=None):
    d = Path(root) / "experiments" / "kalshi_validation"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{cls.name}@{cls.version}.json").write_text(json.dumps({"gates_passed": ok, "code_hash": h or code_hash(cls), "metrics": {"oos_trades": 50}}))


@pytest.fixture
def auto_env(env, monkeypatch):
    svc, fake, rest, clk = env
    monkeypatch.setitem(auto_mod.STRATEGIES, AlwaysBid.name, AlwaysBid)
    return svc, fake, rest, clk


def test_example_strategy_is_not_validated_and_cannot_arm(auto_env):
    svc, *_ = auto_env

    async def go():
        await ready(svc)
        with pytest.raises(OrderRefused, match="not validated"):
            svc.auto.arm("example_spread_quoter", "0.1", ARM_PHRASE)
        with pytest.raises(ValueError):
            approve(svc.demo_ledger, svc.ks.root, "example_spread_quoter", "0.1")
    run(go())
    assert svc.auto.state == "disarmed"


def test_validation_and_human_approval_both_required(auto_env):
    svc, fake, _, _ = auto_env
    root = svc.ks.root

    async def go():
        await ready(svc)
        with pytest.raises(OrderRefused):
            svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE)               # not validated
        _validate(root, AlwaysBid, ok=False)
        with pytest.raises(ValueError):
            approve(svc.demo_ledger, root, AlwaysBid.name, "1")         # gates failed
        _validate(root, AlwaysBid, ok=True, h="different-code")
        with pytest.raises(ValueError):
            approve(svc.demo_ledger, root, AlwaysBid.name, "1")         # validated different code
        _validate(root, AlwaysBid, ok=True)
        with pytest.raises(OrderRefused, match="approval"):
            svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE)               # validated but not approved by a human
        approve(svc.demo_ledger, root, AlwaysBid.name, "1")
        with pytest.raises(OrderRefused, match="ARM DEMO"):
            svc.auto.arm(AlwaysBid.name, "1", "yes")                    # wrong phrase
        svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE, max_positions=2)
        assert svc.auto.state == "armed"
    run(go())
    assert fake.posts == []                                             # arming alone never trades


def test_automation_runs_only_auto_eligible_with_limits_and_traceability(auto_env):
    svc, fake, _, _ = auto_env
    _validate(svc.ks.root, AlwaysBid)

    async def go():
        await ready(svc)
        approve(svc.demo_ledger, svc.ks.root, AlwaysBid.name, "1")
        svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE, max_positions=2, max_orders_per_min=6)
        svc.auto.state = "running"                                       # drive ticks directly (no background loop)
        n = await svc.auto.tick()
        assert n == 2                                                    # max positions
        n2 = await svc.auto.tick()
        assert n2 == 0
    run(go())
    tickers = [b["ticker"] for b in fake.posts]
    assert len(tickers) == 2
    for t in tickers:
        assert svc.access[t].auto                                        # only auto-eligible markets
    origins = {o["origin"] for o in svc.demo_ledger.orders()}
    assert all(o.startswith(f"auto:{AlwaysBid.name}@1:") for o in origins)   # every order traceable to strategy@version:session


def test_pause_stop_emergency_and_restart_disarms(auto_env, tmp_path):
    svc, fake, _, _ = auto_env
    _validate(svc.ks.root, AlwaysBid)

    async def go():
        await ready(svc)
        approve(svc.demo_ledger, svc.ks.root, AlwaysBid.name, "1")
        svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE, max_positions=3)
        svc.auto.start()
        await asyncio.sleep(0.05)
        assert len(fake.posts) >= 1
        svc.auto.pause()
        before = len(fake.posts)
        await asyncio.sleep(0.05)
        assert len(fake.posts) == before                                 # paused: no new orders
        await svc.auto.stop()
        assert svc.auto.state == "disarmed"
        assert all(o["status"] == "canceled" for o in fake.orders.values())   # stop cancels the strategy's open orders
        svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE)
        svc.auto.start()
        await asyncio.sleep(0.03)
        await svc.auto.emergency()
        assert svc.auto.state == "disarmed" and svc.demo.kill_on()
        with pytest.raises(OrderRefused):
            svc.auto.arm(AlwaysBid.name, "1", ARM_PHRASE)                # kill switch blocks re-arming
    run(go())
    # a fresh backend (restart) is always disarmed even though approval persists
    svc2 = TerminalService(svc.ks, live=False, registry=svc.reg, demo_ledger_path=svc.demo_ledger.path)
    assert svc2.auto.state == "disarmed"


def test_strategy_exception_pauses(auto_env):
    svc, fake, _, _ = auto_env

    class Broken(AlwaysBid):
        name, version = "test_broken", "1"

        def decide(self, ctx):
            raise ZeroDivisionError("bad")
    auto_mod.STRATEGIES[Broken.name] = Broken
    _validate(svc.ks.root, Broken)

    async def go():
        await ready(svc)
        approve(svc.demo_ledger, svc.ks.root, Broken.name, "1")
        svc.auto.arm(Broken.name, "1", ARM_PHRASE)
        svc.auto.state = "running"
        assert await svc.auto.tick() == 0
        assert svc.auto.state == "paused" and "ZeroDivisionError" in svc.auto.last_error
    run(go())
    auto_mod.STRATEGIES.pop(Broken.name, None)


# ---------------------------------------------------------------- UI/backend integration
def test_api_end_to_end_manual_order_and_cancel(env):
    svc, fake, _, _ = env
    app = create_terminal_app(svc)
    H = {"X-AICL-Client": "terminal"}
    with TestClient(app) as c:
        for _ in range(50):
            if c.get("/api/health").json()["phase"] == "ready":
                break
            time.sleep(0.05)
        svc.now_fn = lambda: NOW
        svc.recompute_access()
        assert c.post("/api/demo/budget", json={"amount": "700"}, headers=H).json()["ok"]
        for _ in range(50):
            if c.get("/api/demo/status").json()["state"] == "connected":
                break
            time.sleep(0.05)
        body = {"ticker": ETH, "side": "yes", "price": "0.50", "count": 2}
        prep = c.post("/api/demo/orders/prepare", json=body, headers=H).json()
        assert prep["ok"] and prep["token"]
        assert c.post("/api/demo/orders/confirm", json={**body, "token": prep["token"]}).status_code == 403      # header required
        res = c.post("/api/demo/orders/confirm", json={**body, "token": prep["token"]}, headers=H).json()
        assert res["ok"] and res["state"] == "RESTING"
        again = c.post("/api/demo/orders/confirm", json={**body, "token": prep["token"]}, headers=H)
        assert again.status_code == 422                                                                           # single use
        lst = c.get("/api/demo/orders").json()["orders"]
        assert len(lst) == 1 and lst[0]["state"] == "RESTING"
        can = c.post(f"/api/demo/orders/{res['client_order_id']}/cancel", headers=H).json()
        assert can["ok"] and can["state"] == "CANCELED"
        assert c.get("/api/auto/status").json()["state"] == "disarmed"
        k = c.post("/api/demo/kill", headers=H).json()
        assert k["ok"] and c.get("/api/demo/status").json()["kill"] is True
    assert len(fake.posts) == 1


def test_v2_translation_table():
    f = DemoExchange.to_v2
    base = {"ticker": "T", "client_order_id": "c", "count": 3}
    assert f({**base, "side": "yes", "action": "buy", "yes_price_dollars": "0.4500"})["side"] == "bid"
    b = f({**base, "side": "no", "action": "buy", "no_price_dollars": "0.3000"})
    assert (b["side"], b["price"], b["count"]) == ("ask", "0.7000", "3.00")                      # buy NO 30c = ask YES 70c
    c = f({**base, "side": "yes", "action": "sell", "yes_price_dollars": "0.3900", "time_in_force": "immediate_or_cancel", "reduce_only": True})
    assert (c["side"], c["price"], c["reduce_only"], c["time_in_force"]) == ("ask", "0.3900", True, "immediate_or_cancel")
    d = f({**base, "side": "no", "action": "sell", "no_price_dollars": "0.2000", "time_in_force": "immediate_or_cancel", "reduce_only": True})
    assert (d["side"], d["price"]) == ("bid", "0.8000")                                          # sell NO 20c = bid YES 80c
    with pytest.raises(DemoOnlyViolation):
        f({**base, "side": "yes", "action": "sell", "yes_price_dollars": "0.39", "reduce_only": True})   # reduce_only needs IOC


def test_order_funds_the_markets_exchange_shard_first(env):
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        assert svc.demo.shards == {0: Decimal("500.0000"), 2: Decimal("0.0000")}
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 2))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 2)
        assert r["state"] == "RESTING"
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.45"), 1))
        await svc.demo.confirm(p["token"], ETH, "yes", "0.45", 1)
    run(go())
    assert len(fake.transfers) == 1                                    # funded once, second order needs no transfer
    t = fake.transfers[0]
    assert t["amount"] == 5_000_000 and t["source_exchange_shard"] == 0 and t["destination_exchange_shard"] == 2     # $500 in centicents
    assert fake.shards == {0: Decimal("0.00"), 2: Decimal("500.00")}
    assert any(e["kind"] == "funding" for e in svc.demo_ledger.events(50))
    kinds = [(m, pth.rsplit("/", 1)[-1]) for m, _, pth in fake.requests]
    assert kinds.index(("POST", "intra_exchange_instance_transfer")) < kinds.index(("POST", "orders"))


def test_transfer_endpoint_is_fixed_to_own_event_contract_balance():
    with pytest.raises(DemoOnlyViolation):
        check_demo_request("POST", "/portfolio/subaccounts/transfer")
    ex = DemoExchange(signer(), http_transport=httpx.MockTransport(lambda r: httpx.Response(200, json={})))
    for bad in ((Decimal(0), 0, 2), (Decimal(5), 2, 2), (Decimal(5), 0, 101)):
        with pytest.raises(DemoOnlyViolation):
            asyncio.run(ex.shard_transfer(*bad, "x"))
