"""Final-minute harness on recorder data: no outcomes in inputs, gaps excluded, one-sided books, conservative fills."""
import math

from aicrypto.research15.recordings import BookSeries, Recorded
from aicrypto.research_agent import harness_recorded as HR

C = 1_800_000_000 - (1_800_000_000 % 900) + 900
T = "KXBTC15M-TEST"


def _rec(result="yes", value=100.4, book=([(0.60, 50)], [(0.38, 40)]), drop_final=False):
    r = Recorded()
    r.meta[T] = {"asset": "BTC", "strike": 100.0, "close_ts": C}
    r.settled[T] = {"result": result, "settle_value": str(value)}
    pts = [(float(s), value * math.exp(1e-5 * (1 if s % 2 else -1)), float(s)) for s in range(C - 900, C)]
    if drop_final:
        pts = [p for p in pts if p[0] < C - 55]
    r.cf["BRTI"] = pts
    bs = BookSeries()
    for t in range(C - 210, C, 30):                              # unchanged book: a full snapshot every 30 s, like the recorder
        bs.add(float(t), book[0], book[1])
    r.books[T] = bs
    return r


def test_inputs_have_no_outcomes_and_book_persists_until_next_record():
    ctxs, labels, excl = HR.build(None, ["BTC"], rec=_rec())
    assert len(ctxs) == len(HR.LEADS) and excl == {"index_gap": 0, "no_book": 0, "short_history": 0}
    for c in ctxs:
        assert not ({"y", "result", "settle_value", "window", "close_ts", "after_yes", "after_no"} & set(c))
    c = ctxs[0]
    assert c["ask_yes"] == 0.62 and c["bid_yes"] == 0.60 and abs(c["mid"] - 0.61) < 1e-9


def test_index_gap_in_final_minute_is_excluded_not_estimated():
    ctxs, labels, excl = HR.build(None, ["BTC"], rec=_rec(drop_final=True))
    assert excl["index_gap"] > 0 and all(c["n_known"] >= c["n_expected"] - 1 for c in ctxs)


def test_one_sided_book_keeps_the_buyable_side():
    ctxs, labels, excl = HR.build(None, ["BTC"], rec=_rec(book=([(0.97, 30)], [])))      # nobody offers YES
    c = ctxs[0]
    assert c["ask_yes"] is None and c["bid_yes"] == 0.97 and abs(c["mid"] - 0.985) < 1e-9
    tr = HR.trades(ctxs, labels, [0.0] * len(ctxs), 0.0, 0.02)                           # model says NO: buy NO at 3%
    assert tr and tr[0]["side"] == "no" and abs(tr[0]["ask"] - 0.03) < 1e-9


def test_fill_uses_half_depth_and_price_limit():
    assert HR.fill([(0.40, 10), (0.43, 100)], 8, 0.42) == (5, 5 * 0.40)
    assert HR.fill([(0.45, 100)], 1, 0.42) is None
    ctxs, labels, _ = HR.build(None, ["BTC"], rec=_rec(book=([(0.60, 1)], [(0.38, 1)])))  # 50% of 1 contract = nothing
    assert HR.trades(ctxs, labels, [0.99] * len(ctxs), 0.0, 0.02) == []
    ctxs, labels, _ = HR.build(None, ["BTC"], rec=_rec(result="yes"))
    tr = HR.trades(ctxs, labels, [0.99] * len(ctxs), 0.0, 0.02)
    assert len(tr) == 1 and tr[0]["win"] == 1.0                                            # one trade per window
    assert abs(tr[0]["pnl_cons"] - (1 - 0.62 - HR.fee1(0.62))) < 1e-9
