import sys
from datetime import timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.durations import DurationBucket
from aicrypto.kalshi.eligibility import Tier
from aicrypto.kalshi.models import MarketStatus
from aicrypto.kalshi.paths import RequestAllowlist, RequestNotAllowed
from aicrypto.kalshi.registry import MarketRegistry
from aicrypto.kalshi.settings import load_kalshi_settings


@pytest.fixture
def reg(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    r = MarketRegistry(ks, db_path=tmp_path / "registry.sqlite")
    for s in fx.SERIES.values():
        r.upsert_series(s)
    for m in fx.MARKETS.values():
        r.upsert_market(m)
    return r


def test_discovery_universe_is_complete_and_persisted(reg, tmp_path):
    summ = reg.summary()
    assert summ["markets"] == len(fx.MARKETS)
    assert summ["tiers"]["tradeable"] >= 10 and summ["tiers"]["record_only"] == 3 and summ["tiers"]["rejected"] >= 9
    # reload from disk -> same universe
    reg2 = MarketRegistry(reg.s, db_path=tmp_path / "registry.sqlite")
    assert len(reg2.markets) == len(fx.MARKETS) and len(reg2.series) == len(fx.SERIES)
    reg2.reevaluate_all()
    assert reg2.summary()["tiers"] == summ["tiers"]


def test_all_durations_and_assets_discovered(reg):
    dur = reg.durations_available()
    assert dur["BTC"][DurationBucket.M15.value] >= 2 and len(dur["BTC"]) >= 2   # 15m windows + the longer range listing
    assert dur["ETH"][DurationBucket.DAILY.value] == 5 and dur["SOL"][DurationBucket.H1.value] == 2
    assert "GOLD" in dur and "WTI" in dur   # record-only markets are still discovered


def test_ladders_and_overlaps(reg):
    ladders = reg.ladders()
    eth = ladders["KXETHD-26NOV1017"]
    assert [float(m.floor_strike) for m in eth] == [1900, 1950, 2000, 2050, 2100]
    sol = ladders["KXSOLH-26NOV0915"]
    assert len(sol) == 2
    ov = reg.overlapping("BTC", now=fx.T0 + timedelta(minutes=1))
    assert [m.series_ticker for m in ov][:2] == ["KXBTC15M", "KXBTC"]   # 15m window closes before the daily range


def test_rejection_reasons_preserved_and_history_kept(reg):
    rs = reg.rejection_summary()
    assert rs["reference_feed_unavailable"] == 3 and rs["category_denied"] >= 3
    hist = reg.eligibility_history("KXGOLD15M-26NOV091400-00")
    assert len(hist) == 1 and hist[0]["tier"] == "record_only" and "reference_feed_unavailable" in hist[0]["reasons"]


def test_reconsideration_when_feed_becomes_available(reg):
    t = "KXGOLD15M-26NOV091400-00"
    assert reg.decision(t).tier is Tier.RECORD_ONLY
    reg.s.reference_feeds.pyth.enabled = True
    counts = reg.reevaluate_all()
    assert reg.decision(t).tier is Tier.TRADEABLE and counts["record_only"] == 1  # WTI (ICE) stays record-only
    hist = reg.eligibility_history(t)
    assert [h["tier"] for h in hist] == ["record_only", "tradeable"] and hist[-1]["is_current"] == 1 and hist[0]["is_current"] == 0


def test_lifecycle_events(reg):
    o = fx.T0 + timedelta(minutes=30); c = o + timedelta(minutes=15)
    tk = f"KXBTC15M-26NOV09{o.strftime('%H%M')}-{o.strftime('%M')}"
    m = reg.apply_lifecycle(fx.lifecycle_created(tk, o, c, floor=92000.0))
    assert m.status is MarketStatus.INITIALIZED and reg.decision(tk).tier is Tier.TRADEABLE
    assert reg.apply_lifecycle(fx.lifecycle(tk, "activated")).status is MarketStatus.ACTIVE
    assert reg.apply_lifecycle(fx.lifecycle(tk, "deactivated", is_deactivated=True)).status is MarketStatus.INACTIVE
    assert reg.apply_lifecycle(fx.lifecycle(tk, "deactivated", is_deactivated=False)).status is MarketStatus.ACTIVE
    m2 = reg.apply_lifecycle(fx.lifecycle(tk, "close_date_updated", close_ts=int((c - timedelta(minutes=5)).timestamp())))
    assert m2.close_time == c - timedelta(minutes=5)
    m3 = reg.apply_lifecycle(fx.lifecycle(tk, "determined", result="yes", settlement_value="1.0000"))
    assert m3.status is MarketStatus.DETERMINED and m3.result == "yes" and m3.settlement_value_p4 == 10000
    m4 = reg.apply_lifecycle(fx.lifecycle(tk, "settled", settled_ts=int(c.timestamp()) + 300))
    assert m4.status is MarketStatus.FINALIZED and tk in reg.markets  # preserved for history
    assert reg.apply_lifecycle(fx.lifecycle("KXUNKNOWN-1", "activated")) is None
    with reg._conn() as c_:
        assert c_.execute("SELECT COUNT(*) FROM lifecycle_log").fetchone()[0] == 8


def test_metadata_update_can_flip_eligibility(reg):
    t = "KXBTC15M-26NOV091400-00"
    reg.apply_lifecycle(fx.lifecycle(t, "metadata_updated", strike_type="functional"))
    assert reg.decision(t).tier is Tier.REJECTED
    assert len(reg.eligibility_history(t)) == 2


def test_subscription_budget_does_not_limit_discovery(reg):
    reg.s.subscriptions.max_orderbooks = 3
    now = fx.T0 + timedelta(minutes=1)
    subs, add, rem = reg.schedule_subscriptions(now)
    assert len(subs) == 3 and set(add) == set(subs) and rem == []
    assert all(reg.decision(t).tier is Tier.TRADEABLE for t in subs)
    assert reg.summary()["markets"] == len(fx.MARKETS)        # universe intact
    # closing-soon 15m window outranks the far daily ladder legs
    assert "KXBTC15M-26NOV091400-00" in subs


def test_subscription_hysteresis_and_closed_market_removal(reg):
    reg.s.subscriptions.max_orderbooks = 2
    now = fx.T0 + timedelta(minutes=1)
    subs, _, _ = reg.schedule_subscriptions(now)
    # small liquidity change should not swap
    other = next(t for t in reg.active_tradeable(now) if t.ticker not in subs).ticker
    reg.update_liquidity(other, bid_size_c2=200_000, ask_size_c2=200_000)   # big depth
    subs2, add2, rem2 = reg.schedule_subscriptions(now)
    assert len(subs2) == 2
    # after the 15m window settles it must leave the subscription set
    reg.apply_lifecycle(fx.lifecycle("KXBTC15M-26NOV091400-00", "settled"))
    subs3, _, rem3 = reg.schedule_subscriptions(now)
    assert "KXBTC15M-26NOV091400-00" not in subs3 and len(subs3) == 2


def test_record_only_and_rejected_never_subscribed(reg):
    reg.s.subscriptions.max_orderbooks = 100
    subs, _, _ = reg.schedule_subscriptions(fx.T0 + timedelta(minutes=1))
    for t in subs:
        assert reg.decision(t).tier is Tier.TRADEABLE
    assert "KXGOLD15M-26NOV091400-00" not in subs and "KXPRES-28-DEM" not in subs


def test_unhealthy_feed_derank(reg):
    now = fx.T0 + timedelta(minutes=1)
    top = reg.rank(now)[0].ticker
    reg.update_liquidity(top, feed_healthy=False)
    assert reg.rank(now)[0].ticker != top


# ---- runtime request allowlist (adversarial) ------------------------------------------------
@pytest.mark.parametrize("method,path", [
    ("GET", "/trade-api/v2/markets"), ("GET", "/markets?limit=1000&status=open"), ("GET", "/series/KXBTC15M"),
    ("GET", "/markets/KXBTC15M-26NOV091400-00/orderbook"), ("GET", "/exchange/status"), ("GET", "/account/limits"),
    ("GET", "https://external-api.kalshi.com/trade-api/v2/events/KXBTC15M-26NOV091400"),
    ("GET", "/historical/markets/KXBTC15M-26NOV091345-45/candlesticks"),
])
def test_allowlist_permits_market_data(method, path):
    assert RequestAllowlist().check_rest(method, path)


@pytest.mark.parametrize("method,path", [
    ("POST", "/portfolio/orders"), ("DELETE", "/portfolio/orders/abc"), ("POST", "/trade-api/v2/portfolio/orders/batched"),
    ("GET", "/portfolio/orders"), ("GET", "/portfolio/balance"), ("GET", "/portfolio/positions"),
    ("POST", "/portfolio/order_groups"), ("POST", "/api_keys/generate"), ("POST", "/communications/rfqs"),
    ("GET", "/markets/../portfolio/orders"), ("GET", "/markets//../../portfolio/balance"),
    ("GET", "/markets?x=1#/portfolio/orders"), ("get", "/PORTFOLIO/orders"), ("GET", "/margin/orders"),
    ("GET", "/markets/KXBTC/orderbook/../../portfolio/orders"), ("PUT", "/markets"), ("POST", "/markets"),
    ("GET", "/series/KXBTC15M/../../portfolio/orders"), ("GET", "/exchange/user_data_timestamp"),
])
def test_allowlist_refuses_everything_else(method, path):
    al = RequestAllowlist()
    with pytest.raises(RequestNotAllowed):
        al.check_rest(method, path)
    assert al.stats.refused == 1 and al.stats.refused_examples


def test_ws_allowlist():
    al = RequestAllowlist()
    ok = {"id": 1, "cmd": "subscribe", "params": {"channels": ["orderbook_delta", "ticker"], "market_tickers": ["KXBTC15M-1"]}}
    assert al.check_ws_command(ok) is ok
    for bad in [
        {"id": 2, "cmd": "subscribe", "params": {"channels": ["fill"]}},
        {"id": 3, "cmd": "subscribe", "params": {"channels": ["user_orders"]}},
        {"id": 4, "cmd": "create_order", "params": {}},
        {"id": 5, "cmd": "subscribe", "params": {"channels": ["ticker"], "orders": [1]}},
        {"id": 6, "cmd": "subscribe", "params": {"channels": ["order_group_updates"]}},
    ]:
        with pytest.raises(RequestNotAllowed):
            al.check_ws_command(bad)


def test_no_trading_client_dependency_and_no_order_code():
    root = Path(__file__).resolve().parents[1]
    py = (root / "pyproject.toml").read_text().lower()
    for pkg in ("kalshi-python", "pykalshi", "kalshi_python", "kalshi-client"):
        assert pkg not in py
    demo_dir = root / "aicrypto" / "kalshi" / "demo_exec"     # the single permitted order path (demo host only)
    for p in (root / "aicrypto" / "kalshi").rglob("*.py"):
        if demo_dir in p.parents:
            continue
        src = p.read_text().lower()
        assert "portfolio/orders" not in src.replace("/portfolio/|/orders", ""), p   # only the deny regex may mention it
        assert "create_order" not in src and "batch_create" not in src, p
    # inside demo_exec, only exchange.py talks to the API and only trader.py calls create_order
    for p in demo_dir.rglob("*.py"):
        src = p.read_text()
        if p.name not in ("exchange.py", "trader.py"):
            assert "create_order" not in src, p
        assert "batch" not in src.lower().replace("batched|", ""), p


def test_reload_does_not_rewrite_eligibility_history(reg, tmp_path):
    t = "KXGOLD15M-26NOV091400-00"
    assert len(reg.eligibility_history(t)) == 1
    again = MarketRegistry(reg.s, db_path=tmp_path / "registry.sqlite")
    again.reevaluate_all()
    assert len(again.eligibility_history(t)) == 1          # unchanged decision -> no new history row
    again.s.reference_feeds.pyth.enabled = True             # a real change still appends history
    again.reevaluate_all()
    assert len(again.eligibility_history(t)) == 2
