import pandas as pd

from aicrypto.research.leakage import lookahead_probe, recursive_probe
from aicrypto.research.walkforward import make_folds, walk_forward
from aicrypto.settings import WalkForward
from aicrypto.strategies import StrategySpec, compute_signals, random_spec


def leaky_signals(df: pd.DataFrame, spec: StrategySpec) -> pd.DataFrame:
    """Deliberately cheats: enters when the NEXT bar closes higher."""
    out = compute_signals(df, spec)
    out["enter_long"] = (df["close"].shift(-1) > df["close"]).fillna(False).astype(bool)
    return out


def centered_signals(df: pd.DataFrame, spec: StrategySpec) -> pd.DataFrame:
    """Subtler leak: centred rolling mean (uses future bars)."""
    out = compute_signals(df, spec)
    ma = df["close"].rolling(21, center=True).mean()
    out["enter_long"] = (df["close"] > ma).fillna(False).astype(bool)
    return out


def test_causal_families_pass_lookahead(data3, rng):
    df = data3["BTC/USDT"]
    for fam in ["ema_cross", "rsi_reversion", "donchian_breakout", "bollinger_reversion"]:
        rep = lookahead_probe(df, random_spec(rng, fam))
        assert rep.ok, (fam, rep)


def test_leaky_strategies_are_caught(data3, ema_spec):
    df = data3["BTC/USDT"]
    assert not lookahead_probe(df, ema_spec, signal_fn=leaky_signals).ok
    assert not lookahead_probe(df, ema_spec, signal_fn=centered_signals).ok


def test_recursive_probe_reports_drift(data3, ema_spec):
    rep = recursive_probe(data3["BTC/USDT"], ema_spec)
    assert rep.max_rel_drift >= 0
    # EMA with 3x-span warm-up: drift should be tiny and no flips
    assert rep.signal_flips == 0, rep


def test_recursive_probe_catches_short_warmup(data3):
    # Same EMA strategy but pretend startup is far too short => signals differ by warm-up
    spec = StrategySpec("ema_cross", {"fast": 5, "slow": 200, "trend_filter": 0},
                        {"stop_pct": 0.03, "trail_pct": 0.0, "max_bars": 0})
    rep = recursive_probe(data3["BTC/USDT"], spec, warmups=[20, 60, len(data3["BTC/USDT"])], tail=300)
    assert rep.max_rel_drift > 0.01  # path dependence is visible with short warm-ups


def test_fold_layout_has_no_overlap_between_train_and_test():
    wf = WalkForward(train_bars=1000, test_bars=300, step_bars=300, max_folds=5)
    folds = make_folds(3000, wf, warm=50)
    assert len(folds) == 5
    for tr_s, tr_e, te_s, te_e in folds:
        assert te_e - tr_e == 300          # test window length
        assert te_s == tr_e - 50           # lead-in equals warm-up
    assert folds[1][0] == folds[0][0] + 300


def test_walk_forward_runs(data3, ema_spec, capital, costs):
    wf = WalkForward(train_bars=1200, test_bars=400, step_bars=400, max_folds=4, optimizer_samples=4, seed=1)
    res = walk_forward(data3, ema_spec, capital, costs, wf)
    assert res.n_folds == 4
    assert len(res.oos_equity) == 4 * 400
    assert 0 <= res.positive_fold_fraction <= 1
    assert res.oos_trades == sum(f.oos_metrics["trades"] for f in res.folds)
    # determinism under seed
    res2 = walk_forward(data3, ema_spec, capital, costs, wf)
    assert [f.chosen.spec_hash for f in res.folds] == [f.chosen.spec_hash for f in res2.folds]
    assert res.oos_metrics["total_return"] == res2.oos_metrics["total_return"]
