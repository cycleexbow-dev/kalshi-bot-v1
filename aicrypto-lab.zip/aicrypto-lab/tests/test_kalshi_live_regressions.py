"""Regression tests built from real demo-environment payloads (captured 2026-11-09).
Each case was misclassified by the Phase 2 logic and is pinned here."""
import json
from pathlib import Path

import pytest

from aicrypto.kalshi.eligibility import Reason, Tier, evaluate
from aicrypto.kalshi.models import MarketInfo, SeriesInfo
from aicrypto.kalshi.settings import load_kalshi_settings
from aicrypto.kalshi.settlement_map import Provider, ReferenceStatus

FX = json.loads((Path(__file__).parent / "fixtures" / "kalshi" / "live_demo_20261109.json").read_text())
BY = {m["ticker"]: m for m in FX["markets"]}
FREQ = {"KXBTC": "hourly", "KXBTCD": "hourly", "KXETH": "hourly", "KXETHD": "hourly", "KXSOLE": "hourly", "KXHYPE": "hourly",
        "KXBNBD": "hourly", "KXDOGE": "hourly", "KXGOLDH": "hourly", "KXSILVERH": "hourly", "KXWTIH": "hourly",
        "KXPALLADIUMH": "hourly", "KX2YRRATEH": "hourly", "KXINXU": "hourly", "KXNASDAQ100U": "hourly", "KXWTIW": "weekly"}


@pytest.fixture(scope="module")
def ks():
    return load_kalshi_settings()


def build(ticker):
    r = BY[ticker]
    series = SeriesInfo.from_api({"ticker": r["series_ticker"], "title": r["series_ticker"], "category": r["category"],
                                  "categories": [r["category"]], "tags": [], "frequency": FREQ.get(r["series_ticker"], ""),
                                  "settlement_sources": json.loads(r["settlement_sources"]), "fee_type": "quadratic",
                                  "fee_multiplier": 1.0})
    market = MarketInfo.from_api({"ticker": r["ticker"], "event_ticker": "-".join(r["ticker"].split("-")[:2]), "market_type": "binary",
                                  "status": r["status"], "strike_type": r["strike_type"],
                                  "floor_strike": float(r["floor_strike"]) if r["floor_strike"] else None,
                                  "cap_strike": float(r["cap_strike"]) if r["cap_strike"] else None,
                                  "open_time": r["open_time"], "close_time": r["close_time"], "rules_primary": r["rules_primary"],
                                  "yes_sub_title": r["yes_sub_title"]})
    return series, market


@pytest.mark.parametrize("ticker,asset,instrument", [
    ("KXETH-26NOV0923-B2232", "ETH", "ETHUSD_RTI"),        # was: asset 'ET' + suffix 'H'
    ("KXSOLE-26NOV0901-B108.875", "SOL", "SOLUSD_RTI"),    # was: asset 'SOLE'
    ("KXBTCD-26NOV0911-T66999.99", "BTC", "BRTI"),
    ("KXETHD-26NOV0907-T1509.99", "ETH", "ETHUSD_RTI"),    # rules say 'ERTI'; source link says ETHUSD_RTI
    ("KXHYPE-26NOV0908-B78.875", "HYPE", "HYPEUSD_RTI"),
    ("KXBNBD-26NOV0916-T789.99", "BNB", "BNBUSD_RTI"),
])
def test_crypto_ladders_tradeable_with_correct_index(ks, ticker, asset, instrument):
    d = evaluate(*build(ticker), ks)
    assert d.tier is Tier.TRADEABLE, (d.reasons, d.notes)
    assert d.asset == asset and d.reference.instrument == instrument and d.reference.provider is Provider.CF_BENCHMARKS


def test_hourly_cadence_from_series_frequency(ks):
    d = evaluate(*build("KXBTCD-26NOV0911-T66999.99"), ks)
    assert d.duration.bucket.value == "1h"   # listed ~30h ahead, but it is an hourly-settling contract


@pytest.mark.parametrize("ticker,asset,instrument", [
    ("KXGOLDH-26NOV0921-T4067.99", "GOLD", "Metal.Index.1OZGOLD/USD"),
    ("KXSILVERH-26NOV0921-T52.499", "SILVER", "Metal.Index.SILVER/USD"),
    ("KXWTIH-26NOV0922-T87.99", "WTI", "Commodities.Index.PYTHOIL/USD"),
    ("KXPALLADIUMH-26NOV0906-T1021.49", "PALLADIUM", "Metal.XPD/USD"),
    ("KX2YRRATEH-09NOV2609-T450", "UST2Y", "InterestRate.US2Y"),
])
def test_pyth_instrument_read_from_source_link_and_record_only(ks, ticker, asset, instrument):
    d = evaluate(*build(ticker), ks)
    assert d.tier is Tier.RECORD_ONLY and d.reasons == [Reason.REFERENCE_FEED_UNAVAILABLE], (d.reasons, d.notes)
    assert d.asset == asset and d.reference.instrument == instrument and d.reference.provider is Provider.PYTH


def test_pyth_markets_become_tradeable_only_when_feed_enabled(ks):
    ks2 = ks.model_copy(deep=True); ks2.reference_feeds.pyth.enabled = True
    assert evaluate(*build("KXGOLDH-26NOV0921-T4067.99"), ks2).tier is Tier.TRADEABLE
    assert evaluate(*build("KX2YRRATEH-09NOV2609-T450"), ks2).tier is Tier.TRADEABLE


@pytest.mark.parametrize("ticker,asset", [("KXINXU-26NOV09H1500-T7399.9999", "SPX"), ("KXNASDAQ100U-26NOV09H1300-T25919.99", "NDX")])
def test_index_markets_with_example_only_source_are_record_only(ks, ticker, asset):
    d = evaluate(*build(ticker), ks)
    assert d.tier is Tier.RECORD_ONLY and d.asset == asset and d.reference.provider is Provider.UNSPECIFIED
    assert "non-specific" in " ".join(d.notes)
    ks2 = ks.model_copy(deep=True); ks2.reference_feeds.pyth.enabled = True
    assert evaluate(*build(ticker), ks2).tier is Tier.RECORD_ONLY      # enabling Pyth must not unlock these


def test_ice_wti_weekly_record_only(ks):
    d = evaluate(*build("KXWTIW-26NOV1314-B91.50"), ks)
    assert d.tier is Tier.RECORD_ONLY and d.reference.provider is Provider.ICE and d.asset == "WTI"
    assert d.duration.bucket.value == "weekly"


def test_custom_strike_still_rejected(ks):
    d = evaluate(*build("KXDOGE-26NOV0903-B0.147"), ks)   # strike only in text; no floor/cap fields
    assert d.tier is Tier.REJECTED and Reason.STRIKE_TYPE_NOT_ALLOWED in d.reasons


def test_queued_15m_window_is_strike_pending_not_rejected(ks):
    series = SeriesInfo.from_api({"ticker": "KXBTC15M", "title": "BTC 15m", "category": "Crypto", "frequency": "fifteen_min",
                                  "settlement_sources": [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/data/indices/BRTI"}],
                                  "fee_type": "quadratic", "fee_multiplier": 1.0})
    base = {"ticker": "KXBTC15M-26NOV090115-15", "event_ticker": "KXBTC15M-26NOV090115", "market_type": "binary",
            "open_time": "2026-11-09T06:15:00Z", "close_time": "2026-11-09T06:30:00Z",
            "rules_primary": "If the simple average of the sixty seconds of CF Benchmarks' Bitcoin Real-Time Index (BRTI) before the close "
                             "is at or above the simple average of the sixty seconds before the open, then the market resolves to Yes."}
    queued = evaluate(series, MarketInfo.from_api({**base, "status": "initialized", "strike_type": "functional"}), ks)
    assert queued.tier is Tier.RECORD_ONLY and queued.reasons == [Reason.STRIKE_PENDING]
    live = evaluate(series, MarketInfo.from_api({**base, "status": "active", "strike_type": "greater_or_equal", "floor_strike": 91234.5}), ks)
    assert live.tier is Tier.TRADEABLE and live.duration.structure.value == "up_down_window"
    stale = evaluate(series, MarketInfo.from_api({**base, "status": "active", "strike_type": "functional"}), ks)
    assert stale.tier is Tier.REJECTED     # an OPEN window without a usable strike is rejected, not pending


def test_real_payload_fields_all_known():
    from aicrypto.kalshi.schemas import KNOWN_MARKET_EXTRA, KNOWN_SERIES_EXTRA, MARKET_SCHEMA, SERIES_SCHEMA, validate_market, validate_series
    assert not set(FX["raw_market"]) - set(MARKET_SCHEMA) - KNOWN_MARKET_EXTRA
    assert not set(FX["raw_series"]) - set(SERIES_SCHEMA) - KNOWN_SERIES_EXTRA
    validate_market(FX["raw_market"]); validate_series(FX["raw_series"])


def test_ticker_prefix_fallback(ks):
    a = ks.eligibility.asset_from_ticker
    assert a("KXETH") == "ETH" and a("KXSOLE") == "SOL" and a("KXINXU") == "SPX" and a("KXNASDAQ100") == "NDX"
    assert a("KX10YRRATEH") == "UST10Y" and a("KXSHIBAD") == "SHIB" and a("KXNFLGAME") == "" and a("KXAAPLEPS") == ""


def test_commodity_15m_window_listed_active_without_strike_is_pending(ks):
    """Live 2026-11-09: KXGOLD15M windows are listed ACTIVE ~1 day early with strike_type null."""
    series = SeriesInfo.from_api({"ticker": "KXGOLD15M", "title": "Gold 15 min", "category": "Commodities", "frequency": "",
                                  "settlement_sources": [{"name": "Pyth - Gold", "url": "https://app.pyth.com/explore/Metal.Index.GOLD%2FUSD?returnUrl=%2Fexplore%3Fstate%3Dstable"}],
                                  "fee_type": "quadratic", "fee_multiplier": 1.0})
    m = MarketInfo.from_api({"ticker": "KXGOLD15M-26NOV092345-45", "event_ticker": "KXGOLD15M-26NOV092345", "market_type": "binary",
                             "status": "active", "strike_type": None, "open_time": "2026-11-08T22:34:30Z", "close_time": "2026-11-10T04:45:00Z",
                             "rules_primary": "If the close price of the 1-minute candlestick for Gold on Nov 9, 2026 at 11:45 PM EST is at least the close "
                                              "price of the 1-minute Pyth GOLD candlestick at 11:30 PM EDT on November 9, 2026 USD/t.oz, then the market resolves to Yes."})
    d = evaluate(series, m, ks)
    assert d.tier is Tier.RECORD_ONLY and set(d.reasons) == {Reason.REFERENCE_FEED_UNAVAILABLE, Reason.STRIKE_PENDING}, (d.reasons, d.notes)
    assert d.asset == "GOLD" and d.reference.instrument == "Metal.Index.GOLD/USD"
    assert d.reference.method.value == "window_compare_candle_1m"


def test_exchange_test_series_rejected_even_if_crypto(ks):
    series, market = build("KXBTCD-26NOV0911-T66999.99")
    series.ticker = "KXMAXSHARDINGTEST"; series.title = "max sharding test"
    d = evaluate(series, market, ks)
    assert d.tier is Tier.REJECTED and Reason.TEST_SERIES in d.reasons


# ---- third live pass (2026-11-09): wordings observed on the demo exchange ----------------------
def _mk(series_ticker, category, freq, sources, rules, *, status="active", strike_type="greater", floor=1.0, cap=None,
        open_t="2026-11-08T11:34:18Z", close_t="2026-11-09T21:00:00Z"):
    s = SeriesInfo.from_api({"ticker": series_ticker, "title": series_ticker, "category": category, "frequency": freq,
                             "settlement_sources": sources, "fee_type": "quadratic", "fee_multiplier": 1.0})
    m = MarketInfo.from_api({"ticker": f"{series_ticker}-26NOV0916-T1", "event_ticker": f"{series_ticker}-26NOV0916", "market_type": "binary",
                             "status": status, "strike_type": strike_type, "floor_strike": floor, "cap_strike": cap,
                             "open_time": open_t, "close_time": close_t, "rules_primary": rules})
    return s, m


LIVE = {
    "7y_hermes": _mk("KX7YRRATEH", "Financials", "hourly",
                     [{"name": "Pyth - 7Y UST", "url": "https://hermes.pyth.network/v2/updates/price/latest?ids[]=2087a47ebf7bb31aee61ffd003a71efe2bed0dda16746ddde63f498f68ece6ce"}],
                     "If the Pyth security yield for the 7-Year U.S. Treasury Note is above 4.78% at Nov 9, 2026 at 4:00am ET, the market resolves to Yes.", floor=4.78),
    "fx_jpy": _mk("KXUSDJPY15M", "Financials", "fifteen_min", [{"name": "Pyth", "url": "https://pythdata.app/explore"}],
                  "If the value of the USD/JPY exchange rate is at least the value of the USD/JPY exchange rate as published by Pyth Network at 12:30 AM EST on November 9, 2026 At 12:45 AM EST on Nov 9, 2026, then the market resolves to Yes.",
                  strike_type="greater_or_equal", floor=158.242),
    "fx_gbp": _mk("KXGBPUSD15M", "Financials", "fifteen_min",
                  [{"name": "Pyth - GBPUSD", "url": "https://app.pyth.com/explore/FX.GBP%2FUSD?returnUrl=%2Fexplore%3Fsearch%3Dgbpusd%26state%3Dstable"}],
                  "If the value of the GBP/USD exchange rate is at least the value of the GBP/USD exchange rate as published by Pyth Network at 12:30 AM EST on November 9, 2026 At 12:45 AM EST on Nov 9, 2026, then the market resolves to Yes.",
                  strike_type="greater_or_equal", floor=1.33814),
    "rate15m_queued": _mk("KX5YRRATE15M", "Financials", "fifteen_min", [{"name": "Pyth - 5Y UST", "url": "https://app.pyth.com/explore/InterestRate.US5Y"}],
                          "If the Yield of the 5-year U.S. Treasury as reported by Pyth is at least the close yield of the 1-minute Pyth US5Y candlestick at 4:45 PM EST on November 9, 2026% At 5:00 PM EST on Nov 9, 2026, then the market resolves to Yes.",
                          status="initialized", strike_type=None, floor=None),
    "dji": _mk("KXDJI", "Financials", "hourly", [{"name": "Pyth", "url": "https://app.pyth.com/explore/Equity.Index.US30%2FUSD"}],
               "If the value of the Index.US30/USD is at least $52,225 at November 9, 2026 at 4pm ET, then the market resolves to Yes.",
               strike_type="greater_or_equal", floor=52225),
    "inx_eod": _mk("KXINX", "Financials", "daily", [{"name": "For example, Google Finance", "url": "https://www.google.com/finance/quote/.INX:INDEXSP?hl=en"}],
                   "If the end-of-day S&P 500 index value on November 09, 2026 is above 7699.9999, then the market resolves to Yes.", floor=7699.9999),
    "ust_touch": _mk("KX10YRDIRHM", "Financials", "monthly",
                     [{"name": "U.S. Department of the Treasury", "url": "https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve"}],
                     "If the daily published par yield for the 10-year U.S. Treasury is above 5.34% on any business day between Nov 1, 2026 and Nov 30, 2026, then the market resolves to Yes.", floor=5.34),
}


@pytest.mark.parametrize("case,asset,instrument_prefix,method", [
    ("7y_hermes", "UST7Y", "pyth-id:", "value_at_time"),
    ("fx_jpy", "USDJPY", "pyth:USDJPY", "window_compare_value"),
    ("fx_gbp", "GBPUSD", "FX.GBP/USD", "window_compare_value"),
    ("rate15m_queued", "UST5Y", "InterestRate.US5Y", "window_compare_candle_1m"),
    ("dji", "DJI", "Equity.Index.US30/USD", "value_at_time"),
    ("inx_eod", "SPX", "INDEX:SPX", "value_at_time"),
    ("ust_touch", "UST10Y", "UST-PAR:UST10Y", "any_day_touch"),
])
def test_live_financial_wordings_discoverable_record_only(ks, case, asset, instrument_prefix, method):
    d = evaluate(*LIVE[case], ks)
    assert d.tier is Tier.RECORD_ONLY, (case, d.reasons, d.notes)
    assert d.asset == asset and d.reference.instrument.startswith(instrument_prefix) and d.reference.method.value == method, d.reference


def test_queued_rate_window_is_also_strike_pending(ks):
    d = evaluate(*LIVE["rate15m_queued"], ks)
    assert Reason.STRIKE_PENDING in d.reasons


def test_non_usd_cf_market_refused(ks):
    s, m = _mk("KXBTCEU", "Crypto", "daily", [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/data/indices/BRTI_EUR"}],
               "If the simple average of the sixty seconds of CF Benchmarks' Bitcoin Real-Time Index (BRTI) in EUR before 5 PM EST is above €80000 at 5 PM EST, then the market resolves to Yes.")
    d = evaluate(s, m, ks)
    assert d.tier is Tier.REJECTED and "non-USD" in " ".join(d.notes)


@pytest.mark.parametrize("args", [
    ("KXZECMAXMON", "Crypto", "monthly", [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/"}],
     "If the price of ZEC after issuance and through 11:59 PM ET on Nov 30, 2026 is ever above $1720.00, then the market resolves to Yes."),
    ("KXCPIYOY", "Economics", "monthly", [{"name": "Bureau of Labor Statistics", "url": "https://www.bls.gov/cpi/"}],
     "If the Consumer Price Index (CPI) increases by more than 5.0% in the twelve months ending December 2026, then the market resolves to Yes."),
    ("KXDDR5WS", "Financials", "weekly", [{"name": "Ornn", "url": "https://dashboard.ornnai.com/compute"}],
     "If the value of DDR5 16Gb (2Gx8) 4800/5600 spot price is above $63.25 on Dec 18, 2026 at 4 PM ET, then the market resolves to Yes."),
])
def test_still_rejected_ambiguous_or_non_financial(ks, args):
    d = evaluate(*_mk(*args), ks)
    assert d.tier is Tier.REJECTED, (args[0], d.reasons, d.notes)


def test_15m_rules_index_without_underscore_is_parsed_from_rules(ks):
    s, m = _mk("KXZEC15M", "Crypto", "fifteen_min", [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/"}],
               "If the simple average of the sixty seconds of CF Benchmarks' ZECUSDRTI before 1:00 AM EST on Nov 9, 2026 is at least the simple "
               "average of the sixty seconds of CF Benchmarks' ZECUSDRTI before 12:45 AM EST on November 9, 2026, then the market resolves to Yes.",
               strike_type="greater_or_equal", floor=1227.7583, open_t="2026-11-09T05:45:00Z", close_t="2026-11-09T06:00:00Z")
    d = evaluate(s, m, ks)
    assert d.tier is Tier.TRADEABLE and d.reference.instrument == "ZECUSD_RTI"
    assert not any("asset taken from ticker" in n for n in d.reference.notes)   # came from the rules text
    # and a rules/ticker disagreement is caught
    s2, m2 = _mk("KXZEC15M", "Crypto", "fifteen_min", [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/data/indices/BTCUSD_RTI"}],
                 m.rules_primary, strike_type="greater_or_equal", floor=1.0, open_t="2026-11-09T05:45:00Z", close_t="2026-11-09T06:00:00Z")
    assert evaluate(s2, m2, ks).tier is Tier.REJECTED
