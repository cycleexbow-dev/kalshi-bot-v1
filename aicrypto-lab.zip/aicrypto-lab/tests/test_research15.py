"""Offline 15-minute research: no lookahead, correct accounting, and fully separate from trading."""
import math
from decimal import Decimal

import numpy as np

from aicrypto.research15 import audit as A
from aicrypto.research15 import experiment as X
from aicrypto.research15 import realism as R
from aicrypto.research15 import selection as S
from aicrypto.research15.features import Minutes, build_rows, kalshi_quote, window_features

T0 = 1_800_000_000 - (1_800_000_000 % 900)


def _cb(n=400, start=T0 - 300 * 60, drift=0.0):
    rows, v = [], 100.0
    for i in range(n):
        v *= math.exp(drift + (0.0005 if i % 2 else -0.0004))
        rows.append([start + 60 * i, v * 0.999, v * 1.001, v, v, 1.0])
    return rows


def _kc(open_ts, close_ts, ask=0.55, bid=0.53):
    return [{"end": int(open_ts + 60 * k), "ask_c": ask, "bid_c": bid, "ask_h": ask + 0.02, "bid_l": bid - 0.02} for k in range(1, 16)]


def _win(open_ts, strike=100.0, result="yes"):
    return {"ticker": "KXBTC15M-TEST", "asset": "BTC", "open_ts": open_ts, "close_ts": open_ts + 900, "strike": strike, "result": result}


def test_features_ignore_data_after_the_decision():
    w = _win(T0)
    cb = _cb()
    kc = _kc(T0, T0 + 900)
    d = T0 + 600
    a = window_features(w, d, Minutes(cb), kc)
    future_changed = [r if r[0] + 60 <= d else [r[0], 1, 1, 1, 1e6, 1] for r in cb]       # wild prices after d
    kc2 = [c if c["end"] <= d else {**c, "ask_c": 0.99, "bid_c": 0.01} for c in kc]
    b = window_features({**w, "result": "no"}, d, Minutes(future_changed), kc2)            # label flipped too
    for k in ("ask", "bid", "p_model", "z", "mom1", "mom5", "trend15", "dir1h", "dir4h", "vol15", "basis"):
        assert a[k] == b[k], k
    assert a["y"] == 1 and b["y"] == 0


def test_candle_in_progress_is_not_used():
    m = Minutes([[0, 1, 1, 1, 10.0, 1], [60, 1, 1, 1, 20.0, 1]])
    assert m.close_at(119.9) == 10.0 and m.close_at(120) == 20.0
    assert kalshi_quote([{"end": 100, "ask_c": .5, "bid_c": .4}], 99) is None


def test_split_is_by_time_and_choices_use_train_only():
    rows = [{"close_ts": float(i), "y": i % 2, "mid": .5, "ask": .5, "bid": .48, "asset": "BTC", "dir1h": 0, "dir4h": 0,
             "vol_accel": 1, "lead": 300, "worst_yes": .52, "worst_no": .54} for i in range(100)]
    tr, te, cut = X.split(rows)
    assert max(r["close_ts"] for r in tr) < cut <= min(r["close_ts"] for r in te)
    seen = []

    def prob(rs):
        seen.append(len(rs))
        return np.full(len(rs), 0.9)
    out = X.run_strategy(tr, te, prob)
    assert out["edge"] in X.EDGE_GRID and seen == [len(tr), len(te)]


def test_logistic_learns_a_simple_signal():
    rng = np.random.default_rng(0)
    rows = []
    for i in range(2000):
        z = float(rng.normal())
        rows.append({"mid": 0.5, "z": z, "y": int(rng.random() < 1 / (1 + math.exp(-2 * z)))})
    m = X.Logistic(("z",)).fit(rows)
    p = m.predict([{"mid": .5, "z": 1.0}, {"mid": .5, "z": -1.0}])
    assert p[0] > 0.75 and p[1] < 0.25


def test_fill_rules_and_fees():
    r = {"ask": 0.40, "bid": 0.38, "y": 1, "worst_yes": 0.45, "worst_no": None, "close_ts": 0, "asset": "BTC", "dir1h": 0, "dir4h": 0,
         "vol_accel": 1, "lead": 300}
    t = X.trade(r, 0.60, 0.05)
    assert t["side"] == "yes" and abs(t["pnl"] - (1 - 0.40 - 0.02)) < 1e-9
    tw = X.trade(r, 0.60, 0.05, "worst")
    assert tw["price"] == 0.45
    assert X.trade(r, 0.43, 0.05) is None                                               # edge after fee too small
    assert R.taker_fee(10, 0.5) == 0.18 and X.fee1(0.5) == 0.02


def _fill(ts, side, n, px, fee="0.01", order="o1"):
    if side == "yes":
        return {"ts": ts, "market_ticker": "KXBTC15M-26NOV092130-30", "action": "buy", "side": "yes", "count_fp": str(n),
                "yes_price_dollars": str(px), "no_price_dollars": str(1 - px), "fee_cost": fee, "order_id": order}
    return {"ts": ts, "market_ticker": "KXBTC15M-26NOV092130-30", "action": "sell", "side": "no", "count_fp": str(n),
            "yes_price_dollars": str(1 - px), "no_price_dollars": str(px), "fee_cost": fee, "order_id": order}


def test_audit_nets_both_sides_like_kalshi():
    fills = [_fill(1, "yes", 8, 0.42, order="a"), _fill(2, "no", 9, 0.95, order="b")]
    pos = A.positions_from_fills(fills, {"a": "bot:lock:ETH:x@lab1", "b": "bot:favorite:ETH:y@lab1"})
    (t,) = A.settle_positions(pos, {"KXBTC15M-26NOV092130-30": "yes"})
    assert t["gross"] == Decimal("-3.91") and t["both_sides"] and t["family"] == "lock"     # matches the live case
    assert A.close_ts_from_ticker("KXBTC15M-26NOV102015-15") == 1794359700.0                  # 01:15Z = 20:15 New York


def test_audit_metrics():
    tr = [{"net": D, "gross": D, "fees": Decimal("0"), "cost": Decimal("1"), "contracts": Decimal("2"), "entry_ts": i, "close_ts": i}
          for i, D in enumerate([Decimal(x) for x in ("3", "-1", "-1", "2")])]
    m = A.metrics(tr)
    assert m["trades"] == 4 and m["wins"] == 2 and m["profit_factor"] == 2.5 and m["max_drawdown"] == 2.0
    assert m["avg_entry_price"] == 0.5 and m["top1_share"] == 1.0


def test_realism_reprices_with_real_quotes_only_from_that_minute():
    candles = [{"end": 60, "ask_c": .30, "ask_h": .35, "bid_c": .28, "bid_l": .25},
               {"end": 120, "ask_c": .50, "ask_h": .60, "bid_c": .48, "bid_l": .40}]
    r = R.reprice({"ticker": "T", "side": "yes", "entry_ts": 90, "contracts": 10, "demo_price": .20}, candles, "yes")
    assert r["prev_close"]["ask"] == .30 and r["same_close"]["ask"] == .50 and r["worst"]["ask"] == .60
    assert abs(r["real_minus_demo"] - 0.30) < 1e-9
    assert R.reprice({"ticker": "T", "side": "no", "entry_ts": 90, "contracts": 1, "demo_price": .5}, candles, None)["available"] is False


def test_selection_replay_has_no_lookahead():
    trades = []
    for i in range(30):                       # rule A always wins, but each result is known only after its window closes
        trades.append({"cid": "A", "family": "f", "asset": "BTC", "ticker": f"T{i}", "t_entry": i * 900.0, "close_ts": i * 900.0 + 600, "pnl": 0.5})
        trades.append({"cid": "B", "family": "f", "asset": "BTC", "ticker": f"T{i}", "t_entry": i * 900.0, "close_ts": i * 900.0 + 600, "pnl": -0.5})
    r = S.replay(trades, S.policy_t, min_n=5)
    # B is only skipped once 5 of its results are KNOWN, so the first picks are ties (alphabetical A anyway)
    assert r["markets"] == 30 and r["pick_mean"] == 0.5
    assert r["skipped_n"] == 30 - 5                                                   # B skipped once 5 results are known (6th window on)


def test_research_package_never_touches_order_code():
    import pathlib
    src = pathlib.Path(A.__file__).parent
    text = "".join(p.read_text() for p in src.glob("*.py"))
    for bad in ("demo_exec", "DemoExchange", "/portfolio", "create_order", "POST"):
        assert bad not in text, bad
