"""Today's profit/loss counts every position closed since local midnight, after fees, including
positions that settled (which Kalshi drops from its position list)."""
import asyncio
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
from test_demo_exec import env, ready  # noqa: E402,F401


def test_pnl_today_sums_closed_positions_after_fees(env):
    svc, fake, rest, _ = env
    now = datetime.now(timezone.utc)
    midnight = datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0)

    async def tx(account="demo"):
        return [
            {"closed": now.isoformat(), "pnl": "5.00", "fees": "0.20", "by": "bot"},                      # settled win today
            {"closed": now.isoformat(), "pnl": "-2.00", "fees": "0.10", "by": "bot"},                     # loss today
            {"closed": (midnight - timedelta(minutes=5)).astimezone(timezone.utc).isoformat(), "pnl": "9", "fees": "0", "by": "bot"},  # yesterday
            {"closed": None, "pnl": "1", "fees": "0", "by": "bot"},
        ]
    svc.transactions = tx

    async def go():
        await ready(svc)
        await svc.update_pnl_today()
        assert svc.demo.account["realized_today"] == "2.70"                      # 4.80 - 2.10
        assert svc.pnl_today == {"value": "2.70", "trades": 2, "wins": 1}
        await svc.demo.refresh_account()                                          # a refresh keeps the figure
        assert svc.demo.account["realized_today"] == "2.70"
    asyncio.run(go())
