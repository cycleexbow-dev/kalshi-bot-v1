import numpy as np
import pandas as pd
import pytest

from aicrypto.data import synthetic_ohlcv
from aicrypto.research import backtest, compute_metrics
from aicrypto.settings import Capital, Costs
from aicrypto.strategies import StrategySpec, compute_signals, random_spec, mutate_spec, neighbours


def test_backtest_runs_and_is_deterministic(data3, ema_spec, capital, costs):
    r1 = backtest(data3, ema_spec, capital, costs)
    r2 = backtest(data3, ema_spec, capital, costs)
    assert r1.trades_df.equals(r2.trades_df)
    m = compute_metrics(r1)
    assert m["trades"] > 5
    assert 0 <= m["max_drawdown"] <= 1
    assert m["fees_paid"] > 0


def test_spot_only_no_negative_positions_or_cash(data3, ema_spec, capital, costs):
    r = backtest(data3, ema_spec, capital, costs)
    assert (r.trades_df["qty"] > 0).all()
    # equity never goes below zero and never exceeds what 100% allocation could do
    assert (r.equity > 0).all()


def test_fills_happen_one_bar_after_signal(data3, ema_spec, capital, costs):
    sig = {p: compute_signals(df, ema_spec) for p, df in data3.items()}
    r = backtest(data3, ema_spec, capital, costs, signals=sig)
    for t in r.trades[:20]:
        pair_dates = pd.DatetimeIndex(data3[t.pair]["date"])
        i = pair_dates.get_loc(t.entry_time)
        assert sig[t.pair]["enter_long"].iloc[i - 1], "entry must follow a signal on the previous bar"
        assert np.isclose(t.entry_price, data3[t.pair]["open"].iloc[i] * (1 + costs.slip_frac))


def test_risk_sizing_two_percent(data3, capital, costs):
    spec = StrategySpec("ema_cross", {"fast": 10, "slow": 30, "trend_filter": 0},
                        {"stop_pct": 0.04, "trail_pct": 0.0, "max_bars": 0})
    r = backtest(data3, spec, capital, costs)
    t = r.trades[0]
    notional = t.qty * t.entry_price
    # risk = notional * stop_pct ≈ 2% of starting equity (first trade)
    assert abs(notional * 0.04 - 1000 * 0.02) / (1000 * 0.02) < 0.02
    # stop-loss trades lose roughly the risked amount (plus costs), never a lot more unless gapped
    stops = r.trades_df[r.trades_df["reason"] == "stop"]
    if len(stops):
        assert (stops["pnl"] > -0.035 * stops["qty"] * stops["entry_price"] / 0.04 * 0.04 * 1.3).all()


def test_allocation_capped_when_stop_tight(data3, costs):
    cap = Capital(max_alloc_per_trade=0.5)
    spec = StrategySpec("ema_cross", {"fast": 10, "slow": 30, "trend_filter": 0},
                        {"stop_pct": 0.01, "trail_pct": 0.0, "max_bars": 0})  # 2%/1% = 200% -> capped
    r = backtest(data3, spec, cap, costs)
    t = r.trades[0]
    assert t.qty * t.entry_price <= 1000 * 0.5 * 1.001


def test_costs_reduce_pnl(data3, ema_spec, capital):
    free = backtest(data3, ema_spec, capital, Costs(fee_pct=0.0, slippage_bps=0.0))
    paid = backtest(data3, ema_spec, capital, Costs(fee_pct=0.002, slippage_bps=10))
    assert paid.equity.iloc[-1] < free.equity.iloc[-1]
    assert compute_metrics(free)["fees_paid"] == 0


def test_time_and_trailing_exits_fire(data3, capital, costs):
    spec = StrategySpec("donchian_breakout", {"channel": 20, "exit_channel": 10},
                        {"stop_pct": 0.05, "trail_pct": 0.03, "max_bars": 40})
    r = backtest(data3, spec, capital, costs)
    reasons = set(r.trades_df["reason"])
    assert reasons & {"time", "stop", "signal"}
    assert (r.trades_df["bars_held"] <= 40).all()


def test_all_families_produce_signals(data3, rng):
    for fam in ["ema_cross", "rsi_reversion", "donchian_breakout", "bollinger_reversion"]:
        spec = random_spec(rng, fam)
        sig = compute_signals(data3["BTC/USDT"], spec)
        assert sig["enter_long"].dtype == bool
        assert not sig.iloc[: spec.startup_bars()].any().any()


def test_spec_identity_and_mutation(rng):
    s = random_spec(rng, "rsi_reversion")
    assert StrategySpec.from_dict(s.to_dict()).spec_hash == s.spec_hash
    m = mutate_spec(s, rng)
    assert m.family == s.family
    nb = neighbours(s)
    assert len(nb) >= 6 and all(n.spec_hash != s.spec_hash for n in nb)


def test_invalid_specs_rejected():
    with pytest.raises(ValueError):
        StrategySpec("ema_cross", {"fast": 50, "slow": 30, "trend_filter": 0},
                     {"stop_pct": 0.03, "trail_pct": 0, "max_bars": 0})
    with pytest.raises(ValueError):
        StrategySpec("ema_cross", {"fast": 5, "slow": 30, "trend_filter": 0},
                     {"stop_pct": 0.0, "trail_pct": 0, "max_bars": 0})
