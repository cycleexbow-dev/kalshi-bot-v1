"""Shell-level checks on operational scripts (fail-closed behaviour)."""
import os
import stat
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _fake_python(tmp_path, fail_on: str, code: int = 2) -> Path:
    """A stand-in for `python3 -m aicrypto.cli <cmd>` that fails on one subcommand and logs calls."""
    log = tmp_path / "calls.log"
    script = tmp_path / "fakepy"
    script.write_text(
        "#!/usr/bin/env bash\n"
        f"echo \"$3\" >> {log}\n"
        f"if [ \"$3\" = \"{fail_on}\" ]; then exit {code}; fi\n"
        "exit 0\n"
    )
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    return log


def _run_daily(tmp_path, fail_on, code=2):
    log = _fake_python(tmp_path, fail_on, code)
    env = {**os.environ, "PYTHON": str(tmp_path / "fakepy")}
    proc = subprocess.run(["bash", str(ROOT / "scripts" / "daily.sh")], env=env, capture_output=True, text=True, cwd=ROOT)
    calls = log.read_text().split() if log.exists() else []
    return proc.returncode, calls


def test_daily_aborts_when_data_check_fails(tmp_path):
    rc, calls = _run_daily(tmp_path, fail_on="data-check")
    assert rc != 0
    assert calls == ["safety-check", "data-check"], calls   # nothing after the failure ran


def test_daily_aborts_when_safety_check_fails(tmp_path):
    rc, calls = _run_daily(tmp_path, fail_on="safety-check")
    assert rc != 0 and calls == ["safety-check"]


def test_daily_runs_all_steps_when_healthy(tmp_path):
    rc, calls = _run_daily(tmp_path, fail_on="none")
    assert rc == 0
    assert calls == ["safety-check", "data-check", "research", "promote", "safety-check", "report"]


def test_daily_continues_on_expected_promote_rejection(tmp_path):
    rc, calls = _run_daily(tmp_path, fail_on="promote", code=3)
    assert rc == 0 and calls[-1] == "report"


def test_daily_aborts_on_promote_verification_error(tmp_path):
    rc, calls = _run_daily(tmp_path, fail_on="promote", code=4)
    assert rc == 4 and calls[-1] == "promote"


def test_lockfile_pins_everything():
    lock = (ROOT / "requirements.lock").read_text().splitlines()
    pins = [l for l in lock if l and not l.startswith("#")]
    assert pins and all("==" in l for l in pins), "requirements.lock must pin exact versions"
    assert any(l.startswith("pandas==") for l in pins)
    ft = (ROOT / "requirements-freqtrade.lock").read_text()
    assert "freqtrade==" in ft


def test_compose_image_pinned():
    text = (ROOT / "docker-compose.yml").read_text()
    image_lines = [l for l in text.splitlines() if l.strip().startswith("image:")]
    assert any("freqtradeorg/freqtrade:2026.10" in l for l in image_lines)
    assert not any(l.split("#")[0].rstrip().endswith(":stable") for l in image_lines), "moving tag not allowed"
