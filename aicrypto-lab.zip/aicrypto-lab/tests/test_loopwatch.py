"""The live feed drops when the shared event loop is blocked; these keep the big jobs from blocking it."""
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))
from test_terminal import NOW, ks, reg  # noqa: E402,F401

from aicrypto.terminal.loopwatch import LoopWatch  # noqa: E402
from aicrypto.terminal.service import TerminalService  # noqa: E402


def _svc(ks, reg):
    svc = TerminalService(ks, live=False, registry=reg)
    svc.now_fn = lambda: NOW
    return svc


def test_async_access_recompute_matches_sync_and_yields(ks, reg):
    svc = _svc(ks, reg)
    svc.recompute_access()
    want = {t: a.to_dict() for t, a in svc.access.items()}
    assert want                                                      # fixtures contain visible markets
    svc.access = {}
    svc.ACCESS_CHUNK = 2                                             # force several yields on the small fixture set

    async def go():
        ticks = 0

        async def counter():
            nonlocal ticks
            while True:
                ticks += 1
                await asyncio.sleep(0)
        c = asyncio.create_task(counter())
        await svc.recompute_access_async()
        c.cancel()
        return ticks
    ticks = asyncio.run(go())
    assert {t: a.to_dict() for t, a in svc.access.items()} == want
    assert ticks >= 2                                                # other tasks ran while it worked


def test_series_check_is_cached_until_series_change(ks, reg):
    svc = _svc(ks, reg)
    a = svc._series_ok()
    assert svc._series_ok() is a
    any_series = next(iter(reg.series.values()))
    reg.series["ZZZTEST"] = any_series
    try:
        assert svc._series_ok() is not a and "ZZZTEST" in svc._series_ok()
    finally:
        reg.series.pop("ZZZTEST")


def test_loopwatch_reports_where_the_loop_was_stuck():
    lw = LoopWatch(threshold_s=0.3, beat_s=0.05)

    def slow_sync_job():
        time.sleep(0.8)                                              # blocks the loop like a long CPU job

    async def go():
        hb = asyncio.create_task(lw.heartbeat())
        await asyncio.sleep(0.2)
        slow_sync_job()
        await asyncio.sleep(0.4)
        hb.cancel()
    asyncio.run(go())
    st = lw.status()
    assert st["stalls"] >= 1 and st["max_lag_s"] >= 0.3
    assert "slow_sync_job" in st["last_stall"]["where"]
