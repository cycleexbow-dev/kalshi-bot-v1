"""Active positions, per-position cash-out and closed-position transactions (mocked demo exchange)."""
import asyncio
import json
import sys
from decimal import Decimal
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))
from test_demo_exec import ETH, GOLD, FakeDemo, env, ready, run  # noqa: E402,F401

from aicrypto.kalshi.demo_exec.trader import Intent, OrderRefused  # noqa: E402


def _hold(fake, ticker=ETH, qty="3.00", cost="1.50"):
    fake.positions = [{"ticker": ticker, "position_fp": qty, "market_exposure_dollars": cost, "realized_pnl_dollars": "0.00", "fees_paid_dollars": "0.03"}]
    fake.fills.append({"fill_id": f"buy-{ticker}", "order_id": "x-buy", "ticker": ticker, "side": "yes" if not qty.startswith("-") else "no",
                       "action": "buy", "count_fp": qty.lstrip("-"), "yes_price_dollars": "0.5000", "no_price_dollars": "0.5000",
                       "is_taker": True, "fee_cost": "0.0300", "created_time": "2026-11-09T13:40:00Z"})


def _selling(fake, fill_all=True):
    """Make the fake exchange execute IOC sells immediately at the 0.49 best YES bid."""
    orig = fake.handler

    def handler(req: httpx.Request) -> httpx.Response:
        if req.method == "POST" and req.url.path.endswith("/portfolio/events/orders"):
            body = json.loads(req.content)
            if body.get("reduce_only"):
                fake.requests.append((req.method, req.url.host, req.url.path))
                fake.posts.append(body)
                want = int(float(body["count"]))
                n = want if fill_all else 1
                fake.n += 1
                oid = f"sell-{fake.n}"
                fake.orders[oid] = {"order_id": oid, "client_order_id": body["client_order_id"], "ticker": body["ticker"], "side": "yes",
                                    "action": "sell", "status": "executed" if fill_all else "canceled", "fill_count_fp": f"{n:.2f}",
                                    "remaining_count_fp": "0.00", "taker_fees_dollars": "0.0600"}
                fake.fills.append({"fill_id": f"f-{oid}", "order_id": oid, "ticker": body["ticker"], "side": "yes",
                                   "action": "sell", "count_fp": f"{n:.2f}", "yes_price_dollars": "0.4900", "no_price_dollars": "0.5100",
                                   "is_taker": True, "fee_cost": "0.0600", "created_time": "2026-11-09T13:51:00Z"})
                left = want - n
                fake.positions = ([{**fake.positions[0], "position_fp": "0.00", "market_exposure_dollars": "0.00",
                                    "realized_pnl_dollars": "-0.03", "fees_paid_dollars": "0.09"}] if left == 0     # Kalshi keeps the closed row
                                  else [{**fake.positions[0], "position_fp": f"{left:.2f}"}])
                return httpx.Response(201, json={"order_id": oid, "client_order_id": body["client_order_id"], "fill_count": f"{n:.2f}",
                                                 "remaining_count": "0.00", "average_fill_price": "0.4900", "average_fee_paid": "0.0200", "ts_ms": 1})
        return orig(req)
    fake.handler = handler


def test_positions_view_shows_value_and_pnl(env):
    svc, fake, _, _ = env
    _hold(fake)

    async def go():
        await ready(svc)
    run(go())
    (p,) = svc.positions_view()
    assert p["ticker"] == ETH and p["side"] == "yes" and p["contracts"] == "3.00" and p["avg_price"] == "0.5000" and p["cost"] == "1.50"


def test_cashout_sells_whole_position_ioc_reduce_only(env):
    svc, fake, _, _ = env
    _hold(fake)
    _selling(fake)

    async def go():
        await ready(svc)
        q = await svc.demo.cashout_quote(ETH)
        assert q["count"] == 3 and q["bid"] == Decimal("0.49") and q["floor"] == Decimal("0.39") and q["est_proceeds"] == Decimal("1.47")
        r = await svc.demo.cashout(ETH)
        assert r["state"] == "FILLED" and r["sold"] == 3
        assert svc.demo.account["positions"] == []
        with pytest.raises(OrderRefused, match="no open position"):
            await svc.demo.cashout(ETH)
        await svc.demo.reconcile()
        tx = await svc.transactions()
        assert len(tx) == 1
        t = tx[0]
        assert t["how"] == "cashout" and t["side"] == "yes" and t["contracts"] == "3.00" and t["avg_entry"] == "0.5000" and t["avg_exit"] == "0.4900"
        assert t["pnl"] == "-0.03" and t["fees"] == "0.09" and t["pnl_pct"] == -2.0      # Kalshi's realized P/L, fees listed separately
    run(go())
    b = fake.posts[-1]
    assert b["side"] == "ask" and b["count"] == "3.00" and b["time_in_force"] == "immediate_or_cancel"      # sell YES = ask
    assert b["reduce_only"] is True and b["price"] == "0.3900"
    assert {h for _, h, _ in fake.requests} == {"demo-api.kalshi.co"}


def test_cashout_allowed_during_emergency_stop_and_cancels_resting_buys(env):
    svc, fake, _, _ = env
    _selling(fake)                                   # must be installed before the exchange client is created

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.45"), 1))
        await svc.demo.confirm(p["token"], ETH, "yes", "0.45", 1)
        _hold(fake)
        svc.demo.ledger.put("kill_switch", "on")
        r = await svc.demo.cashout(ETH)
        assert r["state"] == "FILLED"
        assert fake.orders["ord-1"]["status"] == "canceled"          # resting buy on that market was cancelled first
    run(go())


def test_cashout_refused_without_bids_and_partial_reported(env):
    svc, fake, rest, _ = env
    _hold(fake)
    _selling(fake, fill_all=False)

    async def go():
        await ready(svc)
        rest.book = {"orderbook_fp": {"yes_dollars": [], "no_dollars": [["0.4900", "80.00"]]}}
        with pytest.raises(OrderRefused, match="Nobody is bidding"):
            await svc.demo.cashout(ETH)
        rest.book = {"orderbook_fp": {"yes_dollars": [["0.4900", "1.00"]], "no_dollars": [["0.4900", "80.00"]]}}
        r = await svc.demo.cashout(ETH)
        assert r["sold"] == 1 and r["count"] == 3 and len(svc.demo.account["positions"]) == 1
    run(go())
    assert len([b for b in fake.posts if b.get("reduce_only")]) == 1


def test_settled_position_appears_in_transactions(env):
    svc, fake, rest, _ = env
    _hold(fake, ticker=GOLD, qty="-2.00", cost="1.00")              # 2 NO contracts bought at 50c

    async def go():
        await ready(svc)
        await svc.demo.reconcile()
        assert await svc.transactions() == []                         # still open
        svc.reg.apply_lifecycle({"type": "market_lifecycle_v2", "msg": {"market_ticker": GOLD, "event_type": "determined", "result": "no"}})
        fake.positions = []                                           # settled positions drop off Kalshi's list
        await svc.demo.refresh_account()
        (t,) = await svc.transactions()
        assert t["how"] == "settled" and t["won"] is True and t["side"] == "no" and t["pnl"] == "1.00" and t["fees"] == "0.03"   # 2.00 - 1.00
    run(go())


def test_settled_position_found_via_market_lookup(env):
    """No lifecycle message reached the app (e.g. it was closed when the market settled): the result
    comes from Kalshi's market data, which the REST client returns as the bare market object."""
    svc, fake, rest, _ = env
    _hold(fake, ticker=GOLD, qty="-2.00", cost="1.00")

    async def go():
        await ready(svc)
        await svc.demo.reconcile()
        fake.positions = []
        await svc.demo.refresh_account()
        assert await svc.transactions() == []                         # result not known yet
        rest.results[GOLD] = "no"
        svc._cache.clear()
        (t,) = await svc.transactions()
        assert t["how"] == "settled" and t["won"] is True and t["pnl"] == "1.00"
    run(go())


def test_settled_pnl_includes_netted_both_sides():
    """Bought 8 YES @42c then 9 NO @95c: Kalshi nets 8 pairs (realized -2.96) and keeps 1 NO
    (exposure 0.95). Market settles YES -> total -3.91 before fees."""
    from aicrypto.terminal.service import _settled_pnl
    assert _settled_pnl("no", "yes", "1.00", "0.95", "-2.96") == Decimal("-3.91")
    assert _settled_pnl("yes", "yes", "2", "1.00", None) == Decimal("1.00")


def test_cashout_api_needs_app_header(env):
    from fastapi.testclient import TestClient
    from aicrypto.terminal.app import create_terminal_app
    svc, *_ = env
    with TestClient(create_terminal_app(svc)) as c:
        assert c.post(f"/api/demo/positions/{ETH}/cashout").status_code == 403
        assert c.post(f"/api/demo/positions/{ETH}/cashout", headers={"X-AICL-Client": "terminal"}).status_code == 422
        assert c.get("/api/demo/positions").json() == {"positions": []}
        assert c.get("/api/demo/transactions").json()["count"] == 0


def test_position_closed_before_tracking_began_still_listed(env):
    """A trade made before this version: Kalshi lists it with zero contracts and a realized P/L;
    side and size come from our own order record."""
    svc, fake, _, _ = env

    async def go():
        await ready(svc)
        p = await svc.demo.prepare(Intent(ETH, "yes", Decimal("0.50"), 10))
        r = await svc.demo.confirm(p["token"], ETH, "yes", "0.50", 10)
        fake.fill("ord-1", Decimal(10))
        await svc.demo.reconcile()
        with svc.demo_ledger._c() as c:
            c.execute("DELETE FROM pos_track")
        fake.positions = [{"ticker": ETH, "position_fp": "0.00", "market_exposure_dollars": "0.00", "realized_pnl_dollars": "0.18", "fees_paid_dollars": "0.35"}]
        await svc.demo.refresh_account()
        (t,) = await svc.transactions()
        assert t["how"] == "cashout" and t["pnl"] == "0.18" and t["side"] == "yes" and t["contracts"] == "10.00" and t["cost"] == "5.00"
    run(go())
