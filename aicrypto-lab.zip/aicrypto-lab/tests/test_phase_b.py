"""Phase B: recorder follows the registry, data-quality report, historical backfill (all offline)."""
import asyncio
import json
import time
from pathlib import Path

from aicrypto.recorder import longer as LG
from aicrypto.recorder import store as St
from aicrypto.timeframes import backfill as BF
from aicrypto.timeframes import quality as Q


def _registry(root: Path, rows):
    d = root / "user_data" / "kalshi" / "timeframes"
    d.mkdir(parents=True, exist_ok=True)
    (d / "registry.json").write_text(json.dumps({"rows": rows}))


def _row(series, asset, bucket, grade="D"):
    return {"series": series, "asset": asset, "bucket": bucket, "data_quality": {"grade": grade}, "research_status": "x"}


class T:
    def __init__(self):
        self.calls, self.fail = [], set()

    async def request(self, method, path, params=None):
        assert method == "GET"
        self.calls.append(dict(params))
        if params["series_ticker"] in self.fail:
            raise TimeoutError("slow")
        return {"markets": []}


class Cl:
    def __init__(self):
        self.transport = T()


def test_recorder_follows_registry_and_polls_slow_series_less_often(tmp_path):
    _registry(tmp_path, [_row("KXGOLDW", "GOLD", "weekly"), _row("KXBTC15M", "BTC", "15m", "A"), _row("KXBNBY", "BNB", "longer"),
                         _row("KXBTCD", "BTC", "1h", "B")])
    plan = LG.series_plan(tmp_path)
    assert "KXGOLDW" in plan and plan["KXGOLDW"]["bucket"] == "weekly"
    assert "KXBTC15M" not in plan and "KXBNBY" not in plan                      # 15m has its own recorder; BNB is not a priority asset
    assert set(LG.SERIES) <= set(plan)                                           # existing coverage never dropped
    clk = [1_800_000_000.0]
    store = St.Store(tmp_path, clock=lambda: clk[0])
    cl = Cl()
    lg = LG.LongerDurations(store, client=cl, clock=lambda: clk[0], root=tmp_path)
    cl.transport.fail = {"KXGOLDW"}

    async def go():
        await lg.poll_quotes(due_only=True)
        n1 = len(cl.transport.calls)
        clk[0] += 61
        await lg.poll_quotes(due_only=True)
        return n1, len(cl.transport.calls) - n1
    n1, n2 = asyncio.run(go())
    assert n1 == len(plan) and n2 == len(plan) - 1                               # weekly series waits 5 min
    store.close()
    recs = list(St.read_source(tmp_path, "kalshi_real_long"))
    cycles = [r for r in recs if r["k"] == "cycle"]
    assert len(cycles) == 2 and cycles[0]["failed"] == ["KXGOLDW"] and cycles[1]["failed"] == []
    assert any(r["k"] == "series_set" for r in recs)


def test_registry_change_is_picked_up_without_restart(tmp_path):
    _registry(tmp_path, [])
    store = St.Store(tmp_path)
    lg = LG.LongerDurations(store, client=Cl(), root=tmp_path)
    n0 = len(lg.series)
    _registry(tmp_path, [_row("KXSILVERMON", "SILVER", "monthly")])
    lg.reload_series()
    assert len(lg.series) == n0 + 1 and lg.buckets["KXSILVERMON"] == "monthly"
    store.close()


def test_quality_report_measures_gaps_failures_and_missing_settlements(tmp_path):
    now = 1_800_000_000.0
    clk = [now - 3 * 3600]
    store = St.Store(tmp_path, clock=lambda: clk[0])
    for i in range(30):                                                          # 10 s health lines with one 5-minute outage
        clk[0] += 300 if i == 15 else 10
        store.write("recorder", "health", kalshi_real={"errors": 0})
    store.write("kalshi_real_long", "market_meta", ticker="A-1", series="KXGOLDH", asset="GOLD", close_ts=now - 7200)
    store.write("kalshi_real_long", "market_meta", ticker="A-1", series="KXGOLDH", asset="GOLD", close_ts=now - 7200)   # restart duplicate
    store.write("kalshi_real_long", "market_meta", ticker="A-2", series="KXGOLDH", asset="GOLD", close_ts=now - 7200)
    store.write("kalshi_real_long", "settled", ticker="A-2", series="KXGOLDH", asset="GOLD")
    store.write("kalshi_real_long", "cycle", polled=3, failed=["KXGOLDH"])
    clk[0] += 600
    store.write("kalshi_real_long", "cycle", polled=3, failed=[])
    store.write("cfindex", "gap", index="BRTI", seconds=2.0)
    store.close()
    _registry(tmp_path, [_row("KXGOLDH", "GOLD", "1h", "C")])
    rep = Q.build(tmp_path, days=2, now=now)
    assert rep["recorder"]["n_outages"] == 1 and rep["recorder"]["downtime_min"] == 5.0
    h = rep["hourly_daily"]
    assert h["markets_seen"] == 2 and h["closed_but_no_settlement"] == 1 and h["closed_but_no_settlement_examples"] == ["A-1"]
    assert h["failed_rounds_by_series"] == {"KXGOLDH": 1} and h["n_cycle_stalls"] == 1
    row = next(r for r in rep["by_asset_duration"] if r["series"] == ["KXGOLDH"])
    assert row["markets_recorded"] == 2 and row["settled"] == 1 and row["failed_rounds"] == 1
    assert rep["settlement_index"]["gaps"] == {"BRTI": 1}
    assert rep["disk"]["retention"].startswith("keep everything") and "free_gb" in rep["disk"]
    assert "uptime" in Q.report(rep)


class BackfillClient:
    def __init__(self, markets, fail_candles=False):
        self.markets, self.fail_candles, self.candle_calls, self.list_calls = markets, fail_candles, [], 0

    async def list_markets(self, **kw):
        self.list_calls += 1
        assert kw["status"] == "settled"
        return self.markets

    async def get_candlesticks_multi(self, tickers, start, end, period):
        self.candle_calls.append((tuple(tickers), start, end, period))
        if self.fail_candles:
            raise RuntimeError("429")
        return {"markets": [{"market_ticker": t, "candlesticks": [{"end_period_ts": end, "yes_ask": {"close_dollars": "0.55"},
                                                                    "yes_bid": {"close_dollars": "0.53"}}]} for t in tickers]}


def _ladder(event, close_iso, settle, strikes):
    return [{"ticker": f"{event}-T{k}", "event_ticker": event, "strike_type": "greater", "floor_strike": k,
             "result": "yes" if settle > k else "no", "expiration_value": str(settle), "close_time": close_iso,
             "open_time": close_iso} for k in strikes]


def test_backfill_keeps_nearest_strikes_and_never_refetches(tmp_path):
    mk = _ladder("KXBTCD-A", "2027-01-15T08:00:00Z", 100_050, range(99_000, 101_100, 100)) + \
         _ladder("KXBTCD-B", "2027-01-15T09:00:00Z", 99_960, range(99_000, 101_100, 100))
    cl = BackfillClient(mk)
    now = BF._ts("2027-01-15T10:00:00Z")
    res = asyncio.run(BF.run(tmp_path, ["KXBTCD"], days=2, near=4, client=cl, progress=lambda *_: None, now=now, spot=False))
    s = res["series"][0]
    assert s["events_listed"] == 2 and s["saved"] == 2 and len(cl.candle_calls) == 2
    ev = BF.load(BF.history_dir(tmp_path) / "KXBTCD" / "KXBTCD-A.json.gz")
    assert len(ev["markets"]) == 21 and set(ev["near"]) == {"KXBTCD-A-T100000", "KXBTCD-A-T100100", "KXBTCD-A-T99900", "KXBTCD-A-T100200"}
    close = BF._ts("2027-01-15T08:00:00Z")
    tick, start, end, period = cl.candle_calls[0]
    assert period == 1 and end - start == BF.CANDLE_WINDOW_S + 120 and end > close
    assert ev["candles"]["KXBTCD-A-T100000"][0]["ask_c"] == 0.55
    res2 = asyncio.run(BF.run(tmp_path, ["KXBTCD"], days=2, near=4, client=cl, progress=lambda *_: None, now=now, spot=False))
    assert res2["series"][0]["already_had"] == 2 and len(cl.candle_calls) == 2       # incremental: nothing fetched again


def test_backfill_failure_is_retried_next_run_not_saved_half_done(tmp_path):
    mk = _ladder("KXETHD-A", "2027-01-15T08:00:00Z", 3005, range(2900, 3100, 10))
    now = BF._ts("2027-01-15T10:00:00Z")
    res = asyncio.run(BF.run(tmp_path, ["KXETHD"], days=2, client=BackfillClient(mk, fail_candles=True), progress=lambda *_: None,
                             now=now, spot=False))
    assert res["series"][0]["failed"] == 1 and not list((BF.history_dir(tmp_path) / "KXETHD").glob("*.json.gz"))
    res = asyncio.run(BF.run(tmp_path, ["KXETHD"], days=2, client=BackfillClient(mk), progress=lambda *_: None, now=now, spot=False))
    assert res["series"][0]["saved"] == 1


def test_backfill_is_background_priority_and_read_only():
    text = Path(BF.__file__).read_text()
    assert 'priority="background"' in text and 'KalshiRestClient("production", signer=None, public=True' in text
    for bad in ("demo_exec", "create_order", "/portfolio", "signer=signer"):
        assert bad not in text


def test_dataset_never_looks_ahead_and_calibration_counts_events(tmp_path):
    from aicrypto.timeframes import dataset as DS
    close = 1_800_003_600.0
    spot = [[close - 3600 + 60 * i, 0, 0, 0, 100.0 + i, 1] for i in range(61)]          # minute i closes at 100+i
    (BF.history_dir(tmp_path) / "spot").mkdir(parents=True, exist_ok=True)
    BF._save(BF.history_dir(tmp_path) / "spot" / "BTC_coinbase.json.gz", spot)
    d = BF.history_dir(tmp_path) / "KXBTCD"
    d.mkdir(parents=True, exist_ok=True)
    mk = [{"ticker": "E-T1", "strike_type": "greater", "floor": 120.0, "cap": None, "result": "yes", "settle": 150.0},
          {"ticker": "E-T2", "strike_type": "greater", "floor": 180.0, "cap": None, "result": "no", "settle": 150.0}]
    cs = {"E-T1": [{"end": close - 600, "bid_c": 0.80, "ask_c": 0.84}, {"end": close - 60, "bid_c": None, "ask_c": 0.99}],
          "E-T2": [{"end": close - 600, "bid_c": 0.10, "ask_c": 0.14}]}
    BF._save(d / "E.json.gz", {"event": "E", "series": "KXBTCD", "asset": "BTC", "close_ts": close, "settle": 150.0,
                                "markets": mk, "candles": cs})
    rs = list(DS.rows(tmp_path, ["KXBTCD"]))
    r = next(x for x in rs if x["ticker"] == "E-T1" and x["minutes_left"] == 10)
    # the candle ending at close-600 covers the minute before it; the spot used must be the minute that ENDED by then
    assert r["spot"] == 100.0 + 49 and abs(r["mid"] - 0.82) < 1e-9 and r["y"] == 1
    assert any(not x["two_sided"] and x["mid"] is None for x in rs)                        # one-sided kept, not filled in
    cal = DS.calibration(rs)
    g = cal["BTC | all"]
    assert g["market_minutes"] == 2 and g["events"] == 1 and g["one_sided_skipped"] == 1
    assert g["bins"]["80-90%"]["yes_won"] == 100.0 and g["bins"]["10-20%"]["yes_won"] == 0.0
