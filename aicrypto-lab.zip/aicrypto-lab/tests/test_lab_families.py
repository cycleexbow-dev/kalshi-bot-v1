"""Bot & Strategies page: one plain row per strategy family with a verdict."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))
from test_lab import lab_env  # noqa: E402,F401


def test_families_have_plain_verdicts(lab_env):
    svc, *_ = lab_env
    svc._lab_by_family = lambda store: ({"fair": (500, 0.12), "favorite": (40, -0.10)} if store is svc.lab.store
                                        else {"fair": (300, -0.03), "momentum": (200, 0.002), "kmomentum": (150, 0.05)})
    svc._shadow_by_family = lambda: {}
    rows = {r["family"]: r for r in asyncio.run(svc.lab_families())}
    assert len(rows) == 7                                  # 6 rule types + the owner's favourite 2-7 min
    assert rows["fair"]["verdict"] == "Loses at real prices" and rows["fair"]["demo_ret"] == 12.0 and rows["fair"]["real_ret"] == -3.0
    assert rows["momentum"]["verdict"] == "No clear edge"
    assert rows["kmomentum"]["verdict"] == "Promising, needs more proof"
    assert rows["favorite"]["verdict"] == "Losing"                         # no real data yet, losing on demo
    assert rows["lock"]["verdict"] == "Still testing"


def test_shadow_results_preferred_once_there_are_enough(lab_env):
    svc, *_ = lab_env
    svc._fam_cache = None
    svc._lab_by_family = lambda store: {"fair": (300, 0.06)}
    svc._shadow_by_family = lambda: {"fair": (120, -0.029)}
    fair = next(r for r in asyncio.run(svc.lab_families()) if r["family"] == "fair")
    assert fair["real_ret"] == -2.9 and fair["real_trades"] == 120 and "delay" in fair["real_source"]
