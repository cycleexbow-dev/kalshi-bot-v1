import pytest

from aicrypto.settings import Capital, load_settings


def test_default_settings_load():
    s = load_settings()
    assert s.capital.starting_balance == 1000.0
    assert s.capital.risk_per_trade == 0.02
    assert s.markets.pairs == ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
    assert s.costs.fee_pct == 0.001
    assert s.budget.workers <= 2


def test_no_leverage_allowed():
    with pytest.raises(ValueError):
        Capital(max_alloc_per_trade=2.0)
    with pytest.raises(ValueError):
        Capital(risk_per_trade=0.5)
