import json
import sys
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.client import KalshiRestClient
from aicrypto.kalshi.discovery import discover, reconcile
from aicrypto.kalshi.eligibility import Tier
from aicrypto.kalshi.registry import MarketRegistry
from aicrypto.kalshi.schemas import STATS, SchemaMismatch, validate_market, validate_series, validate_ws_envelope
from aicrypto.kalshi.settings import load_kalshi_settings
from aicrypto.kalshi.transport import GuardedTransport

DEMO = "https://demo-api.kalshi.co/trade-api/v2"


class FakeKalshi:
    """Mock REST backend serving the Phase 2 fixtures with cursor pagination."""

    def __init__(self, series=None, markets=None, page_size=7, corrupt=(), bulk_series=False):
        self.bulk_series = bulk_series
        self.series = dict(series or fx.SERIES)
        self.markets = dict(markets or fx.MARKETS)
        self.page_size = page_size
        self.corrupt = set(corrupt)
        self.calls = []

    def handler(self, req: httpx.Request) -> httpx.Response:
        self.calls.append((req.method, req.url.path, dict(req.url.params)))
        path = req.url.path.replace("/trade-api/v2", "")
        if path == "/markets":
            status = req.url.params.get("status")
            items = [m for m in self.markets.values() if status in (None, "all") or
                     (status == "open" and m["status"] == "active") or (status == "unopened" and m["status"] == "initialized")]
            items = sorted(items, key=lambda m: m["ticker"])
            start = int(req.url.params.get("cursor") or 0)
            page = items[start:start + self.page_size]
            for m in page:
                if m["ticker"] in self.corrupt:
                    m = {**m, "yes_bid_dollars": 0.48}   # float instead of fixed-point string
                    page[page.index(next(x for x in page if x["ticker"] == m["ticker"]))] = m
            nxt = str(start + self.page_size) if start + self.page_size < len(items) else ""
            return httpx.Response(200, json={"markets": page, "cursor": nxt})
        if path.startswith("/markets/") and path.endswith("/orderbook"):
            return httpx.Response(200, json={"orderbook_fp": {"yes_dollars": [["0.4800", "150.00"]], "no_dollars": [["0.4800", "120.00"]]}})
        if path.startswith("/markets/"):
            t = path.split("/")[2]
            return httpx.Response(200, json={"market": self.markets[t]}) if t in self.markets else httpx.Response(404, text="not found")
        if path == "/series" and self.bulk_series:
            return httpx.Response(200, json={"series": list(self.series.values()), "cursor": ""})
        if path.startswith("/series/"):
            t = path.split("/")[2]
            if t in self.corrupt:
                return httpx.Response(200, json={"series": {**self.series[t], "fee_type": "mystery"}})
            return httpx.Response(200, json={"series": self.series[t]}) if t in self.series else httpx.Response(404)
        if path == "/exchange/status":
            return httpx.Response(200, json={"exchange_active": True, "trading_active": True})
        if path == "/account/limits":
            return httpx.Response(401, text="unauthorized")
        return httpx.Response(404)


def make_client(fake: FakeKalshi, **kw) -> KalshiRestClient:
    t = GuardedTransport(DEMO, http_transport=httpx.MockTransport(fake.handler), requests_per_second=1000, **kw)
    return KalshiRestClient("demo", transport=t)


# ---- schemas ------------------------------------------------------------------------------------
def test_market_schema_accepts_fixtures_and_rejects_shapes():
    for m in fx.MARKETS.values():
        if m["open_time"] is not None:
            validate_market(m)
    with pytest.raises(SchemaMismatch, match="open_time"):
        validate_market(fx.MARKETS["KXBTC15M-26NOV09NOTS-00"])
    bad = dict(fx.MARKETS["KXBTC15M-26NOV091400-00"]); bad["yes_bid_dollars"] = "0.48"   # 2 dp, not 4
    with pytest.raises(SchemaMismatch, match="yes_bid_dollars"):
        validate_market(bad)
    bad = dict(fx.MARKETS["KXBTC15M-26NOV091400-00"]); bad["status"] = "weird"
    with pytest.raises(SchemaMismatch, match="status"):
        validate_market(bad)
    bad = dict(fx.MARKETS["KXBTC15M-26NOV091400-00"]); bad["price_ranges"] = [{"start": "0.01", "end": "0.99", "step": "0.01"}]
    with pytest.raises(SchemaMismatch, match="price_ranges"):
        validate_market(bad)
    before = dict(STATS.unknown_fields)
    validate_market({**fx.MARKETS["KXBTC15M-26NOV091400-00"], "brand_new_field": 1})
    assert STATS.unknown_fields.get("market.brand_new_field", 0) == before.get("market.brand_new_field", 0) + 1


def test_series_schema():
    for s in fx.SERIES.values():
        validate_series(s)
    with pytest.raises(SchemaMismatch, match="fee_type"):
        validate_series({**fx.SERIES["KXBTC15M"], "fee_type": "cubic"})
    with pytest.raises(SchemaMismatch, match="missing required"):
        validate_series({"ticker": "X"})


def test_ws_envelope_schema():
    validate_ws_envelope({"type": "orderbook_snapshot", "sid": 1, "seq": 1, "msg": {"market_ticker": "A", "clock": 5, "yes_dollars_fp": [["0.4800", "10.00"]]}})
    with pytest.raises(SchemaMismatch):
        validate_ws_envelope({"type": "orderbook_snapshot", "sid": 1, "seq": 1, "msg": {"market_ticker": "A", "clock": 5, "yes_dollars_fp": [["0.48", "10"]]}})
    with pytest.raises(SchemaMismatch):
        validate_ws_envelope({"type": "orderbook_delta", "sid": 1, "seq": 2, "msg": {"market_ticker": "A", "clock": 6, "price_dollars": "0.4800", "delta_fp": "1.00", "side": "maybe"}})
    with pytest.raises(SchemaMismatch, match="missing seq"):
        validate_ws_envelope({"type": "orderbook_delta", "sid": 1, "msg": {}})
    validate_ws_envelope({"type": "ticker", "sid": 2, "msg": {"market_ticker": "A", "yes_bid_dollars": "0.4800"}})
    validate_ws_envelope({"type": "error", "id": 1, "msg": {"code": 9, "msg": "auth"}})
    with pytest.raises(SchemaMismatch):
        validate_ws_envelope({"type": "error", "msg": {}})


# ---- client -------------------------------------------------------------------------------------
async def test_client_paginates_and_validates():
    fake = FakeKalshi(page_size=5)
    async with make_client(fake) as c:
        ms = await c.list_markets(status="all")
        assert len(ms) == len(fx.MARKETS) - 1        # the missing-timestamp fixture fails schema
        assert len(c.mismatches) == 1 and c.mismatches[0]["kind"] == "market"
        pages = [p for p in fake.calls if p[1].endswith("/markets")]
        assert len(pages) == (len(fx.MARKETS) + 4) // 5
        s = await c.get_series("KXBTC15M")
        assert s["ticker"] == "KXBTC15M"
        with pytest.raises(SchemaMismatch):
            await make_client(FakeKalshi(corrupt={"KXBTC15M"})).get_series("KXBTC15M")


async def test_client_has_no_write_methods_and_refuses_account_without_auth():
    c = make_client(FakeKalshi())
    assert not [m for m in dir(c) if any(w in m.lower() for w in ("create_order", "cancel", "amend", "place", "buy", "sell", "batch"))]
    from aicrypto.kalshi.transport import TransportError
    with pytest.raises(TransportError, match="401"):
        await c.account_limits()


# ---- discovery ----------------------------------------------------------------------------------
async def test_discovery_builds_full_universe_and_records_mismatches(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    fake = FakeKalshi(page_size=6, corrupt={"KXETHD-26NOV1017-T2000", "KXWTID"})
    async with make_client(fake) as c:
        rep = await discover(c, reg, statuses=("open", "unopened"))
    valid_total = sum(1 for m in fx.MARKETS.values() if m["status"] in ("active", "initialized"))
    assert rep.markets_seen == valid_total - 2          # the corrupted market + the no-timestamp fixture were dropped (fail closed)
    assert rep.schema_mismatches == 3                   # 2 markets + 1 series
    assert rep.series_failed == 1 and "KXWTID" not in reg.series
    # WTI market stored but undecided because its series failed schema -> recorded in notes, not silently accepted
    assert any("KXWTID" in n for n in rep.notes) and reg.decision("KXWTID-26NOV10-T60") is None
    # commodities with unavailable feeds remain discoverable (record_only)
    assert reg.decision("KXGOLD15M-26NOV091400-00").tier is Tier.RECORD_ONLY
    assert rep.tiers["tradeable"] >= 9 and "GOLD" in rep.durations
    with reg._conn() as con:
        rows = con.execute("SELECT kind, context FROM schema_mismatches").fetchall()
    assert len(rows) == 3 and {r["kind"] for r in rows} == {"market", "series.fee_type"}
    # series fetched once each, not per market
    series_calls = [p for p in fake.calls if p[1].startswith("/trade-api/v2/series/")]
    assert len(series_calls) == len({m["ticker"].split("-")[0] for m in fx.MARKETS.values() if m["status"] in ("active", "initialized")})


async def test_reconcile_unknown_ticker(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    reg.upsert_series(fx.SERIES["KXBTC15M"])
    async with make_client(FakeKalshi()) as c:
        n = await reconcile(c, reg, ["KXBTC15M-26NOV091400-00", "KXBTC15M-26NOV09NOTS-00"])
    assert n == 1 and "KXBTC15M-26NOV091400-00" in reg.markets and "KXBTC15M-26NOV09NOTS-00" not in reg.markets


async def test_discovery_uses_bulk_series_and_reports_progress(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    fake = FakeKalshi(page_size=6, bulk_series=True)
    lines = []
    async with make_client(fake) as c:
        rep = await discover(c, reg, statuses=("open", "unopened"), progress=lines.append)
    per_series = [p for p in fake.calls if p[1].startswith("/trade-api/v2/series/")]
    assert per_series == []                                   # everything came from the bulk listing
    assert rep.series_fetched > 0 and rep.markets_upserted == rep.markets_seen
    assert any("page 1" in l for l in lines) and any("saving" in l for l in lines)
    # batch writes persisted
    reg2 = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    assert len(reg2.markets) == rep.markets_seen
