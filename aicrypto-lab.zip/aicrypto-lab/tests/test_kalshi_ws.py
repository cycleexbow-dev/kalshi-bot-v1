"""WebSocket client tests against a local scripted mock Kalshi server (no network)."""
import asyncio
import base64
import json
import sys
from pathlib import Path

import pytest
import websockets
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from websockets.asyncio.server import serve

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.auth import KalshiSigner
from aicrypto.kalshi.orderbook import BookSet, OrderBook
from aicrypto.kalshi.paths import RequestNotAllowed
from aicrypto.kalshi.registry import MarketRegistry
from aicrypto.kalshi.settings import load_kalshi_settings
from aicrypto.kalshi.stream import StreamSession
from aicrypto.kalshi.websocket import KalshiWebSocket


def _signer():
    k = ed25519.Ed25519PrivateKey.generate()
    pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    return KalshiSigner.from_pem_bytes("kid", pem), k.public_key()


class MockKalshiWS:
    """Scripted server. Verifies the handshake signature, assigns sids, replays scripted
    market data, and can inject seq gaps, disconnects and errors."""

    def __init__(self, pub, *, require_auth=True, gap_after=None, drop_after_msgs=None, silent=False, unauth_channels=()):
        self.pub = pub
        self.require_auth = require_auth
        self.gap_after = gap_after
        self.drop_after_msgs = drop_after_msgs
        self.silent = silent
        self.unauth_channels = set(unauth_channels)
        self.received = []
        self.connections = 0
        self.sid = 0
        self.server = None
        self.port = None
        self.snapshot_requests = []

    def _auth_ok(self, headers) -> bool:
        try:
            ts = headers["KALSHI-ACCESS-TIMESTAMP"]
            sig = base64.b64decode(headers["KALSHI-ACCESS-SIGNATURE"])
            self.pub.verify(sig, f"{ts}GET/trade-api/ws/v2".encode())
            return headers["KALSHI-ACCESS-KEY"] == "kid"
        except Exception:
            return False

    async def process_request(self, connection, request):
        if self.require_auth and not self._auth_ok(request.headers):
            return connection.respond(401, "unauthorized\n")
        return None

    async def handler(self, ws):
        self.connections += 1
        sent = 0
        seqs = {}
        async def send(obj):
            nonlocal sent
            if "sid" in obj and obj["type"] not in ("subscribed",):
                sid = obj["sid"]
                seqs[sid] = seqs.get(sid, 0) + 1
                if self.gap_after is not None and seqs[sid] == self.gap_after + 1:
                    seqs[sid] += 3            # inject a gap once
                obj["seq"] = seqs[sid]
            await ws.send(json.dumps(obj))
            sent += 1
            if self.drop_after_msgs is not None and sent >= self.drop_after_msgs:
                self.drop_after_msgs = None  # only once
                await ws.close(code=1011, reason="scripted drop")
        async for raw in ws:
            msg = json.loads(raw)
            self.received.append(msg)
            cmd = msg.get("cmd")
            if cmd == "subscribe":
                chans = msg["params"]["channels"]
                if any(c in self.unauth_channels for c in chans):
                    await ws.send(json.dumps({"type": "error", "id": msg["id"], "msg": {"code": 9, "msg": "Authentication required"}}))
                    continue
                for ch in chans:
                    self.sid += 1
                    sid = self.sid
                    await ws.send(json.dumps({"type": "subscribed", "id": msg["id"], "msg": {"channel": ch, "sid": sid}}))
                    if self.silent:
                        continue
                    if ch == "orderbook_delta":
                        for t in msg["params"].get("market_tickers", []):
                            await send({"type": "orderbook_snapshot", "sid": sid, "msg": {"market_ticker": t, "market_id": "u", "clock": 10,
                                        "yes_dollars_fp": [["0.4800", "150.00"], ["0.4700", "300.00"]], "no_dollars_fp": [["0.5000", "120.00"]]}})
                            for i, (p, d, side) in enumerate([("0.4800", "-50.00", "yes"), ("0.4900", "25.00", "yes"), ("0.5000", "-120.00", "no"), ("0.5100", "80.00", "no")]):
                                await send({"type": "orderbook_delta", "sid": sid, "msg": {"market_ticker": t, "market_id": "u", "clock": 11 + i,
                                            "price_dollars": p, "delta_fp": d, "side": side, "ts_ms": 1700000000000 + i}})
                    elif ch == "ticker":
                        for t in list(fx.MARKETS)[:5]:
                            await send({"type": "ticker", "sid": sid, "msg": {"market_ticker": t, "yes_bid_dollars": "0.4800", "yes_ask_dollars": "0.5200",
                                        "yes_bid_size_fp": "900.00", "yes_ask_size_fp": "800.00", "volume_fp": "5000.00", "open_interest_fp": "100.00", "ts_ms": 1}})
                    elif ch == "market_lifecycle_v2":
                        await send({"type": "market_lifecycle_v2", "sid": sid, "msg": {"market_ticker": "KXBTC15M-26NOV091400-00", "event_type": "activated"}})
                    elif ch.startswith("cfbenchmarks"):
                        for idx in msg["params"].get("index_ids", []):
                            await send({"type": ch, "sid": sid, "msg": {"index_id": idx, "value_usd": "91234.12345678", "source_ts_ms": 1, "received_at": 2}})
            elif cmd == "update_subscription":
                p = msg["params"]
                if p["action"] == "get_snapshot":
                    self.snapshot_requests.append(p["market_tickers"])
                    for t in p["market_tickers"]:
                        await send({"type": "orderbook_snapshot", "sid": p["sid"], "msg": {"market_ticker": t, "market_id": "u", "clock": 99,
                                    "yes_dollars_fp": [["0.4600", "10.00"]], "no_dollars_fp": [["0.5300", "20.00"]]}})
                else:
                    await ws.send(json.dumps({"type": "ok", "id": msg["id"], "sid": p["sid"], "msg": {"market_tickers": p.get("market_tickers", [])}}))
                    if p["action"] == "add_markets":
                        for t in p["market_tickers"]:
                            await send({"type": "orderbook_snapshot", "sid": p["sid"], "msg": {"market_ticker": t, "market_id": "u", "clock": 1,
                                        "yes_dollars_fp": [["0.4000", "1.00"]], "no_dollars_fp": []}})
            elif cmd == "unsubscribe":
                for sid in msg["params"]["sids"]:
                    await ws.send(json.dumps({"type": "unsubscribed", "sid": sid, "seq": 1}))
            elif cmd == "list_subscriptions":
                await ws.send(json.dumps({"type": "ok", "id": msg["id"], "msg": []}))
            else:
                await ws.send(json.dumps({"type": "error", "id": msg.get("id"), "msg": {"code": 5, "msg": "Unknown command"}}))

    async def __aenter__(self):
        self.server = await serve(self.handler, "127.0.0.1", 0, process_request=self.process_request, ping_interval=None)
        self.port = self.server.sockets[0].getsockname()[1]
        return self

    async def __aexit__(self, *exc):
        self.server.close()
        await self.server.wait_closed()

    @property
    def url(self):
        return f"ws://127.0.0.1:{self.port}/trade-api/ws/v2"


async def _run_for(ws: KalshiWebSocket, seconds: float):
    task = asyncio.create_task(ws.run())
    await asyncio.sleep(seconds)
    await ws.stop()
    task.cancel()
    try:
        await task
    except (asyncio.CancelledError, Exception):
        pass


# ---- order book unit tests ---------------------------------------------------------------------------
def test_orderbook_snapshot_delta_and_implied_asks():
    b = OrderBook("X")
    assert not b.apply_delta({"clock": 1, "price_dollars": "0.4800", "delta_fp": "1.00", "side": "yes"})  # before snapshot
    b.apply_snapshot({"clock": 10, "yes_dollars_fp": [["0.4800", "150.00"], ["0.4700", "300.00"]], "no_dollars_fp": [["0.5000", "120.00"]]})
    assert b.valid and b.best_yes_bid == 4800 and b.best_no_bid == 5000 and b.best_yes_ask == 5000 and b.spread_p4 == 200
    assert b.apply_delta({"clock": 11, "price_dollars": "0.4800", "delta_fp": "-150.00", "side": "yes"})
    assert b.best_yes_bid == 4700 and 4800 not in b.yes_bids             # level removed at zero
    assert b.apply_delta({"clock": 12, "price_dollars": "0.5100", "delta_fp": "80.00", "side": "no"})
    assert b.best_no_bid == 5100 and b.best_yes_ask == 4900 and b.yes_asks()[0] == (4900, 8000)
    assert not b.apply_delta({"clock": 12, "price_dollars": "0.5100", "delta_fp": "80.00", "side": "no"})   # duplicate ignored
    assert b.stats.duplicate_deltas == 1 and b.best_no_bid == 5100
    assert not b.apply_delta({"clock": 5, "price_dollars": "0.4700", "delta_fp": "1.00", "side": "yes"})    # clock regression
    assert not b.valid and b.stats.clock_regressions == 1 and b.stats.invalidations == 1
    b.apply_snapshot({"clock": 20, "yes_dollars_fp": [["0.6000", "1.00"]], "no_dollars_fp": [["0.5000", "1.00"]]})
    assert b.crossed()   # 0.60 bid vs 0.50 implied ask: crossed books are flagged, not traded


def test_bookset_seq_tracking():
    bs = BookSet()
    assert bs.check_seq(1, 1) and bs.check_seq(1, 2) and bs.check_seq(2, 7)
    assert not bs.check_seq(1, 5) and bs.gaps == 1 and bs.gap_events == [(1, 3, 5)]
    assert bs.check_seq(1, 5)   # replay of same seq tolerated
    bs.book("A").apply_snapshot({"clock": 1})
    bs.invalidate_all()
    assert bs.invalid_tickers() == ["A"] and bs.seq_by_sid == {}


# ---- connection scenarios ---------------------------------------------------------------------------------
async def test_auth_handshake_required():
    signer, pub = _signer()
    wrong, _ = _signer()
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(wrong, url=srv.url, max_backoff_s=0.2)
        await _run_for(ws, 0.8)
        assert ws.stats.connects == 0 and ws.stats.disconnects >= 1          # rejected at handshake, kept retrying with backoff
        ws2 = KalshiWebSocket(signer, url=srv.url)
        task = asyncio.create_task(ws2.run())
        await ws2.wait_connected(5)
        assert ws2.stats.connects == 1
        await ws2.stop(); task.cancel()


async def test_books_build_from_snapshot_and_deltas_and_fanout():
    signer, pub = _signer()
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        seen = []
        async def h(m): seen.append(m.type)
        ws.handlers.append(h)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        sub = await ws.subscribe(["orderbook_delta"], market_tickers=["A", "B"])
        await asyncio.sleep(0.5)
        assert sub.sid is not None
        for t in ("A", "B"):
            b = ws.books.books[t]
            assert b.valid and b.clock == 14 and b.best_yes_bid == 4900 and b.best_no_bid == 5100 and b.stats.deltas == 4
            assert b.last_update_ns > 0
        assert seen.count("orderbook_snapshot") == 2 and seen.count("orderbook_delta") == 8 and ws.stats.seq_gaps == 0
        assert ws.queue is None and ws.stats.dropped_fanout == 0 and ws.stats.schema_mismatches == 0
        await ws.stop(); task.cancel()


async def test_seq_gap_invalidates_and_resyncs_with_get_snapshot():
    signer, pub = _signer()
    async with MockKalshiWS(pub, gap_after=2) as srv:     # gap injected after the 2nd message of each sid
        ws = KalshiWebSocket(signer, url=srv.url)
        resync_calls = []
        async def on_resync(tickers): resync_calls.append(tickers)
        ws.on_resync_needed = on_resync
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        await ws.subscribe(["orderbook_delta"], market_tickers=["A"])
        await asyncio.sleep(0.6)
        assert ws.stats.seq_gaps >= 1 and ws.stats.resyncs >= 1 and srv.snapshot_requests == [["A"]] * len(srv.snapshot_requests)
        b = ws.books.books["A"]
        assert b.valid and b.clock == 99 and b.best_yes_bid == 4600     # rebuilt from the requested snapshot
        assert resync_calls and resync_calls[0] == ["A"]
        await ws.stop(); task.cancel()


async def test_disconnect_reconnect_resubscribe_and_books_invalidated_then_rebuilt():
    signer, pub = _signer()
    async with MockKalshiWS(pub, drop_after_msgs=3) as srv:
        ws = KalshiWebSocket(signer, url=srv.url, max_backoff_s=0.3)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        sub = await ws.subscribe(["orderbook_delta"], market_tickers=["A"])
        await asyncio.sleep(2.0)
        assert srv.connections == 2 and ws.stats.reconnects == 1 and ws.stats.disconnects == 1
        subs = [m for m in srv.received if m.get("cmd") == "subscribe"]
        assert len(subs) == 2 and subs[1]["params"]["market_tickers"] == ["A"]   # resubscribed with the same markets
        assert ws.books.books["A"].valid and ws.books.books["A"].clock == 14 and sub.sid is not None
        assert ws.books.books["A"].stats.invalidations >= 1
        await ws.stop(); task.cancel()


async def test_stale_socket_forces_reconnect():
    signer, pub = _signer()
    async with MockKalshiWS(pub, silent=True) as srv:
        ws = KalshiWebSocket(signer, url=srv.url, stale_after_s=0.6, ping_interval_s=None, max_backoff_s=0.2)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        await asyncio.sleep(2.0)
        assert ws.stats.stale_events >= 1 and srv.connections >= 2
        await ws.stop(); task.cancel()


async def test_error_code_9_recorded_and_subscription_dropped():
    signer, pub = _signer()
    async with MockKalshiWS(pub, unauth_channels={"orderbook_delta"}) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        await ws.subscribe(["orderbook_delta"], market_tickers=["A"])
        await asyncio.sleep(0.3)
        assert ws.stats.errors and ws.stats.errors[0]["code"] == 9 and ws.subscriptions == []
        await ws.stop(); task.cancel()


async def test_outbound_allowlist_blocks_non_market_commands():
    signer, pub = _signer()
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        with pytest.raises(RequestNotAllowed):
            await ws.subscribe(["fill"])
        with pytest.raises(RequestNotAllowed):
            await ws.subscribe(["user_orders"])
        with pytest.raises(RequestNotAllowed):
            await ws._send({"id": 9, "cmd": "create_order", "params": {"ticker": "A", "side": "yes", "count": 1}})
        assert all(m.get("cmd") in (None, "subscribe", "unsubscribe", "update_subscription", "list_subscriptions") for m in srv.received)
        assert ws.allowlist.stats.refused == 3
        await ws.stop(); task.cancel()


async def test_update_markets_and_unsubscribe():
    signer, pub = _signer()
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        sub = await ws.subscribe(["orderbook_delta"], market_tickers=["A"])
        await asyncio.sleep(0.3)
        await ws.update_markets(sub, add=["C"], delete=["A"])
        await asyncio.sleep(0.3)
        assert sub.market_tickers == ["C"] and ws.books.books["C"].valid
        assert "A" not in ws.books.books                       # dropped subscription leaves no stale book
        acts = [m["params"]["action"] for m in srv.received if m.get("cmd") == "update_subscription"]
        assert acts == ["delete_markets", "add_markets"]
        await ws.unsubscribe(sub)
        await asyncio.sleep(0.2)
        assert ws.subscriptions == [] and any(m.get("cmd") == "unsubscribe" for m in srv.received)
        await ws.stop(); task.cancel()


async def test_bounded_queue_drops_only_fanout():
    signer, pub = _signer()
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url, queue_max=3)   # opt-in consumer queue
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        await ws.subscribe(["orderbook_delta"], market_tickers=["A", "B"])
        await asyncio.sleep(0.5)
        assert ws.stats.dropped_fanout > 0 and ws.queue.qsize() == 3
        assert ws.books.books["A"].valid and ws.books.books["A"].stats.deltas == 4   # books never drop
        await ws.stop(); task.cancel()


async def test_schema_mismatch_frames_are_dropped_not_applied():
    signer, pub = _signer()
    async with MockKalshiWS(pub, silent=True) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        task = asyncio.create_task(ws.run())
        await ws.wait_connected(5)
        await ws._on_frame(json.dumps({"type": "orderbook_snapshot", "sid": 1, "seq": 1, "msg": {"market_ticker": "Z", "clock": 1, "yes_dollars_fp": [["0.48", "1"]]}}))
        await ws._on_frame("not json")
        assert ws.stats.schema_mismatches == 2 and "Z" not in ws.books.books
        await ws.stop(); task.cancel()


# ---- stream session (registry wiring) ---------------------------------------------------------------------
async def test_stream_session_wires_registry_and_respects_budget(tmp_path, monkeypatch):
    # the fixtures' 15-minute windows are dated 2026-11-09; pin the registry's clock inside them so the
    # test does not start failing once that date has passed
    import datetime as _dt
    import aicrypto.kalshi.registry as R

    class _Frozen(_dt.datetime):
        @classmethod
        def now(cls, tz=None):
            return _dt.datetime(2026, 11, 9, 13, 50, tzinfo=_dt.timezone.utc)
    monkeypatch.setattr(R, "datetime", _Frozen)
    signer, pub = _signer()
    ks = load_kalshi_settings(root=tmp_path)
    ks.subscriptions.max_orderbooks = 3
    ks.subscriptions.rotation_seconds = 1
    reg = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    for s in fx.SERIES.values():
        reg.upsert_series(s)
    for m in fx.MARKETS.values():
        reg.upsert_market(m)
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        sess = StreamSession(ks, reg, ws, rest=None, record_dir=tmp_path / "rec")
        await sess.run(seconds=1.5)
    summ = sess.summary()
    assert sess.stats.ticker_updates == 5 and sess.stats.lifecycle_events == 1 and sess.stats.cf_values >= 3
    assert set(sess.stats.by_index) >= {"BRTI", "ETHUSD_RTI", "SOLUSD_RTI"}
    subs = [m for m in srv.received if m.get("cmd") == "subscribe"]
    chans = [c for m in subs for c in m["params"]["channels"]]
    assert "ticker" in chans and "market_lifecycle_v2" in chans and "cfbenchmarks_value_5hz" in chans and "orderbook_delta" in chans
    book_sub = next(m for m in subs if m["params"]["channels"] == ["orderbook_delta"])
    assert len(book_sub["params"]["market_tickers"]) == 3                      # budget enforced
    assert all(reg.decision(t).tier.value == "tradeable" for t in book_sub["params"]["market_tickers"])
    assert "KXGOLD15M-26NOV091400-00" not in book_sub["params"]["market_tickers"]  # record-only never subscribed
    assert summ["registry"]["markets"] == len(fx.MARKETS)                    # universe untouched
    assert summ["books_valid"] == 3 and sess.stats.frames_recorded > 0
    assert summ["live_book_subscriptions"] <= 3 and len(summ["books"]) <= 3     # held books never exceed the budget
    assert ws.stats.dropped_fanout == 0
    assert list((tmp_path / "rec").glob("*.jsonl.gz"))


async def test_stream_progress_lines(tmp_path):
    signer, pub = _signer()
    ks = load_kalshi_settings(root=tmp_path)
    ks.subscriptions.max_orderbooks = 3
    reg = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    for s in fx.SERIES.values():
        reg.upsert_series(s)
    for m in fx.MARKETS.values():
        reg.upsert_market(m)
    lines = []
    async with MockKalshiWS(pub) as srv:
        ws = KalshiWebSocket(signer, url=srv.url)
        sess = StreamSession(ks, reg, ws)
        await sess.run(seconds=1.2, progress=lines.append, every_s=0.5)
    assert lines[0].startswith("connected") and any("books live" in l and "seq_gaps 0" in l for l in lines[1:])
