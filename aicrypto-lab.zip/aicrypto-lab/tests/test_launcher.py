"""Windows launcher logic (windows/launcher/aicl_core.py), tested on Linux.

Unit tests use fakes for wsl.exe and the health probe. The end-to-end test simulates WSL with
local bash and runs the REAL scripts/start_ui.sh -> `aicrypto ui` backend -> /api/health ->
scripts/stop_ui.sh, including duplicate-start prevention.
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "windows" / "launcher"))
import aicl_core as core  # noqa: E402


# ---------------------------------------------------------------- helpers / fakes
def test_decode_wsl_utf16_and_utf8():
    assert core.decode_wsl("Ubuntu\r\ndocker-desktop\r\n".encode("utf-16-le")) == "Ubuntu\r\ndocker-desktop\r\n"
    assert core.decode_wsl(b"\xff\xfe" + "Ubuntu".encode("utf-16-le")) == "Ubuntu"
    assert core.decode_wsl("HOME=/root\nOK\n".encode()) == "HOME=/root\nOK\n"
    assert core.decode_wsl(b"") == ""


@pytest.mark.parametrize("names,pref,want", [
    (["Ubuntu", "docker-desktop"], "", "Ubuntu"),
    (["docker-desktop", "Ubuntu-24.04"], "", "Ubuntu-24.04"),
    (["Debian"], "", None),
    (["\ufeffUbuntu"], "", "Ubuntu"),
    (["Ubuntu", "MyDistro"], "MyDistro", "MyDistro"),
    (["Ubuntu"], "Missing", None),
])
def test_pick_distro(names, pref, want):
    assert core.pick_distro(names, pref) == want


def test_load_config_sanitises(tmp_path):
    p = tmp_path / "launcher.json"
    p.write_text(json.dumps({"project_dir": "x; rm -rf ~", "port": 80, "distro": "Ubuntu"}))
    cfg = core.load_config(p)
    assert cfg.project_dir == "aicrypto-lab" and cfg.port == 8765 and cfg.distro == "Ubuntu"
    p2 = tmp_path / "new.json"
    cfg2 = core.load_config(p2)
    assert p2.exists() and cfg2.health_url == "http://127.0.0.1:8765/api/health"


class _Resp:
    def __init__(self, body): self.body = body
    def read(self, n): return self.body
    def __enter__(self): return self
    def __exit__(self, *a): return False


def test_probe_health_classifies():
    ours = json.dumps({"app": "aicrypto-lab", "component": "terminal", "pid": 5}).encode()
    assert core.probe_health("u", opener=lambda u, timeout: _Resp(ours)).state == "ours"
    assert core.probe_health("u", opener=lambda u, timeout: _Resp(b'{"app":"other"}')).state == "foreign"
    assert core.probe_health("u", opener=lambda u, timeout: _Resp(b"<html>")).state == "foreign"

    def refuse(u, timeout):
        raise ConnectionRefusedError("refused")
    assert core.probe_health("u", opener=refuse).state == "down"


class FakeProc:
    def __init__(self, rc=None):
        self.returncode = rc
        self.pid = 4242
        self.terminated = False
    def poll(self): return self.returncode
    def terminate(self): self.terminated = True


class FakeRunner:
    def __init__(self, distros="Ubuntu\r\n", list_rc=0, project="OK", wsl="C:\\Windows\\System32\\wsl.exe", proc=None, tail=""):
        self.wsl = wsl
        self.distros, self.list_rc, self.project, self.proc, self.tail = distros, list_rc, project, proc or FakeProc(), tail
        self.calls, self.spawned = [], []
    def run(self, args, timeout=60):
        self.calls.append(args)
        if args[:2] == ["-l", "-q"]:
            return self.list_rc, self.distros, ""
        script = args[-1]
        if "NOPROJECT" in script:
            return 0, f"HOME=/root\n{self.project}\n", ""
        if script.startswith("tail"):
            return 0, self.tail, ""
        return 0, "", ""
    def spawn(self, args):
        self.spawned.append(args)
        return self.proc


class FakeHealth:
    def __init__(self, seq):
        self.seq, self.urls = list(seq), []
    def __call__(self, url):
        self.urls.append(url)
        s = self.seq.pop(0) if len(self.seq) > 1 else self.seq[0]
        return core.Health(s, {"pid": 1} if s == "ours" else {}, "" if s != "foreign" else "unexpected service")


class Clock:
    def __init__(self): self.t = 0.0
    def __call__(self): return self.t
    def sleep(self, s): self.t += s


def _launcher(runner, health, **kw):
    clk = Clock()
    cfg = core.LauncherConfig(start_timeout_s=kw.pop("timeout", 30))
    steps = []
    L = core.Launcher(cfg, runner=runner, health=health, sleep=clk.sleep, clock=clk, progress=lambda *a: steps.append(a))
    return L, steps


# ---------------------------------------------------------------- launcher flows
def test_missing_wsl():
    L, _ = _launcher(FakeRunner(wsl=None), FakeHealth(["down"]))
    with pytest.raises(core.LaunchError) as e:
        L.launch()
    assert e.value.code == "no_wsl" and "wsl --install" in e.value.hint


def test_wsl_error_and_missing_distro():
    with pytest.raises(core.LaunchError) as e:
        _launcher(FakeRunner(list_rc=1), FakeHealth(["down"]))[0].launch()
    assert e.value.code == "no_wsl"
    with pytest.raises(core.LaunchError) as e:
        _launcher(FakeRunner(distros="docker-desktop\r\n"), FakeHealth(["down"]))[0].launch()
    assert e.value.code == "no_distro"


@pytest.mark.parametrize("state,code", [("NOPROJECT", "no_project"), ("NOVENV", "no_venv")])
def test_missing_project_or_python_env(state, code):
    r = FakeRunner(project=state)
    with pytest.raises(core.LaunchError) as e:
        _launcher(r, FakeHealth(["down"]))[0].launch()
    assert e.value.code == code and not r.spawned


def test_attaches_to_running_backend_without_duplicate():
    r = FakeRunner()
    L, steps = _launcher(r, FakeHealth(["ours"]))
    assert L.launch() == "http://127.0.0.1:8765/"
    assert L.attached and not L.started_backend and r.spawned == []
    assert L.shutdown() is False                     # never stops a backend it did not start


def test_port_used_by_other_program():
    r = FakeRunner()
    with pytest.raises(core.LaunchError) as e:
        _launcher(r, FakeHealth(["foreign"]))[0].launch()
    assert e.value.code == "port_busy" and r.spawned == []


def test_starts_backend_waits_for_real_health_then_shuts_down():
    r = FakeRunner()
    h = FakeHealth(["down", "down", "down", "ours"])
    L, steps = _launcher(r, h)
    assert L.launch().endswith(":8765/")
    assert len(r.spawned) == 1 and "start_ui.sh" in r.spawned[0][-1] and "8765" in r.spawned[0][-1]
    assert L.started_backend and L.wsl_home == "/root"
    assert set(h.urls) == {"http://127.0.0.1:8765/api/health"}      # the launcher only ever probes health
    assert L.backend_log_unc() == "\\\\wsl.localhost\\Ubuntu\\root\\aicrypto-lab\\logs\\ui.log"
    assert [s for s, st, _ in steps if st == "ok"] == ["wsl", "project", "backend", "health"]
    assert L.shutdown() is True and any("stop_ui.sh" in c[-1] for c in r.calls)


def test_backend_crash_reports_log_tail():
    r = FakeRunner(proc=FakeProc(rc=1), tail="Traceback ...\nValueError: boom\n")
    with pytest.raises(core.LaunchError) as e:
        _launcher(r, FakeHealth(["down"]))[0].launch()
    assert e.value.code == "backend_crashed" and "boom" in e.value.log_tail


def test_backend_crash_missing_env_maps_to_friendly_error():
    r = FakeRunner(proc=FakeProc(rc=20))
    with pytest.raises(core.LaunchError) as e:
        _launcher(r, FakeHealth(["down"]))[0].launch()
    assert e.value.code == "no_venv"


def test_startup_timeout():
    with pytest.raises(core.LaunchError) as e:
        _launcher(FakeRunner(), FakeHealth(["down"]), timeout=5)[0].launch()
    assert e.value.code == "timeout"


def test_launcher_source_has_no_trading_calls():
    src = (REPO / "windows" / "launcher" / "aicl_core.py").read_text() + (REPO / "windows" / "launcher" / "aicl_launcher.py").read_text()
    for bad in ("/portfolio", "/orders", "arm", "automation_start", "requests.post", "method=\"POST\""):
        if bad == "arm":
            continue
        assert bad not in src
    assert "api/health" in src


# ---------------------------------------------------------------- end to end (simulated WSL)
class LocalWSL(core.Runner):
    """Executes the launcher's wsl.exe argument lists with local bash in a fake home."""
    def __init__(self, home: Path):
        self.wsl = "wsl.exe"
        self.home = home
    def _bash(self, args):
        assert args[:5] == ["-d", "Ubuntu", "--cd", "~", "--"] and args[5:7] == ["bash", "-c"], args
        return ["bash", "-c", args[7]]
    def _env(self):
        e = dict(os.environ); e["HOME"] = str(self.home)
        for k in ("KALSHI_API_KEY_ID", "KALSHI_PRIVATE_KEY_PATH", "KALSHI_ENV"):
            e.pop(k, None)
        return e
    def run(self, args, timeout=60):
        if args[:2] == ["-l", "-q"]:
            return 0, "Ubuntu\n", ""
        p = subprocess.run(self._bash(args), cwd=self.home, capture_output=True, timeout=timeout, env=self._env())
        return p.returncode, p.stdout.decode(), p.stderr.decode()
    def spawn(self, args):
        return subprocess.Popen(self._bash(args), cwd=self.home, env=self._env(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def fake_home(tmp_path):
    home = tmp_path / "home"
    proj = home / "aicrypto-lab"
    (proj / "scripts").mkdir(parents=True)
    (proj / "config").mkdir()
    (proj / ".venv" / "bin").mkdir(parents=True)
    for f in ("start_ui.sh", "stop_ui.sh"):
        shutil.copy(REPO / "scripts" / f, proj / "scripts" / f)
    shutil.copy(REPO / "config" / "kalshi.yaml", proj / "config" / "kalshi.yaml")
    shutil.copy(REPO / "docker-compose.yml", proj / "docker-compose.yml")
    shutil.copy(REPO / ".gitignore", proj / ".gitignore")
    wrapper = proj / ".venv" / "bin" / "aicrypto"
    wrapper.write_text(f"#!{sys.executable}\nimport sys\nsys.path.insert(0, {str(REPO)!r})\n"
                       f"from aicrypto.cli import main\nsys.exit(main(['--root', {str(proj)!r}] + sys.argv[1:]))\n")
    wrapper.chmod(0o755)
    return home


def test_end_to_end_start_health_duplicate_and_shutdown(fake_home):
    port = _free_port()
    cfg = core.LauncherConfig(port=port, start_timeout_s=60)
    L = core.Launcher(cfg, runner=LocalWSL(fake_home))
    try:
        assert L.launch() == f"http://127.0.0.1:{port}/"
        assert L.started_backend and L.proc is not None
        h = core.probe_health(cfg.health_url).data
        assert h["app"] == "aicrypto-lab" and h["orders_enabled"] is False
        pid_file = fake_home / "aicrypto-lab" / "run" / "ui.pid"
        assert pid_file.exists() and int(pid_file.read_text()) == h["pid"]
        # a second launcher attaches instead of starting a duplicate backend
        L2 = core.Launcher(cfg, runner=LocalWSL(fake_home))
        L2.launch()
        assert L2.attached and not L2.started_backend
        # starting the backend by hand while one runs is refused (port check)
        r = subprocess.run(["bash", "-c", f"bash ./aicrypto-lab/scripts/start_ui.sh {port}"], cwd=fake_home,
                           env={**os.environ, "HOME": str(fake_home)}, timeout=60)
        assert r.returncode == 3
        log = (fake_home / "aicrypto-lab" / "logs" / "ui.log").read_text()
        assert "already in use" in log
    finally:
        stopped = L.shutdown()
    assert stopped
    for _ in range(40):
        if core.probe_health(cfg.health_url).state == "down":
            break
        time.sleep(0.25)
    assert core.probe_health(cfg.health_url).state == "down"
    assert not (fake_home / "aicrypto-lab" / "run" / "ui.pid").exists()


def test_start_ui_without_python_env_exits_20(fake_home):
    shutil.rmtree(fake_home / "aicrypto-lab" / ".venv")
    r = subprocess.run(["bash", "./aicrypto-lab/scripts/start_ui.sh", "8799"], cwd=fake_home, capture_output=True,
                       env={**os.environ, "HOME": str(fake_home)}, timeout=30)
    assert r.returncode == 20 and b"Python environment missing" in r.stderr


def test_stop_ui_refuses_foreign_pid(fake_home):
    run = fake_home / "aicrypto-lab" / "run"
    run.mkdir()
    sleeper = subprocess.Popen(["sleep", "30"])
    try:
        (run / "ui.pid").write_text(str(sleeper.pid))
        r = subprocess.run(["bash", "./aicrypto-lab/scripts/stop_ui.sh"], cwd=fake_home, capture_output=True, timeout=30)
        assert r.returncode == 1 and sleeper.poll() is None        # unrelated process left alone
    finally:
        sleeper.kill()
