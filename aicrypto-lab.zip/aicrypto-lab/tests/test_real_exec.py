"""Real-money execution (owner decision 2026-11-19, CLAUDE.md rule 21). All traffic goes to a mocked exchange;
no network, no real orders."""
import asyncio
import os
import time
from decimal import Decimal
from pathlib import Path

import httpx
import pytest

from aicrypto.kalshi.auth import HOSTS, CredentialError, Credentials
from aicrypto.kalshi.demo_exec.exchange import DemoExchange
from aicrypto.kalshi.demo_exec.trader import Intent, OrderRefused
from aicrypto.kalshi.real_exec import trader as RT
from aicrypto.kalshi.real_exec.exchange import REAL_BASE, REAL_HOST, RealExchange, RealExchangeViolation
from aicrypto.kalshi.registry import MarketRegistry
from aicrypto.kalshi.settings import load_kalshi_settings
from aicrypto.terminal.service import TerminalService

import test_demo_exec as D           # reuse the fake exchange, fixtures and signer

ETH = D.ETH


class FakeReal(D.FakeDemo):
    """The demo fake, answering only on the production trading host."""

    def handler(self, req: httpx.Request) -> httpx.Response:
        assert req.url.host == REAL_HOST, req.url.host
        demo_req = httpx.Request(req.method, req.url.copy_with(host="demo-api.kalshi.co"), headers=req.headers, content=req.content)
        resp = super().handler(demo_req)      # the parent logic, answering for the real host
        self.requests[-1] = (req.method, req.url.host, req.url.path)
        return resp


@pytest.fixture
def renv(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "registry.sqlite")
    for s in D.fx.SERIES.values():
        reg.upsert_series(s)
    for m in D.fx.MARKETS.values():
        reg.upsert_market(m)
    reg.reevaluate_all()
    demo, real, rest = D.FakeDemo(), FakeReal(), D.FakeRest()
    sg, sg2 = D.signer(), D.signer()
    svc = TerminalService(ks, live=False, registry=reg, rest_factory=lambda: rest,
                          demo_exchange_factory=lambda: DemoExchange(sg, http_transport=httpx.MockTransport(demo.handler)),
                          demo_ledger_path=tmp_path / "demo.sqlite",
                          real_exchange_factory=lambda: RealExchange(sg2, http_transport=httpx.MockTransport(real.handler)),
                          real_ledger_path=tmp_path / "real.sqlite")
    svc.now_fn = lambda: D.NOW
    svc.recompute_access()
    svc.real_lab.quotes[ETH] = (time.monotonic(), 4800, 5000, 500.0, 500.0, 2000.0)     # REAL quote: 48% / 50%
    svc.real_lab.shards[ETH] = 2                                                         # its shard on the REAL exchange
    return svc, demo, real


async def connected(svc):
    await svc.real.refresh_account()
    assert svc.real.state == "connected"


# ------------------------------------------------------------------ structure
def test_real_exchange_is_pinned_to_the_production_trading_host():
    assert REAL_BASE == HOSTS["production"]["rest"] and REAL_HOST == "api.elections.kalshi.com"
    with pytest.raises(RealExchangeViolation):
        RealExchange(D.signer(), _credentials_env="demo")
    with pytest.raises(RealExchangeViolation):
        RealExchange.from_credentials(Credentials("k", Path("/x"), "demo"))
    ex = RealExchange(D.signer(), http_transport=httpx.MockTransport(lambda r: httpx.Response(200, json={})))
    for method, path in (("POST", "/portfolio/withdrawals"), ("POST", "/api_keys"), ("POST", "/portfolio/subaccounts/transfer"),
                         ("POST", "/portfolio/orders/batched"), ("GET", "https://evil.example/portfolio/balance")):
        with pytest.raises(RealExchangeViolation.__mro__[1]):
            asyncio.run(ex._request(method, path))
    redirect = RealExchange(D.signer(), http_transport=httpx.MockTransport(
        lambda r: httpx.Response(302, headers={"Location": "https://elsewhere.example/"})))
    with pytest.raises(RealExchangeViolation):
        asyncio.run(redirect.balance())


def test_demo_module_still_refuses_production():
    with pytest.raises(Exception):
        DemoExchange.from_credentials(Credentials("k", Path("/x"), "production"))


def test_limits_are_fixed_constants():
    assert RT.MIN_TRADE == Decimal("1.00") and RT.PER_TRADE_MAX == Decimal("0.10") and RT.PER_DAY_MAX is None
    assert RT.ARM_PHRASE == "REAL MONEY"


def test_limit_errors():
    ok = dict(equity=Decimal(500), day_equity=Decimal(500), spent_today=Decimal(0))
    assert RT.limit_errors(cost=Decimal("10"), max_loss=Decimal("10.5"), **ok) == []
    assert any("at least $1.00" in e for e in RT.limit_errors(cost=Decimal("0.50"), max_loss=Decimal("0.52"), **ok))
    assert any("10% per-trade" in e for e in RT.limit_errors(cost=Decimal("50.01"), max_loss=Decimal("51"), **ok))
    # no daily spending limit (owner, 2026-11-19): any amount already spent today is fine
    assert RT.limit_errors(cost=Decimal("20"), max_loss=Decimal("21"), equity=Decimal(500), day_equity=Decimal(500),
                           spent_today=Decimal("5000")) == []


# ------------------------------------------------------------------ credentials
def _key(path: Path):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    path.write_bytes(ed25519.Ed25519PrivateKey.generate().private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    os.chmod(path, 0o600)


def test_real_credentials_file(tmp_path):
    repo, home = tmp_path / "repo", tmp_path / "home"
    repo.mkdir(); home.mkdir()
    envf = home / "kalshi_real.env"
    assert RT.load_real_credentials(envf, repo) is None                                  # not set up: nothing to connect
    pem = home / "real.pem"
    _key(pem)
    envf.write_text(f"KALSHI_REAL_API_KEY_ID=SECRET-REAL-ID\nKALSHI_REAL_PRIVATE_KEY_PATH={pem}\n")
    os.chmod(envf, 0o644)
    with pytest.raises(CredentialError):
        RT.load_real_credentials(envf, repo)                                             # settings file must be private
    os.chmod(envf, 0o600)
    c = RT.load_real_credentials(envf, repo)
    assert c.env == "production" and "SECRET-REAL-ID" not in repr(c)
    inside = repo / "real.pem"
    _key(inside)
    envf.write_text(f"KALSHI_REAL_API_KEY_ID=x\nKALSHI_REAL_PRIVATE_KEY_PATH={inside}\n")
    with pytest.raises(CredentialError):
        RT.load_real_credentials(envf, repo)                                             # key inside the repository refused


def test_no_real_key_means_not_set_up(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    svc = TerminalService(ks, live=False, registry=MarketRegistry(ks, db_path=tmp_path / "r.sqlite"),
                          demo_ledger_path=tmp_path / "d.sqlite", real_ledger_path=tmp_path / "r2.sqlite")
    assert svc.real.exchange() is None and svc.real.state == "no_credentials"
    with pytest.raises(OrderRefused):
        svc.real_bot.turn_on("REAL MONEY")
    assert not svc.real_bot.on


# ------------------------------------------------------------------ orders
def test_real_orders_go_to_the_real_host_only_priced_from_the_real_quote(renv):
    svc, demo, real = renv

    async def go():
        await connected(svc)
        r = await svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:test"), automated=True)
        return r
    r = asyncio.run(go())
    assert r["state"] in ("RESTING", "FILLED")
    assert real.posts and real.posts[-1]["price"] == "0.5000" and real.posts[-1]["ticker"] == ETH
    assert all(h == REAL_HOST for _, h, _ in real.requests) and demo.requests == []        # nothing went to demo
    svc.real_lab.quotes[ETH] = (time.monotonic(), 2000, 2200, 500.0, 500.0, 2000.0)      # real ask now 22%
    with pytest.raises(OrderRefused) as e:
        asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:test"), automated=True))
    assert any("above the best offer" in x for x in e.value.errors)                        # fat-finger vs the REAL price
    svc.real_lab.quotes[ETH] = (time.monotonic() - 60, 4800, 5000, 500.0, 500.0, 2000.0)
    with pytest.raises(OrderRefused) as e:
        asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:test"), automated=True))
    assert any("fresh order book" in x for x in e.value.errors)                            # stale real quote blocks


def test_owner_limits_enforced_on_real_orders(renv):
    svc, _, real = renv
    asyncio.run(connected(svc))
    eq = svc.real.equity()                                                                 # $500 cash + $12.34 positions
    with pytest.raises(OrderRefused) as e:
        asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 1, origin="bot:t"), automated=True))
    assert any("at least $1.00" in x for x in e.value.errors)
    big = int(eq * Decimal("0.10") / Decimal("0.50")) + 2
    with pytest.raises(OrderRefused) as e:
        asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), big, origin="bot:t"), automated=True))
    assert any("per-trade limit" in x for x in e.value.errors)
    n = int(eq * Decimal("0.09") / Decimal("0.50"))                                        # ~9% per trade
    placed = 0
    for _ in range(5):
        try:
            asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), n, origin="bot:t"), automated=True))
            placed += 1
        except OrderRefused as e:
            assert not any("Daily limit" in x for x in e.errors)
            break
    assert placed >= 4                                                                     # no daily limit: past 30% is fine
    st = svc.real.limits_status()
    assert st["daily_limit"] is None and st["left_today"] is None and st["daily_loss_stop"] is None


def test_manual_real_orders_are_not_offered(renv):
    svc, _, _ = renv
    with pytest.raises(OrderRefused):
        asyncio.run(svc.real.prepare(Intent(ETH, "yes", Decimal("0.50"), 5)))


# ------------------------------------------------------------------ bot
def test_real_bot_off_at_start_needs_phrase_and_trades_practice_rules(renv):
    svc, _, _ = renv
    assert svc.real_bot.on is False and svc.real_lab.bot is svc.real_bot
    asyncio.run(connected(svc))
    with pytest.raises(OrderRefused):
        svc.real_bot.turn_on("yes")
    svc.real_bot.turn_on("real money")
    assert svc.real_bot.on and svc.real_bot.settings.practice is True
    assert svc.real_bot.may_trade("exploring", 3, None) and not svc.real_bot.may_trade("exploring", 12, -0.01)
    svc.real_bot.configure(stake_pct=50)
    assert svc.real_bot.settings.stake_pct == 10.0                                        # capped at 10%
    svc.real_bot.configure(stake_pct=2)
    n = svc.real_bot.size(Decimal("0.50"), 1000)
    assert n * Decimal("0.50") >= Decimal("1.00") and n * Decimal("0.50") <= svc.real.equity() * Decimal("0.02") + 1


def test_one_emergency_stop_halts_demo_and_real(renv):
    svc, _, real = renv
    from fastapi.testclient import TestClient
    from aicrypto.terminal.app import create_terminal_app
    asyncio.run(connected(svc))
    asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:t"), automated=True))
    svc.real_bot.turn_on("REAL MONEY")
    c = TestClient(create_terminal_app(svc))
    h = {"X-AICL-Client": "terminal", "Origin": "http://127.0.0.1:8765"}
    r = c.post("/api/demo/kill", headers=h).json()
    assert r["ok"] and r["real"] is not None
    assert svc.real_bot.on is False and svc.real.kill_on()
    assert any(o["status"] == "canceled" for o in real.orders.values())
    with pytest.raises(OrderRefused):
        svc.real_bot.turn_on("REAL MONEY")                                                 # stays off until reset
    st = c.get("/api/real/status").json()
    assert st["kill"] is True and st["bot_on"] is False and "SECRET" not in str(st)


def test_research_and_recording_code_never_reach_real_money():
    root = Path(__file__).resolve().parents[1] / "aicrypto"
    for pkg in ("recorder", "research_agent", "research15", "timeframes"):
        for p in (root / pkg).rglob("*.py"):
            assert "real_exec" not in p.read_text(), p


def test_account_switch_shows_the_chosen_account(renv):
    svc, demo, real = renv
    from fastapi.testclient import TestClient
    from aicrypto.terminal.app import create_terminal_app
    asyncio.run(connected(svc))
    asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:t"), automated=True))
    c = TestClient(create_terminal_app(svc))
    assert len(c.get("/api/demo/orders?account=real").json()["orders"]) == 1
    assert c.get("/api/demo/orders").json()["orders"] == []                       # demo is the default and separate
    assert c.get("/api/demo/status?account=real").json()["real"] is True
    assert c.get("/api/demo/orders?account=other").status_code == 400
    for p in ("/api/demo/positions", "/api/demo/transactions", "/api/demo/events", "/api/bot/progress"):
        assert c.get(p + "?account=real").status_code == 200
    st = c.get("/api/terminal/status").json()
    assert st["accounts"]["kalshi_real"]["connected"] is True and st["accounts"]["kalshi_real"]["bot_on"] is False


def test_real_funding_uses_the_real_exchanges_shard_never_the_demo_one(renv):
    svc, _, real = renv
    asyncio.run(connected(svc))
    svc.reg.markets[ETH].raw["exchange_index"] = 0                    # the demo registry says 0 (as happened 2026-11-19)
    real.shards = {0: Decimal("500.00"), 2: Decimal("0.00")}
    asyncio.run(svc.real.refresh_account())
    asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:t"), automated=True))
    assert real.transfers and all(t["destination_exchange_shard"] == 2 for t in real.transfers)
    # unknown real shard: refused, nothing moved
    real.transfers.clear()
    svc.real_lab.shards.pop(ETH)

    async def no_lookup(tickers):
        raise RuntimeError("offline")
    svc.real_lab._markets = no_lookup
    with pytest.raises(OrderRefused) as e:
        asyncio.run(svc.real.place(Intent(ETH, "yes", Decimal("0.50"), 20, origin="bot:t2"), automated=True))
    assert any("Couldn't confirm" in x for x in e.value.errors) and real.transfers == []



def test_cashout_decision_only_sells_positions_that_collapsed(renv):
    svc, _, _ = renv
    r = svc.real
    pos = {"ticker": ETH, "side": "no", "contracts": "20", "exposure": "-12.00"}          # paid 60% per contract
    assert r.cashout_pct() == 10.0
    assert r.cashout_decision(pos, Decimal("0.08"))                                      # 8%: sell
    assert r.cashout_decision(pos, Decimal("0.15")) is None                              # 15%: above the setting
    assert r.cashout_decision(pos, Decimal("0.004")) is None                             # brings back under $0.10
    longshot = {"ticker": ETH, "side": "yes", "contracts": "400", "exposure": "-12.00"}  # paid 3%: a deliberate long shot
    assert r.cashout_decision(longshot, Decimal("0.03")) is None
    assert r.cashout_decision(longshot, Decimal("0.01"))                                 # fell to a third of the price
    r.set_cashout_pct(0)
    assert r.cashout_decision(pos, Decimal("0.02")) is None                              # off


def test_auto_cashout_sells_a_lost_real_position(renv):
    svc, _, real = renv
    asyncio.run(connected(svc))
    svc.real.account["positions"] = [{"ticker": ETH, "side": "yes", "contracts": "20", "exposure": "-10.00"}]
    calls = []

    async def fake_cashout(t, origin="manual", slippage=None):
        calls.append((t, origin, slippage))
        return {"state": "EXECUTED"}
    svc.real.cashout = fake_cashout
    svc.real_lab.quotes[ETH] = (time.monotonic(), 4800, 5000, 500.0, 500.0, 2000.0)      # 48%: keep
    assert asyncio.run(svc.real.auto_cashout()) == [] and calls == []
    svc.real_lab.quotes[ETH] = (time.monotonic(), 600, 800, 500.0, 500.0, 2000.0)        # 6%: sell
    asyncio.run(svc.real.auto_cashout())
    assert calls == [(ETH, "auto", RT.CASHOUT_AUTO_SLIPPAGE)]
    asyncio.run(svc.real.auto_cashout())                                                 # no repeat within the retry wait
    assert len(calls) == 1
