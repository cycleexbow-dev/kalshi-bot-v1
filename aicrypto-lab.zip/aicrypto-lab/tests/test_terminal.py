"""Milestone A: financial-market filtering, access levels, terminal API (read-only), fees."""
import sys
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.eligibility import evaluate  # noqa: E402
from aicrypto.kalshi.models import MarketInfo, SeriesInfo  # noqa: E402
from aicrypto.kalshi.registry import MarketRegistry  # noqa: E402
from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402
from aicrypto.terminal.access import TABS, classify, is_financial_series, tab_for  # noqa: E402
from aicrypto.terminal.app import create_terminal_app  # noqa: E402
from aicrypto.terminal.fees import fee_estimate, preview  # noqa: E402
from aicrypto.terminal.service import TerminalService  # noqa: E402

NOW = datetime(2026, 11, 9, 13, 50, tzinfo=timezone.utc)   # fixtures' 14:00 windows are open, not closing


@pytest.fixture
def ks(tmp_path):
    return load_kalshi_settings(root=tmp_path)


@pytest.fixture
def reg(ks, tmp_path):
    r = MarketRegistry(ks, db_path=tmp_path / "registry.sqlite")
    for s in fx.SERIES.values():
        r.upsert_series(s)
    for m in fx.MARKETS.values():
        r.upsert_market(m)
    return r


def _acc(reg, ks, t):
    m = reg.markets[t]
    return classify(reg.decisions.get(t), m, reg.series.get(m.series_ticker), ks, NOW)


# ---------------------------------------------------------------- strict financial filtering
def test_non_financial_categories_are_never_visible(reg, ks):
    for t in ("KXPRES-28-DEM", "KXNFLGAME-26NOV09-KC", "KXAAPLEPS-26Q4-BEAT"):
        a = _acc(reg, ks, t)
        assert not a.visible and not a.manual and not a.auto, t


@pytest.mark.parametrize("category", ["Climate and Weather", "Sports", "Politics", "Elections", "Entertainment", "Companies", "Earnings", "Culture"])
def test_excluded_categories_hidden_even_with_crypto_looking_ticker(ks, category):
    s = SeriesInfo.from_api({**fx.SERIES["KXBTC15M"], "category": category, "categories": [category]})
    m = MarketInfo.from_api(fx.MARKETS["KXBTC15M-26NOV091400-00"])
    assert not is_financial_series(s, ks)
    assert not classify(evaluate(s, m, ks), m, s, ks, NOW).visible


def test_market_without_decision_is_hidden(reg, ks):
    m = reg.markets["KXBTC15M-26NOV091400-00"]
    assert not classify(None, m, reg.series[m.series_ticker], ks, NOW).visible
    assert not classify(reg.decisions[m.ticker], m, None, ks, NOW).visible


def test_crypto_is_auto_eligible_and_tabbed(reg, ks):
    a = _acc(reg, ks, "KXETHD-26NOV1017-T2000")
    assert a.visible and a.tab == "ETH" and a.auto and a.manual
    assert _acc(reg, ks, "KXLTCH-26NOV0915-T80").tab == "Other Crypto"


def test_gold_visible_but_not_auto_without_reference_feed(reg, ks):
    a = _acc(reg, ks, "KXGOLDD-26NOV0917-T4100")
    assert a.visible and a.tab == "Gold"
    assert not a.auto and "reference_unavailable" in a.auto_blockers
    assert a.manual                       # verified terms + active; feed absence alone does not block manual


def test_metal_tabs_and_others():
    assert tab_for("GOLD", "metals") == "Gold" and tab_for("SILVER", "metals") == "Silver" and tab_for("COPPER", "metals") == "Copper"
    assert tab_for("PLATINUM", "metals") == "Other" and tab_for("WTI", "energy") == "Energy" and tab_for("SPX", "indices") == "Indices"
    assert tab_for("X", "sports") is None


def test_manual_requires_open_status_and_not_closing(reg, ks):
    t = "KXETHD-26NOV1017-T2000"
    m = reg.markets[t]
    late = m.close_time.replace(second=0) if m.close_time else NOW
    a = classify(reg.decisions[t], m, reg.series[m.series_ticker], ks, late)
    assert not a.manual and "closing" in a.manual_blockers
    reg.apply_lifecycle({"type": "market_lifecycle_v2", "msg": {"market_ticker": t, "event_type": "deactivated"}})
    a2 = classify(reg.decisions[t], reg.markets[t], reg.series[m.series_ticker], ks, NOW)
    assert not a2.manual and not a2.auto


def test_unverified_terms_block_trading(reg, ks):
    for t, d in reg.decisions.items():
        a = _acc(reg, ks, t)
        if a.visible and d.tier.value == "rejected":
            assert not a.manual and not a.auto and "terms_unverified" in a.manual_blockers


# ---------------------------------------------------------------- service / all-timeframe browsing
@pytest.fixture
def client(reg, ks):
    svc = TerminalService(ks, live=False, registry=reg)
    app = create_terminal_app(svc)
    with TestClient(app) as c:
        import time
        for _ in range(50):
            if c.get("/api/health").json()["phase"] == "ready":
                break
            time.sleep(0.05)
        yield c, svc


def test_health_and_status(client):
    c, _ = client
    h = c.get("/api/health").json()
    assert h["app"] == "aicrypto-lab" and h["orders_enabled"] is False and h["phase"] == "ready"
    st = c.get("/api/terminal/status").json()
    assert st["mode"]["production_orders"] == "not set up" and st["mode"]["automation"] == "disarmed"   # no real key: nothing to arm
    assert st["accounts"]["local_paper"]["balance"] == "700.00" and st["accounts"]["kalshi_demo"]["connected"] is False


def test_tabs_and_durations_are_discovered_not_hardcoded(client):
    c, svc = client
    tabs = {t["name"]: t for t in c.get("/api/terminal/tabs").json()["tabs"]}
    assert list(tabs) == TABS
    durs = {d for t in tabs.values() for d in t["durations"]}
    expected = {svc.reg.decisions[t].duration.bucket.value for t, a in svc.access.items() if svc.reg.markets[t].status.value == "active"}
    assert durs == expected and len(durs) >= 3          # 15m, hourly, daily, weekly in fixtures


def test_market_list_only_financial(client):
    c, _ = client
    seen = set()
    for tab in TABS:
        r = c.get("/api/terminal/markets", params={"tab": tab, "status": "all", "limit": 500}).json()
        seen |= {row["ticker"] for row in r["rows"]}
    assert seen and not any(t.startswith(("KXPRES", "KXNFL", "KXAAPL")) for t in seen)
    assert any(t.startswith("KXGOLD") for t in seen) and any(t.startswith("KXBTC") for t in seen)


def test_market_filters(client):
    c, _ = client
    r = c.get("/api/terminal/markets", params={"tab": "ETH", "status": "all"}).json()
    assert r["total"] >= 1 and all(x["tab"] == "ETH" for x in r["rows"])
    r2 = c.get("/api/terminal/markets", params={"tab": "ETH", "status": "all", "q": "T2000"}).json()
    assert all("T2000" in x["ticker"] for x in r2["rows"]) and r2["total"] >= 1
    r3 = c.get("/api/terminal/markets", params={"tab": "Gold", "status": "all", "access": "auto"}).json()
    assert r3["total"] == 0                                 # no gold market is auto-eligible without a feed
    assert c.get("/api/terminal/markets", params={"status": "bogus"}).status_code == 400


def test_detail_hides_non_financial_and_shows_terms(client):
    c, _ = client
    assert c.get("/api/terminal/market/KXPRES-28-DEM").status_code == 404
    assert c.get("/api/terminal/market/bad%20ticker").status_code in (400, 404)
    d = c.get("/api/terminal/market/KXGOLDD-26NOV0917-T4100").json()
    assert d["settlement"]["status"] == "feed_unavailable" and d["access"]["auto"] is False and d["orders_enabled"] is False
    assert d["rules_primary"]


def test_preview_is_estimate_only_and_validates(client):
    c, _ = client
    t = "KXETHD-26NOV1017-T2000"
    ok = c.get(f"/api/terminal/market/{t}/preview", params={"side": "yes", "price": "0.50", "count": "10"}).json()
    assert ok["valid"] and ok["cost"] == "5.00" and ok["fee_taker"] == "0.18" and ok["submission"] == "unavailable"   # no demo account here
    for bad in ({"price": "1.20"}, {"price": "0.505"}, {"count": "0"}, {"count": "2.5"}, {"side": "maybe"}, {"price": "abc"}):
        r = c.get(f"/api/terminal/market/{t}/preview", params={"side": "yes", "price": "0.50", "count": "1", **bad}).json()
        assert not r["valid"] and r["errors"], bad


def test_only_demo_and_automation_routes_can_change_state(client):
    c, _ = client
    for route in c.app.routes:
        methods = (getattr(route, "methods", None) or set()) - {"GET", "HEAD"}
        if methods:
            assert methods == {"POST"} and route.path.startswith(("/api/demo/", "/api/auto/", "/api/bot/", "/api/real/")), (route.path, methods)
        assert "portfolio" not in route.path
    # every state-changing call needs the app's header and a local origin (blocks other websites)
    assert c.post("/api/demo/kill").status_code == 403
    assert c.post("/api/demo/kill", headers={"X-AICL-Client": "terminal", "Origin": "https://evil.example"}).status_code == 403
    assert c.post("/api/demo/orders/prepare", json={"ticker": "KXETHD-26NOV1017-T2000", "side": "yes", "price": "0.5", "count": 1}).status_code == 403
    for path in ("/api/real/bot/on", "/api/real/kill", "/api/real/settings"):             # real money: same guard
        assert c.post(path, json={"phrase": "REAL MONEY"}).status_code == 403
        assert c.post(path, json={}, headers={"X-AICL-Client": "terminal", "Origin": "https://evil.example"}).status_code == 403
    for path in ("/api/terminal/order", "/api/orders", "/api/terminal/market/KXETHD-26NOV1017-T2000/order"):
        assert c.post(path, json={}).status_code in (404, 405)


def test_no_secrets_in_any_response(client, monkeypatch):
    c, _ = client
    monkeypatch.setenv("KALSHI_API_KEY_ID", "SECRET-KEY-ID-123")
    monkeypatch.setenv("KALSHI_PRIVATE_KEY_PATH", "/root/.kalshi/demo-key.pem")
    blob = "".join(c.get(p).text for p in ("/api/health", "/api/terminal/status", "/api/terminal/feeds", "/api/terminal/tabs",
                                            "/api/terminal/markets?status=all", "/api/terminal/market/KXETHD-26NOV1017-T2000"))
    assert "SECRET-KEY-ID-123" not in blob and "demo-key.pem" not in blob and "PRIVATE KEY" not in blob


def test_static_ui_served(client):
    c, _ = client
    html = c.get("/").text
    assert "DEMO — SIMULATED FUNDS" in html and "/static/app.js" in html
    js = c.get("/static/app.js").text
    assert "Confirm Demo Trade" in js and "fetch(" in js
    import re as _re
    assert js.count('method: "POST"') == 1 and '"X-AICL-Client": "terminal"' in js     # one POST helper, always with the header
    assert set(_re.findall(r'post\(\s*[`"](/api/[a-z]+)/', js)) <= {"/api/demo", "/api/auto", "/api/bot", "/api/real"}
    assert "REAL MONEY" in js and "/api/real/bot/on" in js                       # real trading is switched on by the owner here only


# ---------------------------------------------------------------- fees
def test_fee_formula():
    assert fee_estimate(Decimal(10), Decimal("0.50")) == Decimal("0.18")      # 0.07*10*0.25 = 0.175 -> 0.18
    assert fee_estimate(Decimal(1), Decimal("0.01")) == Decimal("0.01")       # rounds up to a cent
    assert fee_estimate(Decimal(10), Decimal("0.50"), maker=True, fee_type="quadratic") == Decimal(0)
    assert fee_estimate(Decimal(100), Decimal("0.40"), maker=True, fee_type="quadratic_with_maker_fees") == Decimal("0.42")
    p = preview("no", "0.30", "4")
    assert p.cost == Decimal("1.20") and p.max_loss == p.cost + p.fee_taker and p.max_profit == Decimal(4) - p.cost - p.fee_taker


def test_service_loads_only_financial_series_from_disk(ks):
    import asyncio
    r = MarketRegistry(ks)                      # default path: <root>/user_data/kalshi/registry.sqlite
    for s in fx.SERIES.values():
        r.upsert_series(s)
    for m in fx.MARKETS.values():
        r.upsert_market(m)
    svc = TerminalService(ks, live=False)
    phases = []
    asyncio.run(svc.start())
    assert svc.load.phase == "ready" and svc.load.progress == 1.0
    assert not any(t.startswith(("KXPRES", "KXNFL", "KXAAPL")) for t in svc.reg.markets)     # never even loaded
    assert any(t.startswith("KXGOLD") for t in svc.reg.markets) and any(t.startswith("KXBTC") for t in svc.reg.markets)
    asyncio.run(svc.stop())


def test_service_reports_missing_registry(tmp_path):
    import asyncio
    svc = TerminalService(load_kalshi_settings(root=tmp_path / "empty"), live=False)
    asyncio.run(svc.start())
    assert svc.load.phase == "error" and "discover" in svc.load.error


# ---------------------------------------------------------------- plain-language issues (UI notifications)
def test_issue_missing_market_list(tmp_path):
    import asyncio
    svc = TerminalService(load_kalshi_settings(root=tmp_path / "empty"), live=False)
    asyncio.run(svc.start())
    ids = [i["id"] for i in svc.issues()]
    assert ids == ["NO-MARKETS"]
    i = svc.issues()[0]
    assert i["level"] == "error" and "[NO-MARKETS]" in i["report"] and "discover" in i["report"]


def test_issue_no_key_and_offline_and_stale(reg, ks):
    import time as _t
    svc = TerminalService(ks, live=True, registry=reg)
    svc.load.phase = "ready"
    assert svc.issues() == []
    svc.live.state = "no_credentials"
    assert [i["id"] for i in svc.issues()] == ["NO-KEY"]
    now = _t.time()
    svc.live.state, svc.live.not_live_since, svc.live.last_error = "connecting", now - 10, "ConnectionError"
    assert svc.issues(now) == []                                   # short blips are not reported
    svc.live.not_live_since = now - 95
    off = svc.issues(now)
    assert [i["id"] for i in off] == ["KALSHI-OFFLINE"] and "1 min 35 s" in off[0]["message"]
    svc.live.state = "live"
    svc.ref_last = {"BRTI": (now - 45, 1.0, None), "ETHUSD_RTI": (now - 1, 1.0, None)}
    st = svc.issues(now)
    assert [i["id"] for i in st] == ["PRICES-STALE"] and "BTC" in st[0]["message"] and "ETH" not in st[0]["message"]


def test_issue_background_error_and_status_carries_issues(client):
    c, svc = client
    svc._error("live data", RuntimeError("boom"))
    st = c.get("/api/terminal/status").json()
    assert any(i["id"] == "BACKGROUND" and "boom" in i["report"] for i in st["issues"])
    assert all(set(i) == {"id", "level", "title", "message", "report"} for i in st["issues"])


def test_ui_shows_simple_connection_indicator():
    from aicrypto.terminal.app import STATIC
    js = (STATIC / "app.js").read_text()
    html = (STATIC / "index.html").read_text()
    for gone in ("pill-books", "Sequence gaps", "Schema mismatches", "Dispatch p50", "Live order books", "WebSocket"):
        assert gone not in js + html, gone
    for want in ("Connected", "Copy details for Claude", "Not connected", "Disconnected"):
        assert want in js, want


def test_live15_shows_one_market_per_asset(client):
    c, svc = client
    from datetime import datetime, timezone
    svc.now_fn = lambda: datetime(2026, 11, 9, 14, 5, tzinfo=timezone.utc)
    svc.recompute_access()
    rows = c.get("/api/terminal/live15").json()["markets"]
    assets = [r["asset"] for r in rows]
    assert len(assets) == len(set(assets)) and "BTC" in assets and "GOLD" in assets          # exactly one per asset
    assert assets.index("BTC") < assets.index("GOLD")                                        # crypto first
    assert all(r["duration"] == "15m" for r in rows)
    btc = next(r for r in rows if r["asset"] == "BTC")
    assert btc["ticker"] == "KXBTC15M-26NOV091400-00" and btc["open_now"] is True           # the window open right now


def test_refresh_15m_reports_what_happened(reg, ks):
    import asyncio

    class Rest:
        mismatches = []

        async def list_markets(self, *, status, series_ticker, max_pages):
            if series_ticker == "KXGOLD15M":
                raise TimeoutError("slow")
            return [fx.MARKETS["KXBTC15M-26NOV091400-00"]]
    svc = TerminalService(ks, live=False, registry=reg, rest_factory=lambda: Rest())
    svc.load.phase = "ready"
    rep = asyncio.run(svc.refresh_15m())
    assert rep["series"] == 2 and rep["markets"] == 1 and rep["failed"] == 1 and "KXGOLD15M: TimeoutError" in rep["error"]
    assert not any(i["id"] == "MARKETS-REFRESH" for i in svc.issues())          # partial success is not an alert

    class Dead(Rest):
        async def list_markets(self, **kw):
            raise ConnectionError("no route")
    svc.rest = Dead()
    svc._last_15m_refresh = 0
    rep = asyncio.run(svc.refresh_15m())
    assert rep["markets"] == 0 and rep["failed"] == 2
    i = next(i for i in svc.issues() if i["id"] == "MARKETS-REFRESH")
    assert "ConnectionError" in i["report"]
