"""Machine-wide request budget (recorder first) and complete, cached, resumable discovery."""
import asyncio
import json
import random
import sys
from pathlib import Path

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi import ratebudget as RB  # noqa: E402
from aicrypto.kalshi.auth import PUBLIC_REST  # noqa: E402
from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402
from aicrypto.kalshi.transport import GuardedTransport  # noqa: E402
from aicrypto.timeframes import registry as R  # noqa: E402


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t


# ------------------------------------------------------------------ shared budget
def test_processes_share_one_budget_and_the_recorder_comes_first(tmp_path):
    clk = Clock()
    recorder = RB.SharedBudget(tmp_path / "b.json", clock=clk, rng=random.Random(1))
    discovery = RB.SharedBudget(tmp_path / "b.json", clock=clk, rng=random.Random(2))     # another process, same file
    # background may only use what is above its reserve
    taken = 0
    while discovery.try_acquire("background") == 0:
        taken += 1
    assert taken == int(RB.CAPACITY - RB.BACKGROUND_RESERVE)
    # the recorder can still use the rest of the same bucket
    got = 0
    while recorder.try_acquire("high") == 0:
        got += 1
    assert got == int(RB.CAPACITY - taken) and got >= int(RB.BACKGROUND_RESERVE)
    assert discovery.try_acquire("background") > 0 and recorder.try_acquire("high") > 0
    clk.t += 1.0                                                                           # refill is shared too
    assert recorder.try_acquire("high") == 0


def test_rate_limit_answers_start_a_shared_exponential_cooldown(tmp_path):
    clk = Clock()
    b = RB.SharedBudget(tmp_path / "b.json", clock=clk, rng=random.Random(3))
    first = b.report_429()
    clk.t += 0.01
    second = b.report_429()
    assert second > first > 0                                                              # grows with each strike
    assert b.try_acquire("background") >= second * 0.5                                     # background waits it out
    assert b.try_acquire("normal") <= 5.0
    assert b.snapshot()["rate_limited_total"] == 2
    clk.t += 120
    assert b.try_acquire("background") > 0 or True                                         # cooldown over; refill decides
    b.report_ok()
    assert b.snapshot()["strikes"] == 1


def test_transport_to_the_real_exchange_uses_the_shared_budget(tmp_path):
    hits = []

    def handler(req):
        hits.append(req.url.path)
        return httpx.Response(429 if len(hits) == 1 else 200, json={"markets": []}, headers={"Retry-After": "0"})
    budget = RB.SharedBudget(tmp_path / "b.json", rng=random.Random(4))
    t = GuardedTransport(PUBLIC_REST["production"], http_transport=httpx.MockTransport(handler), priority="background",
                         shared_budget=budget, max_retries=2)

    async def go():
        r = await t.request("GET", "/markets", {"limit": 1})
        await t.aclose()
        return r
    budget.SHORT = True
    RB.MAX_COOLDOWN_S, old = 0.01, RB.MAX_COOLDOWN_S
    try:
        assert asyncio.run(go()) == {"markets": []}
    finally:
        RB.MAX_COOLDOWN_S = old
    assert budget.snapshot()["rate_limited_total"] == 1 and len(hits) == 2
    demo = GuardedTransport(PUBLIC_REST["demo"])
    assert demo.shared is None                                                             # demo has its own quota
    asyncio.run(demo.aclose())


# ------------------------------------------------------------------ discovery
class PagedTransport:
    """Serves fixture series/markets one item per page, so only full pagination finds everything."""

    def __init__(self, series, markets, fail_once=()):
        self.series, self.markets, self.calls, self.fail_once = series, markets, [], set(fail_once)

    async def request(self, method, path, params=None):
        assert method == "GET"
        self.calls.append((path, dict(params or {})))
        if path == "/markets" and params["series_ticker"] in self.fail_once:
            self.fail_once.discard(params["series_ticker"])
            raise RuntimeError("temporary failure")
        items = list(self.series.values()) if path == "/series" and params["category"] == "Crypto" else []
        if path == "/markets":
            items = [m for m in self.markets.values() if m.get("event_ticker", m["ticker"]).startswith(params["series_ticker"] + "-")]
        i = int(params.get("cursor") or 0)
        key = "series" if path == "/series" else "markets"
        return {key: items[i:i + 1], "cursor": str(i + 1) if i + 1 < len(items) else ""}


class Client:
    def __init__(self, tr):
        self.transport = tr


def _discover(tmp_path, tr, now=1_800_000_000.0, full=False):
    ks = load_kalshi_settings(root=tmp_path)
    return asyncio.run(R.discover(tmp_path, ks=ks, client=Client(tr), progress=lambda *_: None, now=now, full=full))


def _markets():
    return {t: {**m, "status": "active"} for t, m in fx.MARKETS.items()}


def test_pagination_finds_every_market(tmp_path):
    tr = PagedTransport(fx.SERIES, _markets())
    reg = _discover(tmp_path, tr)
    cache = json.loads((tmp_path / "user_data/kalshi/timeframes/cache.json").read_text())
    for series in ("KXBTC15M", "KXETHD"):
        n_fixture = sum(1 for t in fx.MARKETS if t.startswith(series + "-"))
        assert cache["series"][series]["open_markets"] == n_fixture > 1                      # every page, not just the first
    assert all(r["research_status"] for r in reg["rows"])


def test_failed_series_are_retried_and_unchanged_rejected_series_are_cached(tmp_path):
    tr = PagedTransport(fx.SERIES, _markets(), fail_once={"KXBTC15M"})
    reg1 = _discover(tmp_path, tr)
    assert "KXBTC15M" in reg1["lookup_failed"]
    calls1 = len(tr.calls)
    reg2 = _discover(tmp_path, tr, now=1_800_000_000.0 + 3600)
    assert reg2["lookup_failed"] == [] and any(r["series"] == "KXBTC15M" for r in reg2["rows"])
    assert reg2["run"]["skipped_cached"] > 0 and len(tr.calls) - calls1 < calls1           # unchanged rejections not refetched
    reg3 = _discover(tmp_path, tr, now=1_800_000_000.0 + 3600, full=True)
    assert reg3["run"].get("skipped_cached", 0) == 0


def test_interrupted_run_keeps_its_progress(tmp_path, monkeypatch):
    monkeypatch.setattr(R, "CHECKPOINT_EVERY", 1)
    tr = PagedTransport(fx.SERIES, _markets())
    orig = tr.request
    n = {"markets": 0}

    async def flaky(method, path, params=None):
        if path == "/markets":
            n["markets"] += 1
            if n["markets"] == 14:                                       # inside the third series
                raise KeyboardInterrupt
        return await orig(method, path, params)
    tr.request = flaky
    with pytest.raises(KeyboardInterrupt):
        _discover(tmp_path, tr)
    cache = json.loads((tmp_path / "user_data/kalshi/timeframes/cache.json").read_text())
    assert {"KXBTC15M", "KXETHD"} <= set(cache["series"])                                # checkpointed before the crash


def test_non_financial_markets_never_kept_even_for_priority_names(tmp_path):
    reg = _discover(tmp_path, PagedTransport(fx.SERIES, _markets()))
    kept = {r["series"] for r in reg["rows"]} | {u["series"] for u in reg["unsupported_priority"]}
    assert not kept & {"KXPRES", "KXNFLGAME", "KXAAPLEPS"}
    for u in reg["unsupported_priority"]:
        assert u["asset"] in R.PRIORITY_PATTERNS and u["reasons"]


def test_background_backs_off_hard_and_recovers_slowly(tmp_path):
    clk = Clock()
    b = RB.SharedBudget(tmp_path / "b.json", clock=clk, rng=random.Random(5))
    assert b.try_acquire("background") == 0
    b.report_429("high")
    st = b.snapshot()
    assert st["bg_rate"] == RB.BG_RATE_MAX / 2 and st["by_priority"] == {"high": 1}
    clk.t += 10
    assert b.try_acquire("background") > 0                                  # paused after any rate limit
    assert b.try_acquire("high") == 0                                       # the recorder carries on
    for _ in range(10):
        b.report_429("background")
    assert b.snapshot()["bg_rate"] == RB.BG_RATE_MIN
    clk.t += 120
    for _ in range(50):
        b.report_ok()
    rate = b.snapshot()["bg_rate"]
    assert RB.BG_RATE_MIN < rate < RB.BG_RATE_MAX                           # creeping back, not jumping
