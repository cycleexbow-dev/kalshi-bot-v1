import sys
from datetime import timedelta
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.durations import DurationBucket, asset_from_series, bucket_for, cadence_from_series, classify
from aicrypto.kalshi.eligibility import Reason, Tier, assert_tradeable, evaluate
from aicrypto.kalshi.models import (ContractStructure, MarketInfo, MarketStatus, SeriesInfo, StrikeType,
                                    c2_to_fp, dollars_to_p4, fp_to_c2, p4_to_dollars)
from aicrypto.kalshi.settings import load_kalshi_settings
from aicrypto.kalshi.settlement_map import Method, Provider, ReferenceStatus, resolve


@pytest.fixture
def ks():
    return load_kalshi_settings()


def S(t):
    return SeriesInfo.from_api(fx.SERIES[t])


def M(t):
    return MarketInfo.from_api(fx.MARKETS[t])


def decide(t, ks):
    return evaluate(S(fx.MARKETS[t]["ticker"].split("-")[0]), M(t), ks)


# ---- units ----------------------------------------------------------------------------
def test_fixed_point_units_exact():
    assert dollars_to_p4("0.5600") == 5600 and dollars_to_p4("1.0000") == 10000 and dollars_to_p4("0.0100") == 100
    assert p4_to_dollars(5600) == "0.5600"
    assert fp_to_c2("300.00") == 30000 and c2_to_fp(30000) == "300.00"
    assert dollars_to_p4(None) is None and fp_to_c2("") is None
    # no float drift
    assert dollars_to_p4("0.1000") + dollars_to_p4("0.2000") == dollars_to_p4("0.3000")


def test_market_parse_and_derived():
    m = M("KXBTC15M-26NOV091400-00")
    assert m.series_ticker == "KXBTC15M" and m.event_ticker == "KXBTC15M-26NOV091400"
    assert m.status is MarketStatus.ACTIVE and m.strike_type is StrikeType.GREATER_OR_EQUAL
    assert m.floor_strike == Decimal("91234.56") and m.spread_p4 == 400 and m.tick_p4 == 100
    assert m.listing_duration == timedelta(minutes=15)
    assert m.yes_bid_size_c2 == 15000


def test_series_parse():
    s = S("KXSOLH")
    assert s.fee_type == "quadratic_with_maker_fees" and s.settlement_sources[0].name == "CF Benchmarks"


# ---- durations ------------------------------------------------------------------------
@pytest.mark.parametrize("minutes,bucket", [(5, DurationBucket.ULTRA_SHORT), (15, DurationBucket.M15), (30, DurationBucket.M30),
                                            (60, DurationBucket.H1), (6 * 60, DurationBucket.MULTI_HOUR), (24 * 60, DurationBucket.DAILY),
                                            (7 * 24 * 60, DurationBucket.WEEKLY), (31 * 24 * 60, DurationBucket.MONTHLY),
                                            (91 * 24 * 60, DurationBucket.QUARTERLY), (400 * 24 * 60, DurationBucket.LONG)])
def test_bucket_from_timestamps(minutes, bucket):
    assert bucket_for(timedelta(minutes=minutes)) is bucket


def test_cadence_and_asset_from_series():
    assert cadence_from_series("KXBTC15M") is DurationBucket.M15 and asset_from_series("KXBTC15M") == "BTC"
    assert cadence_from_series("KXETHD") is DurationBucket.DAILY and asset_from_series("KXETHD") == "ETH"
    assert cadence_from_series("KXGOLDMON") is DurationBucket.MONTHLY and asset_from_series("KXGOLDMON") == "GOLD"
    assert cadence_from_series("KXGOLDDIRY") is DurationBucket.LONG
    assert asset_from_series("KXBTC") == "BTC" and cadence_from_series("KXBTC") is DurationBucket.UNKNOWN
    assert asset_from_series("PRES") is None


def test_classify_structures():
    d15 = classify(M("KXBTC15M-26NOV091400-00"))
    assert d15.bucket is DurationBucket.M15 and d15.structure is ContractStructure.UP_DOWN_WINDOW and not d15.disagreement
    ladder = classify(M("KXETHD-26NOV1017-T2000"))
    assert ladder.structure is ContractStructure.THRESHOLD_ABOVE
    assert ladder.bucket is DurationBucket.DAILY and ladder.disagreement  # listed 3 days early; cadence wins, flagged
    rng = classify(M("KXBTC-26NOV1017-B91500"))
    assert rng.structure is ContractStructure.RANGE


# ---- settlement mapping -----------------------------------------------------------------
def test_crypto_maps_to_cf_and_is_validated(ks):
    r = resolve(S("KXBTC15M"), M("KXBTC15M-26NOV091400-00"), ks)
    assert r.provider is Provider.CF_BENCHMARKS and r.instrument == "BRTI"
    assert r.method is Method.WINDOW_COMPARE_AVG_60S and r.status is ReferenceStatus.VALIDATED
    assert r.feed_name == "cfbenchmarks_value_5hz"
    r2 = resolve(S("KXETHD"), M("KXETHD-26NOV1017-T2000"), ks)
    assert r2.instrument == "ETHUSD_RTI" and r2.method is Method.AVG_60S_BEFORE_TIME
    r3 = resolve(S("KXSOLH"), M("KXSOLH-26NOV0915-T140"), ks)
    assert r3.feed_name == "cfbenchmarks_value_5hz"


def test_pyth_maps_but_feed_unavailable(ks):
    r = resolve(S("KXGOLD15M"), M("KXGOLD15M-26NOV091400-00"), ks)
    assert r.provider is Provider.PYTH and r.instrument == "Metal.XAU/USD"
    assert r.method is Method.WINDOW_COMPARE_CANDLE_1M and r.status is ReferenceStatus.FEED_UNAVAILABLE
    rd = resolve(S("KXGOLDD"), M("KXGOLDD-26NOV0917-T4100"), ks)
    assert rd.method is Method.CANDLE_1M_CLOSE and rd.status is ReferenceStatus.FEED_UNAVAILABLE


def test_ice_maps_feed_unavailable(ks):
    r = resolve(S("KXWTID"), M("KXWTID-26NOV10-T60"), ks)
    assert r.provider is Provider.ICE and r.method is Method.DAILY_SETTLEMENT_PRICE and r.status is ReferenceStatus.FEED_UNAVAILABLE


def test_conflicting_sources_unmapped(ks):
    r = resolve(S("KXLTCH"), M("KXLTCH-26NOV0915-T80"), ks)
    assert r.status is ReferenceStatus.UNMAPPED and "conflict" in " ".join(r.notes)


def test_missing_source_and_vague_rules_unmapped(ks):
    r = resolve(S("KXBTCW"), M("KXBTCW-26NOV14-T90000"), ks)
    assert r.status is ReferenceStatus.UNMAPPED


def test_enabling_pyth_flips_gold_to_validated(ks):
    ks2 = ks.model_copy(deep=True)
    ks2.reference_feeds.pyth.enabled = True
    r = resolve(S("KXGOLD15M"), M("KXGOLD15M-26NOV091400-00"), ks2)
    assert r.status is ReferenceStatus.VALIDATED and r.feed_name == "pyth_value"


# ---- eligibility --------------------------------------------------------------------------
def test_tradeable_crypto_markets(ks):
    for t in ["KXBTC15M-26NOV091400-00", "KXETHD-26NOV1017-T2000", "KXSOLH-26NOV0915-T140", "KXBTC-26NOV1017-B91500"]:
        d = decide(t, ks)
        assert d.tier is Tier.TRADEABLE and d.reasons == [Reason.OK], (t, d.reasons, d.notes)
        assert d.asset_class == "crypto"
        assert_tradeable(d, t)


def test_settled_and_queued_windows_are_discoverable_not_tradeable_by_status(ks):
    d = decide("KXBTC15M-26NOV091345-45", ks)   # finalized
    assert d.tier is Tier.TRADEABLE and "status=finalized" in " ".join(d.notes)  # eligibility != tradability-by-status
    assert M("KXBTC15M-26NOV091345-45").status.is_terminal


def test_record_only_when_reference_feed_unavailable(ks):
    for t in ["KXGOLD15M-26NOV091400-00", "KXGOLDD-26NOV0917-T4100", "KXWTID-26NOV10-T60"]:
        d = decide(t, ks)
        assert d.tier is Tier.RECORD_ONLY and d.reasons == [Reason.REFERENCE_FEED_UNAVAILABLE], t
        assert d.discoverable and not d.accepted
        with pytest.raises(PermissionError):
            assert_tradeable(d, t)
    assert decide("KXGOLD15M-26NOV091400-00", ks).asset_class == "metals"


@pytest.mark.parametrize("ticker,reason", [
    ("KXPRES-28-DEM", Reason.CATEGORY_DENIED),
    ("KXNFLGAME-26NOV09-KC", Reason.CATEGORY_DENIED),
    ("KXAAPLEPS-26Q4-BEAT", Reason.CATEGORY_DENIED),
    ("KXBTC15M-26NOV09FUNC-00", Reason.STRIKE_TYPE_NOT_ALLOWED),
    ("KXETHD-26NOV1017-SCALAR", Reason.MARKET_TYPE_NOT_ALLOWED),
    ("KXBTCW-26NOV14-T90000", Reason.SETTLEMENT_SOURCE_MISSING),
    ("KXBTCW-26NOV14-T90000", Reason.SETTLEMENT_UNMAPPED),
    ("KXBTCFED-26NOV19-UP", Reason.TAG_DENIED),
    ("KXLTCH-26NOV0915-T80", Reason.SETTLEMENT_UNMAPPED),
    ("KXBTC15M-26NOV09PROV-00", Reason.PROVISIONAL),
    ("KXBTC15M-26NOV09NOTS-00", Reason.TIMESTAMPS_MISSING),
])
def test_rejections_with_reasons(ks, ticker, reason):
    d = decide(ticker, ks)
    assert d.tier is Tier.REJECTED and reason in d.reasons, (ticker, d.reasons, d.notes)
    with pytest.raises(PermissionError):
        assert_tradeable(d, ticker)


def test_keywords_alone_never_classify(ks):
    """A politics series whose title says 'Bitcoin' is still politics; a crypto series is
    judged on metadata/rules, not on the word 'election' appearing in its title."""
    s = fx.clone(fx.SERIES["KXPRES"]); s["title"] = "Bitcoin-themed election market"
    d = evaluate(SeriesInfo.from_api(s), M("KXPRES-28-DEM"), ks)
    assert d.tier is Tier.REJECTED
    s2 = fx.clone(fx.SERIES["KXBTC15M"]); s2["title"] = "Election-day Bitcoin 15 min"
    d2 = evaluate(SeriesInfo.from_api(s2), M("KXBTC15M-26NOV091400-00"), ks)
    assert d2.tier is Tier.TRADEABLE


def test_metadata_change_reevaluates(ks):
    """Same market, series metadata later gains a denied tag -> decision flips; rules hash stable."""
    base = decide("KXETHD-26NOV1017-T2000", ks)
    s = fx.clone(fx.SERIES["KXETHD"]); s["tags"] = ["ethereum", "earnings"]
    d = evaluate(SeriesInfo.from_api(s), M("KXETHD-26NOV1017-T2000"), ks)
    assert base.tier is Tier.TRADEABLE and d.tier is Tier.REJECTED and d.rules_hash == base.rules_hash


def test_config_change_changes_fingerprint(ks):
    d1 = decide("KXBTC15M-26NOV091400-00", ks)
    ks2 = ks.model_copy(deep=True); ks2.reference_feeds.pyth.enabled = True
    d2 = decide("KXBTC15M-26NOV091400-00", ks2)
    assert d1.config_hash != d2.config_hash


def test_assert_tradeable_requires_decision():
    with pytest.raises(PermissionError):
        assert_tradeable(None, "X")


def test_kalshi_settings_guardrails(tmp_path):
    import yaml
    from pydantic import ValidationError
    from aicrypto.kalshi.settings import KalshiSettings, load_kalshi_settings as load
    base = yaml.safe_load(open(Path(__file__).resolve().parents[1] / "config" / "kalshi.yaml"))
    for mutate in [lambda c: c.update(paper_only=False), lambda c: c.pop("paper_only"),
                   lambda c: c["risk"].update(leverage=2.0), lambda c: c["risk"].update(max_loss_per_position=0.5)]:
        c = fx.clone(base); mutate(c)
        with pytest.raises(ValidationError):
            KalshiSettings(**c)
    s = load()
    assert s.paper_only is True and s.environment == "demo" and s.reference_feeds.pyth.enabled is False
    assert s.capital.starting_balance == 700.0 and s.subscriptions.max_orderbooks == 24
