"""Phase 1 research agent: sandbox rules, append-only ledger, leakage-free inputs, fixed gates, budgets."""
import json
import math
import pathlib
import sqlite3

import pytest

from aicrypto.research_agent import config as C
from aicrypto.research_agent import harness as H
from aicrypto.research_agent import sandbox as S
from aicrypto.research_agent.__main__ import run_hypothesis
from aicrypto.research_agent.ledger import Ledger

PKG = pathlib.Path(C.__file__).parent


# ------------------------------------------------------------------ sandbox
@pytest.mark.parametrize("src,bad", [
    ("import os\ndef probability(c): return 0.5", "import not allowed: os"),
    ("import socket\ndef probability(c): return 0.5", "import not allowed: socket"),
    ("from subprocess import run\ndef probability(c): return 0.5", "import not allowed"),
    ("def probability(c): return open('x').read()", "name not allowed: open"),
    ("def probability(c): return eval('0.5')", "name not allowed: eval"),
    ("def probability(c): return c.__class__", "dunder attribute"),
    ("def probability(c): return getattr(c, 'x')", "name not allowed: getattr"),
    ("X = 0\ndef probability(c):\n    global X\n    X += 1\n    return 0.5", "global/nonlocal"),
    ("def p(c): return 0.5", "must define probability"),
])
def test_sandbox_static_checks(src, bad):
    assert any(bad in p for p in S.check_source(src)), S.check_source(src)


def test_sandbox_allows_plain_math():
    assert S.check_source("import math\nimport numpy as np\ndef probability(c):\n    return 0.5 + 0 * math.sqrt(4)") == []


def test_sandbox_runs_isolated_and_catches_hidden_state_and_limits(tmp_path):
    ok = tmp_path / "ok.py"
    ok.write_text("def probability(c):\n    return c['mid']")
    assert S.run(ok, [{"mid": 0.3}, {"mid": 0.7}], 10, 512) == [0.3, 0.7]
    stateful = tmp_path / "state.py"
    stateful.write_text("seen = []\ndef probability(c):\n    seen.append(1)\n    return min(0.99, len(seen) / 10)")
    with pytest.raises(S.SandboxError, match="call order"):
        S.run(stateful, [{"mid": 0.3}, {"mid": 0.7}, {"mid": 0.5}], 10, 512)
    out_of_range = tmp_path / "oor.py"
    out_of_range.write_text("def probability(c):\n    return 1.5")
    with pytest.raises(S.SandboxError, match="out of range"):
        S.run(out_of_range, [{"mid": 0.3}], 10, 512)
    slow = tmp_path / "slow.py"
    slow.write_text("def probability(c):\n    x = 0\n    while True:\n        x += 1")
    with pytest.raises(S.SandboxError):
        S.run(slow, [{"mid": 0.3}], 1, 512)


# ------------------------------------------------------------------ ledger
def test_ledger_is_append_only(tmp_path):
    lg = Ledger(tmp_path / "l.sqlite")
    lg.add("started", "h", variants=4)
    lg.add("finished", "h", variants=4, verdict="REJECTED")
    assert lg.variants_tested() == 4 and lg.started_today() == 1
    c = sqlite3.connect(tmp_path / "l.sqlite")
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        c.execute("UPDATE attempts SET verdict='PASSES'")
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        c.execute("DELETE FROM attempts")


# ------------------------------------------------------------------ harness
def _rows(n_days=20, per_day=40, model_edge=0.0):
    ctxs, labels = [], []
    import random
    rng = random.Random(1)
    for d in range(n_days):
        for k in range(per_day):
            true_p = rng.random()
            mid = min(0.97, max(0.03, true_p - model_edge if true_p > 0.5 else true_p + model_edge))
            y = 1 if rng.random() < true_p else 0
            ctxs.append({"mid": mid, "ask_yes": min(0.99, mid + 0.01), "bid_yes": max(0.01, mid - 0.01), "true": true_p})
            labels.append({"window": f"w{d}-{k}", "close_ts": 1_800_000_000 + d * 86400 + k * 900, "lead": 300, "y": y})
    return ctxs, labels


def test_market_as_probability_never_passes():
    cfg = C.load()
    ctxs, labels = _rows()
    res = H.evaluate(ctxs, labels, [c["mid"] for c in ctxs], [0.0, 0.02], cfg.gates, 0)
    assert res["verdict"] == "REJECTED"


def test_gates_count_every_variant_ever_tested():
    cfg = C.load()
    ctxs, labels = _rows()
    probs = [c["true"] for c in ctxs]
    a = H.evaluate(ctxs, labels, probs, [0.0], cfg.gates, 0)
    b = H.evaluate(ctxs, labels, probs, [0.0], cfg.gates, 10_000)
    assert b["z_required"] > a["z_required"] + 1.0 and b["variants_total"] == 10_001


def test_one_trade_per_window_and_conservative_costs():
    ctxs = [{"mid": 0.5, "ask_yes": 0.50, "bid_yes": 0.48}, {"mid": 0.5, "ask_yes": 0.50, "bid_yes": 0.48}]
    labels = [{"window": "w", "close_ts": 1, "lead": 600, "y": 1}, {"window": "w", "close_ts": 1, "lead": 300, "y": 1}]
    tr = H.trades(ctxs, labels, [0.9, 0.9], 0.0, 0.02)
    assert len(tr) == 1
    assert math.isclose(tr[0]["pnl_cons"], 1 - 0.52 - H.fee1(0.52)) and math.isclose(tr[0]["pnl_opt"], 1 - 0.50 - H.fee1(0.50))


def test_wilson_interval():
    lo, hi = H.wilson(83, 100)
    assert 0.74 < lo < 0.76 and 0.89 < hi < 0.90


def test_harness_contexts_have_no_outcomes():
    ctxs, labels = H.build(C.ROOT, ["BTC"], (300,)) if (C.ROOT / "user_data/kalshi/research15/BTC_windows.json.gz").exists() else ([], [])
    for c in ctxs[:50]:
        assert not ({"y", "result", "settle", "close_ts", "window"} & set(c))


# ------------------------------------------------------------------ runner, budgets, protection
def test_runner_records_every_attempt_and_refuses_over_budget(tmp_path, monkeypatch):
    root = tmp_path
    (root / "research" / "sandbox").mkdir(parents=True)
    (root / "research" / "sandbox" / "bad.py").write_text("import os\ndef probability(c): return 0.5")
    spec = root / "bad.json"
    spec.write_text(json.dumps({"id": "bad", "sandbox": "research/sandbox/bad.py", "margins": [0.0]}))
    lg = Ledger(tmp_path / "l.sqlite")
    r = run_hypothesis(spec, lg, root)
    assert r["verdict"] == "REJECTED" and "import not allowed" in r["reasons"][0]
    events = [x["event"] for x in lg.rows()]
    assert events == ["failed", "started"]                                    # the failure is on record
    too_many = root / "many.json"
    too_many.write_text(json.dumps({"id": "many", "sandbox": "research/sandbox/bad.py", "margins": [0.01 * i for i in range(20)]}))
    assert run_hypothesis(too_many, lg, root)["verdict"] == "REFUSED"
    outside = root / "out.json"
    outside.write_text(json.dumps({"id": "out", "sandbox": "../evil.py", "margins": [0.0]}))
    assert run_hypothesis(outside, lg, root)["verdict"] == "REFUSED"
    cfg = C.load()
    for _ in range(cfg.budgets.max_experiments_per_day):
        lg.add("started", "x")
    assert run_hypothesis(spec, lg, root)["verdict"] == "REFUSED"
    assert lg.rows(1)[0]["status"] == "budget"


def test_owner_config_values_are_pinned():
    """Changing a budget or gate must also change this test, so it is visible in review."""
    cfg = C.load()
    assert cfg.assets == ["BTC", "SOL", "ETH", "XRP", "DOGE"]
    assert (cfg.budgets.max_experiments_per_day, cfg.budgets.max_cpu_seconds_per_experiment, cfg.budgets.max_variants_per_hypothesis) == (50, 120, 8)
    g = cfg.gates
    assert (g.alpha_total, g.train_fraction, g.min_test_trades, g.min_test_days, g.conservative_slippage, g.max_drawdown_fraction) == (0.05, 0.6, 300, 7, 0.02, 0.25)
    assert g.require_both_halves_positive and g.require_beats_market_calibration


def test_research_agent_cannot_reach_trading_code():
    text = "".join(p.read_text() for p in PKG.glob("*.py"))
    for bad in ("demo_exec", "DemoExchange", "create_order", "/portfolio", "lab.bot", "LiveLab", "kalshi.client", "websocket"):
        assert bad not in text, bad
    sandbox_dir = C.ROOT / "research" / "sandbox"
    for p in sandbox_dir.glob("*.py"):
        assert S.check_source(p.read_text()) == [], p
