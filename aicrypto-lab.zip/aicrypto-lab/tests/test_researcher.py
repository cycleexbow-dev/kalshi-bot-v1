import time

from aicrypto.agent import ResearchSession, evaluate_candidate
from aicrypto.experiments import Tracker
from aicrypto.settings import Settings, WalkForward, Budget


def small_settings(tmp_path):
    s = Settings(root=tmp_path)
    s.walk_forward = WalkForward(train_bars=1200, test_bars=400, step_bars=400, max_folds=4, optimizer_samples=3, seed=1)
    s.budget = Budget(max_candidates=4, max_minutes=5, workers=1, soft_memory_gb=6)
    return s


def test_evaluate_candidate_idempotent(tmp_path, data3, ema_spec):
    s = small_settings(tmp_path)
    tr = Tracker(tmp_path / "exp")
    r1 = evaluate_candidate(ema_spec, data3, s, tr, check_neighbours=False)
    r2 = evaluate_candidate(ema_spec, data3, s, tr, check_neighbours=False)
    assert r1.run_id == r2.run_id
    assert r2.skipped_reason == "cached"
    assert r1.oos_metrics["total_return"] == r2.oos_metrics["total_return"]
    assert tr.status_of(ema_spec.spec_hash) in ("CANDIDATE", "VALIDATED")
    assert (tr.runs_dir / r1.run_id / "run.json").exists()
    assert (tr.runs_dir / r1.run_id / "oos_equity.csv").exists()


def test_session_respects_candidate_budget_and_is_seeded(tmp_path, data3):
    s = small_settings(tmp_path)
    tr = Tracker(tmp_path / "exp")
    reps = ResearchSession(s, tr, data3, "1h", seed=7, max_candidates=3).run()
    assert len(reps) == 3
    hashes = [r.spec.spec_hash for r in reps]
    tr2 = Tracker(tmp_path / "exp2")
    reps2 = ResearchSession(s, tr2, data3, "1h", seed=7, max_candidates=3).run()
    assert hashes == [r.spec.spec_hash for r in reps2]
    assert tr.sessions()[0]["candidates"] == 3


def test_session_respects_time_budget(tmp_path, data3):
    s = small_settings(tmp_path)
    tr = Tracker(tmp_path / "exp")
    t0 = time.time()
    reps = ResearchSession(s, tr, data3, "1h", seed=1, max_candidates=50, max_minutes=0.0).run()
    assert len(reps) == 0
    assert time.time() - t0 < 5


def test_explicit_specs_go_first(tmp_path, data3, ema_spec):
    s = small_settings(tmp_path)
    tr = Tracker(tmp_path / "exp")
    reps = ResearchSession(s, tr, data3, "1h", seed=1, max_candidates=1, explicit_specs=[ema_spec]).run()
    assert reps[0].spec.spec_hash == ema_spec.spec_hash
