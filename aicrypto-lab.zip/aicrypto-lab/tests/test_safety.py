import json

import pytest

from aicrypto import safety


def good_cfg():
    return {
        "dry_run": True,
        "trading_mode": "spot",
        "exchange": {"name": "binance", "key": "", "secret": ""},
        "api_server": {"enabled": True, "listen_ip_address": "127.0.0.1"},
        "dry_run_wallet": 1000,
    }


def test_good_config_passes():
    assert safety.inspect_config(good_cfg()).ok


@pytest.mark.parametrize(
    "mutate",
    [
        lambda c: c.update(dry_run=False),
        lambda c: c.pop("dry_run"),
        lambda c: c.update(dry_run="true"),
        lambda c: c["exchange"].update(key="abc"),
        lambda c: c["exchange"].update(secret="xyz"),
        lambda c: c.update(trading_mode="futures"),
        lambda c: c.update(margin_mode="isolated"),
        lambda c: c["api_server"].update(listen_ip_address="0.0.0.0"),
    ],
)
def test_bad_configs_blocked(mutate):
    c = good_cfg()
    mutate(c)
    with pytest.raises(safety.LiveTradingBlocked):
        safety.assert_paper_only(c)


def test_scan_configs(tmp_path):
    ud = tmp_path / "user_data"
    ud.mkdir()
    (ud / "config.json").write_text(json.dumps(good_cfg()))
    bad = good_cfg()
    bad["dry_run"] = False
    (ud / "config_live.json").write_text(json.dumps(bad))
    reps = safety.scan_configs(ud)
    assert len(reps) == 2
    assert sum(r.ok for r in reps) == 1


def test_compose_dry_run_flag():
    assert safety.compose_is_dry_run("command: trade --dry-run --config x")
    assert not safety.compose_is_dry_run("command: trade --config x")


def test_no_live_state_in_codebase():
    import pathlib
    root = pathlib.Path(safety.__file__).parent
    for p in root.rglob("*.py"):
        text = p.read_text()
        assert "LIVE" not in [tok.strip('"\'') for tok in text.replace("(", " ").replace(")", " ").split()], p
