import pandas as pd
import pytest

from aicrypto.data import (
    DataIntegrityError,
    fingerprint,
    load_ohlcv,
    save_ohlcv,
    synthetic_ohlcv,
    validate_ohlcv,
)


def test_synthetic_is_deterministic_and_valid():
    a = synthetic_ohlcv(1000, "1h", seed=7)
    b = synthetic_ohlcv(1000, "1h", seed=7)
    pd.testing.assert_frame_equal(a, b)
    validate_ohlcv(a, "1h")
    assert (a["high"] >= a[["open", "close"]].max(axis=1)).all()


def test_feather_roundtrip_and_fingerprint(tmp_path):
    df = synthetic_ohlcv(500, "4h", seed=1)
    save_ohlcv(df, tmp_path, "BTC/USDT", "4h")
    assert (tmp_path / "BTC_USDT-4h.feather").exists()
    back = load_ohlcv(tmp_path, "BTC/USDT", "4h")
    assert len(back) == 500
    assert back["date"].dt.tz is not None
    assert fingerprint(df, "BTC/USDT", "4h").fingerprint == fingerprint(back, "BTC/USDT", "4h").fingerprint
    # different data -> different fingerprint
    assert fingerprint(df.iloc[:-1], "BTC/USDT", "4h").fingerprint != fingerprint(df, "BTC/USDT", "4h").fingerprint


def test_max_rows_bounds_memory(tmp_path):
    save_ohlcv(synthetic_ohlcv(2000, "1h"), tmp_path, "ETH/USDT", "1h")
    df = load_ohlcv(tmp_path, "ETH/USDT", "1h", max_rows=300)
    assert len(df) == 300


def test_freqtrade_can_read_our_feather(tmp_path):
    """Second-opinion engine must read the same files."""
    ft = pytest.importorskip("freqtrade.data.history")
    from freqtrade.enums import CandleType

    save_ohlcv(synthetic_ohlcv(300, "1h"), tmp_path, "SOL/USDT", "1h")
    df = ft.load_pair_history(pair="SOL/USDT", timeframe="1h", datadir=tmp_path, candle_type=CandleType.SPOT)
    assert len(df) == 300


@pytest.mark.parametrize(
    "mutate,msg",
    [
        (lambda d: d.__setitem__("date", d["date"].iloc[::-1].values), "monotonic"),
        (lambda d: d.loc[5, "high"] and d.__setitem__("high", d["low"] * 0.5), "inconsistent"),
        (lambda d: d.__setitem__("close", d["close"].where(d.index != 3, float("nan"))), "NaN"),
    ],
)
def test_validation_catches_problems(mutate, msg):
    df = synthetic_ohlcv(200, "1h")
    mutate(df)
    with pytest.raises(DataIntegrityError, match=msg):
        validate_ohlcv(df, "1h")


def test_validation_catches_gaps():
    df = synthetic_ohlcv(200, "1h")
    df = df.drop(index=list(range(50, 100))).reset_index(drop=True)
    with pytest.raises(DataIntegrityError, match="irregular"):
        validate_ohlcv(df, "1h", max_gap_fraction=0.001)
