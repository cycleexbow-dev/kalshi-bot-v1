import time

import pytest

from aicrypto.data import fingerprint
from aicrypto.experiments import Tracker, RunRecord
from aicrypto.experiments.tracker import make_run_id
from aicrypto.promotion import evaluate_gates
from aicrypto.promotion.gates import neighbour_retention
from aicrypto.research.leakage import LookaheadReport, RecursiveReport, lookahead_probe, recursive_probe
from aicrypto.research.walkforward import walk_forward
from aicrypto.settings import Gates, WalkForward


def test_run_id_reproducible_and_sensitive(data3, ema_spec):
    ds = [fingerprint(df, p, "1h") for p, df in data3.items()]
    cfg = {"fee": 0.001}
    a = make_run_id(ema_spec, ds, cfg, "abc")
    b = make_run_id(ema_spec, ds, cfg, "abc")
    assert a == b
    assert make_run_id(ema_spec, ds, {"fee": 0.002}, "abc") != a
    assert make_run_id(ema_spec, ds, cfg, "def") != a
    ds2 = [fingerprint(df.iloc[:-5], p, "1h") for p, df in data3.items()]
    assert make_run_id(ema_spec, ds2, cfg, "abc") != a


def test_tracker_roundtrip_and_lifecycle(tmp_path, ema_spec):
    t = Tracker(tmp_path / "exp")
    rec = RunRecord("r1", time.time(), ema_spec.spec_hash, ema_spec.family, "1h", "BTC/USDT", "abc", 42,
                    "CANDIDATE", False, 1.0, 0.5, 0.1, 0.1, 50, 4, 0.5, True, True, ema_spec.to_json())
    t.record(rec, {"gates": {"passed": False}})
    assert t.has_run("r1")
    assert t.load_run("r1")["gates"]["passed"] is False
    assert t.list_runs()[0]["run_id"] == "r1"
    t.set_status(ema_spec, "VALIDATED", "r1", "all gates")
    assert t.status_of(ema_spec.spec_hash) == "VALIDATED"
    with pytest.raises(ValueError):
        t.set_status(ema_spec, "LIVE", "r1")  # no such state exists
    assert t.summary()["lifecycle"]["VALIDATED"] == 1


def test_gates_reject_by_default(data3, ema_spec, capital, costs):
    wf = WalkForward(train_bars=1200, test_bars=400, step_bars=400, max_folds=4, optimizer_samples=3)
    res = walk_forward(data3, ema_spec, capital, costs, wf)
    look = lookahead_probe(data3["BTC/USDT"], ema_spec)
    rec = recursive_probe(data3["BTC/USDT"], ema_spec)
    out = evaluate_gates(res, look, rec, Gates(min_oos_sharpe=99.0))
    assert not out.passed
    assert "oos_sharpe" in out.failed_names
    assert any(r.name == "lookahead" and r.passed for r in out.results)


def test_leak_fails_gate(data3, ema_spec, capital, costs):
    wf = WalkForward(train_bars=1200, test_bars=400, step_bars=400, max_folds=4, optimizer_samples=2)
    res = walk_forward(data3, ema_spec, capital, costs, wf, optimise=False)
    leaky = LookaheadReport([1], [3], 3, False, "leak")
    rec = RecursiveReport([1], 0, 0.0, True)
    out = evaluate_gates(res, leaky, rec, Gates(min_trades=0, min_folds=0, min_positive_fold_fraction=0,
                                                 min_oos_sharpe=-99, min_oos_is_ratio=-99, max_drawdown=1))
    assert out.failed_names == ["lookahead"]


def test_neighbour_retention():
    assert neighbour_retention(0.10, [0.08, 0.09, 0.11]) == pytest.approx(0.9)
    assert neighbour_retention(0.10, [-0.1, -0.2, 0.3]) == 0.0
    assert neighbour_retention(-0.1, [0.1]) == 0.0
