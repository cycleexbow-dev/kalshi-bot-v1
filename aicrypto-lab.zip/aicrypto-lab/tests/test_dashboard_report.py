import sqlite3

from fastapi.testclient import TestClient

from aicrypto.agent import evaluate_candidate
from aicrypto.dashboard import create_app
from aicrypto.data import save_ohlcv
from aicrypto.experiments import Tracker
from aicrypto.freqtrade_bridge import write_config
from aicrypto.reporting import build_daily_report, read_paper_trades
from aicrypto.settings import Settings, WalkForward


def _populate(tmp_path, data3, ema_spec):
    s = Settings(root=tmp_path)
    s.walk_forward = WalkForward(train_bars=1200, test_bars=400, step_bars=400, max_folds=3, optimizer_samples=2)
    for p, df in data3.items():
        save_ohlcv(df, tmp_path / "user_data" / "data" / "binance", p, "1h")
    tr = Tracker(tmp_path / "experiments")
    rep = evaluate_candidate(ema_spec, data3, s, tr, check_neighbours=False)
    write_config(s, ema_spec.class_name, "1h")
    (tmp_path / "docker-compose.yml").write_text("command: trade --dry-run")
    return s, tr, rep


def _fake_dryrun_db(path):
    con = sqlite3.connect(path)
    con.execute("""CREATE TABLE trades (id INTEGER PRIMARY KEY, pair TEXT, strategy TEXT, open_date TEXT, close_date TEXT,
        open_rate REAL, close_rate REAL, stake_amount REAL, amount REAL, stop_loss REAL, close_profit REAL,
        close_profit_abs REAL, exit_reason TEXT, leverage REAL, is_short INTEGER, is_open INTEGER)""")
    rows = [
        (1, "BTC/USDT", "ACx", "2026-01-01 00:00", "2026-01-02 00:00", 100, 103, 50, 0.5, 97, 0.03, 1.5, "exit_signal", 1.0, 0, 0),
        (2, "ETH/USDT", "ACx", "2026-01-02 00:00", "2026-01-03 00:00", 100, 97, 50, 0.5, 97, -0.03, -1.6, "stop_loss", 1.0, 0, 0),
        (3, "SOL/USDT", "ACx", "2026-01-04 00:00", None, 100, None, 50, 0.5, 97, None, None, None, 1.0, 0, 1),
    ]
    con.executemany("INSERT INTO trades VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    con.commit(); con.close()


def test_paper_reader(tmp_path):
    s = Settings(root=tmp_path)
    assert not read_paper_trades(s).available
    (tmp_path / "user_data").mkdir()
    _fake_dryrun_db(tmp_path / "user_data" / "tradesv3.dryrun.sqlite")
    p = read_paper_trades(s)
    assert p.available and p.closed_trades == 2 and p.open_trades == 1
    assert abs(p.realized_pnl - (-0.1)) < 1e-9
    assert p.equity_curve[-1]["equity"] == 999.9


def test_report_content(tmp_path, data3, ema_spec):
    s, tr, rep = _populate(tmp_path, data3, ema_spec)
    md = build_daily_report(s, tr, "2026-11-08")
    assert "simulated" in md.lower() and "not rejected" in md
    assert "profitable" not in md.replace("is not evidence that it is profitable", "")
    assert "## Safety attestation" in md and "all paper-only: **yes**" in md
    assert ema_spec.spec_hash in md
    assert "BTC/USDT | 1h |" in md


def test_dashboard_endpoints(tmp_path, data3, ema_spec):
    s, tr, rep = _populate(tmp_path, data3, ema_spec)
    client = TestClient(create_app(s))
    assert "PAPER ONLY" in client.get("/").text
    st = client.get("/api/status").json()
    assert st["paper_only"] is True and st["all_configs_safe"] is True and st["compose_dry_run"] is True
    runs = client.get("/api/runs").json()
    assert runs[0]["run_id"] == rep.run_id
    d = client.get(f"/api/runs/{rep.run_id}").json()
    assert d["spec"]["family"] == "ema_cross" and len(d["oos_equity"]) > 100
    assert client.get("/api/runs/nope").status_code == 404
    assert client.get("/api/paper").json()["available"] is False
    assert len(client.get("/api/data").json()) == 9
    assert "No report yet" in client.get("/api/report").text
    # no write/control endpoints exposed
    assert client.post("/api/runs").status_code == 405
