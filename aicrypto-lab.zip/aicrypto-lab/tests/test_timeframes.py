"""Phase A multi-timeframe registry: durations from official metadata, financial-only, coverage and ratings."""
import asyncio
import pathlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402
from aicrypto.timeframes import registry as R  # noqa: E402


class FakeTransport:
    def __init__(self, series, markets):
        self.series, self.markets, self.calls = series, markets, []

    async def request(self, method, path, params=None):
        assert method == "GET" and path in ("/series", "/markets")      # read-only market data only
        self.calls.append((path, dict(params or {})))
        if path == "/series":
            # every fixture series is offered under every category, to prove the eligibility rules (not the
            # category request) are what keep politics, sports and company markets out
            return {"series": list(self.series.values()) if params["category"] == "Crypto" else []}
        st = params["series_ticker"]
        return {"markets": [m for m in self.markets.values() if m.get("event_ticker", m["ticker"]).startswith(st + "-")]}


class FakeClient:
    def __init__(self, series, markets):
        self.transport = FakeTransport(series, markets)


def _run(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    open_markets = {t: {**m, "status": "active"} for t, m in fx.MARKETS.items()}
    return asyncio.run(R.discover(tmp_path, ks=ks, client=FakeClient(fx.SERIES, open_markets), progress=lambda *_: None))


def test_registry_finds_financial_durations_and_rejects_the_rest(tmp_path):
    reg = _run(tmp_path)
    rows = reg["rows"]
    series = {r["series"] for r in rows}
    assert not series & {"KXPRES", "KXNFLGAME", "KXAAPLEPS"}                     # politics, sports, earnings: never
    assert "KXBTC15M" in series
    view = R.by_asset_timeframe(reg)
    assert "15m" in view["BTC"]
    for r in rows:
        assert r["bucket"] in R.BUCKET_ORDER and r["asset"] and r["reference"]["provider"]
        assert r["data_quality"]["grade"] in "ABCD"
    assert (tmp_path / "user_data/kalshi/timeframes/registry.json").exists()


def test_ratings_follow_the_data_that_is_actually_recorded():
    assert R.rate("crypto", "15m", "validated", {"stream": "kalshi_real"})["grade"] == "A"
    assert R.rate("crypto", "1h", "validated", {"stream": "kalshi_real_long"})["grade"] == "B"
    c = R.rate("metals", "daily", "feed_unavailable", {"stream": "kalshi_real_long"})
    assert c["grade"] == "C" and any("settlement reference" in m for m in c["missing"])
    assert R.rate("crypto", "weekly", "validated", {})["grade"] == "D"


def test_recorder_coverage_map_matches_the_recorder():
    from aicrypto.recorder.longer import SERIES
    cov = R.recorded_streams()
    assert cov["KXBTC15M"]["stream"] == "kalshi_real" and cov["KXBTCD"]["stream"] == "kalshi_real_long"
    assert set(SERIES) <= set(cov)


def test_timeframes_package_is_read_only():
    text = "".join(p.read_text() for p in pathlib.Path(R.__file__).parent.glob("*.py"))
    for bad in ("demo_exec", "DemoExchange", "create_order", "/portfolio", "POST", "signer=signer"):
        assert bad not in text, bad
    assert 'KalshiRestClient("production", signer=None, public=True' in text
