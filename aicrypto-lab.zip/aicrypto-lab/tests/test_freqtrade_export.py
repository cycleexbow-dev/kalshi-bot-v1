import json
import py_compile
from pathlib import Path

import pytest

from aicrypto import safety
from aicrypto.data import save_ohlcv
from aicrypto.freqtrade_bridge import render_strategy, write_strategy, write_config, render_config
from aicrypto.freqtrade_bridge.runner import run_freqtrade
from aicrypto.research import backtest, compute_metrics
from aicrypto.settings import Settings
from aicrypto.strategies import random_spec

ROOT = Path(__file__).resolve().parents[1]


def test_rendered_strategies_compile(tmp_path, rng):
    s = Settings(root=tmp_path)
    for fam in ["ema_cross", "rsi_reversion", "donchian_breakout", "bollinger_reversion"]:
        spec = random_spec(rng, fam)
        p = write_strategy(spec, s)
        py_compile.compile(str(p), doraise=True)
        src = p.read_text()
        assert "can_short = False" in src
        assert "return 1.0  # spot only" in src
        assert f"startup_candle_count = {spec.startup_bars()}" in src


def test_config_is_paper_only(tmp_path):
    s = Settings(root=tmp_path)
    cfg = render_config(s, "X", "1h")
    assert cfg["dry_run"] is True and cfg["exchange"]["key"] == "" and cfg["trading_mode"] == "spot"
    p = write_config(s, "X", "1h")
    reps = safety.scan_configs(tmp_path / "user_data")
    assert len(reps) == 1 and reps[0].ok
    assert json.loads(p.read_text())["api_server"]["listen_ip_address"] == "127.0.0.1"


def test_compose_forces_dry_run_and_localhost():
    text = (ROOT / "docker-compose.yml").read_text()
    assert safety.compose_is_dry_run(text)
    assert "FREQTRADE__DRY_RUN=true" in text
    assert '"127.0.0.1:8081:8081"' in text and '"127.0.0.1:8080:8080"' in text
    assert "mem_limit: 2g" in text


def test_runner_refuses_trade_subcommand(tmp_path):
    with pytest.raises(PermissionError):
        run_freqtrade(tmp_path, "trade", ["--dry-run"])


@pytest.mark.slow
def test_freqtrade_second_opinion_agrees_on_trade_count(tmp_path, data3, ema_spec):
    """Our engine vs Freqtrade's own backtester on identical data: same number of trades,
    and Freqtrade's lookahead-analysis reports no bias for the exported strategy."""
    pytest.importorskip("freqtrade")
    from aicrypto.freqtrade_bridge import freqtrade_backtest, freqtrade_lookahead

    s = Settings(root=tmp_path)
    data_dir = tmp_path / "user_data" / "data" / "binance"
    for p, df in data3.items():
        save_ohlcv(df, data_dir, p, "1h")
    write_strategy(ema_spec, s)
    write_config(s, ema_spec.class_name, "1h")
    ours = compute_metrics(backtest(data3, ema_spec, s.capital, s.costs))
    ft = freqtrade_backtest(tmp_path, "user_data/config_dryrun.json", ema_spec.class_name, fee=s.costs.fee_pct,
                            offline_pairs=s.markets.pairs)
    ratio = ft.trades / ours["trades"]
    assert abs(ratio - 1.0) <= s.gates.freqtrade_trade_count_tolerance, (ft, ours["trades"])
    la = freqtrade_lookahead(tmp_path, "user_data/config_dryrun.json", ema_spec.class_name,
                             timerange="20230201-20230505", offline_pairs=s.markets.pairs)
    assert la.has_bias is False
