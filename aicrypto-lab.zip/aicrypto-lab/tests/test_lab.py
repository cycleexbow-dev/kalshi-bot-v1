"""Live strategy lab + Toggle bot (15-minute crypto and commodity windows)."""
import asyncio
import math
import sys
import time
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
sys.path.append(str(Path(__file__).parent))
import fixtures as fx  # noqa: E402
from test_demo_exec import FakeDemo, FakeRest, signer  # noqa: E402

from aicrypto.kalshi.demo_exec.exchange import DemoExchange  # noqa: E402
from aicrypto.kalshi.demo_exec.trader import OrderRefused  # noqa: E402
from aicrypto.kalshi.lab import engine as E  # noqa: E402
from aicrypto.kalshi.lab.candidates import NEEDS_REFERENCE, WindowView, build, taker_fee  # noqa: E402
from aicrypto.kalshi.lab.features import prob_up_avg_settle, realized_sigma  # noqa: E402
from aicrypto.kalshi.registry import MarketRegistry  # noqa: E402
from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402
from aicrypto.terminal.app import create_terminal_app  # noqa: E402
from aicrypto.terminal.service import TerminalService  # noqa: E402

BTC = "KXBTC15M-26NOV091400-00"
GOLD = "KXGOLD15M-26NOV091400-00"
CLOSE = datetime(2026, 11, 9, 14, 15, tzinfo=timezone.utc).timestamp()


# ---------------------------------------------------------------- features
def test_probability_model():
    # far from close, at the target: coin flip
    assert abs(prob_up_avg_settle(now=0, close_ts=600, target=100, spot=100, sigma=1e-4, window_prints=[]) - 0.5) < 1e-9
    # well above target with little time and low vol: near certain
    assert prob_up_avg_settle(now=0, close_ts=120, target=100, spot=101, sigma=1e-4, window_prints=[]) > 0.99
    # inside the averaging minute, 55 prints fixed well above target: locked in
    p = prob_up_avg_settle(now=0, close_ts=5, target=100, spot=100.0, sigma=5e-4, window_prints=[100.5] * 55)
    assert p > 0.99
    # all 60 prints known: exact
    assert prob_up_avg_settle(now=0, close_ts=0.5, target=100, spot=100, sigma=1e-4, window_prints=[99.9] * 60) == 0.0
    # more of the average fixed -> less uncertainty for the same spot
    a = prob_up_avg_settle(now=0, close_ts=50, target=100, spot=100.02, sigma=3e-4, window_prints=[100.02] * 10)
    b = prob_up_avg_settle(now=0, close_ts=10, target=100, spot=100.02, sigma=3e-4, window_prints=[100.02] * 50)
    assert b > a > 0.5


def test_realized_sigma():
    pts, v = [], 100.0
    for i in range(400):
        v *= math.exp(2e-4 * (1 if i % 2 else -1))
        pts.append((float(i), v))
    s = realized_sigma(pts)
    assert s is not None and abs(s - 2e-4) < 1e-5


def test_candidate_grid_respects_reference_rule():
    cands = build({"crypto": ["BTC"], "commodity": ["GOLD", "COPPER"]})
    for c in cands:
        if c.asset in ("GOLD", "COPPER"):
            assert c.family not in NEEDS_REFERENCE and not c.needs_reference
    assert any(c.family == "lock" and c.asset == "BTC" for c in cands)
    assert len({c.cid for c in cands}) == len(cands)


def _w(**kw):
    base = dict(ticker="T", asset="BTC", asset_class="crypto", now=0.0, close_ts=20.0, open_ts=-880.0, yes_bid=Decimal("0.90"),
                yes_ask=Decimal("0.91"), yes_bid_size=100, yes_ask_size=100)
    base.update(kw)
    return WindowView(**base)


def test_rules_use_executable_prices_and_fees():
    from aicrypto.kalshi.lab.candidates import f_favorite, f_lock
    # lock: model says 0.99, ask 0.91, fee 0.01 -> edge 0.07
    assert f_lock({"last_s": 30, "edge": 0.04}, _w(p_up=0.99)) == "yes"
    assert f_lock({"last_s": 30, "edge": 0.04}, _w(p_up=0.93)) is None            # 0.93-0.91-0.01 < 0.04
    assert f_lock({"last_s": 30, "edge": 0.04}, _w(p_up=0.99, yes_ask_size=0)) is None   # nothing to buy
    assert f_lock({"last_s": 15, "edge": 0.01}, _w(p_up=0.99)) is None            # too early
    assert f_favorite({"window": (60, 10), "band": (0.90, 0.94)}, _w()) == "yes"
    assert f_favorite({"window": (60, 10), "band": (0.95, 0.98)}, _w()) is None
    assert taker_fee(Decimal("0.50")) == Decimal("0.02")                           # 0.0175 rounded up


# ---------------------------------------------------------------- lab against a live-like service
class Clock:
    def __init__(self, t):
        self.t = t

    def __call__(self):
        return self.t


@pytest.fixture
def lab_env(tmp_path, monkeypatch):
    ks = load_kalshi_settings(root=tmp_path)
    reg = MarketRegistry(ks, db_path=tmp_path / "registry.sqlite")
    for s in fx.SERIES.values():
        reg.upsert_series(s)
    for m in fx.MARKETS.values():
        reg.upsert_market(m)
    reg.reevaluate_all()
    fake, rest = FakeDemo(), FakeRest()
    sg = signer()
    svc = TerminalService(ks, live=False, registry=reg, rest_factory=lambda: rest,
                          demo_exchange_factory=lambda: DemoExchange(sg, http_transport=httpx.MockTransport(fake.handler)),
                          demo_ledger_path=tmp_path / "demo.sqlite")
    now = CLOSE - 20
    svc.now_fn = lambda: datetime.fromtimestamp(now, timezone.utc)
    svc.recompute_access()
    clk = Clock(now)
    svc.lab.clock = clk
    svc.lab.bot.clock = clk
    svc.demo.clock = clk
    # live quotes for both windows (top of book from the ticker channel)
    for t, (b, a) in {BTC: (9000, 9100), GOLD: (9100, 9200)}.items():
        reg.update_liquidity(t, yes_bid_p4=b, yes_ask_p4=a, bid_size_c2=50000, ask_size_c2=50000, last_update_mono=time.monotonic())
    # BRTI prints: steady above the 91234.56 target through the averaging minute
    from collections import deque
    pts = deque(maxlen=7200)
    v = 91300.0
    for i in range(900):
        v *= math.exp(1e-5 * (1 if i % 2 else -1))
        pts.append((now - 900 + i, v))
    svc.ref["BRTI"] = pts
    svc.ref_last["BRTI"] = (now - 0.5, v, None)
    svc.lab.setup()
    return svc, fake, rest, clk


def test_focus_is_15m_crypto_and_commodities_only(lab_env):
    svc, *_ = lab_env
    f = svc.lab.focus
    assert "BTC" in f.get("crypto", []) and "GOLD" in f.get("commodity", [])
    for t in svc.lab.focus_markets():
        assert svc.reg.decisions[t].duration.bucket.value == "15m"
    assert not any("KXETHD" in t for t in svc.lab.focus_markets())          # hourly/daily ignored


def test_shadow_trades_once_per_window_and_settle(lab_env):
    svc, fake, rest, clk = lab_env
    n1 = asyncio.run(svc.lab.tick())
    assert n1 > 0
    n2 = asyncio.run(svc.lab.tick())
    assert n2 == 0                                                       # one entry per rule per window
    opened = svc.lab.store.open_trades()
    assert {t["ticker"] for t in opened} <= {BTC, GOLD}
    assert any(t["cid"].startswith("lock:BTC") for t in opened)          # final-seconds lock-in fired
    assert not any(t["ticker"] == GOLD and t["cid"].split(":")[0] in NEEDS_REFERENCE for t in opened)
    assert all(t["phase"] == "disc" for t in opened)
    # settle: Kalshi determines BTC=yes, GOLD=no
    svc.reg.apply_lifecycle({"type": "market_lifecycle_v2", "msg": {"market_ticker": BTC, "event_type": "determined", "result": "yes"}})
    svc.reg.apply_lifecycle({"type": "market_lifecycle_v2", "msg": {"market_ticker": GOLD, "event_type": "determined", "result": "no"}})
    clk.t = CLOSE + 10
    done = asyncio.run(svc.lab.settle())
    assert done == len(opened) and svc.lab.store.open_trades() == []
    sb = {r["cid"]: r for r in svc.lab.store.scoreboard() if r["n"]}
    for r in sb.values():
        tr = [t for t in opened if t["cid"] == r["cid"]][0]
        win = (tr["side"] == "yes") if tr["ticker"] == BTC else (tr["side"] == "no")
        exp = (1 if win else 0) - float(tr["price"]) - float(tr["fee"])
        assert abs(r["net_total"] - exp) < 1e-9


def test_unresolved_window_is_voided_not_counted(lab_env):
    svc, fake, rest, clk = lab_env
    asyncio.run(svc.lab.tick())

    async def no_result(t):
        return {"market": {"result": ""}}
    rest.get_market = no_result
    clk.t = CLOSE + 7 * 3600
    asyncio.run(svc.lab.settle())
    assert all(r["n"] == 0 for r in svc.lab.store.scoreboard())


# ---------------------------------------------------------------- promotion gates
def _feed(store, cid, pnls, phase, t0):
    with store._c() as c:
        for i, p in enumerate(pnls):
            c.execute("INSERT INTO trades (cid, ticker, side, price, fee, t_entry, close_ts, phase, result, pnl, settled_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                      (cid, f"T{phase}{t0}{i}", "yes", "0.5", "0.02", t0 + i, t0 + i, phase, "yes" if p > 0 else "no", str(p), t0 + i))


def test_promotion_requires_fresh_confirmation(lab_env):
    svc, _, _, clk = lab_env
    lab = svc.lab
    cid = next(c.cid for c in lab.cands if c.family == "favorite" and c.asset == "GOLD")
    good = [0.10, -0.05] * 100                                              # +2.5c/trade, strongly positive
    _feed(lab.store, cid, good, "disc", 1000)
    ch = dict((a, b) for a, b, _ in lab.promote())
    assert ch.get(cid) == "shortlisted"
    # the same old trades must not confirm it: nothing new yet -> still shortlisted
    clk.t += 1
    assert cid not in dict((a, b) for a, b, _ in lab.promote())
    since = lab.store._c().execute("SELECT stage_since FROM candidates WHERE cid=?", (cid,)).fetchone()[0]
    _feed(lab.store, cid, [0.10, -0.05] * 130, "conf", since + 1)
    ch = dict((a, b) for a, b, _ in lab.promote())
    assert ch.get(cid) == "proven"


def test_confirmation_failure_rejects(lab_env):
    svc, _, _, clk = lab_env
    lab = svc.lab
    cid = next(c.cid for c in lab.cands if c.family == "imbalance" and c.asset == "BTC")
    _feed(lab.store, cid, [0.10, -0.05] * 100, "disc", 1000)
    lab.promote()
    since = lab.store._c().execute("SELECT stage_since FROM candidates WHERE cid=?", (cid,)).fetchone()[0]
    _feed(lab.store, cid, [0.05, -0.10] * 60, "conf", since + 1)            # it was luck
    ch = dict((a, b) for a, b, _ in lab.promote())
    assert ch.get(cid) == "rejected"


def test_no_edge_retires_and_proven_can_be_demoted(lab_env):
    svc, _, _, _ = lab_env
    lab = svc.lab
    a = next(c.cid for c in lab.cands if c.family == "kmomentum" and c.asset == "GOLD")
    _feed(lab.store, a, [0.05, -0.06] * 300, "disc", 1000)
    assert dict((x, y) for x, y, _ in lab.promote()).get(a) == "retired"
    b = next(c.cid for c in lab.cands if c.family == "favorite" and c.asset == "BTC")
    lab.store.set_stage(b, "proven", "test", 0)
    lab.stage[b] = "proven"
    _feed(lab.store, b, [-0.05, 0.02] * 60, "live", 5000)
    assert dict((x, y) for x, y, _ in lab.promote()).get(b) == "retired_live"


def test_bonferroni_threshold_grows_with_shortlist():
    import statistics
    z1 = statistics.NormalDist().inv_cdf(1 - 0.05 / 1)
    z50 = statistics.NormalDist().inv_cdf(1 - 0.05 / 50)
    assert z50 > z1 + 1.2


# ---------------------------------------------------------------- Toggle bot
def test_bot_off_by_default_and_needs_preconditions(lab_env):
    svc, *_ = lab_env
    assert svc.lab.bot.on is False
    with pytest.raises(OrderRefused):
        svc.lab.bot.turn_on()                            # not connected, no budget

    async def go():
        svc.demo.set_budget("700")
        await svc.demo.refresh_account()
        svc.lab.bot.turn_on()
    asyncio.run(go())
    assert svc.lab.bot.on
    svc2 = TerminalService(svc.ks, live=False, registry=svc.reg, demo_ledger_path=svc.demo_ledger.path)
    assert svc2.lab.bot.on is False                      # every restart: off


def test_bot_trades_only_proven_rules_and_stops_on_kill(lab_env):
    svc, fake, _, clk = lab_env
    lab = svc.lab
    _.book = {"orderbook_fp": {"yes_dollars": [["0.9100", "500.00"]], "no_dollars": [["0.0800", "500.00"]]}}   # gold book
    gold_fav = next(c for c in lab.cands if c.asset == "GOLD" and c.family == "favorite" and c.params["band"] == (0.90, 0.94)
                    and c.params["window"] == (60, 10))

    async def go():
        svc.demo.set_budget("700")
        await svc.demo.refresh_account()
        await lab.tick()                                 # bot off: shadow only
        assert fake.posts == []
        lab.entered.clear()
        with lab.store._c() as c:
            c.execute("DELETE FROM trades")
        lab.store.set_stage(gold_fav.cid, "proven", "test", clk.t)
        lab.stage[gold_fav.cid] = "proven"
        lab.bot.configure(practice=False)
        lab.bot.turn_on()
        await lab.tick()
        assert len(fake.posts) == 1, lab.bot.last_error  # practice off: only the proven rule traded
        body = fake.posts[0]
        acct = svc.demo.account
        want = int((Decimal(acct["balance"]) + Decimal(acct["portfolio_value"])) * Decimal("0.02") / Decimal(body["price"]))
        cap = int(Decimal("7.00") / Decimal(body["price"]))                       # $700 spending limit set above: 1% per market
        assert want > cap > 1 and body["count"] == f"{cap}.00"                    # sized from the account, held inside the limit
        assert body["ticker"] == GOLD and body["side"] == "bid"
        o = svc.demo_ledger.orders()[0]
        assert o["origin"].startswith(f"bot:{gold_fav.cid}@lab")                  # traceable to rule + lab version
        lab.entered.clear()
        await lab.tick()
        assert len(fake.posts) == 1                      # one working order per market
        await svc.demo.kill()
        assert lab.bot.on is False
    asyncio.run(go())


def test_bot_toggle_api_requires_app_header(lab_env):
    svc, *_ = lab_env
    with TestClient(create_terminal_app(svc)) as c:
        assert c.post("/api/bot/toggle").status_code == 403
        r = c.post("/api/bot/toggle", headers={"X-AICL-Client": "terminal"})
        assert r.status_code in (200, 422)
        assert c.get("/api/lab/summary").json()["bot"]["on"] in (True, False)
        assert "rows" in c.get("/api/lab/scoreboard").json()


def test_bot_may_act_in_final_minute_but_not_last_3_seconds(lab_env):
    svc, fake, rest, clk = lab_env
    from aicrypto.kalshi.demo_exec.trader import Intent
    rest.book = {"orderbook_fp": {"yes_dollars": [["0.9100", "500.00"]], "no_dollars": [["0.0800", "500.00"]]}}

    async def go():
        svc.demo.set_budget("700")
        await svc.demo.refresh_account()
        # 20 s left: manual orders refused (60 s rule), bot orders allowed
        p = await svc.demo.prepare(Intent(GOLD, "yes", Decimal("0.92"), 1))
        assert any("60 seconds" in e for e in p["errors"])
        r = await svc.demo.place(Intent(GOLD, "yes", Decimal("0.92"), 1, origin="bot:test"), automated=True, feed_free=True)
        assert r["state"] == "RESTING"
        # 2 s left: refused even for the bot
        svc.now_fn = lambda: datetime.fromtimestamp(CLOSE - 2, timezone.utc)
        with pytest.raises(OrderRefused, match="3 seconds"):
            await svc.demo.place(Intent(GOLD, "no", Decimal("0.09"), 1, origin="bot:test"), automated=True, feed_free=True)
        # feed-free does not open reference-dependent automation on gold
        svc.now_fn = lambda: datetime.fromtimestamp(CLOSE - 20, timezone.utc)
        with pytest.raises(OrderRefused, match="not eligible for automated"):
            await svc.demo.place(Intent(GOLD, "no", Decimal("0.09"), 1, origin="bot:test"), automated=True, feed_free=False)
    asyncio.run(go())


def test_practice_mode_trades_learning_rules_but_not_losing_ones(lab_env):
    svc, fake, _, clk = lab_env
    lab = svc.lab
    _.book = {"orderbook_fp": {"yes_dollars": [["0.9100", "500.00"]], "no_dollars": [["0.0800", "500.00"]]}}

    async def go():
        await svc.demo.refresh_account()
        assert lab.bot.settings.practice is True         # default
        lab.bot.turn_on()
        # every rule has a losing record: nothing may trade
        lab.stats = {c.cid: (20, -0.01) for c in lab.cands}
        await lab.tick()
        assert fake.posts == []
        # no record yet: learning rules trade, one order per market
        lab.entered.clear()
        lab.stats = {}
        await lab.tick()
        assert fake.posts and len({b["ticker"] for b in fake.posts}) == len(fake.posts)
        o = svc.demo_ledger.orders()[0]
        assert o["origin"].startswith("bot:")
    asyncio.run(go())


def test_bot_counts_just_filled_market_as_taken(lab_env):
    """A filled bot order blocks that market even before Kalshi's position list shows it, so a
    second rule cannot buy the opposite side seconds later (seen live on 2026-11-10)."""
    svc, _, _, clk = lab_env
    b = svc.lab.bot
    svc.demo.account = {"balance": "100.00", "portfolio_value": "0.00", "positions": []}
    with svc.demo_ledger._c() as c:
        for cid, tk, age in (("a", "KXETH15M-NEW", 5), ("b", "KXETH15M-OLD", 20 * 60)):
            c.execute("INSERT INTO orders (client_order_id, ticker, side, action, count_c2, filled_c2, remaining_c2, state, origin,"
                      " created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                      (cid, tk, "yes", "buy", 800, 800, 0, "FILLED", "bot:fair:ETH@lab1", clk.t - age, clk.t - age))
    busy = b._busy_tickers()
    assert "KXETH15M-NEW" in busy and "KXETH15M-OLD" not in busy


def test_bot_stake_compounds_with_balance(lab_env):
    svc, *_ = lab_env
    b = svc.lab.bot
    svc.demo.account = {"balance": "100.00", "portfolio_value": "0.00"}
    small = b.size(Decimal("0.50"), 1000)
    svc.demo.account = {"balance": "200.00", "portfolio_value": "0.00"}
    assert small == 4 and b.size(Decimal("0.50"), 1000) == 8      # 2% of the account, doubles with it
    assert b.size(Decimal("0.50"), 3) == 3                        # never more than is offered
    assert b.size(Decimal("0.50"), 1.5) == 0                      # under $1 available: skip
    svc.demo.account = {"balance": "20.00", "portfolio_value": "0.00"}
    assert b.size(Decimal("0.50"), 1000) == 2 and b.size(Decimal("0.08"), 1000) == 13   # 2% would be 40c: raised to $1
    svc.demo.account = {"balance": "0.20", "portfolio_value": "0.00"}
    assert b.size(Decimal("0.50"), 1000) == 0                     # cannot afford $1: no trade


def test_bot_settings_api_bounds(lab_env):
    svc, *_ = lab_env
    with TestClient(create_terminal_app(svc)) as c:
        h = {"X-AICL-Client": "terminal"}
        assert c.post("/api/bot/settings", json={"stake_pct": 5}).status_code == 403
        assert c.post("/api/bot/settings", json={"stake_pct": 50}, headers=h).json()["ok"] is False
        r = c.post("/api/bot/settings", json={"stake_pct": 5, "practice": False}, headers=h).json()
        assert r["stake_pct"] == 5 and r["practice"] is False



def test_owner_rule_favourite_70_90_with_2_to_7_minutes_left():
    from aicrypto.kalshi.lab.candidates import GRID, LAB_FIRST, f_favorite
    assert GRID["favmid"] == {"window": [(420, 120)], "band": [(0.70, 0.90)]} and "favmid" in LAB_FIRST
    p = {"window": (420, 120), "band": (0.70, 0.90)}
    six_min = dict(close_ts=360.0, yes_bid=Decimal("0.79"), yes_ask=Decimal("0.80"))
    assert f_favorite(p, _w(**six_min)) == "yes"                           # 80% with 6 minutes left
    assert f_favorite(p, _w(**{**six_min, "close_ts": 150.0})) == "yes"    # 2.5 minutes left
    assert f_favorite(p, _w(**{**six_min, "close_ts": 20.0})) is None      # too late
    assert f_favorite(p, _w(**{**six_min, "close_ts": 600.0})) is None     # too early
    assert f_favorite(p, _w(**{**six_min, "yes_bid": Decimal("0.94"), "yes_ask": Decimal("0.95")})) is None   # over 90%
