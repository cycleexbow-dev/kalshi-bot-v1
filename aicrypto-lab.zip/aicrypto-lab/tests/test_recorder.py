"""Recorder + production-price shadow engine: read-only, gaps recorded, conservative fills."""
import asyncio
import json
import math
import pathlib
import time
from collections import deque

import pytest

from aicrypto.recorder import store as St
from aicrypto.recorder.cfindex import CFIndex
from aicrypto.recorder.kalshi_real import Book, RealKalshi
from aicrypto.recorder.shadow import ShadowEngine, fee_total, simulate_fill
from aicrypto.recorder.spot import SpotFeed
from aicrypto.research15 import finalminute as FM
from aicrypto.research15.recordings import BookSeries, Recorded, load

PKG = pathlib.Path(St.__file__).parent


class Clock:
    def __init__(self, t):
        self.t = t

    def __call__(self):
        return self.t


def test_recorder_package_cannot_place_orders():
    text = "".join(p.read_text() for p in PKG.glob("*.py"))
    for bad in ("demo_exec", "DemoExchange", "create_order", "/portfolio", '"POST"', "'POST'", "DELETE", "production\", signer=signer"):
        assert bad not in text, bad
    n_clients = text.count("KalshiRestClient(")
    assert n_clients >= 1 and text.count('KalshiRestClient("production", signer=None, public=True') == n_clients   # every one unsigned, public
    assert 'KalshiWebSocket(signer, "demo")' in text                                    # the CF index comes from the demo socket


def test_store_roundtrip_and_truncation(tmp_path):
    s = St.Store(tmp_path, clock=lambda: 1_800_000_000.0)
    s.write("x", "a", v=1)
    s.write("x", "b", v=2)
    s.close()
    rows = list(St.read_source(tmp_path, "x"))
    assert [r["k"] for r in rows] == ["a", "b"] and rows[0]["t"] == 1_800_000_000.0


def test_fill_uses_share_of_depth_limit_and_rounded_fee():
    asks = [(0.40, 10), (0.41, 4), (0.43, 100)]
    f = simulate_fill(asks, 8, limit=0.42)
    assert f["filled"] == 7 and f["levels"] == [(0.40, 5), (0.41, 2)]                 # half of each level, 0.43 is over the limit
    assert f["fee"] == fee_total([(0.40, 5), (0.41, 2)]) == math.ceil(100 * 0.07 * (5 * .4 * .6 + 2 * .41 * .59)) / 100
    assert simulate_fill(asks, 1, limit=0.39)["filled"] == 0                           # price moved away: no fill, never assumed
    assert simulate_fill([(0.5, 1)], 1, limit=0.6)["filled"] == 0                      # 50% of 1 contract rounds down to nothing


def test_book_asks_convert_from_opposite_bids():
    b = Book(0, yes_bids=[(0.60, 5)], no_bids=[(0.38, 7), (0.30, 9)])
    assert b.asks("yes") == [(0.62, 7), (0.70, 9)] and b.asks("no") == [(0.40, 5)]
    assert b.best_ask() == (0.62, 7) and b.best_bid() == (0.60, 5)


class FakeTransport:
    def __init__(self):
        self.calls, self.fail = [], set()
        self.markets, self.books, self.trades = {}, {}, {}

    async def request(self, method, path, params=None):
        assert method == "GET"
        self.calls.append((path, params))
        if path in self.fail:
            raise TimeoutError("slow")
        if path == "/markets":
            if "series_ticker" in params:
                return {"markets": [m for m in self.markets.values() if m["ticker"].startswith(params["series_ticker"])]}
            want = params["tickers"].split(",")
            return {"markets": [self.markets[t] for t in want if t in self.markets]}
        if path == "/markets/orderbooks":
            return {"orderbooks": [{"ticker": t, "orderbook_fp": self.books[t]} for t in params["tickers"] if t in self.books]}
        if path == "/markets/trades":
            return {"trades": self.trades.get(params["ticker"], [])}
        if path.startswith("/series/"):
            return {"series": {"fee_type": "quadratic", "fee_multiplier": 1, "settlement_sources": [{"name": "CF Benchmarks"}]}}
        raise AssertionError(path)


class FakeClient:
    def __init__(self):
        self.transport = FakeTransport()


OPEN = 1_800_000_000 - (1_800_000_000 % 900)
T = "KXBTC15M-TEST"


def _iso(ts):
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, timezone.utc).isoformat().replace("+00:00", "Z")


def _kalshi(tmp_path, clk):
    store = St.Store(tmp_path, clock=clk)
    cl = FakeClient()
    cl.transport.markets[T] = {"ticker": T, "status": "active", "floor_strike": 100.0, "open_time": _iso(OPEN), "close_time": _iso(OPEN + 900),
                               "yes_bid_dollars": "0.30", "yes_ask_dollars": "0.32"}
    cl.transport.books[T] = {"yes_dollars": [["0.30", "50"]], "no_dollars": [["0.68", "40"], ["0.60", "100"]]}
    return store, cl, RealKalshi(store, client=cl, clock=clk, assets=["BTC"])


def test_real_kalshi_records_meta_quotes_books_trades_settlement_and_gaps(tmp_path):
    clk = Clock(OPEN + 100)
    store, cl, k = _kalshi(tmp_path, clk)

    async def go():
        await k.refresh_series()
        assert await k.discover() == 1
        assert await k.poll_quotes() == 1 and await k.poll_quotes() == 0            # unchanged quote not repeated
        assert await k.poll_books() == 1
        cl.transport.trades[T] = [{"trade_id": "a", "created_time": _iso(OPEN + 90), "count_fp": "3", "yes_price_dollars": "0.31"}]
        assert await k.poll_trades(T) == 1 and await k.poll_trades(T) == 0          # deduplicated
        cl.transport.fail.add("/markets/orderbooks")
        assert await k.poll_books() == 0                                             # failure -> recorded error, no invented book
        cl.transport.fail.clear()
        clk.t = OPEN + 910
        cl.transport.markets[T] = {**cl.transport.markets[T], "status": "finalized", "result": "yes", "expiration_value": "100.5"}
        assert await k.poll_settlements() == 1
    asyncio.run(go())
    store.close()
    kinds = [r["k"] for r in St.read_source(tmp_path, "kalshi_real")]
    for k_ in ("series_meta", "market_meta", "quote", "book_full", "trade", "error", "settled"):
        assert k_ in kinds, k_
    assert all(path != "/portfolio" for path, _ in cl.transport.calls)


def test_cf_index_parses_both_channels_and_avg60(tmp_path):
    store = St.Store(tmp_path, clock=lambda: 1_800_000_000.0)
    cf = CFIndex(store, lambda: None, ["BTC", "HYPE"])
    cf.on_value({"type": "cfbenchmarks_value_5hz", "msg": {"index_id": "BRTI", "value_usd": "100.5", "source_ts_ms": 1_799_999_999_800}}, 1_800_000_000.0)
    cf.on_value({"type": "cfbenchmarks_value", "msg": {"index_id": "HYPEUSD_RTI", "data": json.dumps({"time": 1_800_000_000_000, "value": "72.2"}),
                                                      "avg_60s_data": {"value": "72.1", "window_size": 43}}}, 1_800_000_000.2)
    cf.on_value({"type": "cfbenchmarks_value", "msg": {"index_id": "X", "value": "not a number"}}, 1_800_000_000.3)
    store.close()
    recs = list(St.read_source(tmp_path, "cfindex"))
    assert [r["k"] for r in recs] == ["value", "avg60", "value", "invalid"]
    assert recs[0]["lat_ms"] == 200.0 and cf.last["HYPEUSD_RTI"][1] == 72.2 and cf.stats["invalid"] == 1


def test_spot_feed_records_trade_id_gaps(tmp_path):
    store = St.Store(tmp_path, clock=lambda: 1_800_000_000.0)
    f = SpotFeed(store, "coinbase", ["BTC"])
    for tid in (10, 11, 15):
        f.on_message(json.dumps({"type": "ticker", "product_id": "BTC-USD", "price": "1", "trade_id": tid, "time": "2027-01-15T08:00:00Z"}), 1_800_000_000.0)
    store.close()
    gaps = [r for r in St.read_source(tmp_path, "coinbase") if r["k"] == "gap"]
    assert len(gaps) == 1 and gaps[0]["missing"] == 3 and f.stats["gaps"] == 1


class FakeCF:
    def __init__(self, now, value=100.6):
        self.last = {"BRTI": (now, value, now)}
        self._pts = [(now - 899 + i, value * math.exp(1e-5 * (1 if i % 2 else -1))) for i in range(900)]

    def asset_index(self, a):
        return "BRTI" if a == "BTC" else None

    def series(self, idx, since):
        return [(t, v) for t, v in self._pts if t >= since]


def test_shadow_proposes_fills_with_latency_and_settles(tmp_path):
    clk = Clock(OPEN + 890)                                    # 10 s left: final-seconds rules may fire
    store, cl, k = _kalshi(tmp_path, clk)
    asyncio.run(k.discover())
    st = k.markets[T]
    st.book = Book(clk.t, yes_bids=[(0.88, 50)], no_bids=[(0.08, 40)])        # YES ask 0.92; index far above target
    st.books.append(st.book)
    sh = ShadowEngine(tmp_path / "shadow.sqlite", k, FakeCF(clk.t), clock=clk)
    n = sh.tick()
    assert n > 0 and sh.tick() == 0                             # each rule proposes once per window
    clk.t += 1.5
    later = Book(clk.t, yes_bids=[(0.88, 50)], no_bids=[(0.07, 40)])         # ask moved to 0.93 (within the 2c limit)
    st.books.append(later)
    sh.resolve_fills()
    clk.t += 3
    st.books.append(Book(clk.t, yes_bids=[(0.88, 50)], no_bids=[(0.05, 40)])) # ask 0.95: outside the limit for a 0.92 signal
    sh.resolve_fills()
    st.result = "yes"
    assert sh.settle() == n
    import sqlite3
    rows = sqlite3.connect(tmp_path / "shadow.sqlite").execute("SELECT side, signal_ask, fills, net, result FROM proposals").fetchall()
    side, ask, fills, net, result = next(r for r in rows if r[0] == "yes" and abs(r[1] - 0.92) < 1e-9)
    fills, net = json.loads(fills), json.loads(net)
    assert fills["L1"]["one"]["vwap"] == 0.93 and fills["L1"]["delay_s"] >= 1.0
    assert fills["L3"]["one"]["filled"] == 0                    # price ran past the limit: no fill assumed
    assert net["L1_one"] == round(1 - 0.93 - 0.01, 4) and "L3_one" not in net and result == "yes"


def test_final_minute_model_basics():
    p = FM.prob_yes([101.0] * 50, spot=101.0, target=100.0, sigma=1e-4)
    assert p["p"] > 0.99 and abs(p["mean"] - 101.0) < 1e-9
    assert FM.prob_yes([99.0] * 60, 99.0, 100.0, 1e-4)["p"] == 0.0             # all prints known: exact
    assert abs(FM._t_cdf(0.0, 5) - 0.5) < 1e-9 and abs(FM._t_cdf(1.0, 1e9) - FM._t_cdf(1.0, math.inf)) < 1e-3
    assert FM._t_cdf(-3, 4) > FM._t_cdf(-3, math.inf)                          # fatter tails than the normal


def test_final_minute_evaluate_records_gaps_and_scores_fills():
    rec = Recorded()
    C = OPEN + 900
    rec.meta[T] = {"asset": "BTC", "strike": 100.0, "close_ts": C}
    rec.settled[T] = {"result": "yes", "settle_value": "100.4"}
    rec.cf["BRTI"] = [(float(s), 100.4 * math.exp(1e-5 * (1 if s % 2 else -1)), float(s)) for s in range(C - 900, C)]
    bs = BookSeries()
    for s in range(C - 120, C):
        bs.add(float(s), [(0.60, 50)], [(0.38, 40)])                           # YES ask 0.62: far below the model's ~1.0
    rec.books[T] = bs
    r = FM.evaluate(rec, assets=("BTC",))
    assert r["usable"] == len(FM.LEADS_S) and r["filled"] >= 1 and r["net_c_per_contract"] > 0
    assert r["settle_avg_error_bp"]["n"] == 1
    rec.cf["BRTI"] = [x for x in rec.cf["BRTI"] if x[0] < C - 60]               # index feed lost in the final minute
    r2 = FM.evaluate(rec, assets=("BTC",))
    assert r2["missing"]["missing_index_data"] == len(FM.LEADS_S) and r2["filled"] == 0


def test_hourly_daily_recorder_records_meta_changes_and_settlements(tmp_path):
    from aicrypto.recorder.longer import LongerDurations

    class T:
        def __init__(self):
            self.calls, self.open, self.settled, self.fail = [], [], [], False

        async def request(self, method, path, params=None):
            assert method == "GET" and path == "/markets"
            self.calls.append(dict(params))
            if self.fail:
                raise TimeoutError("slow")
            return {"markets": self.open if params.get("status") == "open" else self.settled}

    class Cl:
        def __init__(self):
            self.transport = T()

    cl = Cl()
    store = St.Store(tmp_path, clock=lambda: 1_800_000_000.0)
    lg = LongerDurations(store, client=cl, clock=lambda: 1_800_000_000.0, series={"KXBTCD": "BTC"})
    m = {"ticker": "KXBTCD-X-T100", "event_ticker": "KXBTCD-X", "status": "active", "strike_type": "greater", "floor_strike": 100,
         "close_time": "2027-01-15T08:00:00Z", "yes_bid_dollars": "0.40", "yes_ask_dollars": "0.42"}
    cl.transport.open = [m]

    async def go():
        assert await lg.poll_quotes() == 1 and await lg.poll_quotes() == 0          # unchanged price not repeated
        cl.transport.open = [{**m, "yes_bid_dollars": "0.41"}]
        assert await lg.poll_quotes() == 1
        cl.transport.settled = [{**m, "status": "finalized", "result": "yes", "expiration_value": "101"}]
        assert await lg.poll_settled() == 1 and await lg.poll_settled() == 0         # each settlement once
        cl.transport.fail = True
        await lg.poll_quotes()                                                       # failure recorded, not guessed
    asyncio.run(go())
    store.close()
    kinds = [r["k"] for r in St.read_source(tmp_path, "kalshi_real_long")]
    assert kinds.count("quote") == 2 and kinds.count("market_meta") == 1 and "settled" in kinds and "error" in kinds
    assert all(c.get("limit") == 1000 for c in cl.transport.calls)
