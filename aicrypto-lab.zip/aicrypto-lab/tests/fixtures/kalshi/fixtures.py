"""Synthetic, schema-faithful Kalshi payloads for offline tests.

Shapes follow docs.kalshi.com (GET /series, GET /market, market_lifecycle_v2) as read
on 2026-11-08. Values are invented; tickers mimic observed naming conventions.
"""
from __future__ import annotations

import copy
from datetime import datetime, timedelta, timezone

T0 = datetime(2026, 11, 9, 14, 0, tzinfo=timezone.utc)


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


CF_RULES_15M = (
    "If the simple average of the CF Benchmarks Bitcoin Real Time Index (BRTI) over the 60 seconds (one minute) "
    "before the close of this market is at or above the simple average of the same index over the 60 seconds before "
    "this market opened, then the market resolves to Yes."
)
CF_RULES_HOURLY = (
    "If the simple average of the CF Benchmarks {name} Real Time Index over the one minute (60 seconds) prior to "
    "{time} is above {strike}, then the market resolves to Yes."
)
PYTH_RULES_15M = (
    "Will the price of Gold be at or above the target price at the end of the 15-minute window? "
    "If the close price of the 1-minute candlestick for Gold at the end of the window is at or above the target, "
    "then the market resolves to Yes. Outcome verified from Pyth - Gold."
)
PYTH_RULES_DAILY = (
    "If the close price of the 1-minute candlestick for gold on {date} at 5:00 PM EDT is above {strike} USD/t.oz, "
    "then the market resolves to Yes. Outcome verified from Pyth - Gold."
)
ICE_RULES_DAILY = "If the official daily settlement price of the front-month WTI crude oil futures contract on ICE on {date} is above {strike}, then the market resolves to Yes."


SERIES = {
    "KXBTC15M": {"ticker": "KXBTC15M", "title": "Bitcoin price up or down (15 min)", "category": "Crypto", "categories": ["Crypto"],
                 "tags": ["bitcoin", "crypto"], "frequency": "15 minutes", "fee_type": "quadratic", "fee_multiplier": 1.0,
                 "settlement_sources": [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com/indices/BRTI"}],
                 "contract_url": "https://kalshi-public-docs.s3.amazonaws.com/contract_terms/CRYPTO.pdf", "contract_terms_url": "https://kalshi.com/terms", "additional_prohibitions": []},
    "KXETHD": {"ticker": "KXETHD", "title": "Ethereum price at 5pm EST", "category": "Crypto", "categories": ["Crypto"],
               "tags": ["ethereum"], "frequency": "daily", "fee_type": "quadratic", "fee_multiplier": 1.0,
               "settlement_sources": [{"name": "CF Benchmarks", "url": "https://www.cfbenchmarks.com"}],
               "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXSOLH": {"ticker": "KXSOLH", "title": "Solana price hourly", "category": "Crypto", "categories": ["Crypto"], "tags": ["solana"],
               "frequency": "hourly", "fee_type": "quadratic_with_maker_fees", "fee_multiplier": 1.0,
               "settlement_sources": [{"name": "CF Benchmarks", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXBTC": {"ticker": "KXBTC", "title": "Bitcoin price range", "category": "Crypto", "categories": ["Crypto"], "tags": ["bitcoin"],
              "frequency": "daily", "fee_type": "quadratic", "fee_multiplier": 1.0,
              "settlement_sources": [{"name": "CF Benchmarks", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXGOLD15M": {"ticker": "KXGOLD15M", "title": "Gold 15 min", "category": "Commodities", "categories": ["Commodities", "Metals"],
                  "tags": ["gold", "metals"], "frequency": "15 minutes", "fee_type": "quadratic", "fee_multiplier": 1.0,
                  "settlement_sources": [{"name": "Pyth", "url": "https://pyth.network"}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXGOLDD": {"ticker": "KXGOLDD", "title": "Gold price daily", "category": "Commodities", "categories": ["Commodities"], "tags": ["gold"],
                "frequency": "daily", "fee_type": "quadratic", "fee_multiplier": 1.0,
                "settlement_sources": [{"name": "Pyth", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXWTID": {"ticker": "KXWTID", "title": "WTI crude daily settlement", "category": "Commodities", "categories": ["Commodities", "Energy"],
               "tags": ["oil"], "frequency": "daily", "fee_type": "quadratic", "fee_multiplier": 1.0,
               "settlement_sources": [{"name": "ICE", "url": "https://www.ice.com"}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXPRES": {"ticker": "KXPRES", "title": "Presidential election winner", "category": "Politics", "categories": ["Politics", "Elections"],
               "tags": ["election"], "frequency": "one-off", "fee_type": "quadratic", "fee_multiplier": 1.0,
               "settlement_sources": [{"name": "Associated Press", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXNFLGAME": {"ticker": "KXNFLGAME", "title": "NFL game winner", "category": "Sports", "categories": ["Sports"], "tags": ["nfl"],
                  "frequency": "weekly", "fee_type": "quadratic", "fee_multiplier": 1.0,
                  "settlement_sources": [{"name": "NFL", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    "KXAAPLEPS": {"ticker": "KXAAPLEPS", "title": "Apple EPS beat?", "category": "Companies", "categories": ["Companies", "Earnings"],
                  "tags": ["earnings", "company"], "frequency": "quarterly", "fee_type": "quadratic", "fee_multiplier": 1.0,
                  "settlement_sources": [{"name": "Apple Inc.", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    # Financial category but with a crypto-looking ticker and *no* settlement source
    "KXBTCW": {"ticker": "KXBTCW", "title": "Bitcoin weekly", "category": "Crypto", "categories": ["Crypto"], "tags": ["bitcoin"],
               "frequency": "weekly", "fee_type": "quadratic", "fee_multiplier": 1.0,
               "settlement_sources": [], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    # Crypto with a 'fed' tag -> tag denylist (macro announcement dependence)
    "KXBTCFED": {"ticker": "KXBTCFED", "title": "BTC after FOMC", "category": "Crypto", "categories": ["Crypto"], "tags": ["bitcoin", "fomc"],
                 "frequency": "one-off", "fee_type": "quadratic", "fee_multiplier": 1.0,
                 "settlement_sources": [{"name": "CF Benchmarks", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
    # Crypto category but settlement metadata says Pyth while rules say CF -> conflict
    "KXLTCH": {"ticker": "KXLTCH", "title": "Litecoin hourly", "category": "Crypto", "categories": ["Crypto"], "tags": ["litecoin"],
               "frequency": "hourly", "fee_type": "quadratic", "fee_multiplier": 1.0,
               "settlement_sources": [{"name": "Pyth", "url": ""}], "contract_url": "", "contract_terms_url": "", "additional_prohibitions": []},
}


def market(ticker: str, *, series: str, open_at: datetime, close_at: datetime, strike_type: str = "greater_or_equal",
           floor=None, cap=None, status="active", rules="", yes_bid="0.4800", yes_ask="0.5200", bid_size="150.00",
           ask_size="120.00", volume="1200.00", oi="800.00", market_type="binary", provisional=False, step="0.0100",
           result="", settlement_value=None, expected_exp=None):
    d = {
        "ticker": ticker, "event_ticker": "-".join(ticker.split("-")[:2]), "market_type": market_type,
        "title": f"{series} market", "yes_sub_title": "Yes", "no_sub_title": "No", "status": status,
        "created_time": iso(open_at - timedelta(minutes=5)), "updated_time": iso(open_at), "open_time": iso(open_at),
        "close_time": iso(close_at), "expected_expiration_time": iso(expected_exp or close_at + timedelta(minutes=5)),
        "latest_expiration_time": iso(close_at + timedelta(days=1)), "settlement_timer_seconds": 300, "can_close_early": False,
        "strike_type": strike_type, "floor_strike": floor, "cap_strike": cap, "functional_strike": None, "custom_strike": None,
        "rules_primary": rules, "rules_secondary": "Standard contingencies apply.",
        "yes_bid_dollars": yes_bid, "yes_ask_dollars": yes_ask,
        "no_bid_dollars": f"{1 - float(yes_ask):.4f}", "no_ask_dollars": f"{1 - float(yes_bid):.4f}",
        "yes_bid_size_fp": bid_size, "yes_ask_size_fp": ask_size, "last_price_dollars": "0.5000",
        "volume_fp": volume, "volume_24h_fp": volume, "open_interest_fp": oi, "notional_value_dollars": "1.0000",
        "price_level_structure": "default", "price_ranges": [{"start": "0.0100", "end": "0.9900", "step": step}],
        "result": result, "settlement_value_dollars": settlement_value, "settlement_ts": None, "expiration_value": "",
        "is_provisional": provisional,
    }
    return d


def build_markets():
    m = {}
    # 15-minute BTC windows: current, next (queued), and a settled one
    for i, (st, res) in enumerate([("finalized", "yes"), ("active", ""), ("initialized", "")]):
        o = T0 + timedelta(minutes=15 * (i - 1)); c = o + timedelta(minutes=15)
        tk = f"KXBTC15M-26NOV09{o.strftime('%H%M')}-{o.strftime('%M')}"
        m[tk] = market(tk, series="KXBTC15M", open_at=o, close_at=c, floor=91234.56, status=st, rules=CF_RULES_15M, result=res,
                       settlement_value="1.0000" if res == "yes" else None)
    # ETH daily ladder: 5 strikes for the same 5pm observation, listed 3 days ahead
    close = T0.replace(hour=22, minute=0) + timedelta(days=1)
    for k in [1900, 1950, 2000, 2050, 2100]:
        tk = f"KXETHD-26NOV1017-T{k}"
        m[tk] = market(tk, series="KXETHD", open_at=close - timedelta(days=3), close_at=close, strike_type="greater", floor=k,
                       rules=CF_RULES_HOURLY.format(name="Ether", time="5pm EST", strike=k), yes_bid=f"{0.9 - (k-1900)/400:.4f}",
                       yes_ask=f"{0.93 - (k-1900)/400:.4f}")
    # SOL hourly ladder, two strikes, closes in 40 minutes (overlaps the 15M window)
    hc = T0 + timedelta(minutes=40)
    for k in [140, 145]:
        tk = f"KXSOLH-26NOV0915-T{k}"
        m[tk] = market(tk, series="KXSOLH", open_at=hc - timedelta(hours=1), close_at=hc, strike_type="greater", floor=k,
                       rules=CF_RULES_HOURLY.format(name="Solana", time="3pm EST", strike=k))
    # BTC range (between)
    tk = "KXBTC-26NOV1017-B91500"
    m[tk] = market(tk, series="KXBTC", open_at=T0 - timedelta(days=1), close_at=close, strike_type="between", floor=91000, cap=91999.99,
                   rules=CF_RULES_HOURLY.format(name="Bitcoin", time="5pm EST", strike="the range"))
    # Gold 15M (Pyth) and Gold daily (Pyth) — mapped, feed unavailable
    o = T0; tk = f"KXGOLD15M-26NOV09{o.strftime('%H%M')}-00"
    m[tk] = market(tk, series="KXGOLD15M", open_at=o, close_at=o + timedelta(minutes=15), floor=4123.45, rules=PYTH_RULES_15M)
    tk = "KXGOLDD-26NOV0917-T4100"
    m[tk] = market(tk, series="KXGOLDD", open_at=T0 - timedelta(days=2), close_at=close, strike_type="greater", floor=4100,
                   rules=PYTH_RULES_DAILY.format(date="November 10, 2026", strike=4100))
    # WTI daily on ICE — mapped, feed unavailable
    tk = "KXWTID-26NOV10-T60"
    m[tk] = market(tk, series="KXWTID", open_at=T0 - timedelta(days=1), close_at=close, strike_type="greater", floor=60,
                   rules=ICE_RULES_DAILY.format(date="November 10, 2026", strike=60))
    # Prohibited categories
    m["KXPRES-28-DEM"] = market("KXPRES-28-DEM", series="KXPRES", open_at=T0 - timedelta(days=300), close_at=T0 + timedelta(days=700),
                                strike_type="custom", rules="Resolves Yes if the Democratic nominee wins.")
    m["KXNFLGAME-26NOV09-KC"] = market("KXNFLGAME-26NOV09-KC", series="KXNFLGAME", open_at=T0 - timedelta(days=6), close_at=T0 + timedelta(hours=5),
                                       strike_type="custom", rules="Resolves Yes if Kansas City wins.")
    m["KXAAPLEPS-26Q4-BEAT"] = market("KXAAPLEPS-26Q4-BEAT", series="KXAAPLEPS", open_at=T0 - timedelta(days=30), close_at=T0 + timedelta(days=60),
                                      strike_type="greater", floor=1.5, rules="Resolves Yes if reported EPS exceeds consensus.")
    # Functional strike on a crypto series (unsupported structure)
    tk = "KXBTC15M-26NOV09FUNC-00"
    m[tk] = market(tk, series="KXBTC15M", open_at=T0, close_at=T0 + timedelta(minutes=15), strike_type="functional", rules=CF_RULES_15M)
    m[tk]["functional_strike"] = "value*2"
    # Scalar market type
    tk = "KXETHD-26NOV1017-SCALAR"
    m[tk] = market(tk, series="KXETHD", open_at=T0, close_at=close, market_type="scalar", strike_type="greater", floor=2000,
                   rules=CF_RULES_HOURLY.format(name="Ether", time="5pm EST", strike=2000))
    # Missing settlement source (series KXBTCW), ambiguous rules
    tk = "KXBTCW-26NOV14-T90000"
    m[tk] = market(tk, series="KXBTCW", open_at=T0 - timedelta(days=2), close_at=T0 + timedelta(days=5), strike_type="greater", floor=90000,
                   rules="Resolves Yes if Bitcoin closes the week above 90000 according to a reputable source.")
    # Tag-denied (fomc)
    tk = "KXBTCFED-26NOV19-UP"
    m[tk] = market(tk, series="KXBTCFED", open_at=T0, close_at=T0 + timedelta(days=10), floor=1,
                   rules=CF_RULES_HOURLY.format(name="Bitcoin", time="2pm EST", strike=1))
    # Settlement source conflict (metadata Pyth, rules CF)
    tk = "KXLTCH-26NOV0915-T80"
    m[tk] = market(tk, series="KXLTCH", open_at=T0, close_at=T0 + timedelta(hours=1), strike_type="greater", floor=80,
                   rules=CF_RULES_HOURLY.format(name="Litecoin", time="3pm EST", strike=80))
    # Provisional + missing timestamps variants of a valid market
    tk = "KXBTC15M-26NOV09PROV-00"
    m[tk] = market(tk, series="KXBTC15M", open_at=T0, close_at=T0 + timedelta(minutes=15), floor=1, rules=CF_RULES_15M, provisional=True)
    tk = "KXBTC15M-26NOV09NOTS-00"
    m[tk] = market(tk, series="KXBTC15M", open_at=T0, close_at=T0 + timedelta(minutes=15), floor=1, rules=CF_RULES_15M)
    m[tk]["open_time"] = None
    return m


MARKETS = build_markets()


def lifecycle_created(ticker: str, open_at: datetime, close_at: datetime, floor=12345.0, strike_type="greater_or_equal"):
    return {"type": "market_lifecycle_v2", "sid": 7, "seq": 1, "msg": {
        "market_ticker": ticker, "event_type": "created", "exchange_index": 0,
        "open_ts": int(open_at.timestamp()), "close_ts": int(close_at.timestamp()),
        "additional_metadata": {"name": ticker, "title": "BTC price up in next 15 mins?", "yes_sub_title": "Yes", "no_sub_title": "No",
                                 "rules_primary": CF_RULES_15M, "rules_secondary": "", "can_close_early": False,
                                 "event_ticker": "-".join(ticker.split("-")[:2]),
                                 "expected_expiration_ts": int((close_at + timedelta(minutes=5)).timestamp()),
                                 "strike_type": strike_type, "floor_strike": floor, "cap_strike": None},
        "price_level_structure": "default", "price_ranges": [{"start": "0.0100", "end": "0.9900", "step": "0.0100"}]}}


def lifecycle(ticker: str, event_type: str, **extra):
    return {"type": "market_lifecycle_v2", "sid": 7, "seq": 2, "msg": {"market_ticker": ticker, "event_type": event_type, **extra}}


def clone(d: dict) -> dict:
    return copy.deepcopy(d)
