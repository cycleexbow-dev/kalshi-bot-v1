import base64
import json
import os
import re
import stat
from pathlib import Path

import httpx
import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, padding, rsa

from aicrypto.kalshi import auth
from aicrypto.kalshi.auth import Credentials, CredentialError, KalshiSigner, redact_headers
from aicrypto.kalshi.paths import RequestNotAllowed
from aicrypto.kalshi.ratelimit import TokenBucket
from aicrypto.kalshi.transport import GuardedTransport, RateLimited, TransportError

ROOT = Path(__file__).resolve().parents[1]
DEMO = "https://demo-api.kalshi.co/trade-api/v2"


def _ed_pem():
    k = ed25519.Ed25519PrivateKey.generate()
    return k, k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


def _rsa_pem():
    k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return k, k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


# ---- signing --------------------------------------------------------------------------------
def test_ed25519_signature_matches_spec():
    k, pem = _ed_pem()
    s = KalshiSigner.from_pem_bytes("kid-1", pem)
    h = s.headers("get", "/trade-api/v2/markets?limit=5", timestamp_ms=1710000000123)
    assert h["KALSHI-ACCESS-KEY"] == "kid-1" and h["KALSHI-ACCESS-TIMESTAMP"] == "1710000000123"
    msg = b"1710000000123GET/trade-api/v2/markets"            # query stripped, method upper-cased
    k.public_key().verify(base64.b64decode(h["KALSHI-ACCESS-SIGNATURE"]), msg)
    assert s.verify("1710000000123GET/trade-api/v2/markets", h["KALSHI-ACCESS-SIGNATURE"])
    assert not s.verify("tampered", h["KALSHI-ACCESS-SIGNATURE"])


def test_rsa_pss_signature_matches_spec():
    k, pem = _rsa_pem()
    s = KalshiSigner.from_pem_bytes("kid-2", pem)
    assert s.key_type == "rsa"
    h = s.headers("GET", "/trade-api/ws/v2", timestamp_ms=5)
    k.public_key().verify(base64.b64decode(h["KALSHI-ACCESS-SIGNATURE"]), b"5GET/trade-api/ws/v2",
                          padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32), hashes.SHA256())


def test_signer_never_reveals_material():
    _, pem = _ed_pem()
    s = KalshiSigner.from_pem_bytes("secret-key-id", pem)
    txt = repr(s) + str(s)
    assert "secret-key-id" not in txt and "PRIVATE" not in txt
    assert redact_headers({"KALSHI-ACCESS-SIGNATURE": "abc", "Accept": "x"}) == {"KALSHI-ACCESS-SIGNATURE": "***", "Accept": "x"}


def test_credentials_from_env_guardrails(tmp_path):
    _, pem = _ed_pem()
    key = tmp_path / "k.pem"; key.write_bytes(pem); key.chmod(0o600)
    env = {"KALSHI_API_KEY_ID": "abc", "KALSHI_PRIVATE_KEY_PATH": str(key)}
    c = Credentials.from_env("demo", repo_root=ROOT, environ=env)
    assert c.env == "demo" and "abc" not in repr(c)
    with pytest.raises(CredentialError, match="disagrees"):
        Credentials.from_env("demo", environ={**env, "KALSHI_ENV": "production"})
    key.chmod(0o644)
    with pytest.raises(CredentialError, match="0600"):
        Credentials.from_env("demo", environ=env)
    key.chmod(0o600)
    inside = ROOT / "tests" / "_tmp_key.pem"; inside.write_bytes(pem); inside.chmod(0o600)
    try:
        with pytest.raises(CredentialError, match="outside the repository"):
            Credentials.from_env("demo", repo_root=ROOT, environ={**env, "KALSHI_PRIVATE_KEY_PATH": str(inside)})
    finally:
        inside.unlink()
    with pytest.raises(CredentialError):
        Credentials.from_env("demo", environ={})


# ---- transport ------------------------------------------------------------------------------
def _mock(handler):
    return httpx.MockTransport(handler)


@pytest.mark.asyncio
async def test_transport_allowlist_before_network():
    hits = []
    async def handler(req):
        hits.append(str(req.url)); return httpx.Response(200, json={"ok": True})
    t = GuardedTransport(DEMO, http_transport=_mock(handler))
    assert await t.request("GET", "/markets", {"limit": 10, "cursor": None}) == {"ok": True}
    assert hits == [DEMO + "/markets?limit=10"]
    for m, p in [("POST", "/portfolio/orders"), ("GET", "/portfolio/balance"), ("DELETE", "/markets"), ("GET", "/markets/../portfolio/orders")]:
        with pytest.raises(RequestNotAllowed):
            await t.request(m, p)
    assert hits == [DEMO + "/markets?limit=10"]       # nothing refused ever reached the network
    assert t.stats.refused == 4 and t.allowlist.stats.refused >= 3


def test_transport_refuses_unknown_hosts():
    for bad in ["https://evil.example.com/trade-api/v2", "http://demo-api.kalshi.co/trade-api/v2", "https://api.elections.kalshi.com"]:
        with pytest.raises(TransportError):
            GuardedTransport(bad)


@pytest.mark.asyncio
async def test_transport_signs_with_normalised_path():
    _, pem = _ed_pem()
    signer = KalshiSigner.from_pem_bytes("kid", pem)
    seen = {}
    async def handler(req):
        seen.update(dict(req.headers)); return httpx.Response(200, json={})
    t = GuardedTransport(DEMO, signer=signer, http_transport=_mock(handler))
    await t.request("GET", "/trade-api/v2/markets/KXBTC15M-1/orderbook", {"depth": 5})
    ts = seen["kalshi-access-timestamp"]
    assert signer.verify(f"{ts}GET/trade-api/v2/markets/KXBTC15M-1/orderbook", seen["kalshi-access-signature"])


@pytest.mark.asyncio
async def test_transport_retries_429_and_5xx_then_fails_closed():
    calls = {"n": 0}
    async def handler(req):
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(429, headers={"Retry-After": "0"})
        if calls["n"] == 2:
            return httpx.Response(503)
        return httpx.Response(200, json={"markets": []})
    t = GuardedTransport(DEMO, http_transport=_mock(handler), max_retries=3)
    t._backoff = lambda a: 0.0
    assert await t.request("GET", "/markets") == {"markets": []}
    assert t.stats.rate_limited == 1 and t.stats.server_errors == 1 and calls["n"] == 3

    async def always429(req):
        return httpx.Response(429)
    t2 = GuardedTransport(DEMO, http_transport=_mock(always429), max_retries=2)
    t2._backoff = lambda a: 0.0
    with pytest.raises(RateLimited):
        await t2.request("GET", "/markets")

    async def bad(req):
        return httpx.Response(404, text="nope")
    t3 = GuardedTransport(DEMO, http_transport=_mock(bad))
    with pytest.raises(TransportError, match="404"):
        await t3.request("GET", "/markets/NOPE")

    async def boom(req):
        raise httpx.ConnectError("down")
    t4 = GuardedTransport(DEMO, http_transport=_mock(boom), max_retries=1)
    t4._backoff = lambda a: 0.0
    with pytest.raises(TransportError, match="network error"):
        await t4.request("GET", "/markets")


def test_token_bucket_paces():
    b = TokenBucket(tokens_per_second=20, burst_seconds=1, cost_per_request=10)   # 2 req/s, burst 2
    assert b.try_acquire() == 0.0 and b.try_acquire() == 0.0
    wait = b.try_acquire()
    assert 0 < wait <= 0.5


def test_transport_is_the_only_http_import():
    """Only three modules may import an HTTP library: kalshi/transport.py (read-only market data),
    kalshi/demo_exec/exchange.py (demo-host-only orders, owner decision 2026-11-09) and
    kalshi/real_exec/exchange.py (real-account orders on the same allowlist, owner decision 2026-11-19).
    Only websocket.py may import a WebSocket library. This keeps every allowlist impossible to bypass."""
    pkg = ROOT / "aicrypto" / "kalshi"
    http_ok = {pkg / "transport.py", pkg / "demo_exec" / "exchange.py", pkg / "real_exec" / "exchange.py"}
    http_libs = re.compile(r"^\s*(import|from)\s+(httpx|requests|aiohttp|urllib3|urllib\.request|http\.client)\b", re.M)
    ws_libs = re.compile(r"^\s*(import|from)\s+(websockets|websocket|aiohttp)\b", re.M)
    for p in pkg.rglob("*.py"):
        src = p.read_text()
        if p not in http_ok:
            assert not http_libs.search(src), f"{p} imports an HTTP library"
        if p.name != "websocket.py":
            assert not ws_libs.search(src), f"{p} imports a WebSocket library"
    # and transport has exactly one public request method
    src = (pkg / "transport.py").read_text()
    assert src.count("async def request(") == 1 and "def post" not in src and "def delete" not in src
