"""A lifecycle message about an unknown market must not make the feed reader wait for a REST lookup
(that stalled the socket and Kalshi dropped it with "keepalive ping timeout")."""
import asyncio
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.stream import StreamSession  # noqa: E402
from aicrypto.kalshi.websocket import InboundMessage  # noqa: E402


class SlowRest:
    def __init__(self):
        self.calls = []
        self.mismatches = []

    async def get_market(self, ticker):
        self.calls.append(ticker)
        await asyncio.sleep(0.5)                       # a slow REST answer
        return fx.MARKETS["KXBTC15M-26NOV091400-00"]


class Reg:
    def __init__(self):
        self.upserts = []

    def apply_lifecycle(self, d):
        return None                                    # unknown market: needs a lookup

    def upsert_market(self, m):
        self.upserts.append(m["ticker"])


def _msg(ticker):
    d = {"type": "market_lifecycle_v2", "sid": 1, "seq": 1, "msg": {"market_ticker": ticker, "event_type": "created"}}
    return InboundMessage(raw="", t_recv_ns=0, t_decoded_ns=0, data=d, type=d["type"], sid=1, seq=1)


def test_unknown_market_lookup_runs_in_background():
    rest, reg = SlowRest(), Reg()
    ws = SimpleNamespace(handlers=[])
    sess = StreamSession(SimpleNamespace(), reg, ws, rest=rest)

    async def go():
        t0 = time.monotonic()
        await sess._on_message(_msg("KXNEW-1"))
        await sess._on_message(_msg("KXNEW-1"))          # same market again while the lookup runs
        handled = time.monotonic() - t0
        await asyncio.sleep(0.8)
        return handled
    handled = asyncio.run(go())
    assert handled < 0.1                                 # the reader was not held up
    assert rest.calls == ["KXNEW-1"]                     # one lookup per market, not one per message
    assert reg.upserts and sess.stats.reconciled == 1
