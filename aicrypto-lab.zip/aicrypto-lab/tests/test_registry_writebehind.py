"""Registry writes on a background thread: in order, durable after flush, never lost on stop."""
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "fixtures" / "kalshi"))
import fixtures as fx  # noqa: E402

from aicrypto.kalshi.registry import MarketRegistry  # noqa: E402
from aicrypto.kalshi.settings import load_kalshi_settings  # noqa: E402


def _reg(tmp_path):
    ks = load_kalshi_settings(root=tmp_path)
    r = MarketRegistry(ks, db_path=tmp_path / "reg.sqlite")
    for s in fx.SERIES.values():
        r.upsert_series(s)
    return r


def test_write_behind_persists_in_order_and_reloads(tmp_path):
    r = _reg(tmp_path)
    r.start_write_behind()
    t = "KXBTC15M-26NOV091400-00"
    for m in fx.MARKETS.values():
        r.upsert_market(m)
    r.apply_lifecycle({"msg": {"market_ticker": t, "event_type": "determined", "result": "yes"}})
    assert r.markets[t].raw.get("result") == "yes"                   # memory is updated immediately
    hist = r.eligibility_history(t) if hasattr(r, "eligibility_history") else None
    r.stop_write_behind()                                             # flushes everything queued
    c = sqlite3.connect(tmp_path / "reg.sqlite")
    assert c.execute("SELECT COUNT(*) FROM markets").fetchone()[0] == len(fx.MARKETS)
    assert c.execute("SELECT result FROM markets WHERE ticker=?", (t,)).fetchone()[0] == "yes"   # later write won
    assert c.execute("SELECT COUNT(*) FROM lifecycle_log").fetchone()[0] == 1
    assert c.execute("SELECT COUNT(*) FROM eligibility WHERE ticker=? AND is_current=1", (t,)).fetchone()[0] == 1
    r2 = MarketRegistry(load_kalshi_settings(root=tmp_path), db_path=tmp_path / "reg.sqlite")
    assert len(r2.markets) == len(fx.MARKETS)
    if hist is not None:
        assert hist                                                  # history read saw the queued writes


def test_without_write_behind_writes_are_immediate(tmp_path):
    r = _reg(tmp_path)
    m = next(iter(fx.MARKETS.values()))
    r.upsert_market(m)
    c = sqlite3.connect(tmp_path / "reg.sqlite")
    assert c.execute("SELECT COUNT(*) FROM markets").fetchone()[0] == 1
