#!/usr/bin/env bash
# Stop the terminal backend started by start_ui.sh (graceful SIGTERM, then SIGKILL after 10 s).
set -uo pipefail
cd "$(dirname "$0")/.."
PIDF=run/ui.pid
if [[ ! -f "$PIDF" ]]; then echo "not running"; exit 0; fi
PID="$(cat "$PIDF")"
if ! [[ "$PID" =~ ^[0-9]+$ ]] || ! kill -0 "$PID" 2>/dev/null; then rm -f "$PIDF"; echo "not running (stale pid file removed)"; exit 0; fi
# only signal our own backend process
if ! tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null | grep -q "aicrypto ui"; then
  echo "pid $PID is not the AI Crypto Lab backend; leaving it alone"; rm -f "$PIDF"; exit 1
fi
kill -TERM "$PID"
for _ in $(seq 1 20); do kill -0 "$PID" 2>/dev/null || { echo "stopped"; exit 0; }; sleep 0.5; done
kill -KILL "$PID" 2>/dev/null; rm -f "$PIDF"; echo "killed"
