#!/usr/bin/env python3
"""Micro-benchmark: order-book delta application and WS frame processing (decode + schema
check + book update) on a synthetic burst. Single core, no network. Reports throughput and
per-event latency percentiles. Run on the target machine for real numbers."""
import asyncio, json, random, statistics, time
from aicrypto.kalshi.orderbook import OrderBook
from aicrypto.kalshi.websocket import KalshiWebSocket
from aicrypto.kalshi.auth import KalshiSigner
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

N = 200_000
rng = random.Random(1)

def deltas(n):
    out = []
    clock = 10
    for i in range(n):
        clock += rng.choice([0, 1, 1, 1, 2])
        p = f"0.{rng.randint(1, 98):02d}00"
        d = f"{rng.choice([-1, 1]) * rng.randint(1, 500)}.00"
        out.append({"type": "orderbook_delta", "sid": 1, "seq": i + 2, "msg": {"market_ticker": "BENCH", "market_id": "u", "clock": clock,
                    "price_dollars": p, "delta_fp": d, "side": rng.choice(["yes", "no"]), "ts_ms": 1700000000000 + i}})
    return out

def bench_book():
    b = OrderBook("BENCH")
    b.apply_snapshot({"clock": 10, "yes_dollars_fp": [[f"0.{p:02d}00", "1000.00"] for p in range(1, 50)],
                      "no_dollars_fp": [[f"0.{p:02d}00", "1000.00"] for p in range(1, 50)]})
    ds = deltas(N)
    lat = []
    t0 = time.perf_counter()
    for d in ds:
        s = time.perf_counter_ns(); b.apply_delta(d["msg"]); lat.append(time.perf_counter_ns() - s)
    dt = time.perf_counter() - t0
    lat.sort()
    return {"deltas_per_s": int(N / dt), "p50_us": lat[len(lat)//2] / 1e3, "p99_us": lat[int(len(lat)*0.99)] / 1e3, "max_us": lat[-1] / 1e3}

async def bench_frames():
    k = ed25519.Ed25519PrivateKey.generate()
    pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    ws = KalshiWebSocket(KalshiSigner.from_pem_bytes("k", pem), url="ws://127.0.0.1:1/x", queue_max=10)
    ws.books.book("BENCH").apply_snapshot({"clock": 10, "yes_dollars_fp": [["0.4800", "100.00"]], "no_dollars_fp": [["0.5000", "100.00"]]})
    frames = [json.dumps(d) for d in deltas(N // 4)]
    lat = []
    t0 = time.perf_counter()
    for f in frames:
        s = time.perf_counter_ns(); await ws._on_frame(f); lat.append(time.perf_counter_ns() - s)
    dt = time.perf_counter() - t0
    lat.sort()
    return {"frames_per_s": int(len(frames) / dt), "p50_us": lat[len(lat)//2] / 1e3, "p99_us": lat[int(len(lat)*0.99)] / 1e3,
            "max_us": lat[-1] / 1e3, "dropped_fanout": ws.stats.dropped_fanout, "book_valid": ws.books.books["BENCH"].valid}

if __name__ == "__main__":
    print(json.dumps({"book_apply_delta": bench_book(), "ws_frame_decode_validate_apply": asyncio.run(bench_frames())}, indent=2))
