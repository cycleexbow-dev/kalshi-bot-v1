#!/usr/bin/env bash
# Daily job: bounded research session, promotion check, report.
# FAIL-CLOSED: any failing step aborts the run; nothing downstream executes.
# Schedule with cron in WSL:
#   15 6 * * * /home/<you>/aicrypto-lab/scripts/daily.sh >> /home/<you>/aicrypto-lab/reports/cron.log 2>&1
set -euo pipefail
cd "$(dirname "$0")/.."
if [ -f .venv/bin/activate ]; then source .venv/bin/activate; fi
PY="${PYTHON:-python3}"

step() { echo "[daily] $(date -u +%FT%TZ) $*"; }

step "safety-check";  "$PY" -m aicrypto.cli safety-check
step "data-check";    "$PY" -m aicrypto.cli data-check
step "research";      "$PY" -m aicrypto.cli research --timeframe 1h \
                        --max-candidates "${MAX_CANDIDATES:-20}" --max-minutes "${MAX_MINUTES:-20}"
# promote exit codes: 0 PROMOTED, 3 expected rejection / nothing to promote (continue),
# 2 safety blocked, 4 verification error (fail closed: abort).
step "promote";       rc=0; "$PY" -m aicrypto.cli promote --dry-run-config || rc=$?
if [ "$rc" -ne 0 ] && [ "$rc" -ne 3 ]; then echo "[daily] promote failed with rc=$rc (fail closed)"; exit "$rc"; fi
step "safety-check";  "$PY" -m aicrypto.cli safety-check   # re-check after promote wrote a config
step "report";        "$PY" -m aicrypto.cli report
step "done"
