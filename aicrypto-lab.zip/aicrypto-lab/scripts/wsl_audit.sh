#!/usr/bin/env bash
# Audit the WSL target environment. Read-only; prints PASS/WARN/FAIL per item.
set -u
pass() { printf "PASS  %s\n" "$1"; }
warn() { printf "WARN  %s\n" "$1"; }
fail() { printf "FAIL  %s\n" "$1"; }

echo "== aicrypto-lab WSL audit =="
if grep -qi microsoft /proc/version 2>/dev/null; then pass "running inside WSL ($(uname -r))"; else warn "not WSL: $(uname -r)"; fi
. /etc/os-release 2>/dev/null && echo "      distro: ${PRETTY_NAME:-unknown}"

if command -v python3 >/dev/null; then
  v=$(python3 -c 'import sys;print(".".join(map(str,sys.version_info[:3])))')
  case "$v" in 3.11*|3.12*|3.13*) pass "python3 $v";; *) warn "python3 $v (want 3.11-3.13)";; esac
else fail "python3 missing (sudo apt install python3 python3-venv python3-pip)"; fi
python3 -c 'import venv' 2>/dev/null && pass "python3-venv" || fail "python3-venv missing"

if command -v docker >/dev/null; then
  if docker info >/dev/null 2>&1; then pass "docker daemon reachable ($(docker --version))"; else fail "docker installed but daemon unreachable — enable Docker Desktop WSL integration or start dockerd"; fi
  docker compose version >/dev/null 2>&1 && pass "docker compose" || fail "docker compose plugin missing"
else fail "docker missing"; fi

mem_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}'); mem_gb=$((mem_kb/1024/1024))
if [ "$mem_gb" -ge 6 ]; then pass "WSL memory ${mem_gb} GB"; else warn "WSL memory ${mem_gb} GB — raise in %UserProfile%\\.wslconfig (see docs/WSL_SETUP.md)"; fi
swap_kb=$(grep SwapTotal /proc/meminfo | awk '{print $2}'); [ "$swap_kb" -gt 0 ] && pass "swap $((swap_kb/1024/1024)) GB" || warn "no swap configured"
echo "      cpus: $(nproc)"

free_gb=$(df -BG . | awk 'NR==2{gsub("G","",$4);print $4}')
[ "$free_gb" -ge 5 ] && pass "free disk ${free_gb} GB" || warn "free disk ${free_gb} GB (<5 GB)"

if curl -fsS -m 10 https://api.binance.com/api/v3/ping >/dev/null 2>&1; then pass "binance public API reachable"; else warn "binance public API unreachable (try kraken: set markets.exchange in config/research.yaml)"; fi
if command -v git >/dev/null; then pass "git"; else warn "git missing"; fi
echo "== done =="
