#!/usr/bin/env bash
# One-time Kalshi DEMO key setup for aicrypto-lab. Run inside Ubuntu (WSL):
#   bash /mnt/c/Users/*/Downloads/kalshi_demo_setup.sh
# Finds the downloaded key in Windows Downloads, moves it to ~/.kalshi (mode 600),
# asks for the Key ID, sets env vars in ~/.bashrc, installs the project, runs checks.
# Never prints the key, the Key ID or signatures.
set -euo pipefail
say() { printf "\n==> %s\n" "$*"; }

grep -qi microsoft /proc/version 2>/dev/null || { echo "Run this inside Ubuntu (WSL), not PowerShell or CMD."; exit 1; }

# ---- 1. Windows Downloads folder --------------------------------------------------------
WINUSER=$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r' || true)
DL="/mnt/c/Users/${WINUSER}/Downloads"
if [ -z "$WINUSER" ] || [ ! -d "$DL" ]; then
  DL=$(ls -d /mnt/c/Users/*/Downloads 2>/dev/null | grep -v -E "/(Public|Default|All Users)/" | head -1 || true)
fi
[ -n "$DL" ] && [ -d "$DL" ] || { echo "Couldn't find your Windows Downloads folder."; exit 1; }
say "Windows Downloads: $DL"

# ---- 2. Find the private key (newest small file there that starts with a PEM header) ------
KEY_SRC=""
while IFS= read -r f; do
  if head -c 80 "$f" 2>/dev/null | grep -q "BEGIN.*PRIVATE KEY"; then KEY_SRC="$f"; break; fi
done < <(find "$DL" -maxdepth 1 -type f -size -10k -mtime -30 -printf '%T@ %p\n' 2>/dev/null | sort -rn | cut -d' ' -f2-)

mkdir -p "$HOME/.kalshi" && chmod 700 "$HOME/.kalshi"
if [ -n "$KEY_SRC" ]; then
  say "Found key file: $(basename "$KEY_SRC")"
  cp "$KEY_SRC" "$HOME/.kalshi/demo-key.pem"
elif [ -f "$HOME/.kalshi/demo-key.pem" ]; then
  say "No new key in Downloads; using existing ~/.kalshi/demo-key.pem"
else
  echo "Couldn't find the key file in $DL (looked for a file starting with '-----BEGIN ... PRIVATE KEY-----')."
  echo "Re-download it from the demo site's API Keys page into Downloads and run this again."
  exit 1
fi
chmod 600 "$HOME/.kalshi/demo-key.pem"
echo "Stored at ~/.kalshi/demo-key.pem  ($(stat -c '%A' "$HOME/.kalshi/demo-key.pem"))"

# ---- 3. Key ID -> ~/.bashrc ------------------------------------------------------------------
if grep -q "KALSHI_API_KEY_ID" "$HOME/.bashrc" 2>/dev/null; then
  say "Kalshi settings already in ~/.bashrc (leaving them as they are)"
else
  echo
  read -rp "Paste your demo Key ID (the UUID shown on the API Keys page), then press Enter: " KID
  KID=$(printf "%s" "$KID" | tr -d '[:space:]')
  [ -n "$KID" ] || { echo "No Key ID entered."; exit 1; }
  if ! [[ "$KID" =~ ^[0-9a-fA-F-]{36}$ ]]; then
    echo "Note: that doesn't look like a standard UUID. Continuing; auth will tell us if it's wrong."
  fi
  cat >> "$HOME/.bashrc" <<EOF

# Kalshi DEMO key for aicrypto-lab (read-only market data; key lives outside the repo)
export KALSHI_ENV=demo
export KALSHI_API_KEY_ID="$KID"
export KALSHI_PRIVATE_KEY_PATH="\$HOME/.kalshi/demo-key.pem"
EOF
  say "Saved Key ID and key path to ~/.bashrc"
fi
export KALSHI_ENV=demo
export KALSHI_API_KEY_ID="$(grep -oP 'KALSHI_API_KEY_ID="\K[^"]+' "$HOME/.bashrc" | tail -1)"
export KALSHI_PRIVATE_KEY_PATH="$HOME/.kalshi/demo-key.pem"

# ---- 4. Project install ----------------------------------------------------------------------
if [ ! -f "$HOME/aicrypto-lab/aicrypto/kalshi/auth.py" ]; then
  ZIP=$(ls -t "$DL"/aicrypto-lab*.zip 2>/dev/null | head -1 || true)
  [ -n "$ZIP" ] || { echo "aicrypto-lab.zip not found in $DL. Download it from the chat and re-run."; exit 1; }
  command -v unzip >/dev/null || { sudo apt-get update -qq && sudo apt-get install -y unzip; }
  say "Unpacking $(basename "$ZIP") into ~/aicrypto-lab"
  unzip -q -o "$ZIP" -d "$HOME"
fi
cd "$HOME/aicrypto-lab"
if ! python3 -c 'import ensurepip' 2>/dev/null; then
  say "Installing python3-venv (sudo password may be asked)"
  sudo apt-get update -qq && sudo apt-get install -y python3-venv
fi
[ -d .venv ] || python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
say "Installing project dependencies (a minute or two the first time)"
pip install -q --upgrade pip
pip install -q -e ".[dev]"

# ---- 5. Checks -------------------------------------------------------------------------------
say "Safety check"
aicrypto safety-check
say "Auth check (prints key type only)"
aicrypto kalshi auth-check

# ---- 6. Tidy up the Windows copy of the key ----------------------------------------------------
if [ -n "$KEY_SRC" ] && [ -f "$KEY_SRC" ]; then
  echo
  read -rp "Delete the copy of the key in Windows Downloads now? [Y/n] " ans
  if [[ ! "$ans" =~ ^[Nn] ]]; then rm -f "$KEY_SRC" && echo "Deleted."; fi
fi

say "All set. In any NEW terminal, run:  cd ~/aicrypto-lab && source .venv/bin/activate"
echo "Next step (first real connection to the demo site):  aicrypto kalshi discover"
