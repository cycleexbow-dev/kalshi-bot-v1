#!/usr/bin/env bash
# Download public OHLCV candles with Freqtrade (inside Docker). No API keys needed.
# Usage: scripts/download_data.sh [DAYS] [TIMEFRAMES...]
set -euo pipefail
cd "$(dirname "$0")/.."
DAYS="${1:-1095}"; shift || true
TFS="${*:-15m 1h 4h}"
mkdir -p user_data/data user_data/logs user_data/strategies
# Ensure a (paper-only) config exists for the exchange section.
python3 -m aicrypto.cli safety-check >/dev/null 2>&1 || true
[ -f user_data/config_dryrun.json ] || python3 -m aicrypto.cli init-config
docker compose run --rm --no-deps freqtrade download-data \
  --config /freqtrade/user_data/config_dryrun.json \
  --pairs BTC/USDT ETH/USDT SOL/USDT \
  --timeframes $TFS \
  --days "$DAYS" \
  --data-format-ohlcv feather \
  --erase
echo "Downloaded. Verifying integrity..."
python3 -m aicrypto.cli data-check
