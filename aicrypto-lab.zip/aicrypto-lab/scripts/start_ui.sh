#!/usr/bin/env bash
# Start the AI Crypto Lab terminal backend (used by the Windows launcher; also fine by hand).
#   bash scripts/start_ui.sh [port]
# Binds 127.0.0.1 only. Read-only market data. Never starts trading or automation.
set -euo pipefail
cd "$(dirname "$0")/.."
PORT="${1:-8765}"
mkdir -p logs run

if [[ ! -x .venv/bin/aicrypto ]]; then
  echo "[start_ui] Python environment missing: run 'bash scripts/kalshi_demo_setup.sh' or see docs/WSL_SETUP.md" >&2
  exit 20
fi

# Demo credentials live in ~/.bashrc (written by scripts/kalshi_demo_setup.sh), but ~/.bashrc
# returns early for non-interactive shells. Pick up exactly the three KALSHI_* export lines.
if [[ -z "${KALSHI_API_KEY_ID:-}" && -f "$HOME/.bashrc" ]]; then
  eval "$(grep -E '^export KALSHI_(ENV|API_KEY_ID|PRIVATE_KEY_PATH)=' "$HOME/.bashrc" || true)"
fi

# rotate the log at ~5 MB
if [[ -f logs/ui.log && $(stat -c %s logs/ui.log) -gt 5000000 ]]; then
  mv -f logs/ui.log logs/ui.log.1
fi
echo "[start_ui] $(date -Is) starting on 127.0.0.1:${PORT}" >> logs/ui.log
exec .venv/bin/aicrypto ui --port "$PORT" >> logs/ui.log 2>&1
