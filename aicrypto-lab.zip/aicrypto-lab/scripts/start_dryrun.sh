#!/usr/bin/env bash
# Start the Freqtrade paper-trading bot. Refuses to start unless every config under
# user_data passes the safety check and the compose command carries --dry-run.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m aicrypto.cli safety-check
grep -q -- "--dry-run" docker-compose.yml || { echo "docker-compose.yml lost --dry-run; refusing to start"; exit 1; }
[ -f user_data/config_dryrun.json ] || { echo "no user_data/config_dryrun.json — run: aicrypto promote"; exit 1; }
docker compose up -d freqtrade dashboard
echo "Paper bot running. Dashboard: http://127.0.0.1:8080   Freqtrade API: http://127.0.0.1:8081"
echo "Logs: docker compose logs -f freqtrade"
