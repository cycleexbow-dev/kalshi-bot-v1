#!/usr/bin/env python3
"""Summarise the local Kalshi registry for review: tier counts by official category,
which series are tradeable/record-only, rejected financial-category series with reasons,
random market samples per tier (rules text, strikes, timestamps, mapped reference), and one
raw market + series payload. Contains public market metadata only; no credentials.
Writes kalshi_sample.json to Windows Downloads (WSL) or the current directory."""
import glob, json, os, random, sqlite3, sys

db_path = sys.argv[1] if len(sys.argv) > 1 else "user_data/kalshi/registry.sqlite"
db = sqlite3.connect(db_path); db.row_factory = sqlite3.Row
q = lambda sql, *a: [dict(r) for r in db.execute(sql, a)]
random.seed(7)
CUR = "FROM eligibility e JOIN markets m ON m.ticker=e.ticker LEFT JOIN series s ON s.ticker=m.series_ticker WHERE e.is_current=1"
FIN = "('Crypto','Financials','Commodities','Economics','Metals','Energy','Indices')"
out = {
    "counts": q(f"SELECT e.tier, COUNT(*) n {CUR} GROUP BY 1"),
    "series_categories": q("SELECT category, COUNT(*) n FROM series GROUP BY 1 ORDER BY n DESC"),
    "tier_by_category": q(f"SELECT s.category, e.tier, COUNT(*) n {CUR} GROUP BY 1,2 ORDER BY n DESC LIMIT 100"),
    "tradeable_series": q(f"SELECT m.series_ticker, m.asset, m.duration_bucket, m.structure, COUNT(*) n {CUR} AND e.tier='tradeable' GROUP BY 1,2,3,4 ORDER BY n DESC LIMIT 150"),
    "record_only_series": q(f"SELECT m.series_ticker, m.asset, m.duration_bucket, COUNT(*) n {CUR} AND e.tier='record_only' GROUP BY 1,2,3 ORDER BY n DESC LIMIT 100"),
    "rejected_financial_series": q(f"SELECT m.series_ticker, s.category, e.reasons, COUNT(*) n, MIN(m.ticker) example {CUR} AND e.tier='rejected' AND s.category IN {FIN} GROUP BY 1,2,3 ORDER BY n DESC LIMIT 150"),
    "undecided_series": q("SELECT series_ticker, COUNT(*) n FROM markets WHERE ticker NOT IN (SELECT ticker FROM eligibility WHERE is_current=1) GROUP BY 1 ORDER BY n DESC LIMIT 80"),
}
def sample(where, k):
    rows = q(f"SELECT m.ticker, m.series_ticker, s.category, s.tags, s.settlement_sources, m.status, m.strike_type, m.floor_strike, m.cap_strike, "
             f"m.open_time, m.close_time, m.duration_bucket, m.structure, m.asset, e.tier, e.reasons, e.notes, e.reference, m.raw {CUR} AND {where}")
    rows = random.sample(rows, min(k, len(rows)))
    for r in rows:
        raw = json.loads(r.pop("raw"))
        r["title"] = raw.get("title"); r["yes_sub_title"] = raw.get("yes_sub_title")
        r["rules_primary"] = (raw.get("rules_primary") or "")[:500]
    return rows
def one_per_series(where, limit=120):
    rows = q(f"SELECT m.series_ticker, s.category, s.frequency, s.settlement_sources, e.tier, e.reasons, e.notes, e.reference, "
             f"m.ticker, m.status, m.strike_type, m.floor_strike, m.cap_strike, m.open_time, m.close_time, m.raw {CUR} AND {where} "
             f"GROUP BY m.series_ticker ORDER BY COUNT(*) DESC LIMIT {limit}")
    for r in rows:
        raw = json.loads(r.pop("raw"))
        r["rules_primary"] = (raw.get("rules_primary") or "")[:400]; r["yes_sub_title"] = raw.get("yes_sub_title")
        r["title"] = raw.get("title")
    return rows
out["example_per_rejected_financial_series"] = one_per_series(f"e.tier='rejected' AND s.category IN {FIN}")
out["example_per_record_only_series"] = one_per_series("e.tier='record_only'", 80)
out["example_per_tradeable_series"] = one_per_series("e.tier='tradeable'", 200)
out["series_frequencies"] = q("SELECT frequency, COUNT(*) n FROM series GROUP BY 1 ORDER BY n DESC LIMIT 40")
out["sample_tradeable"] = sample("e.tier='tradeable'", 25)
out["sample_record_only"] = sample("e.tier='record_only'", 10)
out["sample_rejected_financial"] = sample(f"e.tier='rejected' AND s.category IN {FIN}", 25)
out["sample_rejected_other"] = sample(f"e.tier='rejected' AND (s.category NOT IN {FIN} OR s.category IS NULL)", 10)
r = q("SELECT raw FROM markets WHERE series_ticker LIKE 'KXBTC%' LIMIT 1") or q("SELECT raw FROM markets LIMIT 1")
out["raw_market_example"] = json.loads(r[0]["raw"]) if r else None
r = q("SELECT raw FROM series WHERE ticker LIKE 'KXBTC%' LIMIT 1") or q("SELECT raw FROM series LIMIT 1")
out["raw_series_example"] = json.loads(r[0]["raw"]) if r else None
try:
    out["schema_mismatches"] = q("SELECT kind, context, problems FROM schema_mismatches ORDER BY ts DESC LIMIT 50")
except sqlite3.OperationalError:
    out["schema_mismatches"] = []
dls = [d for d in glob.glob("/mnt/c/Users/*/Downloads") if not any(x in d for x in ("Public", "Default", "All Users"))]
dest = os.path.join(dls[0] if dls else ".", "kalshi_sample.json")
with open(dest, "w") as fh:
    json.dump(out, fh, indent=1, default=str)
print(f"wrote {dest} ({os.path.getsize(dest)//1024} KB)")
