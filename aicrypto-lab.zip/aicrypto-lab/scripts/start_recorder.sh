#!/usr/bin/env bash
# Start the read-only market-data recorder + production-price shadow engine in the background.
#   bash scripts/start_recorder.sh
# Reads public real-exchange market data (no account, no keys, no orders), the CF index from the demo
# WebSocket (demo key) and Coinbase/Kraken public feeds. It can never place an order.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs run
if [[ -f run/recorder.pid ]] && kill -0 "$(cat run/recorder.pid)" 2>/dev/null; then echo "already running"; exit 0; fi
if [[ -z "${KALSHI_API_KEY_ID:-}" && -f "$HOME/.bashrc" ]]; then
  eval "$(grep -E "^export KALSHI_(ENV|API_KEY_ID|PRIVATE_KEY_PATH)=" "$HOME/.bashrc" || true)"
fi
if [[ -f logs/recorder.log && $(stat -c %s logs/recorder.log) -gt 5000000 ]]; then mv -f logs/recorder.log logs/recorder.log.1; fi
echo "[start_recorder] $(date -Is)" >> logs/recorder.log
setsid nohup .venv/bin/python -m aicrypto.recorder >> logs/recorder.log 2>&1 < /dev/null &
echo "started"
