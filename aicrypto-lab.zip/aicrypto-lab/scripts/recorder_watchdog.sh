#!/usr/bin/env bash
# Recorder crash recovery (Phase B). Checks every 60 s:
#   * crashed: run/recorder.pid exists but that process is gone   -> start it again
#   * hung:    alive, but run/recorder_status.json not updated for 180 s -> stop, then start
# A deliberate stop (scripts/stop_recorder.sh, or SIGTERM) removes the pid file, so the watchdog leaves it stopped.
#   start:  setsid nohup bash scripts/recorder_watchdog.sh >/dev/null 2>&1 &
#   stop:   kill "$(cat run/recorder_watchdog.pid)"
# Every action is logged to logs/recorder_watchdog.log. It never touches the app, the bot or any order path.
set -uo pipefail
cd "$(dirname "$0")/.."
mkdir -p logs run
if [[ -f run/recorder_watchdog.pid ]] && kill -0 "$(cat run/recorder_watchdog.pid)" 2>/dev/null; then echo "watchdog already running"; exit 0; fi
echo $$ > run/recorder_watchdog.pid
trap 'rm -f run/recorder_watchdog.pid; exit 0' TERM INT
log() { echo "$(date -Is) $*" >> logs/recorder_watchdog.log; }
log "watchdog started (pid $$)"
while true; do
  sleep 60 & wait $!
  [[ -f run/recorder.pid ]] || continue                       # stopped on purpose (or never started): leave it
  PID="$(cat run/recorder.pid 2>/dev/null)"
  if ! [[ "$PID" =~ ^[0-9]+$ ]] || ! kill -0 "$PID" 2>/dev/null; then
    log "recorder pid $PID is gone (crash): restarting"
    rm -f run/recorder.pid
    bash scripts/start_recorder.sh >> logs/recorder_watchdog.log 2>&1
    sleep 120 & wait $!                                       # give it time to start before judging again
    continue
  fi
  if [[ -f run/recorder_status.json ]]; then
    AGE=$(( $(date +%s) - $(stat -c %Y run/recorder_status.json) ))
    if (( AGE > 180 )); then
      log "recorder status not updated for ${AGE}s (hung): restarting"
      bash scripts/stop_recorder.sh >> logs/recorder_watchdog.log 2>&1
      bash scripts/start_recorder.sh >> logs/recorder_watchdog.log 2>&1
      sleep 120 & wait $!
    fi
  fi
done
